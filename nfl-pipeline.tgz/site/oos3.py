import json, csv, collections, random, re
MASTER={11,22,33}
def red(n):
    while n>9 and n not in MASTER: n=sum(int(d) for d in str(n))
    return n
def lifep(b):
    y,m,d=b.split("-"); return red(red(int(m))+red(int(d))+red(sum(map(int,y))))
def norm(n):
    n=re.sub(r"[^a-z ]","",n.lower().replace("-"," "))
    return " ".join(w for w in n.split() if w not in {"jr","sr","ii","iii","iv","v"})
GM={}
for r in csv.DictReader(open("/home/runner/nfl/games/games.csv")):
    if r["home_score"] and r["away_score"] and r["home_score"]!=r["away_score"]:
        GM[r["game_id"]]={"d":r["gameday"],"s":int(r["season"]),
          "win":r["home_team"] if int(r["home_score"])>int(r["away_score"]) else r["away_team"]}
units=collections.defaultdict(dict)
for y in range(2013,2026):
    bd={}; nm={}
    for r in csv.DictReader(open(f"/home/runner/nfl/hist/roster_{y}.csv",encoding="utf-8")):
        if not r.get("birth_date"): continue
        if r.get("pfr_id"): bd[r["pfr_id"]]=r["birth_date"]
        nm[(norm(r["full_name"]),r["team"])]=r["birth_date"]; nm.setdefault(norm(r["full_name"]),r["birth_date"])
    for r in csv.DictReader(open(f"/home/runner/nfl/hist/snaps_{y}.csv",encoding="utf-8")):
        gid=r["game_id"]
        if gid not in GM: continue
        if sum(float(r[k] or 0) for k in ("offense_snaps","defense_snaps","st_snaps"))<=0: continue
        b=bd.get(r["pfr_player_id"]) or nm.get((norm(r["player"]),r["team"])) or nm.get(norm(r["player"]))
        if b: units[gid].setdefault(r["team"],[]).append(b)
good=[g for g,v in units.items() if len(v)==2 and all(len(x)>=20 for x in v.values())]
LP={}; DN={}
def lp(b):
    if b not in LP: LP[b]=lifep(b)
    return LP[b]
def dn(d):
    if d not in DN: DN[d]=lifep(d)
    return DN[d]
random.seed(13); N=20000
def run(gids,plp,dnum):
    w=n=0
    for gid in gids:
        if dn(GM[gid]["d"])!=dnum: continue
        sh={t:sum(1 for b in bl if lp(b)==plp)/len(bl) for t,bl in units[gid].items()}
        ts=list(sh)
        if sh[ts[0]]==sh[ts[1]]: continue
        more=ts[0] if sh[ts[0]]>sh[ts[1]] else ts[1]
        n+=1; w+=(GM[gid]["win"]==more)
    if not n: return 0,0,None
    dev=abs(w/n-0.5); ge=sum(1 for _ in range(N) if abs(sum(random.random()<0.5 for _ in range(n))/n-0.5)>=dev-1e-12)
    return w,n,(ge+1)/(N+1)
print("Life path 5 on date number 5, split by era:")
for lab,lo,hi in [("2013-2019",2013,2019),("2020-2025",2020,2025)]:
    g=[x for x in good if lo<=GM[x]["s"]<=hi]
    w,n,p=run(g,5,5); print(f"  {lab}: {w}-{n-w} = {w/n*100:.1f}%  p={p:.3f}  ({n} games)")
print()
print("Same pattern, every other date number (should be ~50% if 5-on-5 is special):")
tot=[0,0]
for d in [1,2,3,4,6,7,8,9,11]:
    w,n,p=run(good,5,d)
    if n>=60: print(f"  life path 5 on date number {d}: {w}-{n-w} = {w/n*100:.1f}% ({n} games)"); tot[0]+=w; tot[1]+=n
print(f"  pooled other date numbers: {tot[0]}-{tot[1]-tot[0]} = {tot[0]/tot[1]*100:.1f}%")
