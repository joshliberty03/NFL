"""Super Bowl I-LX: date numerology, franchise founding numbers, and tests against coin-flip outcomes."""
import json, random, sys, collections
MASTER = {11, 22, 33}
ORDER = [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 22, 33]
def red(n):
    while n > 9 and n not in MASTER: n = sum(int(d) for d in str(n))
    return n
def lifep(b):
    y, m, d = b.split("-"); return red(red(int(m)) + red(int(d)) + red(sum(map(int, y))))
def pday(b, date):
    _, bm, bd = b.split("-"); y, m, d = date.split("-")
    py = red(red(int(bm)) + red(int(bd)) + red(sum(map(int, y))))
    return red(red(py + red(int(m))) + red(int(d)))
FOUNDED = {
 "ARI": None, "ATL": "1965-06-30", "BAL": "1996-02-09", "BUF": "1959-10-28", "CAR": "1993-10-26",
 "CHI": "1920-09-17", "CIN": "1967-05-23", "CLE": "1944-06-04", "DAL": "1960-01-28", "DEN": "1959-08-14",
 "DET": None, "GB": "1919-08-11", "HOU": "1999-10-06", "IND": "1953-01-23", "JAX": "1993-11-30",
 "KC": "1959-08-14", "LA": "1937-02-12", "LAC": "1959-08-14", "LV": "1960-01-30", "MIA": "1965-08-16",
 "MIN": "1960-01-28", "NE": "1959-11-16", "NO": "1966-11-01", "NYG": "1925-08-01", "NYJ": "1959-08-14",
 "PHI": "1933-07-08", "PIT": "1933-07-08", "SEA": "1974-06-04", "SF": "1944-06-04", "TB": "1974-04-24",
 "TEN": "1959-08-14", "WAS": "1932-07-09",
}
# franchise codes for every name that has appeared in a Super Bowl
NAME = {"Green Bay Packers": "GB", "Kansas City Chiefs": "KC", "Oakland Raiders": "LV", "Los Angeles Raiders": "LV",
 "New York Jets": "NYJ", "Baltimore Colts": "IND", "Indianapolis Colts": "IND", "Minnesota Vikings": "MIN",
 "Dallas Cowboys": "DAL", "Miami Dolphins": "MIA", "Washington Redskins": "WAS", "Pittsburgh Steelers": "PIT",
 "Denver Broncos": "DEN", "Los Angeles Rams": "LA", "St. Louis Rams": "LA", "Philadelphia Eagles": "PHI",
 "San Francisco 49ers": "SF", "Cincinnati Bengals": "CIN", "Chicago Bears": "CHI", "New England Patriots": "NE",
 "New York Giants": "NYG", "Buffalo Bills": "BUF", "San Diego Chargers": "LAC", "Atlanta Falcons": "ATL",
 "Tennessee Titans": "TEN", "Baltimore Ravens": "BAL", "Tampa Bay Buccaneers": "TB", "Carolina Panthers": "CAR",
 "Seattle Seahawks": "SEA", "Arizona Cardinals": "ARI", "New Orleans Saints": "NO"}
src, hist, out = sys.argv[1:4]
sbs = []
for line in open(src):
    num, date, w, ws, l, ls = line.strip().split("|")
    W, L = NAME[w], NAME[l]
    sbs.append({"n": num, "d": date, "wn": w, "w": W, "ws": int(ws), "ln": l, "l": L, "ls": int(ls), "dn": lifep(date),
                "wlp": lifep(FOUNDED[W]) if FOUNDED[W] else None, "llp": lifep(FOUNDED[L]) if FOUNDED[L] else None,
                "wpd": pday(FOUNDED[W], date) if FOUNDED[W] else None, "lpd": pday(FOUNDED[L], date) if FOUNDED[L] else None})
print("super bowls:", len(sbs))
# cross-check against the nflverse game file (1999 season on)
H = json.load(open(hist))
nv = {g[3]: g for g in H["games"] if g[2] == "SB"}
bad = []
for s in sbs:
    g = nv.get(s["d"])
    if not g: continue
    win = g[4] if g[6] > g[7] else g[5]
    if win != s["w"] or max(g[6], g[7]) != s["ws"]: bad.append((s["n"], s["w"], win))
print("cross-checked with game file:", sum(1 for s in sbs if s["d"] in nv), "mismatches:", bad)

def stat(key_w, key_l, flips):
    w = n = 0
    for s, f in zip(sbs, flips):
        a, b = (s[key_l], s[key_w]) if f else (s[key_w], s[key_l])  # f=True swaps who won
        if a is None or b is None: continue
        am, bm = a == s["dn"], b == s["dn"]
        if am == bm: continue
        n += 1; w += am
    return w, n
random.seed(60)
SIMS = 20000
sims = [[random.random() < 0.5 for _ in sbs] for _ in range(SIMS)]
def test(kw, kl):
    w, n = stat(kw, kl, [False] * len(sbs))
    if not n: return {"wins": 0, "games": 0, "p": None}
    dev = abs(w / n - 0.5); ge = 0
    for s in sims:
        sw, sn = stat(kw, kl, s)
        if sn and abs(sw / sn - 0.5) >= dev - 1e-12: ge += 1
    return {"wins": w, "games": n, "p": (ge + 1) / (SIMS + 1)}
tests = {"pd_match": test("wpd", "lpd"), "lp_match": test("wlp", "llp")}
print(tests)
# winners' team personal day vs losers'
wpd = collections.Counter(s["wpd"] for s in sbs if s["wpd"]); lpd = collections.Counter(s["lpd"] for s in sbs if s["lpd"])
print("winner PDs", sorted(wpd.items())); print("loser PDs", sorted(lpd.items()))
print("date numbers", sorted(collections.Counter(s["dn"] for s in sbs).items()))
json.dump({"sbs": sbs, "tests": tests}, open(out, "w"), separators=(",", ":"))
