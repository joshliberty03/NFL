import json, csv, collections, statistics, sys, os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
Q=json.load(open("qb.json")); QB=Q["qbs"]
rec=collections.defaultdict(lambda:[0,0]); cur=collections.defaultdict(lambda:[0,0]); teams=collections.defaultdict(collections.Counter)
for r in csv.DictReader(open("/home/runner/nfl/games/games.csv")):
    if not r["home_score"] or r["home_score"]==r["away_score"]: continue
    for s,opp in (("home","away"),("away","home")):
        q=r[s+"_qb_id"]
        if q not in QB: continue
        won=int(r[s+"_score"])>int(r[opp+"_score"])
        rec[q][0]+=won; rec[q][1]+=1; teams[q][r[s+"_team"]]+=1
        if r["season"]=="2026": cur[q][0]+=won; cur[q][1]+=1
rows=[]
for q,v in QB.items():
    w,n=rec[q]
    rows.append({"name":v["name"],"legal":v["legal"] if v["legal"]!=v["name"] else "","birth":v["birth"],
      "lp":v["lp"],"bday":v["bday"],"expr":v["expr"],"soul":v["soul"],"pers":v["pers"],
      "exprC":v["expr_common"] if v["expr_common"]!=v["expr"] else None,
      "w":w,"l":n-w,"team":teams[q].most_common(1)[0][0] if teams[q] else "",
      "teams":len(teams[q]),"cur":cur[q][1]>0,"curw":cur[q][0],"curn":cur[q][1]})
rows.sort(key=lambda r:-r["w"]-r["l"])
# equal-weight per QB tables
eq={}
for f in ("lp","bday","expr","soul","pers"):
    by=collections.defaultdict(list)
    for r in rows:
        if r["w"]+r["l"]>=16 and r[f]: by[r[f]].append(r["w"]/(r["w"]+r["l"]))
    eq[f]=[{"v":v,"mean":statistics.mean(x),"nqb":len(x)} for v,x in sorted(by.items()) if len(x)>=8]
# start-weighted tables already in qb.json["tables"]
contrib={}
for f,v in (("lp",5),("bday",2),("expr",9),("expr",6)):
    qs=[r for r in rows if r[f]==v and r["w"]+r["l"]>=20]
    qs.sort(key=lambda r:-r["w"])
    tot=sum(r["w"]+r["l"] for r in rows if r[f]==v); win=sum(r["w"] for r in rows if r[f]==v)
    contrib[f"{f}{v}"]={"field":f,"v":v,"w":win,"n":tot,"top":[{"name":r["name"],"w":r["w"],"l":r["l"]} for r in qs[:6]]}
json.dump({"rows":rows,"match":Q["match"],"tables":Q["tables"],"eq":eq,"contrib":contrib,
  "n_games":Q["n_games"],"seasons":Q["seasons"],
  "perm":{"bday":0.061,"expr":0.298,"lp":0.937},
  "within":{"lp":[52.46,52.13,1420],"expr":[51.83,51.90,1424],"bday":[51.71,51.48,1400]}},
  open("qbpage.json","w"),separators=(",",":"))
print("qbs:",len(rows),"| active 2026:",sum(1 for r in rows if r["cur"]))
print("top:",[(r["name"],r["w"],r["l"]) for r in rows[:4]])
print("size",os.path.getsize("qbpage.json"))
