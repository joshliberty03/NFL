"""Same permutation tests, applied to sun signs and Chinese zodiac."""
import json, csv, random, collections, re
A=json.load(open("astro.json")); S=json.load(open("step2.json")); AP=json.load(open("appear.json"))
P=A["players"]; CO=A["coaches"]; TM=A["teams"]; DT=A["dates"]
AN=['Rat','Ox','Tiger','Rabbit','Dragon','Snake','Horse','Goat','Monkey','Rooster','Dog','Pig']
TRI={}
for grp in [('Rat','Dragon','Monkey'),('Ox','Snake','Rooster'),('Tiger','Horse','Dog'),('Rabbit','Goat','Pig')]:
    for a in grp: TRI[a]=set(grp)
OPP={a:AN[(AN.index(a)+6)%12] for a in AN}
GEN={'Wood':'Fire','Fire':'Earth','Earth':'Metal','Metal':'Water','Water':'Wood'}
CTRL={'Wood':'Earth','Earth':'Water','Water':'Fire','Fire':'Metal','Metal':'Wood'}
# player index -> fields: 6 sign, 7 animal, 8 yelem, 9 selem, 10 mode
games=[g for g in S["games"] if g["played"] and g["winner"]!="TIE"]
gi={g["game_id"]:i for i,g in enumerate(games)}
# who played: appear.json indexes games in the same played-order
AG=AP["g"]; apidx={AG[i][0]:i for i in range(len(AG))}
roster=collections.defaultdict(list)   # (gameIdx, team) -> [player idx]
for pid,lst in AP["a"].items():
    for gidx,team in lst:
        gid=AG[gidx][0]
        if gid in gi: roster[(gi[gid],team)].append(int(pid))
TG=[]
for i,g in enumerate(games):
    d=DT[g["date"]]; h,a=g["home"],g["away"]
    if (i,h) not in roster or (i,a) not in roster: continue
    side={}
    for s,t in (("home",h),("away",a)):
        ps=roster[(i,t)]
        side[s]={"team":t,"ps":ps,
          "sign_share":sum(1 for j in ps if P[j][6]==d["sign"])/len(ps),
          "tri_share":sum(1 for j in ps if P[j][7] in TRI[d["danimal"]])/len(ps),
          "opp_share":sum(1 for j in ps if P[j][7]==OPP[d["danimal"]])/len(ps),
          "gen_share":sum(1 for j in ps if GEN.get(P[j][8])==d["delem"])/len(ps),
          "coach_sign":CO[t]["sign"],"coach_animal":CO[t]["animal"],
          "team_sign":TM[t]["sign"] if TM[t] else None,"team_animal":TM[t]["animal"] if TM[t] else None,
          "coach_tri":CO[t]["animal"] in TRI[d["danimal"]],
          "team_tri":(TM[t]["animal"] in TRI[d["danimal"]]) if TM[t] else None}
    TG.append((d,side["home"],side["away"],g["winner"]==h))
print("games:",len(TG),"player-appearances:",sum(len(s["ps"]) for _,h,a,_ in TG for s in (h,a)))
actual=[x[3] for x in TG]; random.seed(77); N=10000
sims=[[random.random()<0.5 for _ in TG] for _ in range(N)]
def share_stat(key,outcomes):
    w=n=0
    for (d,h,a,_),hw in zip(TG,outcomes):
        if h[key]==a[key]: continue
        n+=1; w+=(hw if h[key]>a[key] else not hw)
    return w,n
def bool_stat(key,outcomes):
    w=n=0
    for (d,h,a,_),hw in zip(TG,outcomes):
        if h[key] is None or a[key] is None or h[key]==a[key]: continue
        n+=1; w+=(hw if h[key] else not hw)
    return w,n
def match_stat(key,field,outcomes):
    w=n=0
    for (d,h,a,_),hw in zip(TG,outcomes):
        hm,am=h[key]==d[field],a[key]==d[field]
        if hm==am: continue
        n+=1; w+=(hw if hm else not hw)
    return w,n
def pval(fn,*args):
    w,n=fn(*args,actual)
    if not n: return {"wins":0,"games":0,"rate":None,"p":None}
    dev=abs(w/n-0.5); ge=0
    for s in sims:
        sw,sn=fn(*args,s)
        if sn and abs(sw/sn-0.5)>=dev-1e-12: ge+=1
    return {"wins":w,"games":n,"rate":w/n,"p":(ge+1)/(N+1)}
tests={
 "roster_sun_sign":pval(share_stat,"sign_share"),
 "roster_day_trine":pval(share_stat,"tri_share"),
 "roster_day_clash":pval(share_stat,"opp_share"),
 "roster_elem_generating":pval(share_stat,"gen_share"),
 "coach_sign_is_date_sign":pval(match_stat,"coach_sign","sign"),
 "coach_animal_trine_day":pval(bool_stat,"coach_tri"),
 "team_animal_trine_day":pval(bool_stat,"team_tri"),
 "team_sign_is_date_sign":pval(match_stat,"team_sign","sign"),
}
for k,v in tests.items(): print(k,v)
# grids: player sun sign x date sun sign, player animal x day animal
def grid(keyP,keyD,outcomes):
    win=collections.Counter(); tot=collections.Counter()
    for (d,h,a,_),hw in zip(TG,outcomes):
        for s,won in ((h,hw),(a,not hw)):
            for j in s["ps"]:
                k=(P[j][keyP],d[keyD]); tot[k]+=1; win[k]+=won
    return win,tot
def grid_out(keyP,keyD,minN=40,SUB=3000):
    gw,gt=grid(keyP,keyD,actual)
    cells=[c for c in gt if gt[c]>=minN]; dev={c:abs(gw[c]/gt[c]-0.5) for c in cells}; ge=collections.Counter()
    for s in sims[:SUB]:
        sw,st=grid(keyP,keyD,s)
        for c in cells:
            if abs(sw[c]/st[c]-0.5)>=dev[c]-1e-12: ge[c]+=1
    rows=[]
    for c in sorted(gt):
        r={"a":c[0],"b":c[1],"wins":gw[c],"apps":gt[c],"rate":gw[c]/gt[c]}
        if c in cells: r["p"]=(ge[c]+1)/(SUB+1)
        rows.append(r)
    t=[r for r in rows if "p" in r]; sig=[r for r in t if r["p"]<0.05]
    print(f"grid {keyP}x{keyD}: tested {len(t)} p<.05 {len(sig)} expected {0.05*len(t):.1f}")
    for r in sorted(sig,key=lambda r:r["p"])[:6]: print("   ",r)
    return rows,{"tested":len(t),"sig":len(sig),"expected":0.05*len(t)}
sg,sgs=grid_out(6,"sign")
ag,ags=grid_out(7,"danimal")
eg,egs=grid_out(8,"delem")
json.dump({"tests":tests,"sign_grid":sg,"sign_sum":sgs,"animal_grid":ag,"animal_sum":ags,
           "elem_grid":eg,"elem_sum":egs,"n_games":len(TG)},open("astro_tests.json","w"),separators=(",",":"))
