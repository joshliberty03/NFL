import json, collections
MASTER={11,22,33}; ORDER=[1,2,3,4,5,6,7,8,9,11,22,33]
def red(n):
    while n>9 and n not in MASTER: n=sum(int(d) for d in str(n))
    return n
def lifep(b):
    y,m,d=b.split("-"); return red(red(int(m))+red(int(d))+red(sum(map(int,y))))
def pday(b,date):
    _,bm,bd=b.split("-"); y,m,d=date.split("-")
    py=red(red(int(bm))+red(int(bd))+red(sum(map(int,y))))
    return red(red(py+red(int(m)))+red(int(d)))
FOUNDED=json.load(open("founded.json")); H=json.load(open("history.json")); S=json.load(open("step2.json"))
COACH={c["team"]:c for c in S["coaches"]}
G=[g for g in H["games"] if g[6]!=g[7]]
# train on everything through the 2025 season plus 2026 games already played
train=[g for g in G if g[0]<=2025]
cur=[g for g in G if g[0]==2026]
def rates(games):
    dn=collections.defaultdict(lambda:[0,0]); pd=collections.defaultdict(lambda:[0,0]); tm=collections.defaultdict(lambda:[0,0])
    for g in games:
        for t,s,o,p in ((g[4],g[6],g[7],g[11]),(g[5],g[7],g[6],g[12])):
            w=1 if s>o else 0
            tm[t][0]+=w; tm[t][1]+=1
            dn[(t,g[10])][0]+=w; dn[(t,g[10])][1]+=1
            if p is not None: pd[(t,p)][0]+=w; pd[(t,p)][1]+=1
    return dn,pd,tm
def shrunk(c,b,k): w,n=c; return (w+k*b)/(n+k)
dnR,pdR,tmR=rates(train); base=sum(1 for g in train if g[6]>g[7])/len(train)
# 2026 form, blended with long-run team rate
cur26=collections.defaultdict(lambda:[0,0])
for g in cur:
    for t,s,o in ((g[4],g[6],g[7]),(g[5],g[7],g[6])): cur26[t][0]+= s>o; cur26[t][1]+=1
def strength(t):
    longrun=shrunk(tmR[t],base,10); form=shrunk(cur26[t],longrun,4)
    return 0.45*longrun+0.55*form
def numer(t,date):
    dn=lifep(date); p=pday(FOUNDED[t],date) if FOUNDED[t] else None
    tb=shrunk(tmR[t],base,10)
    a=shrunk(dnR[(t,dn)],tb,25)-tb
    b=(shrunk(pdR[(t,p)],tb,25)-tb) if p is not None else 0.0
    return {"score":(a+b)/2,"dnEdge":a,"pdEdge":b,"pd":p,"cpd":pday(COACH[t]["birth_date"],date)}
HOME=0.055
out=[]
for g in S["games"]:
    if g["played"]: continue
    h,a,date=g["home"],g["away"],g["date"]
    nh,na=numer(h,date),numer(a,date)
    sh,sa=strength(h)+HOME,strength(a)
    nPick=h if nh["score"]>na["score"] else a if na["score"]>nh["score"] else ""
    bPick=h if sh>sa else a if sa>sh else ""
    out.append({"id":g["game_id"],"wk":int(g["week"]),"date":date,"home":h,"away":a,"dn":g["universal_day"],
      "nPick":nPick,"nEdge":round(abs(nh["score"]-na["score"]),4),
      "bPick":bPick,"bConf":round(abs(sh-sa),4),
      "agree":bool(nPick and nPick==bPick),
      "h":{"pd":nh["pd"],"cpd":nh["cpd"],"dnEdge":round(nh["dnEdge"],4),"pdEdge":round(nh["pdEdge"],4),"str":round(sh,4)},
      "a":{"pd":na["pd"],"cpd":na["cpd"],"dnEdge":round(na["dnEdge"],4),"pdEdge":round(na["pdEdge"],4),"str":round(sa,4)}})
# how both models would have done on the 81 games already played in 2026 (trained on pre-2026 only)
dn0,pd0,tm0=rates([g for g in G if g[0]<=2025]); base0=base
def numer0(t,date):
    dn=lifep(date); p=pday(FOUNDED[t],date) if FOUNDED[t] else None
    tb=shrunk(tm0[t],base0,10)
    a=shrunk(dn0[(t,dn)],tb,25)-tb
    b=(shrunk(pd0[(t,p)],tb,25)-tb) if p is not None else 0.0
    return (a+b)/2
sc={"numerology":[0,0],"baseline":[0,0],"home":[0,0]}
for g in cur:
    hw=g[6]>g[7]; h,a,date=g[4],g[5],g[3]
    nh,na=numer0(h,date),numer0(a,date)
    if nh!=na: sc["numerology"][0]+=(hw if nh>na else not hw); sc["numerology"][1]+=1
    sh=shrunk(tm0[h],base0,10)+HOME; sa=shrunk(tm0[a],base0,10)
    if sh!=sa: sc["baseline"][0]+=(hw if sh>sa else not hw); sc["baseline"][1]+=1
    sc["home"][0]+=hw; sc["home"][1]+=1
print("2026 so far (models trained only on 1999-2025):")
for k,(w,n) in sc.items(): print(f"  {k:11s} {w}/{n} = {w/n:.3f}")
bt=[{"test":"2013–2017","pure":0.496,"base":0.568,"home":0.574,"n":1331},
    {"test":"2018–2021","pure":0.514,"base":0.555,"home":0.534,"n":1083},
    {"test":"2022–2025","pure":0.510,"base":0.565,"home":0.554,"n":1136}]
json.dump({"games":out,"season_check":sc,"backtest":bt,"home_edge":HOME},open("forecast.json","w"),separators=(",",":"))
print("upcoming games:",len(out),"weeks",min(g['wk'] for g in out),"-",max(g['wk'] for g in out))
print("agree:",sum(1 for g in out if g["agree"]),"disagree:",sum(1 for g in out if g["nPick"] and not g["agree"]))
print("sample:",out[0])
