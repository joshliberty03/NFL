/* ===================== GRIDIRON SHOWDOWN (retro head-to-head football) ===================== */
window.__showdown=function(stage,api){
  const PX=4,VW=64,VH=26,CW=256,CH=208;
  const rnd=Math.random,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const TEAMS_=Object.keys(TEAMCOL).sort((a,b)=>TEAMCOL[a][2].localeCompare(TEAMCOL[b][2]));
  const LV={0:{n:'Rookie',m:.86,react:.55},1:{n:'Pro',m:.96,react:.25},2:{n:'All-Pro',m:1.05,react:0}};
  const QL={45:'Short (45s quarters)',90:'Normal (90s quarters)',150:'Long (150s quarters)'};
  const S0={rb:6.9,qb:5.6,wr:7.3,ol:4.6,te:6.6,dl:6.9,lb:7.2,cb:7.6,s:7.5};
  let G=null,cv,ctx,raf=0,last=0,acc=0,dead=false,ui={};
  const pad={dx:0,dy:0};
  const keys={},inp=[{dx:0,dy:0,a:false,b:false,c:false,d:false,e:false},{dx:0,dy:0,a:false,b:false,c:false,d:false,e:false}];
  const rec=()=>{try{return JSON.parse(localStorage.getItem('gm.sd.rec'))||{w:0,l:0,t:0}}catch(e){return{w:0,l:0,t:0}}};
  const saveRec=r=>{try{localStorage.setItem('gm.sd.rec',JSON.stringify(r))}catch(e){}};
  const tn=a=>TEAMCOL[a][2],tc=(a,i)=>TEAMCOL[a][i||0];
  function lum(h){const n=parseInt(h.slice(1),16);return ((n>>16&255)*.3+(n>>8&255)*.59+(n&255)*.11)}
  function cdist(h1,h2){const p=h=>{const n=parseInt(h.slice(1),16);return[n>>16&255,n>>8&255,n&255]},x=p(h1),y=p(h2);return Math.hypot(x[0]-y[0],x[1]-y[1],x[2]-y[2])}
  function fixCols(a,b){ // the two teams must always wear clearly opposite colours
    const ca=tc(a);let cb=tc(b);
    if(cdist(ca,cb)<170){const alt=tc(b,1);cb=cdist(ca,alt)>=170?alt:(lum(ca)>130?'#15171d':'#f4f4f6')}
    return[ca,cb]}

  /* ------------------------------ setup UI ------------------------------ */
  stage.innerHTML=`<div class="sd">
    <div class="sdmenu" id="sdmenu"></div>
    <div class="sdgame" id="sdgame" hidden>
      <div class="sdscore" id="sdscore" aria-live="polite"></div>
      <div class="sdwrap" id="sdwrap"><canvas id="sdcv" width="${CW}" height="${CH}" aria-label="Football field"></canvas><div class="sdover" id="sdover" hidden></div>
        <div class="sdjoy" id="sdjoy" hidden><i></i></div>
        <div class="sdhint" id="sdhint" hidden></div>
        <div class="sdpad" id="sdpad"><div class="abtns"><button data-b="e" id="sdbtnE">BOOST</button><button data-b="d" id="sdbtnD">STRIP</button><button data-b="c" id="sdbtnC">TRUCK</button><button data-b="b" id="sdbtnB">STIFF-ARM</button><button data-b="a" id="sdbtnA">SPIN</button></div></div>
        <div class="sdplays" id="sdplays"></div></div>
      <div class="sdtools"><button class="btn" type="button" id="sdsim">Sim rest of game</button><button class="btn" type="button" id="sdmute"></button><button class="btn" type="button" id="sdcam"></button></div>
      <p class="note" id="sdhelp"></p>
    </div></div>`;
  cv=stage.querySelector('#sdcv');ctx=cv.getContext('2d');ctx.imageSmoothingEnabled=false;
  ['sdmenu','sdgame','sdscore','sdover','sdplays','sdhelp','sdwrap'].forEach(i=>ui[i]=stage.querySelector('#'+i));

  /* ------------------------------ season mode ------------------------------ */
  const SK='gm.sd.season';
  const sget=()=>{try{const v=JSON.parse(localStorage.getItem(SK));return v&&v.team&&TEAMCOL[v.team]?v:null}catch(e){return null}};
  const sset=v=>{try{if(v)localStorage.setItem(SK,JSON.stringify(v));else localStorage.removeItem(SK)}catch(e){}};
  const toS=x=>x==='LAR'?'LA':x,toC=x=>x==='LA'?'LAR':x;
  const sched=t=>{t=toS(t);return SEA.filter(g=>g.h===t||g.a===t).sort((a,b)=>a.wk-b.wk)};
  function srec(S){let w=0,l=0,t=0;Object.values(S.res).forEach(r=>{if(r.us>r.them)w++;else if(r.us<r.them)l++;else t++});return{w,l,t}}
  const srecTxt=S=>{const r=srec(S);return r.w+'-'+r.l+(r.t?'-'+r.t:'')};
  function beginSeason(team){sset({team,lvl:+stage.querySelector('#ssl').value,qlen:+stage.querySelector('#ssq').value,res:{}});showSeason()}
  function simScore(t,o,home){
    const R=RK['2026'],lg=Object.values(R).reduce((a,x)=>a+x.ppg,0)/Object.keys(R).length;
    const m=lg*Math.pow(R[t].ppg/lg,.9)*Math.pow(R[o].papg/lg,.9)*(home?1.03:.97);
    const g=()=>{let u=0,v=0;while(!u)u=Math.random();while(!v)v=Math.random();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)};
    return Math.max(0,Math.round(m+g()*8));
  }
  function simGameRes(S,g){
    const us=toS(S.team),home=g.h===us,opp=home?g.a:g.h;let a=simScore(us,opp,home),b=simScore(opp,us,!home);
    if(a===b){if(Math.random()<.5)a+=3;else b+=3}
    S.res[g.id]={us:a,them:b,sim:1};
  }
  function showSeason(){
    const S=sget();if(!S){showMenu();return}
    if(G){G=null}
    ui.sdgame.hidden=true;ui.sdmenu.hidden=false;
    const T=S.team,Ts=toS(T),gs=sched(T),done=gs.filter(g=>S.res[g.id]),next=gs.find(g=>!S.res[g.id]),r=srec(S);
    const wkAll=gs.map(g=>g.wk),maxW=Math.max(...wkAll),minW=1;
    const rows=[];for(let w=minW;w<=maxW;w++){
      const g=gs.find(x=>x.wk===w);
      if(!g){rows.push(`<tr class="sbye"><td>${w}</td><td colspan="2">BYE WEEK</td><td></td></tr>`);continue}
      const home=g.h===Ts,opp=home?g.a:g.h,x=S.res[g.id];
      const res=x?`<b class="${x.us>x.them?'w':x.us<x.them?'l':''}">${x.us>x.them?'W':x.us<x.them?'L':'T'} ${x.us}-${x.them}</b>${x.sim?' <span class="st">sim</span>':''}`:(next&&next.id===g.id?'<span class="st">up next</span>':'');
      rows.push(`<tr${next&&next.id===g.id?' class="snext"':''}><td>${w}</td><td>${tlogo(opp,18)} ${home?'vs':'at'} <b>${esc(tn(toC(opp)))}</b></td><td>${res}</td><td>${home?'Home':'Away'}</td></tr>`)}
    const pct=done.length?Math.round((r.w+r.t/2)/done.length*100):0;
    const L=S.lvl;
    ui.sdmenu.innerHTML=`<div class="card sdcard"><div class="teamhead"><h2>${tlogo(Ts,30)} ${esc(tn(T))} season</h2><span class="count">${LV[L].n} · ${QL[S.qlen]||''}</span></div>
      <div class="pkstats"><div class="pkstat"><b>${r.w}-${r.l}${r.t?'-'+r.t:''}</b><span>Season record</span></div><div class="pkstat"><b>${done.length?pct+'%':'-'}</b><span>Win %</span></div><div class="pkstat"><b>${done.length}/${gs.length}</b><span>Games played</span></div></div>
      ${next?`<div class="sdnext"><span class="st">Week ${next.wk}</span><b>${tlogo(Ts,22)} ${tn(T)} ${next.h===Ts?'vs':'at'} ${tlogo(next.h===Ts?next.a:next.h,22)} ${esc(tn(toC(next.h===Ts?next.a:next.h)))}</b>
        <div class="filters"><button class="btn solid" type="button" id="ssplay">Play week ${next.wk}</button><button class="btn" type="button" id="sssim">Sim this game</button><button class="btn" type="button" id="sssimall">Sim rest of season</button></div></div>`
        :`<div class="sdnext"><b>Season complete: ${r.w}-${r.l}${r.t?'-'+r.t:''}</b><span class="note">${r.w>=12?'A dominant year.':r.w>=9?'A winning season.':r.w>=7?'Right around .500.':'A rough one. Run it back.'}</span></div>`}
      <div class="tablebox"><table class="sttbl"><thead><tr><th>Wk</th><th>Opponent</th><th>Result</th><th></th></tr></thead><tbody>${rows.join('')}</tbody></table></div>
      <div class="filters"><button class="btn" type="button" id="ssback">Back to menu</button><button class="btn" type="button" id="ssreset">Reset season</button></div>
      <p class="note">Matchups and order follow the real 2026 NFL schedule for ${esc(tn(T))}. Results here are your own and do not change the real standings.</p></div>`;
    const q=id=>ui.sdmenu.querySelector('#'+id);
    if(next){
      q('ssplay').onclick=()=>{const home=next.h===Ts,opp=home?next.a:next.h;newGame(T,toC(opp),1,S.lvl,S.qlen);G.season={id:next.id,home}};
      q('sssim').onclick=()=>{simGameRes(S,next);sset(S);showSeason()};
      q('sssimall').onclick=()=>{gs.filter(g=>!S.res[g.id]).forEach(g=>simGameRes(S,g));sset(S);showSeason()};
    }
    q('ssback').onclick=showMenu;
    let armed=false;q('ssreset').onclick=()=>{if(!armed){armed=true;q('ssreset').textContent='Press again to erase this season';setTimeout(()=>{armed=false;if(q('ssreset'))q('ssreset').textContent='Reset season'},4000);return}sset(null);showMenu()};
  }

  function showMenu(){
    const SS=sget(),r=rec(),opts=TEAMS_.map(a=>`<option value="${a}">${NAMES[a]||a}</option>`).join('');
    ui.sdgame.hidden=true;ui.sdmenu.hidden=false;
    ui.sdmenu.innerHTML=`<div class="card sdcard"><h2>Gridiron Showdown</h2>
      <p class="sub">Retro head-to-head football. Pick a play, then run, throw and tackle in real time. Beat the CPU or hand the keyboard to a friend.</p>
      <div class="filters">
        <label for="sdt1">Your team<select id="sdt1">${opts}</select></label>
        <label for="sdt2">Opponent<select id="sdt2">${opts}</select></label>
        <label for="sdmode">Mode<select id="sdmode"><option value="1">1 player vs CPU</option><option value="2">2 players, one device</option><option value="0">Watch CPU vs CPU</option></select></label>
        <label for="sdlvl">CPU level<select id="sdlvl"><option value="0">Rookie</option><option value="1" selected>Pro</option><option value="2">All-Pro</option></select></label>
        <label for="sdlen">Game length<select id="sdlen">${Object.keys(QL).map(k=>`<option value="${k}"${k==90?' selected':''}>${QL[k]}</option>`).join('')}</select></label>
      </div>
      <div class="filters"><button class="btn solid" type="button" id="sdgo">Kick off</button></div>
      <p class="note">Your record vs the CPU: <b>${r.w}-${r.l}${r.t?'-'+r.t:''}</b></p>
      <p class="note"><b>Controls.</b> Move: WASD or arrow keys, or the on-screen pad. <b>Offense:</b> A (F/Space) throw or SPIN, B (G) STIFF-ARM, C (H) TRUCK. <b>Defense:</b> A dive, B (G) switch player, C (H) BIG HIT, D (J) STRIP. Power moves drain a shared power bar that refills over time. BOOST (E key) is a short sprint with its own thin cyan bar under the power bar; use it on offense or to chase down a runner. Tackles now need a wrap-up, so use moves to break free. 2 players: P1 WASD + F/G/H/J, P2 arrows + K/L/;/'. Hotkeys 1-6 pick plays.</p></div>
    <div class="card sdcard" id="sdseasoncard"><h2>Season mode</h2>
      <p class="sub">Pick your team and play its real 2026 schedule, week by week, against the same opponents the NFL lined up. Your win-loss record is saved on this device.</p>
      <div class="filters"><label for="sst">Your team<select id="sst">${opts}</select></label>
        <label for="ssl">CPU level<select id="ssl"><option value="0">Rookie</option><option value="1" selected>Pro</option><option value="2">All-Pro</option></select></label>
        <label for="ssq">Game length<select id="ssq">${Object.keys(QL).map(k=>`<option value="${k}"${k==45?' selected':''}>${QL[k]}</option>`).join('')}</select></label></div>
      <div class="filters"><button class="btn solid" type="button" id="ssgo">${SS?'Continue season ('+tn(SS.team)+' '+srecTxt(SS)+')':'Start season'}</button>${SS?'<button class="btn" type="button" id="ssnew">New season with these picks</button>':''}</div>
    </div>`;
    const SS2=SS;
    const t1=stage.querySelector('#sdt1'),t2=stage.querySelector('#sdt2');t1.value=TEAMS_[0];t2.value=TEAMS_[Math.floor(TEAMS_.length/2)];
    {const st=stage.querySelector('#sst');st.value=(SS&&SS.team)||(TI&&TEAMS_.includes('KC')?'KC':TEAMS_[0]);
      stage.querySelector('#ssgo').onclick=()=>{if(SS){showSeason();return}beginSeason(st.value)};
      const nb=stage.querySelector('#ssnew');if(nb)nb.onclick=()=>beginSeason(st.value)}
    stage.querySelector('#sdgo').onclick=()=>newGame(t1.value,t2.value===t1.value?TEAMS_.find(x=>x!==t1.value):t2.value,+stage.querySelector('#sdmode').value,+stage.querySelector('#sdlvl').value,+stage.querySelector('#sdlen').value);
  }

  /* ------------------------------ game state ------------------------------ */
  function newGame(a,b,mode,lvl,qlen){
    const cols=fixCols(a,b);
    G={teams:[a,b],col:[[cols[0],tc(a,1)],[cols[1],tc(b,1)]],mode,lvl,qlen,score:[0,0],q:1,clock:qlen,off:mode===1?0:(rnd()<.5?0:1),startOff:0,los:25,lineToGain:35,down:1,
       phase:'select',ents:[],O:[],D:[],ball:{holder:null,air:false,x:32,y:25},play:null,t:0,thrown:false,msg:'',ot:false,done:false,cam:25,ctrlD:null,target:0,since:0,om:mode,fast:false,pm:[1,1],bs:[1,1],fx:[],dcall:'base',pat:false,twoPt:false,shake:0,stats:{plays:0,yds:[0,0],pa:[0,0],pc:[0,0],pyd:[0,0],ra:[0,0],ryd:[0,0],fd:[0,0],to:[0,0],sk:[0,0],pen:[[0,0],[0,0]],long:[0,0]}};
    G.startOff=G.off;
    ui.sdmenu.hidden=true;ui.sdgame.hidden=false;showSimBtn();ui.sdover.hidden=true;ui.sdover.className='sdover';
    const touch=('ontouchstart' in window)||navigator.maxTouchPoints>0;ui.sdhelp.textContent=mode===2?'P1: WASD, F/G/H/J.  P2: arrows, K/L/;/\'.':touch?'Drag on the field to move. Tap a receiver to throw. Use the round buttons for boost, spin, stiff-arm, truck, dive, hit, strip and switch. Tap a pass play once to preview its routes, tap again to snap.':'Move: WASD or arrows. Offense: F spin, G stiff-arm, H truck, E boost. Defense: F dive, G switch, H hit, J strip, E boost. Keys 1-9 and 0 pick plays; Enter hikes.';
    try{window.focus();ui.sdgame.scrollIntoView({block:'start'})}catch(er){}
    stage.querySelector('#sdpad').style.display=mode===2?'none':'';stage.querySelector('#sdjoy').hidden=true;
    setupPlay();goSelect();
    if(!raf){last=0;raf=requestAnimationFrame(loop)}
  }
  const human=t=>G.mode===2||(G.mode===1&&t===0);
  const pick=a=>{let r=rnd()*a.reduce((s,x)=>s+x[1],0);for(const x of a){if((r-=x[1])<=0)return x[0]}return a[0][0]};
  const PLAYORD=['run1','run2','run3','pass1','pass3','pass4','pass2','pass5'];
  const PLAYN={run1:'Run inside',run2:'Run outside',run3:'Draw',pass1:'Short pass',pass3:'Quick slants',pass4:'Play action',pass2:'Deep pass',pass5:'Screen'};
  const DCALLS=[['base','Base'],['blitz','Blitz'],['man','Man'],['prevent','Prevent'],['box','Run stop']];
  /* ---- sound (synthesised, no files) ---- */
  let AC=null,snd=(()=>{try{return localStorage.getItem('gm.sd.snd')!=='0'}catch(e){return true}})();
  function ac(){if(!snd)return null;if(!AC){try{AC=new(window.AudioContext||window.webkitAudioContext)()}catch(e){snd=false;return null}}try{if(AC.state==='suspended')AC.resume()}catch(e){}return AC}
  function noiseBuf(a){if(!a._nb){const n=a.sampleRate*1.8,b=a.createBuffer(1,n,a.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;a._nb=b}return a._nb}
  function nz(a,t,dur,f0,f1,vol,type,swell){const s=a.createBufferSource();s.buffer=noiseBuf(a);const f=a.createBiquadFilter();f.type=type||'bandpass';f.frequency.setValueAtTime(f0,t);f.frequency.exponentialRampToValueAtTime(Math.max(30,f1),t+dur);const g=a.createGain();
    if(swell){g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(vol,t+dur*.35);g.gain.exponentialRampToValueAtTime(.0001,t+dur)}else{g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.0001,t+dur)}
    s.connect(f);f.connect(g);g.connect(a.destination);s.start(t);s.stop(t+dur+.05)}
  function tn_(a,t,dur,f0,f1,vol,type){const o=a.createOscillator(),g=a.createGain();o.type=type||'sine';o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+dur);g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.0001,t+dur);o.connect(g);g.connect(a.destination);o.start(t);o.stop(t+dur+.05)}
  function sfx(n){
    if(!snd||(G&&G.fast))return;const a=ac();if(!a)return;const t=a.currentTime;
    try{switch(n){
      case'snap':tn_(a,t,.14,110,55,.35);nz(a,t,.1,900,300,.12);break;
      case'throw':nz(a,t,.22,700,2600,.16);break;
      case'catch':nz(a,t,.08,1800,900,.25);tn_(a,t,.08,260,140,.18);break;
      case'hit':nz(a,t,.2,500,120,.55,'lowpass');tn_(a,t,.16,90,40,.4);break;
      case'boost':nz(a,t,.25,600,3500,.1,'highpass');break;
      case'kick':tn_(a,t,.12,180,60,.4);nz(a,t,.12,1200,300,.2);break;
      case'whistle':[0,.2].forEach(d=>{const o=a.createOscillator(),g=a.createGain(),l=a.createOscillator(),lg=a.createGain();o.type='square';o.frequency.value=2900;l.frequency.value=38;lg.gain.value=140;l.connect(lg);lg.connect(o.frequency);g.gain.setValueAtTime(.0001,t+d);g.gain.exponentialRampToValueAtTime(.05,t+d+.02);g.gain.exponentialRampToValueAtTime(.0001,t+d+.17);o.connect(g);g.connect(a.destination);o.start(t+d);l.start(t+d);o.stop(t+d+.2);l.stop(t+d+.2)});break;
      case'flag':[0,.12,.24].forEach(d=>tn_(a,t+d,.1,880,880,.12,'triangle'));break;
      case'roar':nz(a,t,1.7,500,900,.3,'bandpass',true);nz(a,t,1.7,1500,1800,.1,'bandpass',true);break;
      case'groan':nz(a,t,.9,400,200,.18,'bandpass',true);break}}catch(e){}
  }
  const offT=()=>G.off,defT=()=>1-G.off;

  function mk(role,team,x,y,side){return{role,team,x,y,vx:0,vy:0,sx:x,sy:y,stun:0,eng:false,engT:0,hold:0,free:false,jt:0,jcd:0,dive:0,boostT:0,wrapT:0,truckT:0,touch:false,hit:false,route:null,ri:0,spd:S0[role],ph:rnd()*6}}
  function setupPlay(){
    const L=G.los,o=G.off,d=1-o,E=[],O=[],D=[];
    const add=(arr,e)=>{E.push(e);arr.push(e);return e};
    const q=add(O,mk('qb',o,32,L-3)),rb=add(O,mk('rb',o,32,L-6.5)),te=add(O,mk('te',o,39,L-.7));
    const w1=add(O,mk('wr',o,6,L-.8)),w2=add(O,mk('wr',o,58,L-.8)),w3=add(O,mk('wr',o,20,L-1.8));
    [30.6,33.4].forEach(x=>add(O,mk('ol',o,x,L-.7)));
    [29.2,32,34.8].forEach(x=>add(D,mk('dl',d,x,L+.9)));
    [21,43].forEach(x=>add(D,mk('lb',d,x,L+4.3)));
    [6,58].forEach(x=>add(D,mk('cb',d,x,L+5)));
    [32].forEach(x=>add(D,mk('s',d,x,L+11)));
    G.O=O;G.D=D;G.ents=E;G.qb=q;G.rb=rb;G.te=te;G.wrs=[w1,w2,w3,te];G.ol=O.slice(6);G.dl=D.slice(0,3);G.lb=D.slice(3,5);G.cb=D.slice(5,7);G.sf=D.slice(7,8);
    G.rcv=[w1,w2,w3];G.kick=null;G.endCar=null;G.endTD=false;G.catchY=undefined;G.pm=[1,1];G.bs=[1,1];G.fx=[];G.ball={holder:q,air:false,x:q.x,y:q.y};G.thrown=false;G.t=0;G.target=0;G.ctrlD=null;G.since=0;
    D.forEach(e=>e.spd*=LV[G.lvl].m*1.17*(human(d)?1.02:1));
    G.cam=L+2;
  }
  function goSelect(){
    G.phase='select';G.preview=null;
    const ot=offT(),L=G.los,toGo=Math.max(1,Math.round(G.lineToGain-L));
    const down=['1st','2nd','3rd','4th'][G.down-1],spot=L<=50?'own '+L:'opp '+(100-L);
    G.msg=`${down} & ${G.lineToGain>=100?'Goal':toGo} at ${spot}`;
    renderScore();ui.sdover.hidden=true;
    const pl=ui.sdplays;
    if(G.pat&&!human(ot)){patKick();return}
    if(G.mode===0||(!human(ot)&&!human(1-ot))){setTimeout(()=>{if(!dead&&G&&G.phase==='select')snap(cpuCall())},60);pl.innerHTML='';return}
    if(G.pat&&human(ot)){goPAT();return}
    if(G.twoPt)G.msg='Two-point try from the 2';
    if(human(ot)){
      const inFG=100-L+17<=56&&!G.twoPt;
      pl.innerHTML=`<div class="sdcall"><b>${tn(G.teams[ot])} ball. Pick a play</b></div>
        <div class="sdbtns">${PLAYORD.map((p,i)=>`<button class="btn" data-pl="${p}">${i+1} ${PLAYN[p]}</button>`).join('')}${G.down===4&&!G.twoPt?`<button class="btn" data-pl="punt">9 Punt</button>${inFG?`<button class="btn" data-pl="fg">0 FG (${100-L+17} yd)</button>`:''}`:''}</div>`;
    }else{
      G.dcall=G.dcall||'base';
      pl.innerHTML=`<div class="sdcall"><b>${tn(G.teams[ot])} have the ball.</b> Call your defense, then hike. You control the highlighted player.</div><div class="sdbtns d5">${DCALLS.map((x,i)=>`<button class="btn${x[0]===G.dcall?' sel':''}" data-dc="${x[0]}">${i+1} ${x[1]}</button>`).join('')}<button class="btn solid hike" data-pl="auto">6 Hike!</button></div>`;
    }
  }
  function goPAT(){
    G.phase='select';G.pat=true;ui.sdover.hidden=true;G.msg='Point after touchdown';renderScore();
    ui.sdplays.innerHTML=`<div class="sdcall"><b>Touchdown, ${tn(G.teams[G.off])}!</b> Kick the extra point or go for two?</div><div class="sdbtns"><button class="btn solid" data-pt="1">Kick extra point (+1)</button><button class="btn" data-pt="2">Go for two (+2)</button></div>`;
  }
  function patKick(){const o=G.off,ok=rnd()<.96;G.pat=false;if(ok)G.score[o]+=1;afterScore(o,ok?'EXTRA POINT GOOD':'EXTRA POINT MISSED',ok?'+1':'No good');sfx(ok?'kick':'groan')}
  function patGo(){G.pat=false;G.twoPt=true;G.los=98;G.down=1;G.lineToGain=100;setupPlay();goSelect()}
  function cpuCall(){
    const L=G.los,toGo=G.lineToGain-L,me=G.score[G.off]-G.score[1-G.off],late=G.q>=4&&G.clock<60;
    if(G.down===4){
      if(100-L+17<=50&&!(toGo<=1.5&&L>60&&me<0))return'fg';
      if(toGo<=2.5&&L>45&&(me<0||L>70))return rnd()<.5?'run1':'pass1';
      if(L<55)return 'punt';
      return rnd()<.5?'pass1':'run1';
    }
    let pPass=toGo>8?.7:toGo>4?.5:.3;if(late&&me<0)pPass=.85;if(late&&me>0)pPass=.15;
    if(rnd()<pPass){
      if(late&&me<0&&toGo>10)return pick([['pass2',.55],['pass4',.45]]);
      if(toGo>12)return pick([['pass2',.38],['pass4',.24],['pass1',.2],['pass5',.18]]);
      if(toGo>6)return pick([['pass1',.34],['pass3',.22],['pass4',.24],['pass2',.14],['pass5',.06]]);
      return pick([['pass3',.4],['pass1',.28],['pass4',.2],['pass5',.07],['pass2',.05]]);
    }
    return toGo<=3?pick([['run1',.55],['run2',.28],['run3',.17]]):pick([['run1',.38],['run2',.34],['run3',.28]]);
  }
  function cpuDefCall(){
    const L=G.los,toGo=G.lineToGain-L,me=G.score[1-G.off]-G.score[G.off],late=G.q>=4&&G.clock<75;
    if(G.lvl===0&&rnd()<.6)return'base';
    if(late&&me>0&&toGo>3)return'prevent';
    if(toGo<=2)return rnd()<.5?'box':'base';
    if(toGo>=9&&G.down>=2)return pick([['prevent',.3],['blitz',.2],['base',.35],['man',.15]]);
    if(G.down===3)return pick([['blitz',.3],['man',.25],['base',.45]]);
    return pick([['base',.5],['blitz',.15],['man',.17],['box',.18]]);
  }
  function snap(call){
    if(G.phase!=='select'||G.pat)return;
    ui.sdplays.innerHTML='';
    if(call==='auto')call=cpuCall();
    if(call==='punt'||call==='fg')return kick(call);
    // pre-snap penalties
    if(!G.twoPt&&rnd()<.04){
      const offF=rnd()<.5,o=G.off,L=G.los;G.stats.plays+=0;
      if(offF){const nl=clamp(L-5,1,99);G.stats.pen[o][0]++;G.stats.pen[o][1]+=L-nl;G.los=nl;G.phase='banner';sfx('flag');return banner('FALSE START','Offense, 5 yards. Replay the down')}
      const nl=Math.min(99,L+5);G.stats.pen[1-o][0]++;G.stats.pen[1-o][1]+=nl-L;G.phase='banner';sfx('flag');
      if(nl>=G.lineToGain){G.stats.fd[o]++;G.down=1;G.los=nl;G.lineToGain=Math.min(100,nl+10);return banner('OFFSIDE','Defense, 5 yards. First down')}
      G.los=nl;return banner('OFFSIDE','Defense, 5 yards. Replay the down')}
    G.play=call;G.phase='live';G.t=0;G.thrown=false;G.since=0;G.catchY=undefined;sfx('snap');
    const o=G.off,d=1-o;
    if(G.mode!==2){const hu=human(G.off),isP=call.startsWith('pass');if(G.stats.plays<3||true)showHint(hu?(isP?'Drag to move. Tap a receiver to throw!':'Drag to run. A to juke!'):'You are on defense: drag to chase. A to dive!')}
    const rb=G.rb,q=G.qb;
    if(call.startsWith('run')){G.ball.holder=rb;rb.spd=S0.rb;if(call==='run2'){rb.route=[[rb.x>32?52:12,rb.y+1.2]]}}
    else{G.ball.holder=q;setRoutes(call)}
    G.hold=call==='run1'?1.4:call==='run2'?1.1:call==='run3'?1.7:call==='pass3'?.9+rnd()*.8:call==='pass5'?.5+rnd()*.3:call==='pass4'?1.6+rnd()*1.5:(1.5+rnd()*1.6);
    G.dcall=human(d)?(G.dcall||'base'):cpuDefCall();const dc=G.dcall;
    G.blitz=rnd()<.22;G.defKnow=G.lvl===2||rnd()<.5;
    if(dc==='blitz')G.blitz=true;else if(dc!=='base')G.blitz=false;
    if(dc==='box')G.defKnow=true;
    G.dl.forEach((x,i)=>{x.hold=G.hold*(.8+rnd()*.5)});G.dl[2].hold*=1.4;
    if(dc==='blitz')G.dl.forEach(x=>x.hold*=.78);if(dc==='prevent')G.dl.forEach(x=>x.hold*=1.3);
    G.lb.forEach(e=>{e.react=LV[G.lvl].react});G.D.forEach(e=>e.react=LV[G.lvl].react*(.6+rnd()*.8));
    if(dc==='prevent'||dc==='man')G.D.forEach(e=>{if(e.role!=='dl')e.react+=(dc==='prevent'?.22:.08)});
    if(dc==='box')G.D.forEach(e=>{if(e.role==='lb'||e.role==='s')e.spd*=1.06});
    G.cpuThrowAt=call==='pass3'?.8+rnd()*.5:call==='pass5'?1.5+rnd()*.5:call==='pass4'?1.8+rnd()*1.2:1.5+rnd()*1.4+(call==='pass2'?.7:0);
    if(dc!=='base'){const lab={blitz:'BLITZ!',man:'MAN COVERAGE',prevent:'PREVENT',box:'RUN STOP'}[dc];if(lab)fx(32,G.los+3,lab,'#ff8a5c')}
    if(call==='pass5')G.target=3;
    renderScore();
  }
  const ROUTES={
    pass2:[[[0,28]],[[0,14],[5,24]],[[0,9],[-6,19]],[[0,7],[2,12]]],
    pass1:[[[0,6.5],[.8,5.2]],[[0,2.5],[5,8.5]],[[0,4.5],[-3.5,5.2]],[[-4.5,1.2],[-8,2.2]]],
    pass3:[[[0,1.6],[5.6,6.4]],[[0,1.6],[5.6,6.4]],[[0,1.5],[6,3]],[[0,1.5],[-5,4.5]]],
    pass4:[[[0,18]],[[0,10],[5,19]],[[0,7],[-5.5,15]],[[0,5],[3,11]]]
  };
  function setRoutes(call){
    const scr=call==='pass5';
    G.wrs=G.rcv.concat([scr?G.rb:G.te]);
    G.wrs.forEach(w=>{w.blk=false;w.route=null;w.ri=0});
    if(scr){
      G.rcv.forEach(w=>{w.blk=true;w.route=[];w.r0=[w.x,w.y];w.spd=S0.wr});
      const rb=G.rb,sideX=(G.screenSide=G.screenSide||(rnd()<.5?12:52));
      rb.route=[[sideX,G.los-3.4],[sideX+(sideX<32?1:-1)*1.5,G.los-1.2]];rb.ri=0;rb.r0=[rb.x,rb.y];rb.spd=S0.wr;G.screenSide=0;return}
    const sp=ROUTES[call]||ROUTES.pass1;
    G.wrs.forEach((w,i)=>{const side=w.x<32?1:-1,pts=[];
      sp[i].forEach(([dx,dy])=>{pts.push([clamp(w.x+dx*side*(i===3?-1:1),1,63),w.y+dy])});w.route=pts;w.ri=0;w.r0=[w.x,w.y];w.spd=S0.wr});
  }

  /* ------------------------------ kicks ------------------------------ */
  const spotTxt=n=>n<=50?'own '+n:'opp '+(100-n);
  function kick(call){
    const L=G.los,o=G.off;G.phase='banner';let txt,sub='';sfx('kick');
    if(call==='fg'){const d=100-L+17,p=clamp(1.08-(d-18)*.0225,.05,.97),ok=rnd()<p,wide=rnd()<.5?-1:1;
      if(ok){G.score[o]+=3;txt='FIELD GOAL IS GOOD!';sub=`${d} yards. +3`;afterScore(o,txt,sub)}
      else{txt='NO GOOD';sub=`${d}-yard attempt missed`;turnover(Math.max(20,100-L),txt,sub)}
      // ball flight, drawn in the new offense's frame
      G.kick={x0:32,y0:100-(L-7),x1:64-(ok?32:32+wide*4.2),y1:-10,T:1.15,h:ok?10:8,t:0};return}
    const far=rnd()<.1?24+rnd()*8:36+rnd()*13,land=L+far,lx=32+(rnd()-.5)*8;txt='PUNT';
    if(land>=100){turnover(20,txt,'Touchback');G.kick={x0:32,y0:100-(L-7),x1:64-lx,y1:100-Math.min(land,106),T:1.3,h:15,t:0};return}
    const fair=rnd()<.38,ret=fair?0:Math.round(rnd()*rnd()*24),nl=clamp(Math.round(100-land)+ret,1,99);
    turnover(nl,txt,fair?`Fair catch at the ${spotTxt(nl)}`:ret?`Returned ${ret} yards to the ${spotTxt(nl)}`:`Downed at the ${spotTxt(nl)}`);
    G.kick={x0:32,y0:100-(L-7),x1:64-lx,y1:100-land,T:1.3,h:15,t:0};
  }
  function turnover(newLos,txt,sub){G.off=1-G.off;G.los=clamp(Math.round(newLos),1,99);G.down=1;G.lineToGain=Math.min(100,G.los+10);banner(txt,sub)}
  function afterScore(o,txt,sub){
    if(G.q>=5){G.done=true}
    const r=rnd(),ret=clamp(Math.round(14+rnd()*24+(rnd()<.1?20:0)),8,60),k=r<.55?{los:30,txt:'Touchback'}:{los:ret,txt:'Kickoff returned to the '+spotTxt(ret)};
    G.off=1-o;G.los=k.los;G.down=1;G.lineToGain=Math.min(100,k.los+10);banner(txt,(sub?sub+' \u00b7 ':'')+k.txt);
  }

  /* ------------------------------ play outcome ------------------------------ */
  function endPlay(res){
    if(G.phase!=='live')return;G.phase='banner';G.stats.plays++;
    const o=G.off,d=1-o,old=G.los,S=G.stats,isP=G.play.startsWith('pass'),caught=G.catchY!==undefined;
    G.endCar=G.ball.holder||null;G.endTD=res.type==='td';G.bt=0;
    // penalties that wipe out the play
    if(!G.twoPt){
      const gainP=res.type==='td'?100-old:(res.y===undefined?0:Math.round(res.y)-old);
      if((res.type==='tackle'||res.type==='td')&&gainP>=7&&rnd()<.055){S.plays--;S.pen[o][0]++;S.pen[o][1]+=10;G.los=clamp(old-10,1,99);sfx('flag');return banner(res.type==='td'?'TOUCHDOWN NULLIFIED':'HOLDING','Offense, 10 yards. Replay the down')}
      if(res.type==='inc'&&isP&&rnd()<.035){const nl=Math.min(99,old+5);S.pen[d][0]++;S.pen[d][1]+=nl-old;S.fd[o]++;G.down=1;G.los=nl;G.lineToGain=Math.min(100,nl+10);sfx('flag');return banner('DEFENSIVE HOLDING','Defense, 5 yards. Automatic first down')}
      if(res.type==='dpi'){const nl=clamp(Math.round(res.y),old+1,99);S.pen[d][0]++;S.pen[d][1]+=nl-old;S.fd[o]++;S.pyd[o]+=nl-old;G.down=1;G.los=nl;G.lineToGain=Math.min(100,nl+10);G.endCar=null;sfx('flag');return banner('PASS INTERFERENCE',`Defense, ${nl-old} yards. Automatic first down`)}
    }
    (G.log=G.log||[]).push([G.play,res.type,res.y===undefined?0:Math.round(res.y-old),+G.t.toFixed(1)]);
    // box score
    const gainY=res.type==='td'?100-old:(res.y===undefined?0:Math.round(res.y)-old);
    if(res.type==='td'||res.type==='tackle'||res.type==='sack'||res.type==='fumble'){
      if(isP&&(caught||res.type==='sack'))S.pyd[o]+=gainY;else{S.ryd[o]+=gainY;S.ra[o]++}
      S.long[o]=Math.max(S.long[o],gainY)}
    if(res.type==='sack')S.sk[d]++;
    if(res.type==='int'||res.type==='fumble'){S.to[o]++}
    if(res.type==='td'){
      if(G.twoPt){G.twoPt=false;G.score[o]+=2;sfx('roar');return afterScore(o,'TWO-POINT GOOD!','+2')}
      sfx('roar');G.score[o]+=6;
      if(G.q<5&&G.mode!==0&&!G.fast&&human(o)){G.pat=true;return banner('TOUCHDOWN!','+6')}
      G.score[o]+=1;return afterScore(o,'TOUCHDOWN!','+7 (extra point good)')}
    sfx(res.type==='int'||res.type==='fumble'?'groan':'whistle');
    if(G.twoPt){G.twoPt=false;return afterScore(o,'TWO-POINT FAILED','No good')}
    if(res.type==='fumble'){const y=res.y;return turnover(clamp(100-Math.round(y),1,99),'FUMBLE!','Defense recovers the ball')}
    if(res.type==='int'){const y=res.y;let nl=y>=100?20:100-Math.round(y);return turnover(clamp(nl,1,99),'INTERCEPTED!',y>=100?'Touchback':'Picked off')}
    let txt,sub;
    if(res.type==='inc'){txt='INCOMPLETE';sub='';G.down++}
    else{const nl=clamp(Math.round(res.y),1,99),gain=nl-old;G.stats.yds[o]+=gain;
      txt=res.type==='sack'?'SACKED!':res.oob?'OUT OF BOUNDS':'TACKLED';sub=(gain>=0?'+':'')+gain+' yards';
      if(nl>=G.lineToGain||nl>=99&&false){S.fd[o]++;G.down=1;G.los=nl;G.lineToGain=Math.min(100,nl+10);txt='FIRST DOWN!';sub=(gain>=0?'+':'')+gain+' yards'}
      else{G.los=nl;G.down++}}
    if(G.down>4){return turnover(100-G.los,'TURNOVER ON DOWNS',sub)}
    if(!res.oob&&res.type!=='inc')G.clock=Math.max(0,G.clock-G.qlen/900*16);
    banner(txt,sub);
  }
  function banner(txt,sub){
    G.phase='banner';ui.sdover.hidden=false;ui.sdover.className='sdover b';
    ui.sdover.innerHTML=`<div class="sdban"><b>${txt}</b><span>${sub||''}</span></div>`;
    renderScore();G.bt=0;
  }
  function afterBanner(){
    ui.sdover.hidden=true;
    if(G.pat){return goPAT()}
    if(G.done&&G.q>=5)return finish();
    if(G.clock<=0){
      if(G.q===2){G.q=3;G.clock=G.qlen;G.off=1-G.startOff;G.los=25;G.down=1;G.lineToGain=35;return interstitial('HALFTIME',`${G.score[0]} - ${G.score[1]}`)}
      if(G.q===4){if(G.score[0]===G.score[1]){G.q=5;G.clock=G.qlen;G.ot=true;G.off=rnd()<.5?0:1;G.los=25;G.down=1;G.lineToGain=35;return interstitial('OVERTIME','Sudden death. First score wins.')}return finish()}
      if(G.q>=5)return finish();
      G.q++;G.clock=G.qlen;return interstitial('END OF QUARTER',`Starting quarter ${G.q}`);
    }
    setupPlay();goSelect();
  }
  function interstitial(a,b){
    G.phase='banner';ui.sdover.hidden=false;ui.sdover.className='sdover b';
    ui.sdover.innerHTML=`<div class="sdban"><b>${a}</b><span>${b}</span></div>`;G.bt=-1.2;renderScore();
  }
  function boxScore(){
    const S=G.stats,r=(l,f)=>`<tr><td>${l}</td><td>${f(0)}</td><td>${f(1)}</td></tr>`;
    return `<table class="sdst"><tr><th></th><th>${G.teams[0]}</th><th>${G.teams[1]}</th></tr>`+
      r('Total yards',t=>S.pyd[t]+S.ryd[t])+r('Passing',t=>`${S.pc[t]}/${S.pa[t]}, ${S.pyd[t]} yd`)+r('Rushing',t=>`${S.ra[t]} att, ${S.ryd[t]} yd`)+
      r('First downs',t=>S.fd[t])+r('Turnovers',t=>S.to[t])+r('Sacks',t=>S.sk[t])+r('Penalties',t=>`${S.pen[t][0]}-${S.pen[t][1]} yd`)+r('Longest play',t=>S.long[t]+' yd')+`</table>`}
  function finish(){
    G.phase='final';const[a,b]=G.score,w=a>b?0:b>a?1:-1;
    if(G.season){const S=sget();if(S){S.res[G.season.id]={us:a,them:b};sset(S)}}else if(G.om===1){const r=rec();if(w===0)r.w++;else if(w===1)r.l++;else r.t++;saveRec(r)}
    ui.sdover.hidden=false;ui.sdover.className='sdover f';ui.sdplays.innerHTML='';
    const who=w<0?'TIE GAME':G.om===1?(w===0?'YOU WIN!':'CPU WINS'):`${tn(G.teams[w])} WIN!`;
    ui.sdover.innerHTML=`<div class="sdban fin"><span>FINAL</span><b>${who}</b><span class="big">${tn(G.teams[0])} ${a} - ${b} ${tn(G.teams[1])}</span>${boxScore()}${G.season?`<div class="sdbtns"><button class="btn solid" data-act="shub">Back to season</button></div>`:'<div class="sdbtns"><button class="btn solid" data-act="again">Play again</button><button class="btn" data-act="menu">Change teams</button></div>'}</div>`;
    if(G.season){const S=sget();if(S)ui.sdover.querySelector('.big').insertAdjacentHTML('afterend',`<span>Season record ${srecTxt(S)}</span>`)}
    renderScore();
  }

  /* ------------------------------ simulation ------------------------------ */
  const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
  function moveTo(e,tx,ty,sp,dt){
    if(e.stun>0){e.stun-=dt;e.vx=e.vy=0;return}
    const dx=tx-e.x,dy=ty-e.y,d=Math.hypot(dx,dy);
    if(d<.05){e.vx=e.vy=0;return}
    const s=Math.min(sp,d/dt);e.vx=dx/d*s;e.vy=dy/d*s;e.x+=e.vx*dt;e.y+=e.vy*dt;
  }
  function drive(e,dx,dy,sp,dt){
    if(e.stun>0){e.stun-=dt;e.vx=e.vy=0;return}
    const m=Math.hypot(dx,dy);if(m<.05){e.vx=e.vy=0;return}
    e.vx=dx/m*sp;e.vy=dy/m*sp;e.x+=e.vx*dt;e.y+=e.vy*dt;
  }
  function pw(team,cost){if(G.pm[team]>=cost-1e-6){G.pm[team]-=cost;return true}return false}
  function fx(x,y,txt,col){G.fx.push({x,y,txt,col:col||'#fff',t:0});if(/HIT|TRUCK|STRIP|SACK/.test(txt)){G.shake=Math.max(G.shake||0,.32);sfx('hit')}else if(/^BOOST/.test(txt))sfx('boost')}
  function doBoost(e){if(!e||e.boostT>0||e.stun>0||G.bs[e.team]<.28)return;G.bs[e.team]-=.28;e.boostT=1.15;fx(e.x,e.y,'BOOST!','#6ee7ff')}
  function doSpin(c){if(c.jt>0||c.jcd>0||!pw(c.team,.2))return;c.jt=.34;c.jcd=.3;c.wrapT=0;fx(c.x,c.y,'SPIN','#fff')}
  function doStiff(c){
    if(!pw(c.team,.3))return;let near=null,nd=2.4;G.D.forEach(df=>{const d=dist(df,c);if(d<nd){nd=d;near=df}});
    c.wrapT=0;
    if(!near){fx(c.x,c.y,'STIFF-ARM','#fff');return}
    near.stun=1.1;near.dive=0;near.hit=false;near.touch=false;const dx=near.x-c.x,dy=near.y-c.y,m=Math.hypot(dx,dy)||1;near.x+=dx/m*1.6;near.y+=dy/m*1.6;
    G.D.forEach(df=>{if(df!==near&&dist(df,c)<1.3)df.touch=false});
    fx(near.x,near.y,'STIFF-ARM!','#ffd23a');
  }
  function doTruck(c){if(c.truckT>0||!pw(c.team,.45))return;c.truckT=.45;c.wrapT=0;fx(c.x,c.y,'TRUCK!','#ff8a5c')}
  function doHit(df){if(df.dive>0||df.stun>0||!pw(df.team,.4))return false;df.hit=true;df.dive=.3;fx(df.x,df.y,'HIT!','#ffd23a');return true}
  function doStrip(df,c){
    if(!c||dist(df,c)>2||!pw(df.team,.25))return;
    if(rnd()<.38){fx(c.x,c.y,'STRIPPED!','#ff6b5c');endPlay({type:'fumble',y:Math.max(1,c.y)})}else{df.stun=.45;fx(df.x,df.y,'NO LUCK','#cfe6ff')}
  }
  function getIn(t){return G.mode===2?inp[t]:inp[0]}
  function focus(){const b=G.ball;if(b.holder)return b.holder;if(b.air)return{x:b.tx,y:b.ty};return G.qb}
  function step(dt){
    if(!G)return;
    if(G.shake>0)G.shake=Math.max(0,G.shake-dt);
    if(G.kick&&G.kick.t<G.kick.T){G.kick.t+=dt;const k=G.kick.t/G.kick.T;G.cam+=(clamp(G.kick.y0+(G.kick.y1-G.kick.y0)*k+4,-10+VH/2,110-VH/2)-G.cam)*Math.min(1,dt*4)}
    if(G.phase==='banner'){G.bt=(G.bt||0)+dt;if(G.bt>1.35)afterBanner();return}
    if(G.phase!=='live')return;
    G.t+=dt;const b=G.ball,o=G.off,d=1-o,isRun=G.play.startsWith('run'),L=G.los;
    if(G.clock>0)G.clock=Math.max(0,G.clock-dt);
    // ------- clear edge-triggered buttons into locals
    const iO=human(o)?getIn(o):null,iD=human(d)?getIn(d):null;
    const aO=iO&&iO.a,bO=iO&&iO.b,cO=iO&&iO.c,eO=iO&&iO.e,aD=iD&&iD.a,bD=iD&&iD.b,cD=iD&&iD.c,dD=iD&&iD.d,eD=iD&&iD.e;
    if(iO){iO.a=false;iO.b=false;iO.c=false;iO.d=false;iO.e=false}if(iD){iD.a=false;iD.b=false;iD.c=false;iD.d=false;iD.e=false}
    for(let i=0;i<2;i++){G.pm[i]=Math.min(1,G.pm[i]+dt*.14);G.bs[i]=Math.min(1,G.bs[i]+dt*.11)}
    G.ents.forEach(e=>{if(e.boostT>0)e.boostT=Math.max(0,e.boostT-dt)});
    G.fx=G.fx.filter(f=>(f.t+=dt)<.95);
    // ------- offense
    const car=b.holder,qb=G.qb;
    if(!G.dl[2].free&&G.t>G.dl[2].hold)G.dl[2].free=true;
    // blockers
    G.ol.forEach((ol,i)=>{
      const dlI=[0,1][i],dl=G.dl[dlI];
      if(!dl.free){const tx=dl.x,ty=dl.y-.95;
        if(Math.abs(dl.x-ol.x)<1.1&&Math.abs(dl.y-ol.y)<1.7){ol.eng=true;dl.engT+=dt/(i===3?1.4:1);ol.vx=ol.vy=0;ol.y=dl.y-.95;
          if(dl.engT>dl.hold){dl.free=true;ol.eng=false}}
        else moveTo(ol,tx,ty,S0.ol,dt)}
      else moveTo(ol,ol.sx,ol.y,1.5,dt);
    });
    // TE blocks edge on runs
    if(isRun&&!car.route&&G.te!==car){const t=G.lb[1];moveTo(G.te,t.x,t.y-1,S0.te,dt)}
    // receivers
    G.wrs.forEach((w,i)=>{
      if(b.holder===w)return;
      if(w.blk){const cb=G.cb[i===1?1:0],dd=i===2?G.lb[0]:cb;moveTo(w,dd.x,Math.min(dd.y-1,w.sy+8),6,dt);return}
      if(isRun){if(i<3){const cb=G.cb[i===1?1:0],dd=i===2?G.lb[0]:cb;moveTo(w,dd.x,Math.min(dd.y-1,w.sy+8),6,dt)}return}
      if(w.route&&w.ri<w.route.length){const p=w.route[w.ri];moveTo(w,p[0],p[1],S0.wr,dt);if(Math.hypot(p[0]-w.x,p[1]-w.y)<.25)w.ri++}
      else if(b.air&&G.tgt===w){}
      else{w.vx=w.vy=0}
    });
    // human offense control
    if(iO){
      let ctl=null;if(car)ctl=car;else if(b.air&&G.tgt&&G.tgt.team===o)ctl=G.tgt;
      if(ctl){
        const sp=ctl===qb?S0.qb:ctl.role==='rb'?S0.rb:S0.wr*0.96;
        if(eO)doBoost(ctl);const jm=(ctl.boostT>0?1.4:1)*(ctl.jt>0?1.3:1)*(ctl.truckT>0?1.28:1)*(ctl.wrapT>.02?.55:1);drive(ctl,iO.dx,iO.dy,sp*jm*(ctl.stun>0?0:1),dt);
        if(ctl===qb&&!G.thrown&&!isRun){
          if(bO){const ws=G.wrs;G.target=(G.target+1)%ws.length}
          if(aO)throwTo(G.wrs[G.target])
        }else if(ctl===car){if(aO)doSpin(ctl);if(bO)doStiff(ctl);if(cO)doTruck(ctl)}
      }
    }
    // cpu offense
    if(!iO||!(car||b.air)){
      if(car&&!iO){
        if(car===qb&&!G.thrown&&!isRun){
          const press=G.D.some(x=>!x.stun&&dist(x,qb)<2.3&&!(x.role==='dl'&&!x.free&&x.engT>0));
          if(G.t>G.cpuThrowAt||press&&G.t>.9){const tg=bestTarget();if(tg)throwTo(tg);else if(G.t>G.cpuThrowAt+1.6)runAI(car,dt)}
          else{moveTo(qb,qb.x+Math.sin(G.t*2)*.4,Math.max(L-6.5,qb.y-1),3,dt)}
        }else runAI(car,dt);
        if(car.jcd>0)car.jcd-=dt;
      }
    }
    if(car){car.jt=Math.max(0,car.jt-dt);car.jcd=Math.max(0,car.jcd-dt);car.truckT=Math.max(0,car.truckT-dt)}
    // RB (pass plays) stays to block/check
    if(!isRun&&G.rb!==car&&!G.wrs.includes(G.rb)){moveTo(G.rb,G.rb.sx,G.rb.sy,2,dt)}
    if(!isRun&&car!==G.te&&!G.wrs.includes(G.te)){moveTo(G.te,G.te.sx,G.te.sy,2,dt)}
    if(G.play==='run3'&&car!==qb){moveTo(qb,32,qb.sy-1.8,3,dt)}
    if(!isRun&&G.thrown&&!car&&b.air&&!iO){ /* cpu receivers adjust to ball */
      const w=G.tgt;if(w&&w.team===o)moveTo(w,b.tx,b.ty,S0.wr,dt)}
    // ------- ball
    if(b.air){
      b.t+=dt;const k=Math.min(1,b.t/b.T);b.x=b.ax+(b.tx-b.ax)*k;b.y=b.ay+(b.ty-b.ay)*k;b.z=Math.sin(k*Math.PI)*(2+b.dist*.08);if(b.trail){b.trail.push([b.x,b.y,b.z]);if(b.trail.length>14)b.trail.shift()}
      // swat
      G.D.forEach(df=>{if(df.dive>0&&dist(df,{x:b.x,y:b.y})<1.9&&b.z<2.8&&!b.swat&&k>.35){b.swat=true}});
      if(k>=1)resolveCatch();
    }else if(car){b.x=car.x;b.y=car.y}
    // ------- defense
    updateDefense(dt,iD,aD,bD,cD,dD,eD);
    // ------- tackles
    const c=b.holder;
    if(c&&G.phase==='live'){
      if(c.y>=100){return endPlay({type:'td'})}
      const qbPre=c===qb&&!G.thrown,LV_=G.lvl;let n=0;
      if(!qbPre&&(c.x<=.7||c.x>=VW-.7)&&c.y>L-1)return endPlay({type:'tackle',y:Math.max(1,c.y),oob:true});
      for(const df of G.D){
        if(df.stun>0){df.touch=false;continue}
        if(df.role==='dl'&&!df.free&&dist(df,c)>1.3)continue;
        const tr=df.dive>0?1.65:1.15,dd=dist(df,c);
        if(dd>=tr){if(dd>tr+.5)df.touch=false;continue}
        if(c.jt>0){if(!df.touch){df.touch=true;if(rnd()<.72){df.stun=.8;df.dive=0;df.hit=false;fx(c.x,c.y,'SPIN!','#fff')}}continue}
        if(!df.touch){
          df.touch=true;
          if(c.truckT>0&&!(df.hit&&rnd()<.4)){if(rnd()<.72){df.stun=1.4;df.dive=0;df.hit=false;fx(df.x,df.y,'TRUCKED!','#ff8a5c');continue}}
          const human_=df===G.ctrlD,hitChance=df.hit?1:human_?0:[.05,.11,.2][LV_];
          if(hitChance>0&&rnd()<hitChance&&!qbPre){fx(c.x,c.y,'BIG HIT!','#ffd23a');if(rnd()<(df.hit?.24:.18)){return endPlay({type:'fumble',y:Math.max(1,c.y)})}return endPlay({type:'tackle',y:Math.max(1,c.y)})}
          const miss=qbPre?0:human_?.12:[.45,.36,.28][LV_];
          if(rnd()<miss){df.stun=.7;df.dive=0;df.hit=false;fx(df.x,df.y,'MISSED!','#cfe6ff');continue}
          if(df.dive>0)c.wrapT+=.22;
        }
        n++;
      }
      if(n>0){c.wrapT+=dt*(1+(n-1)*.9);
        // cpu strip attempts while being wrapped
        if(!qbPre&&G.D.some(x=>x.touch&&x!==G.ctrlD)&&rnd()<dt*[.2,.4,.65][LV_]&&rnd()<.33){fx(c.x,c.y,'STRIPPED!','#ff6b5c');return endPlay({type:'fumble',y:Math.max(1,c.y)})}
      }
      else c.wrapT=Math.max(0,c.wrapT-dt*1.8);
      if(c.wrapT>=(qbPre?.4:.5)){
        const sack=qbPre&&!isRun&&c.y<L+.5;
        return endPlay({type:sack?'sack':'tackle',y:Math.max(1,c.y)});
      }
    }
    // clamp field
    G.ents.forEach(e=>{e.x=clamp(e.x,.6,VW-.6);e.y=clamp(e.y,-9,109)});
    // camera
    const f=focus();let ty0=f.y+3.5;
    if(!b.air&&!b.holder&&false){}
    if(human(o)&&b.holder===G.qb&&!G.thrown&&!isRun0()&&G.wrs[G.target]){ty0=Math.max(f.y+3.5,(G.qb.y+G.wrs[G.target].y)/2+3)}
    else if(b.air){ty0=Math.max(f.y+3.5,(b.y*.4+b.ty*.6)+3.5)}
    else if(b.holder&&b.holder.team===o){ty0=f.y+3.5+clamp(b.holder.vy*.35,-1,3)}
    const target=clamp(ty0,-10+VH/2,110-VH/2);G.cam+=(target-G.cam)*Math.min(1,dt*5);
  }
  const isRun0=()=>G.play&&G.play.startsWith('run');
  function runAI(c,dt){
    // pick heading that stays away from defenders ahead
    c.ait=(c.ait||0)-dt;
    if(c.ait<=0||c.ax===undefined){c.ait=.2;let best=-1,bx=c.x;
      for(let dx=-9;dx<=9;dx+=2.25){const tx=clamp(c.x+dx,2,62),ty=c.y+7;let m=99;
        G.D.forEach(df=>{if(df.y<c.y-1.2)return;const ax=c.x,ay=c.y,bx_=tx,by=ty,vx=bx_-ax,vy=by-ay,l2=vx*vx+vy*vy;let t=((df.x-ax)*vx+(df.y-ay)*vy)/l2;t=clamp(t,0,1);const px=ax+vx*t,py=ay+vy*t;m=Math.min(m,Math.hypot(df.x-px,df.y-py)*(df.role==='dl'&&!df.free?1.6:1))});
        const sc=m-Math.abs(dx)*.08;if(sc>best){best=sc;bx=tx}}
      c.ax=bx}
    if(c.boostT<=0&&c.y>G.los+2&&G.bs[c.team]>.6&&rnd()<dt*0)doBoost(c);const sp=(c.role==='qb'?S0.qb:c.role==='rb'?S0.rb:S0.wr*.96)*(c.boostT>0?1.38:1)*(c.truckT>0?1.28:1)*(c.wrapT>.02?.55:1);
    drive(c,(c.ax-c.x)*.9,5,sp,dt);
    // juke when a defender is close ahead
    if(c.jcd<=0&&c.jt<=0&&G.D.some(df=>df.stun<=0&&df.y>c.y&&dist(df,c)<2.1)&&rnd()<.4)doSpin(c);
    if(c.wrapT>.1&&rnd()<dt*4)doStiff(c);
    if(c.truckT<=0&&G.D.filter(df=>df.stun<=0&&df.y>=c.y-.5&&dist(df,c)<3.6).length>=1&&rnd()<dt*1.1)doTruck(c);
  }
  function bestTarget(){
    let best=null,bs=-99;
    G.wrs.forEach(w=>{if(w.blk||!w.route||!w.route.length||w.ri===0&&G.t<.6)return;
      let open=99;G.D.forEach(df=>{open=Math.min(open,dist(df,w))});
      const adv=w.y-G.qb.y,sc=open*1.3+adv*.06-(w.ri<w.route.length&&G.play==='pass2'?0:0)+rnd()*.7;
      if(open>2.0&&w.y>G.los-2&&sc>bs){bs=sc;best=w}});
    return best;
  }
  function predictLand(w){
    const q=G.qb,SP=24;let tx=w.x,ty=w.y;
    for(let i=0;i<3;i++){const d=Math.hypot(tx-q.x,ty-q.y),T=d/SP+.15;tx=clamp(w.x+w.vx*T,1,63);ty=w.y+w.vy*T}
    const d=Math.hypot(tx-q.x,ty-q.y);return{tx,ty,d,T:d/SP+.15}
  }
  function throwTo(w){
    const q=G.qb,b=G.ball;if(G.thrown)return;
    const P=predictLand(w),tx=P.tx,ty=P.ty,SP=24,d=P.d;b.trail=[];b.rel={x:q.x,y:q.y};
    G.stats.pa[G.off]++;sfx('throw');G.thrown=true;G.tgt=w;b.holder=null;b.air=true;b.ax=q.x;b.ay=q.y;b.tx=tx;b.ty=ty;b.t=0;b.T=d/SP+.15;b.dist=d;b.swat=false;b.x=q.x;b.y=q.y;
  }
  function resolveCatch(){
    const b=G.ball,land={x:b.tx,y:b.ty};b.air=false;
    if(b.swat){return endPlay({type:'inc'})}
    let rec=null,rd=99,df=null,dd=99;
    G.wrs.concat([G.rb]).forEach(w=>{const d=dist(w,land);if(d<rd){rd=d;rec=w}});
    G.D.forEach(x=>{const d=dist(x,land);if(d<dd&&x.stun<=0){dd=d;df=x}});
    const rOK=rd<2.3,dOK=dd<1.5;
    let res='inc';
    if(rOK&&dOK){const p=clamp(.7+(dd-rd)*.3,.3,.96);if(rnd()<p)res='catch';else res=rnd()<(human(G.off)?.12:.25)?'int':'inc'}
    else if(rOK){res=rnd()<.94?'catch':'inc'}
    else if(dOK&&dd<.9){res=rnd()<(human(G.off)?.04:.11)?'int':'inc'}
    if(res==='catch'){G.stats.pc[G.off]++;sfx('catch');const ay=Math.round(land.y-G.los);fx(land.x,land.y,(ay>=0?'CAUGHT '+ay:'BEHIND LOS '+(-ay))+' YD','#9fe8b0');G.catchY=land.y;b.holder=rec;G.thrown=true;rec.jt=0;rec.jcd=0;rec.wrapT=0;rec.truckT=0;rec.route=null;return}
    if(res==='int'){return endPlay({type:'int',y:land.y})}
    if(dOK&&!b.swat&&rnd()<.1)return endPlay({type:'dpi',y:land.y});
    endPlay({type:'inc'});
  }
  function updateDefense(dt,iD,aD,bD,cD,dD,eD){
    const b=G.ball,L=G.los,o=G.off,d=1-o,c=b.holder,isRun=G.play.startsWith('run'),f=focus();
    const dc=G.dcall||'base',draw=G.play==='run3',pastLOS=c&&c.y>L+.4,chase=pastLOS||(isRun&&G.defKnow&&G.t>(dc==='box'?.1:.15)+(draw?.6:0))||(isRun&&G.t>.55+(draw?.7:0));
    // human control selection
    let ctl=null;
    if(iD){
      let near=null,nd=99;G.D.forEach(x=>{const dd=dist(x,f)+(x.role==='dl'&&!x.free?4:0);if(dd<nd){nd=dd;near=x}});
      if(!G.ctrlD||bD){
        if(bD&&G.ctrlD){const ord=G.D.filter(x=>x!==G.ctrlD).sort((p,q)=>dist(p,f)-dist(q,f));G.ctrlD=ord[0]}
        else G.ctrlD=near}
      else if(near!==G.ctrlD&&dist(G.ctrlD,f)-nd>1.6)G.ctrlD=near;
      ctl=G.ctrlD;
    }else G.ctrlD=null;
    G.D.forEach((df,i)=>{
      if(df.dive>0){df.dive-=dt;if(df.dive<=0){df.stun=Math.max(df.stun,df.hit?1.0:.55);df.hit=false}}
      if(df===ctl){
        const sp=df.spd*(df.dive>0?(df.hit?1.9:1.5):1)*(df.boostT>0?1.35:1);
        if(aD&&df.dive<=0&&df.stun<=0){df.dive=.3;df.dvx=iD.dx||0;df.dvy=iD.dy||(f.y>df.y?1:-1)}
        if(cD&&df.dive<=0&&df.stun<=0&&doHit(df)){df.dvx=iD.dx||(f.x-df.x);df.dvy=iD.dy||(f.y-df.y)}
        if(dD&&df.stun<=0)doStrip(df,c);if(eD)doBoost(df)
        if(df.dive>0){const m=Math.hypot(df.dvx,df.dvy)||1;drive(df,df.dvx,df.dvy,sp,dt)}
        else drive(df,iD.dx,iD.dy,sp,dt);
        return}
      if(G.t<df.react)return;
      if(df.stun>0){df.stun-=dt;return}
      if(df.dive>0){return}
      // CPU defender logic
      let tx,ty;const sp=df.spd;
      if(c&&chase){const v=Math.min(.7,dist(df,c)/sp);tx=c.x+c.vx*v;ty=c.y+c.vy*v;
        if(df.role==='dl'&&!df.free&&dist(df,c)>2.5){moveTo(df,df.x,df.y,0,dt);return}
      }else if(b.air){const dd=dist(df,{x:b.tx,y:b.ty});if(b.t<.08){tx=df.x;ty=df.y}else if(dd<12||df.role==='cb'||df.role==='s'){tx=b.tx;ty=b.ty;moveTo(df,tx,ty,df.spd*.88,dt);return}else{tx=df.x;ty=df.y}}
      else if(draw&&c&&!chase&&df.role!=='dl'){tx=df.sx;ty=df.sy+2.6}
      else if(c&&!G.thrown&&!isRun){ // pass play pre-throw
        if(df.role==='dl'){tx=G.qb.x;ty=G.qb.y;if(!df.free){moveTo(df,df.x+(tx-df.x)*.1,df.y-.15,df.spd*.25,dt);return}}
        else if(df.role==='lb'){if(G.blitz&&i!==4){tx=G.qb.x;ty=G.qb.y}else{const w=G.wrs[i-1]||G.wrs[3];
          if(G.play==='pass4'&&G.t<.9){tx=df.x;ty=df.y+.9}
          else if(dc==='man'){tx=w.x;ty=Math.max(G.los+2,w.y+.8)}
          else{tx=clamp(w.x*.6+df.sx*.4,2,62);ty=Math.max(G.los+4.2,Math.min(w.y+1,G.los+(dc==='prevent'?10:8)))}}}
        else if(df.role==='cb'){const w=G.wrs[i-5],deep=G.play==='pass2'||G.play==='pass4',cu={base:[1.6,3.2],blitz:[1.2,3.2],man:[.5,1.2],prevent:[4.8,7],box:[1.3,2.2]}[dc];tx=w.x;ty=w.y+cu[deep?1:0]}
        else{const w=G.wrs[0].y>G.wrs[1].y?G.wrs[0]:G.wrs[1],deep=G.play==='pass2'||G.play==='pass4',dp=deep?{base:9,blitz:9,man:3.5,prevent:13,box:4.5}[dc]:{base:3,blitz:3,man:1.2,prevent:7,box:2.2}[dc];
          if(dc==='blitz'&&i===7){tx=G.qb.x;ty=G.qb.y}
          else if(G.play==='pass4'&&G.t<.9){tx=df.x;ty=df.y+.9}
          else{tx=df.sx;ty=Math.max(df.y,w.y+dp);if(dc==='man')tx=w.x*.8+df.sx*.2;else if(!deep&&w.y>G.los+4){tx=(tx+w.x)/2;ty=w.y+2}}}
      }else{tx=df.x;ty=df.y}
      if(df.role==='dl'&&!df.free){moveTo(df,df.x,df.y,0,dt);return}
      if(df.boostT<=0&&c&&c.team!==df.team&&dist(df,c)>4.5&&G.bs[df.team]>.6&&rnd()<dt*[.12,.3,.6][G.lvl])doBoost(df);
      moveTo(df,tx,ty,sp*(df.boostT>0?1.3:1),dt);
    });
    G.D.forEach(df=>{if(df.role==='dl'&&!df.free&&df.engT>0){df.y+=.0}});
  }

  /* ------------------------------ 3D renderer (three.js, falls back to 2D) ------------------------------ */
  let T3=null; // null = not tried, false = unavailable, object = ready
  const S3=2,ZV=z=>1.7+z*1.5;
  const camPref=()=>{try{return localStorage.getItem('gm.sd.cam')==='wide'}catch(e){return false}};
  function init3(){
    if(T3!==null)return;
    let c3=null;
    try{
      if(typeof THREE==='undefined')throw new Error('no three');
      c3=document.createElement('canvas');c3.id='sd3cv';c3.setAttribute('aria-hidden','true');c3.width=CW*S3;c3.height=CH*S3;
      ui.sdwrap.insertBefore(c3,cv);
      const r=new THREE.WebGLRenderer({canvas:c3,antialias:true,alpha:false,powerPreference:'high-performance'});
      r.setPixelRatio(1);r.setSize(CW*S3,CH*S3,false);
      r.shadowMap.enabled=true;r.shadowMap.type=THREE.PCFSoftShadowMap;
      const sc=new THREE.Scene();sc.background=new THREE.Color(0x9db4cc);sc.fog=new THREE.Fog(0xaebccc,70,230);
      const cam=new THREE.PerspectiveCamera(58,CW/CH,.4,300);
      sc.add(new THREE.HemisphereLight(0xffffff,0x6c7d62,.95));
      const sun=new THREE.DirectionalLight(0xfff0d8,.95);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);
      const sh=sun.shadow.camera;sh.left=-26;sh.right=26;sh.top=26;sh.bottom=-26;sh.near=1;sh.far=110;sh.updateProjectionMatrix();sun.shadow.bias=-.0006;
      sc.add(sun);sc.add(sun.target);
      const T={r,sc,cam,c3,sun,rigs:new Map(),mats:{},on:false,offKey:'',crowd:[],camx:32,wide:camPref(),bk:''};
      // ---------- field ----------
      const fc=document.createElement('canvas');fc.width=1024;fc.height=1920;T.fc=fc;
      T.ft=new THREE.CanvasTexture(fc);T.ft.anisotropy=Math.min(8,r.capabilities.getMaxAnisotropy());
      const field=new THREE.Mesh(new THREE.PlaneGeometry(64,120),new THREE.MeshLambertMaterial({map:T.ft}));
      field.rotation.x=-Math.PI/2;field.position.set(32,0,-50);field.receiveShadow=true;sc.add(field);
      const out=new THREE.Mesh(new THREE.PlaneGeometry(120,170),new THREE.MeshLambertMaterial({color:0x2b7634}));out.rotation.x=-Math.PI/2;out.position.set(32,-.05,-50);out.receiveShadow=true;sc.add(out);
      const band=(w,l,x,z)=>{const m=new THREE.Mesh(new THREE.PlaneGeometry(w,l),new THREE.MeshLambertMaterial({color:0xe8ecee}));m.rotation.x=-Math.PI/2;m.position.set(x,-.02,z);sc.add(m)};
      band(2.2,134,-1.6,-50);band(2.2,134,65.6,-50);band(68,2.2,32,13.2);band(68,2.2,32,-113.2);
      // ---------- stadium ----------
      const seat=document.createElement('canvas');seat.width=256;seat.height=128;const g=seat.getContext('2d');
      g.fillStyle='#8c8f97';g.fillRect(0,0,256,128);
      const pal=['#c9ccd3','#6f747e','#5b606b','#b34a3c','#3a5fa8','#d9d9de','#e0b23a','#7d8590'];
      for(let y=0;y<128;y+=4){g.fillStyle=(y/4)%2?'#7a7e87':'#868a93';g.fillRect(0,y,256,3);for(let x=0;x<256;x+=3){if(Math.random()<.55){g.fillStyle=pal[(Math.random()*pal.length)|0];g.fillRect(x,y,2,3)}}g.fillStyle='rgba(0,0,0,.4)';g.fillRect(0,y+3,256,1)}
      const st=new THREE.CanvasTexture(seat);st.wrapS=st.wrapT=THREE.RepeatWrapping;st.anisotropy=4;T.seat=st;
      const ac=document.createElement('canvas');ac.width=512;ac.height=32;const ag=ac.getContext('2d');
      [['#8a3fd8',60],['#ffd21f',70],['#18a9e6',60],['#ffffff',90],['#18a9e6',50],['#232733',70],['#e8433f',50],['#ffffff',62]].reduce((x,[c,w])=>{ag.fillStyle=c;ag.fillRect(x,0,w,32);ag.fillStyle=c==='#ffffff'?'#e8433f':'rgba(255,255,255,.85)';ag.fillRect(x+8,12,w-16,4);ag.fillRect(x+14,19,w-28,3);return x+w},0);
      const adt=new THREE.CanvasTexture(ac);adt.wrapS=THREE.RepeatWrapping;adt.repeat.set(5,1);
      const concrete=new THREE.MeshLambertMaterial({color:0xcfd3d8}),steel=new THREE.MeshLambertMaterial({color:0x7b828c}),dark=new THREE.MeshLambertMaterial({color:0x3a3f48});
      const slope=(len,x0,y0,x1,y1,rep)=>{const geo=new THREE.BufferGeometry(),h=len/2;
        geo.setAttribute('position',new THREE.Float32BufferAttribute([x0,y0,-h,x0,y0,h,x1,y1,h,x0,y0,-h,x1,y1,h,x1,y1,-h],3));
        geo.setAttribute('uv',new THREE.Float32BufferAttribute([0,0,rep,0,rep,3,0,0,rep,3,0,3],2));
        geo.computeVertexNormals();const m=new THREE.Mesh(geo,new THREE.MeshLambertMaterial({map:st,side:THREE.DoubleSide}));return m};
      const side=len=>{const gr=new THREE.Group(),L=len;
        const wall=new THREE.Mesh(new THREE.BoxGeometry(.6,2.4,L),concrete);wall.position.set(0,1.2,0);gr.add(wall);
        gr.add(slope(L,-.3,2.4,-13,11,L/9));                                       // lower seats
        const rail=new THREE.Mesh(new THREE.BoxGeometry(.4,1.1,L),steel);rail.position.set(-13,11.5,0);gr.add(rail);
        const ledge=new THREE.Mesh(new THREE.BoxGeometry(5,1,L),steel);ledge.position.set(-15.4,12,0);gr.add(ledge);
        const fas=new THREE.Mesh(new THREE.BoxGeometry(.3,1.7,L),new THREE.MeshBasicMaterial({map:adt.clone()}));fas.material.map.needsUpdate=true;fas.material.map.wrapS=THREE.RepeatWrapping;fas.material.map.repeat.set(L/22,1);fas.position.set(-12.9,13.2,0);gr.add(fas);
        for(let z=-L/2+6;z<L/2;z+=14){const p=new THREE.Mesh(new THREE.BoxGeometry(1,9,1),steel);p.position.set(-13.2,7,z);gr.add(p)}
        gr.add(slope(L,-18,12.5,-34,30,L/9));                                      // upper seats
        const fas2=new THREE.Mesh(new THREE.BoxGeometry(.3,1.6,L),new THREE.MeshBasicMaterial({map:adt.clone()}));fas2.material.map.needsUpdate=true;fas2.material.map.wrapS=THREE.RepeatWrapping;fas2.material.map.repeat.set(L/22,1);fas2.material.map.offset.x=.4;fas2.position.set(-17.7,13.4,0);gr.add(fas2);
        const roof=new THREE.Mesh(new THREE.BoxGeometry(3,1.4,L),dark);roof.position.set(-34,31,0);gr.add(roof);
        return gr};
      const mk=(len,x,z,ry)=>{const s=side(len);s.position.set(x,0,z);s.rotation.y=ry;sc.add(s)};
      mk(150,-3.4,-50,0);mk(150,67.4,-50,Math.PI);mk(122,32,-123.8,-Math.PI/2);mk(122,32,17.4,Math.PI/2);
      // ---------- scoreboards (far end + near end) ----------
      const bc=document.createElement('canvas');bc.width=512;bc.height=192;T.bc=bc;T.bt=new THREE.CanvasTexture(bc);
      [[32,-127,0],[32,20,Math.PI]].forEach(([x,z,ry])=>{const gr=new THREE.Group(),fr=new THREE.Mesh(new THREE.BoxGeometry(17,6.6,.8),dark);gr.add(fr);
        const bd=new THREE.Mesh(new THREE.PlaneGeometry(16,6),new THREE.MeshBasicMaterial({map:T.bt}));bd.position.z=.45;gr.add(bd);gr.position.set(x,19,z);gr.rotation.y=ry;sc.add(gr)});
      // ---------- goal posts, pylons, benches ----------
      const yel=new THREE.MeshLambertMaterial({color:0xffd23a,emissive:0x3a2c00}),pad=new THREE.MeshLambertMaterial({color:0x1d4fd8});
      const post=z=>{const gp=new THREE.Group();
        const b=new THREE.Mesh(new THREE.CylinderGeometry(.22,.26,1.6,10),pad);b.position.y=.8;gp.add(b);
        const n=new THREE.Mesh(new THREE.CylinderGeometry(.14,.16,2.2,8),yel);n.position.y=2.6;gp.add(n);
        const bar=new THREE.Mesh(new THREE.BoxGeometry(6.4,.18,.18),yel);bar.position.y=3.6;gp.add(bar);
        [-3.2,3.2].forEach(dx=>{const u=new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,7.5,6),yel);u.position.set(dx,7.3,0);gp.add(u)});
        gp.position.set(32,0,z);gp.traverse(o=>{if(o.isMesh)o.castShadow=true});sc.add(gp)};
      post(10);post(-110);
      const org=new THREE.MeshLambertMaterial({color:0xff6a10});
      [[0,0],[64,0],[0,-100],[64,-100],[0,10],[64,10],[0,-110],[64,-110]].forEach(([x,z])=>{const m=new THREE.Mesh(new THREE.BoxGeometry(.3,1.2,.3),org);m.position.set(x,.6,z);m.castShadow=true;sc.add(m)});
      [[-3.6,-35],[-3.6,-65],[67.6,-35],[67.6,-65]].forEach(([x,z])=>{const m=new THREE.Mesh(new THREE.BoxGeometry(1.2,.9,12),new THREE.MeshLambertMaterial({color:0x2a3140}));m.position.set(x,.45,z);sc.add(m)});
      // ---------- down markers ----------
      const line=col=>{const m=new THREE.Mesh(new THREE.PlaneGeometry(64,.4),new THREE.MeshBasicMaterial({color:col,transparent:true,opacity:.9}));m.rotation.x=-Math.PI/2;m.position.set(32,.04,0);sc.add(m);return m};
      T.los=line(0x3a7bff);T.ltg=line(0xffd23a);
      // ---------- ball ----------
      const ball=new THREE.Mesh(new THREE.SphereGeometry(.34,16,12),new THREE.MeshPhongMaterial({color:0x7d4220,shininess:30}));ball.scale.set(.72,.72,1.35);ball.castShadow=true;
      const lace=new THREE.Mesh(new THREE.BoxGeometry(.05,.05,.5),new THREE.MeshBasicMaterial({color:0xffffff}));lace.position.y=.26;ball.add(lace);
      sc.add(ball);T.ball=ball;
      const bs=new THREE.Mesh(new THREE.CircleGeometry(.4,12),new THREE.MeshBasicMaterial({color:0,transparent:true,opacity:.3}));bs.rotation.x=-Math.PI/2;bs.position.y=.05;sc.add(bs);T.bsh=bs;
      T.shGeo=new THREE.CircleGeometry(.7,14);T.shMat=new THREE.MeshBasicMaterial({color:0,transparent:true,opacity:.18});
      T.ringGeo=new THREE.RingGeometry(1,1.3,28);T.ringMat=new THREE.MeshBasicMaterial({color:0xffe14a,side:THREE.DoubleSide,transparent:true,opacity:.95});
      T.v=new THREE.Vector3();
      c3.addEventListener('webglcontextlost',e=>{e.preventDefault();T3=false;ui.sdwrap.classList.remove('sd3');c3.remove();cv.width=CW;cv.height=CH;ctx.setTransform(1,0,0,1,0,0);ctx.imageSmoothingEnabled=false});
      ui.sdwrap.classList.add('sd3');
      cv.width=CW*S3;cv.height=CH*S3;
      T3=T;
    }catch(err){T3=false;if(c3)c3.remove();ui.sdwrap.classList.remove('sd3');cv.width=CW;cv.height=CH;ctx.setTransform(1,0,0,1,0,0);ctx.imageSmoothingEnabled=false;try{window.__sd3err=String(err&&err.message||err)}catch(e){}}
  }
  const lam=(T,hex,em)=>{const k=hex+(em||'');return T.mats[k]||(T.mats[k]=new THREE.MeshLambertMaterial({color:hex,emissive:em||0x000000}))};
  const hexN=h=>parseInt(h.slice(1),16);
  const shade=(h,f)=>{const n=parseInt(h.slice(1),16),c=v=>Math.max(0,Math.min(255,Math.round(v*f)));return '#'+[c(n>>16&255),c(n>>8&255),c(n&255)].map(v=>v.toString(16).padStart(2,'0')).join('')};
  function paintBoard(T){
    const ql=G.q>=5?'OT':'Q'+G.q,m=Math.floor(G.clock/60),s=Math.floor(G.clock%60),toGo=Math.max(1,Math.round(G.lineToGain-G.los));
    const key=[G.score[0],G.score[1],G.q,m,s,G.down,toGo].join();if(T.bk===key)return;T.bk=key;
    const g=T.bc.getContext('2d'),W=512,H=192;g.fillStyle='#0b0d12';g.fillRect(0,0,W,H);g.fillStyle='#181b24';g.fillRect(6,6,W-12,H-12);
    g.textBaseline='middle';g.font='bold 40px "Courier New", monospace';g.fillStyle='#ff9a1f';
    g.textAlign='left';g.fillText(G.teams[0],28,48);g.fillText(G.teams[1],28,104);
    g.textAlign='right';g.fillText(String(G.score[0]),W-28,48);g.fillText(String(G.score[1]),W-28,104);
    g.font='bold 30px "Courier New", monospace';g.textAlign='left';g.fillStyle='#ffd27a';g.fillText(ql+'  '+m+':'+String(s).padStart(2,'0'),28,155);
    g.textAlign='right';g.fillText(['1ST','2ND','3RD','4TH'][G.down-1]+' & '+(G.lineToGain>=100?'GOAL':toGo),W-28,155);
    T.bt.needsUpdate=true;
  }
  function paintField(T,o){
    const g=T.fc.getContext('2d'),W=1024,H=1920,K=16,Y=y=>(110-y)*K;
    g.fillStyle='#2f8a3a';g.fillRect(0,0,W,H);
    for(let y=0;y<100;y+=5){g.fillStyle=((y/5)%2)?'#3b9a46':'#2f8a3a';g.fillRect(0,Y(y+5),W,5*K)}
    for(let i=0;i<9000;i++){g.globalAlpha=.07;g.fillStyle=Math.random()<.5?'#bfe9a0':'#0e3a16';g.fillRect(Math.random()*W,Math.random()*H,1+Math.random()*2,3+Math.random()*7)}g.globalAlpha=1;
    const ez=(y0,y1,k)=>{const c=G.col[k],base=lum(c[0])>170?shade(c[0],.7):shade(c[0],.85);g.fillStyle=base;g.fillRect(0,Y(y1),W,(y1-y0)*K);
      for(let i=0;i<2200;i++){g.globalAlpha=.08;g.fillStyle='#000';g.fillRect(Math.random()*W,Y(y1)+Math.random()*(y1-y0)*K,1+Math.random()*2,3+Math.random()*6)}g.globalAlpha=1;
      g.fillStyle='rgba(0,0,0,.16)';for(let i=0;i<W;i+=64)g.fillRect(i,Y(y1),32,(y1-y0)*K);
      const nm=tn(G.teams[k]).toUpperCase();let fs=120;g.font='900 '+fs+'px Impact, "Arial Black", sans-serif';while(g.measureText(nm).width>W-60&&fs>30){fs-=4;g.font='900 '+fs+'px Impact, "Arial Black", sans-serif'}
      g.textAlign='center';g.textBaseline='middle';g.lineWidth=10;g.strokeStyle='rgba(0,0,0,.35)';g.strokeText(nm,W/2,Y((y0+y1)/2));g.fillStyle=lum(c[1])>lum(base)+40||lum(c[1])<lum(base)-40?c[1]:'#ffffff';g.fillText(nm,W/2,Y((y0+y1)/2))};
    ez(-10,0,o);ez(100,110,1-o);
    g.fillStyle='#fff';
    for(let y=0;y<=100;y+=5){const th=y%10===0?6:3;g.fillRect(0,Y(y)-th/2,W,th)}
    g.globalAlpha=.8;for(let y=1;y<100;y++){if(y%5===0)continue;g.fillRect(24*K-3,Y(y)-1,12,3);g.fillRect(40*K-9,Y(y)-1,12,3)}g.globalAlpha=1;
    g.font='900 64px "Arial Black", Impact, sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillStyle='rgba(255,255,255,.93)';
    for(let y=10;y<=90;y+=10){const n=y<=50?y:100-y;const dy=y<50?-34:y>50?34:0;g.fillText(String(n),150,Y(y)+dy);g.fillText(String(n),W-150,Y(y)+dy)}
    g.beginPath();g.arc(W/2,Y(50),78,0,7);g.fillStyle=G.col[o][0];g.globalAlpha=.9;g.fill();g.globalAlpha=1;g.lineWidth=6;g.strokeStyle='#fff';g.stroke();
    g.fillStyle=lum(G.col[o][0])>150?'#101418':'#ffffff';g.font='900 54px Impact, sans-serif';g.fillText(G.teams[o],W/2,Y(50)+3);
    g.fillStyle='#fff';g.fillRect(0,0,10,H);g.fillRect(W-10,0,10,H);
    T.ft.needsUpdate=true;
  }
  const SKINS=['#f0c8a0','#d5a070','#a8683c','#6b4228'];
  function makeRig(T,e){
    const col=G.col[e.team],jc=hexN(col[0]),acc=hexN(col[1]===col[0]?'#ffffff':col[1]);
    const dk=lum(col[0])<120,pcHex=lum(col[1])>170&&cdist(col[0],col[1])>120?col[1]:(dk?'#eceef2':'#1c202b'),pc=hexN(pcHex);
    const sk=lam(T,hexN(SKINS[Math.floor(e.ph*1.7)%4])),jm=lam(T,jc),pm=lam(T,pc),am=lam(T,acc);
    const hm=T.mats['h'+jc]||(T.mats['h'+jc]=new THREE.MeshPhongMaterial({color:jc,shininess:60,specular:0x555555}));
    const mask=lam(T,0xb9bcc4),shoe=lam(T,0x14161c),glove=lam(T,lum(col[0])<120?0xf2f2f4:0x15171c);
    const G_=(k,f)=>T[k]||(T[k]=f());
    const capT=G_('gCapT',()=>new THREE.CapsuleGeometry(.17,.42,4,8)),capS=G_('gCapS',()=>new THREE.CapsuleGeometry(.135,.4,4,8)),
      capA=G_('gCapA',()=>new THREE.CapsuleGeometry(.12,.3,4,8)),capF=G_('gCapF',()=>new THREE.CapsuleGeometry(.1,.28,4,8));
    const R=new THREE.Group();R.rotation.order='YXZ';
    const inner=new THREE.Group();R.add(inner);
    const legs=[-1,1].map(s=>{const p=new THREE.Group();p.position.set(s*.23,1.1,0);
      const th=new THREE.Mesh(capT,pm);th.position.y=-.3;p.add(th);
      const stripe=new THREE.Mesh(G_('gStr',()=>new THREE.BoxGeometry(.035,.62,.12)),am);stripe.position.set(s*.175,-.3,0);p.add(stripe);
      const kn=new THREE.Group();kn.position.y=-.58;p.add(kn);
      const sh=new THREE.Mesh(capS,pm);sh.position.y=-.27;kn.add(sh);
      const ft=new THREE.Mesh(G_('gShoe',()=>new THREE.BoxGeometry(.26,.16,.5)),shoe);ft.position.set(0,-.58,.08);kn.add(ft);
      p.userData.knee=kn;inner.add(p);return p});
    const torso=new THREE.Group();torso.position.y=1.08;inner.add(torso);
    const tb=new THREE.Mesh(G_('gTor',()=>{const gg=new THREE.CylinderGeometry(.5,.4,1.0,12);gg.scale(1,1,.62);return gg}),jm);tb.position.y=.5;torso.add(tb);
    const pads=new THREE.Mesh(G_('gPad',()=>{const gg=new THREE.SphereGeometry(.5,12,8);gg.scale(1.3,.5,.86);return gg}),jm);pads.position.y=1.0;torso.add(pads);
    const belt=new THREE.Mesh(G_('gBelt',()=>new THREE.CylinderGeometry(.42,.42,.12,12).scale(1,1,.64)),pm);belt.position.y=.04;torso.add(belt);
    const neck=new THREE.Mesh(G_('gNeck',()=>new THREE.CylinderGeometry(.12,.15,.2,8)),sk);neck.position.y=1.2;torso.add(neck);
    const head=new THREE.Mesh(G_('gHead',()=>{const gg=new THREE.SphereGeometry(.37,16,12);gg.scale(1,1.06,1.12);return gg}),hm);head.position.y=1.5;torso.add(head);
    const hs=new THREE.Mesh(G_('gHs',()=>new THREE.BoxGeometry(.08,.04,.78)),am);hs.position.set(0,1.88,0);torso.add(hs);
    const fm=new THREE.Mesh(G_('gFm',()=>new THREE.TorusGeometry(.18,.02,6,16)),mask);fm.position.set(0,1.42,.38);fm.scale.set(1,.9,1);torso.add(fm);
    const fm2=new THREE.Mesh(G_('gFm2',()=>new THREE.BoxGeometry(.34,.025,.04)),mask);fm2.position.set(0,1.38,.41);torso.add(fm2);
    const arms=[-1,1].map(s=>{const p=new THREE.Group();p.position.set(s*.7,1.0,0);
      const ua=new THREE.Mesh(capA,jm);ua.position.y=-.26;p.add(ua);
      const el=new THREE.Group();el.position.y=-.5;p.add(el);
      const fa=new THREE.Mesh(capF,sk);fa.position.y=-.2;el.add(fa);
      const gl=new THREE.Mesh(G_('gGlove',()=>new THREE.SphereGeometry(.125,8,6)),glove);gl.position.y=-.42;el.add(gl);
      p.userData.elbow=el;torso.add(p);return p});
    // jersey numbers
    const NR={qb:[1,19],rb:[20,39],wr:[80,89],te:[80,89],ol:[60,79],dl:[90,99],lb:[50,59],cb:[20,39],s:[20,39]}[e.role]||[1,99];
    const num=Math.floor(NR[0]+Math.min(.999,e.ph/6.3)*(NR[1]-NR[0]+1)),ncol=lum(col[0])<140?'#ffffff':'#101418',nk=num+ncol;
    T.nt=T.nt||{};if(!T.nt[nk]){const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');g.font='900 46px Impact, "Arial Black", sans-serif';g.textAlign='center';g.textBaseline='middle';g.lineWidth=5;g.strokeStyle=ncol==='#ffffff'?'rgba(0,0,0,.4)':'rgba(255,255,255,.35)';g.strokeText(String(num),32,34);g.fillStyle=ncol;g.fillText(String(num),32,34);T.nt[nk]=new THREE.CanvasTexture(c)}
    const nm=new THREE.MeshBasicMaterial({map:T.nt[nk],transparent:true});
    const nb=new THREE.Mesh(G_('gNum',()=>new THREE.PlaneGeometry(.8,.8)),nm);nb.position.set(0,.55,-.28);nb.rotation.y=Math.PI;torso.add(nb);
    const nf=new THREE.Mesh(T.gNum,nm);nf.position.set(0,.55,.28);nf.scale.setScalar(.7);torso.add(nf);
    R.traverse(o=>{if(o.isMesh&&o.material!==nm)o.castShadow=true});
    const sh=new THREE.Mesh(T.shGeo,T.shMat);sh.rotation.x=-Math.PI/2;sh.position.y=.04;T.sc.add(sh);
    const ring=new THREE.Mesh(T.ringGeo,T.ringMat);ring.rotation.x=-Math.PI/2;ring.position.y=.07;ring.visible=false;
    T.sc.add(R);R.add(ring);
    return{R,inner,legs,torso,arms,sh,ring,jm,jc,gray:false,yaw:e.team===G.off?Math.PI:0,mats:[tb,pads,arms[0].children[0],arms[1].children[0]]};
  }
  function sync3(hlf){
    const T=T3,o=G.off,b=G.ball,key=o+'|'+G.teams.join()+'|'+G.col.join();
    if(T.offKey!==key){T.offKey=key;paintField(T,o);T.rigs.forEach(r=>{T.sc.remove(r.R);T.sc.remove(r.sh)});T.rigs.clear()}
    paintBoard(T);
    const seen=new Set();
    G.ents.forEach(e=>{
      let r=T.rigs.get(e);if(!r){r=makeRig(T,e);T.rigs.set(e,r)}seen.add(e);
      const v=Math.hypot(e.vx,e.vy),run=Math.min(1,v/6);
      if(v>.6){const ty=Math.atan2(e.vx,-e.vy);let d=ty-r.yaw;while(d>Math.PI)d-=2*Math.PI;while(d<-Math.PI)d+=2*Math.PI;r.yaw+=d*.35}
      else{const ty=e.team===o?Math.PI:0;let d=ty-r.yaw;while(d>Math.PI)d-=2*Math.PI;while(d<-Math.PI)d+=2*Math.PI;r.yaw+=d*.08}
      const ph=G.t*13+e.ph,sw=Math.sin(ph)*.95*run;
      r.R.position.set(e.x,0,-e.y);r.R.rotation.y=r.yaw;
      let lift=0,pitch=0,armUp=0;
      if(G.phase==='banner'&&e===G.endCar){const k=Math.min(1,(G.bt||0)*5);if(G.endTD){armUp=1;lift=Math.abs(Math.sin((G.bt||0)*9))*.55}else{pitch=-1.45*k;lift=.28*k}}
      if(e.jt>0){lift=Math.min(1.1,e.jt*3.2);armUp=1}
      if(e.dive>0){pitch=1.35;lift=.35}
      else if(e.stun>0){pitch=.75;lift=-.05}
      r.legs[0].rotation.x=sw;r.legs[1].rotation.x=-sw;
      r.legs[0].userData.knee.rotation.x=.12+Math.max(0,-sw)*1.2*run;r.legs[1].userData.knee.rotation.x=.12+Math.max(0,sw)*1.2*run;
      r.arms[0].rotation.x=-sw*.9-armUp*2.5;r.arms[1].rotation.x=sw*.9-armUp*2.5;
      r.arms[0].userData.elbow.rotation.x=-.25-run*.9;r.arms[1].userData.elbow.rotation.x=-.25-run*.9;
      r.torso.rotation.x=.12+.3*run;
      if(b.holder===e){r.arms[1].rotation.x=-1.1;r.arms[1].rotation.z=-.3;r.arms[1].userData.elbow.rotation.x=-1.1}else r.arms[1].rotation.z=0;
      r.R.rotation.x=pitch;r.R.position.y=lift+(run*Math.abs(Math.sin(ph))*.1);
      r.sh.position.set(e.x,.04,-e.y);r.sh.scale.setScalar(1-Math.min(.45,lift*.3));
      const gray=e.stun>0&&e.dive<=0;
      if(gray!==r.gray){r.gray=gray;const m=gray?lam(T,0x8c8c8c):r.jm;r.mats.forEach(x=>x.material=m)}
      r.ring.visible=hlf(e);
      if(r.ring.visible){r.ring.rotation.z=G.t*2;}
    });
    T.rigs.forEach((r,e)=>{if(!seen.has(e)){T.sc.remove(r.R);T.sc.remove(r.sh);T.rigs.delete(e)}});
    // ball
    const bl=T.ball;
    if(b.holder){const h=b.holder,r=T.rigs.get(h),yaw=r?r.yaw:0,lx=.55,lz=.4;
      bl.position.set(h.x+lx*Math.cos(yaw)+lz*Math.sin(yaw),1.55+(r?r.R.position.y:0),-h.y-lx*Math.sin(yaw)+lz*Math.cos(yaw));
      bl.rotation.set(0,yaw,0);T.bsh.visible=false}
    else{const z=b.air?ZV(b.z||0):.32;bl.position.set(b.x,z,-b.y);
      if(b.air){const vx=(b.tx-b.x),vy=(b.ty-b.y);bl.rotation.set(-.5,Math.atan2(vx,-vy),G.t*14)}else bl.rotation.set(.3,0,0);
      T.bsh.visible=true;T.bsh.position.set(b.x,.06,-b.y);T.bsh.scale.setScalar(b.air?Math.max(.5,1-ZV(b.z||0)*.08):1)}
    if(G.kick&&G.kick.t<G.kick.T&&G.phase==='banner'){const K=G.kick,k=K.t/K.T;
      bl.position.set(K.x0+(K.x1-K.x0)*k,Math.sin(k*Math.PI)*K.h+.5,-(K.y0+(K.y1-K.y0)*k));bl.rotation.set(k*14,0,0);T.bsh.visible=true;T.bsh.position.set(bl.position.x,.06,bl.position.z)}
    // down lines
    T.los.position.z=-G.los;T.ltg.visible=G.lineToGain<100;T.ltg.position.z=-G.lineToGain;
    // camera: low chase cam behind the offense, or a high wide view
    const fy=G.cam,tx=b.holder?b.holder.x:(b.x==null?32:b.x),lead=0,wide=T.wide,sk=G.shake>0?G.shake:0;
    const want=clamp(tx+lead,wide?18:20,wide?46:44);
    T.camx+=(want-T.camx)*.3;{const lim=wide?10:8;if(T.camx-want>lim)T.camx=want+lim;else if(want-T.camx>lim)T.camx=want-lim}
    const fov=wide?72:76;if(T.cam.fov!==fov){T.cam.fov=fov;T.cam.updateProjectionMatrix()}
    const jx=(Math.random()-.5)*sk*1.6,jy=(Math.random()-.5)*sk*1.2;
    if(wide){T.cam.position.set(T.camx+jx,27+jy,-(fy-34));T.cam.lookAt(T.camx,0,-(fy+6))}
    else{T.cam.position.set(T.camx+jx,15+jy,-(fy-27));T.cam.lookAt(T.camx,0,-(fy+8))}
    T.cam.updateMatrixWorld();T.cam.matrixWorldInverse.copy(T.cam.matrixWorld).invert();
    // sun + shadow follow the action
    T.sun.position.set(T.camx-14,36,-(fy)+18);T.sun.target.position.set(T.camx,0,-(fy+4));T.sun.target.updateMatrixWorld();
    T.r.render(T.sc,T.cam);
  }
  // project a world point (x,y yards, z height) to canvas coordinates
  function P3(x,y,z){
    if(!T3||!T3.on)return[sx(x),sy(y)-Math.round((z||0)*PX*.9)];
    T3.v.set(x,z||0,-y).project(T3.cam);
    return[(T3.v.x*.5+.5)*CW,(-T3.v.y*.5+.5)*CH];
  }
  // pixels per yard at a ground spot (for marker sizes)
  function K3(x,y){if(!T3||!T3.on)return PX;const a=P3(x,y,0),b=P3(x+1,y,0);return Math.abs(b[0]-a[0])}
  function unproj(px,py){
    const T=T3,nx=px/CW*2-1,ny=-(py/CH*2-1);
    const p=new THREE.Vector3(nx,ny,.5).unproject(T.cam),c=T.cam.position,d=p.sub(c).normalize();
    const t=(1.3-c.y)/d.y;return{x:c.x+d.x*t,y:-(c.z+d.z*t)};
  }

  /* ------------------------------ rendering ------------------------------ */
  const SKIN='#e0a878';
  function sx(x){return Math.round(x*PX)}
  function sy(y){return Math.round(CH/2-(y-G.cam)*PX)}
  function drawField(){
    const o=G.off,c=G.col;
    ctx.fillStyle='#2e7a38';ctx.fillRect(0,0,CW,CH);
    for(let y=-10;y<110;y+=5){const a=sy(y+5),h=sy(y)-a;if(a>CH||a+h<0)continue;ctx.fillStyle=(Math.floor((y+10)/5)%2)?'#34853f':'#2e7a38';ctx.fillRect(0,a,CW,h)}
    // end zones
    const ez=(y0,y1,k)=>{const a=sy(y1),h=sy(y0)-a;ctx.fillStyle=c[k][0];ctx.fillRect(0,a,CW,h);ctx.fillStyle=c[k][1];ctx.font='bold 9px monospace';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(tn(G.teams[k]).toUpperCase(),CW/2,a+h/2)};
    ez(-10,0,o);ez(100,110,1-o);
    ctx.fillStyle='#fff';
    for(let y=0;y<=100;y+=5){const yy=sy(y);if(yy<-2||yy>CH+2)continue;ctx.fillRect(0,yy,CW,y%10===0?2:1);
      if(y%10===0&&y>0&&y<100){const n=y<=50?y:100-y;ctx.font='bold 8px monospace';ctx.fillStyle='#e9fbe9';ctx.textAlign='left';ctx.fillText(String(n),4,yy+9);ctx.textAlign='right';ctx.fillText(String(n),CW-4,yy+9);ctx.fillStyle='#fff'}}
    ctx.fillRect(0,0,2,CH);ctx.fillRect(CW-2,0,2,CH);
    ctx.globalAlpha=.55;for(let y=0;y<100;y++){const yy=sy(y);if(yy<-2||yy>CH+2)continue;ctx.fillRect(sx(24),yy,2,1);ctx.fillRect(sx(40),yy,2,1)}ctx.globalAlpha=1;
    // LOS and first down
    if(G.phase!=='banner'||true){ctx.fillStyle='#3a7bff';ctx.fillRect(0,sy(G.los)-1,CW,2);
      if(G.lineToGain<100){ctx.fillStyle='#ffd23a';ctx.fillRect(0,sy(G.lineToGain)-1,CW,2)}}
  }
  function drawPlayer(e,col,hl,hasBall){
    const x=sx(e.x),y=sy(e.y);if(y<-12||y>CH+12)return;
    const run=Math.hypot(e.vx,e.vy)>.5,fr=run?Math.floor((G.t*10+e.ph)%2):0,jt=e.jt>0;
    ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(x-3,y+2,7,2);
    ctx.fillStyle='#e8e8ee';ctx.fillRect(x-2,y-1+(fr?0:0),2,3+(fr?1:0));ctx.fillRect(x+1,y-1,2,3+(fr?0:1));// legs/pants
    ctx.fillStyle=e.stun>0&&e.dive<=0?'#8c8c8c':col[0];ctx.fillRect(x-3,y-5,7,5); // jersey
    ctx.fillStyle=col[1];ctx.fillRect(x-3,y-5,7,1);
    ctx.fillStyle=SKIN;ctx.fillRect(x-1,y-7,3,2);
    ctx.fillStyle=col[1]===col[0]?'#fff':col[1];ctx.fillRect(x-2,y-9,5,2);ctx.fillRect(x-2,y-7,1,1);
    if(jt){ctx.fillStyle='rgba(255,255,255,.75)';ctx.fillRect(x-4,y-10,9,1)}
    if(e.dive>0){ctx.fillStyle='rgba(255,255,255,.5)';ctx.fillRect(x-4,y+1,9,1)}
    if(hl){ctx.fillStyle='#ffe14a';ctx.fillRect(x-1,y-17,3,1);ctx.fillRect(x-2,y-16,5,1);ctx.fillRect(x-3,y-15,7,1);ctx.fillRect(x-4,y-14,9,1);ctx.fillStyle='#000';ctx.fillRect(x-4,y-13,9,1);ctx.strokeStyle='#ffe14a';ctx.strokeRect(x-5.5,y-10.5,11,13)}
  }
  function render(){
    if(!G)return;
    if(T3===null)init3();
    const d3=!!T3;if(d3)T3.on=true;
    const o=G.off,cO=G.col[o],cD=G.col[1-o],b=G.ball,tgt=G.wrs&&G.wrs[G.target];
    const hum=human(o)&&!b.air?(b.holder||G.qb):null;
    const hl=e=>(e.team===o&&e===hum)||e===G.ctrlD||(b.air&&G.tgt===e&&human(o)&&e.team===o);
    const Zq=z=>d3?ZV(z):z;
    if(d3){ctx.setTransform(S3,0,0,S3,0,0);ctx.clearRect(0,0,CW,CH);sync3(hl)}
    else{
      drawField();
      const all=G.ents.slice().sort((p,q)=>q.y-p.y);
      all.forEach(e=>{const isO=e.team===o;drawPlayer(e,isO?cO:cD,hl(e),false)});
    }
    // marker arrows over highlighted players (3D)
    if(d3)G.ents.forEach(e=>{if(!hl(e))return;const [x,y]=P3(e.x,e.y,3.1);ctx.fillStyle='#ffe14a';ctx.strokeStyle='#000';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-4,y-6);ctx.lineTo(x+4,y-6);ctx.closePath();ctx.fill();ctx.stroke()});
    // target marker for qb
    if(human(o)&&G.phase==='live'&&b.holder===G.qb&&!G.thrown&&!G.play.startsWith('run')&&tgt){const [x,y]=P3(tgt.x,tgt.y,.7),s=K3(tgt.x,tgt.y)/PX;ctx.strokeStyle='#fff';ctx.lineWidth=1;ctx.strokeRect(x-6*s,y-7*s,12*s,14*s)}
    // ball (2D only; 3D draws a real ball)
    if(!d3&&(G.phase==='live'||G.phase==='banner'||G.phase==='select')){
      const hx=b.holder?b.holder.x:b.x,hy=b.holder?b.holder.y:b.y;
      const z=b.air?(b.z||0):0,bx=sx(hx)+(b.holder?3:0),by=sy(hy)-(b.holder?4:0)-Math.round(z*PX*.9);
      if(b.air){ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(sx(b.x)-2,sy(b.y),5,2)}
      ctx.fillStyle='#7a4a1e';ctx.fillRect(bx-2,by-1,5,3);ctx.fillStyle='#fff';ctx.fillRect(bx,by,1,1)}
    // ---- receiver routes ----
    const drawRoutes=(wrs,cols,live)=>{
      wrs.forEach((w,i)=>{if(!w.route||!w.route.length||!w.r0)return;const pts=[[w.r0[0],w.r0[1]]].concat(w.route);
        const tgtw=G.wrs[G.target]===w&&live,col=tgtw?'#ffffff':cols;
        for(let k=0;k<pts.length-1;k++){
          const done=live&&w.ri>k,A=P3(pts[k][0],pts[k][1],d3?.06:0),B=P3(pts[k+1][0],pts[k+1][1],d3?.06:0),a=A[0],bx=B[0],ya=A[1],yb=B[1];
          ctx.globalAlpha=done?.18:(tgtw?.95:.6);ctx.fillStyle=col;
          const n=Math.max(2,Math.round(Math.hypot(bx-a,yb-ya)/4));
          for(let j=0;j<n;j++){if(j%2)continue;const t=j/n;ctx.fillRect(a+(bx-a)*t,ya+(yb-ya)*t,2,2)}}
        const e=pts[pts.length-1],p=pts[pts.length-2],E=P3(e[0],e[1],d3?.06:0),Pp=P3(p[0],p[1],d3?.06:0),ex=E[0],ey=E[1],ang=Math.atan2(ey-Pp[1],ex-Pp[0]);
        ctx.globalAlpha=tgtw?1:.8;ctx.fillStyle=col;ctx.beginPath();ctx.moveTo(ex+Math.cos(ang)*4,ey+Math.sin(ang)*4);ctx.lineTo(ex+Math.cos(ang+2.5)*4,ey+Math.sin(ang+2.5)*4);ctx.lineTo(ex+Math.cos(ang-2.5)*4,ey+Math.sin(ang-2.5)*4);ctx.fill();
        ctx.globalAlpha=1;ctx.font='bold 7px monospace';ctx.textAlign='center';ctx.fillStyle='rgba(0,0,0,.7)';ctx.fillText(String(i+1),ex+1,ey-5);ctx.fillStyle=col;ctx.fillText(String(i+1),ex,ey-6)});ctx.globalAlpha=1};
    if(G.wrs&&G.wrs.length&&G.play&&!G.play.startsWith('run')&&G.phase==='live'&&!G.thrown&&b.holder===G.qb){drawRoutes(G.wrs,'#ffe14a',true)}
    if(G.phase==='select'&&G.preview&&G.wrs&&G.wrs[0].route&&G.wrs[0].route.length||G.phase==='select'&&G.preview==='pass5')drawRoutes(G.wrs,'#ffe14a',false);
    // ---- QB aim preview, flight path, yard readouts ----
    if(G.phase==='live'){
      const arcPt=(ax,ay,bx,by,k,dd)=>({x:ax+(bx-ax)*k,y:ay+(by-ay)*k,z:Math.sin(k*Math.PI)*(2+dd*.08)});
      const dash=(ax,ay,bx,by,dd,col,alpha,full)=>{ctx.fillStyle=col;ctx.globalAlpha=alpha;for(let i=1;i<=20;i++){if(!full&&i%2)continue;const p=arcPt(ax,ay,bx,by,i/20,dd),q=P3(p.x,p.y,Zq(p.z));ctx.fillRect(q[0],q[1],2,2)}ctx.globalAlpha=1};
      const qbHold=human(o)&&b.holder===G.qb&&!G.thrown&&!G.play.startsWith('run');
      if(qbHold){
        G.wrs.forEach((w,i)=>{const ay=Math.round(w.y-G.los),q=P3(w.x,w.y,2.7);ctx.font='bold 7px monospace';ctx.textAlign='center';ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillText(ay+'',q[0]+1,q[1]-1);ctx.fillStyle=i===G.target?'#fff':'rgba(255,255,255,.55)';ctx.fillText(ay+'',q[0],q[1]-2)});
        const w=G.wrs[G.target];
        if(w){const P=predictLand(w);let open=99;G.D.forEach(df=>{open=Math.min(open,dist(df,{x:P.tx,y:P.ty}))});
          const col=open>3.2?'#6dff8a':open>2.1?'#ffe14a':'#ff6b5c';
          dash(G.qb.x,G.qb.y,P.tx,P.ty,P.d,col,.9,false);
          const q=P3(P.tx,P.ty,Zq(0)),px=q[0],py=q[1],s=K3(P.tx,P.ty)/PX;ctx.strokeStyle=col;ctx.lineWidth=1;ctx.strokeRect(px-4.5*s,py-3.5*s,9*s,7*s);
          const air=Math.round(P.ty-G.los);ctx.font='bold 8px monospace';ctx.textAlign='center';const lab=air+' YD'+(open>3.2?' OPEN':open>2.1?'':' TIGHT');
          const lx=clamp(px,26,CW-26);ctx.fillStyle='rgba(0,0,0,.65)';ctx.fillText(lab,lx+1,py-7);ctx.fillStyle=col;ctx.fillText(lab,lx,py-8)}
      }
      if(b.air&&b.rel){
        dash(b.rel.x,b.rel.y,b.tx,b.ty,b.dist,'#ffffff',.45,true);
        (b.trail||[]).forEach((p,i,a)=>{ctx.globalAlpha=.12+.5*i/a.length;ctx.fillStyle='#ffe9b0';const q=P3(p[0],p[1],Zq(p[2]));ctx.fillRect(q[0]-1,q[1]-1,2,2)});ctx.globalAlpha=1;
        const k=Math.min(1,b.t/b.T),q=P3(b.tx,b.ty,Zq(0)),px=q[0],py=q[1],s=K3(b.tx,b.ty)/PX,r=(3+Math.round((1-k)*5))*s;ctx.strokeStyle='#fff';ctx.globalAlpha=.8;ctx.strokeRect(px-r,py-r*.7,r*2,r*1.4);ctx.globalAlpha=1;
        const air=Math.round(b.ty-G.los);ctx.font='bold 8px monospace';ctx.textAlign='center';const lx=clamp(px,28,CW-28);ctx.fillStyle='rgba(0,0,0,.65)';ctx.fillText('AIR '+air+' YD',lx+1,py-9);ctx.fillStyle='#fff';ctx.fillText('AIR '+air+' YD',lx,py-10)}
      const h=b.holder;
      if(h&&h.team===o&&h!==G.qb||h&&h===G.qb&&h.y>G.los+.5){
        const gain=Math.round(h.y-G.los),first=h.y>=G.lineToGain,txt=first?'1ST DOWN +'+gain:(gain>=0?'+':'')+gain+' YD';
        const hp=P3(h.x,h.y,3.3);ctx.font='bold 8px monospace';ctx.textAlign='center';const hx2=clamp(hp[0],24,CW-24),hy2=hp[1]-(d3?8:0);ctx.fillStyle='rgba(0,0,0,.7)';ctx.fillRect(hx2-ctx.measureText(txt).width/2-2,hy2-7,ctx.measureText(txt).width+4,9);ctx.fillStyle=first?'#ffd23a':gain<0?'#ff8a7a':'#fff';ctx.fillText(txt,hx2,hy2)}
      // mini field strip on the right edge: where the ball is on the 100 yards
      const sh=CH-40,s0=20,my=y=>s0+sh-(clamp(y,0,100)/100)*sh;
      ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(CW-7,s0-2,6,sh+4);ctx.fillStyle='rgba(255,255,255,.25)';for(let y=0;y<=100;y+=10)ctx.fillRect(CW-7,Math.round(my(y)),6,1);
      ctx.fillStyle='#3a7bff';ctx.fillRect(CW-8,Math.round(my(G.los)),8,1);if(G.lineToGain<100){ctx.fillStyle='#ffd23a';ctx.fillRect(CW-8,Math.round(my(G.lineToGain)),8,1)}
      ctx.strokeStyle='rgba(255,255,255,.35)';ctx.strokeRect(CW-7.5,Math.round(my(G.cam+VH/2)),6,Math.round(VH/100*sh));
      const bp=b.holder||{y:b.y};ctx.fillStyle='#fff';ctx.fillRect(CW-6,Math.round(my(bp.y))-1,4,3)}
    // power meters + effects
    if(G.phase==='live'){
      for(let t=0;t<2;t++){const x=t===0?3:CW-3-40,v=G.pm[t];ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(x-1,CH-9,42,6);ctx.fillStyle=G.col[t][0];ctx.fillRect(x,CH-8,Math.round(40*v),4);ctx.fillStyle='rgba(255,255,255,.7)';ctx.fillRect(x+Math.round(40*.2),CH-8,1,4);ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(x-1,CH-3,42,3);ctx.fillStyle='#6ee7ff';ctx.fillRect(x,CH-2,Math.round(40*G.bs[t]),1)}
      ctx.font='bold 9px monospace';ctx.textAlign='center';
      G.fx.forEach(f=>{const a=1-f.t/.95,q=P3(f.x,f.y,2.3),x=q[0],y=q[1]-f.t*16;ctx.globalAlpha=Math.max(0,a);ctx.fillStyle='#000';ctx.fillText(f.txt,x+1,y+1);ctx.fillStyle=f.col;ctx.fillText(f.txt,x,y)});
      ctx.globalAlpha=1;ctx.textAlign='left'}
  }
  function renderScore(){
    if(!G)return;const t=G.teams,c=G.col,m=Math.floor(G.clock/60),s=Math.floor(G.clock%60),o=G.off;
    const qn=G.q>=5?'OT':'Q'+G.q;
    ui.sdscore.innerHTML=`<div class="sdt${o===0?' has':''}" style="--tc:${c[0][0]};--tc2:${c[0][1]}"><span class="sdn">${tn(t[0])}${G.om===1?' (you)':''}</span><b>${G.score[0]}</b></div>
      <div class="sdmid"><b>${qn} ${m}:${String(s).padStart(2,'0')}</b><span>${G.msg||''}</span></div>
      <div class="sdt${o===1?' has':''}" style="--tc:${c[1][0]};--tc2:${c[1][1]}"><b>${G.score[1]}</b><span class="sdn">${tn(t[1])}${G.om===1?' (CPU)':''}</span></div>`;
  }

  /* ------------------------------ loop + input ------------------------------ */
  function loop(ts){
    if(dead)return;raf=requestAnimationFrame(loop);
    if(!last)last=ts;let dt=Math.min(.05,(ts-last)/1000);last=ts;
    pollKeys();
    if(G&&G.fast&&!stage.hidden&&G.phase!=='final'){for(let i=0;i<1500&&G.phase!=='final';i++){if(G.phase==='select')snap(cpuCall());step(1/60)}acc=0;if(G.phase==='final'){G.fast=false;showSimBtn()}renderScore();render();return}
    if(G&&!stage.hidden){acc+=dt;let n=0;while(acc>=1/60&&n<6){step(1/60);acc-=1/60;n++}if(n===6)acc=0;
      if(G.phase==='live')renderScoreClock();updatePad();render()}
  }
  let lastClk=-1;function renderScoreClock(){const s=Math.ceil(G.clock);if(s!==lastClk){lastClk=s;renderScore()}}
  function pollKeys(){
    const k=keys;
    if(G&&G.mode===2){
      inp[0].dx=(k.d?1:0)-(k.a?1:0);inp[0].dy=(k.w?1:0)-(k.s?1:0);
      inp[1].dx=(k.arrowright?1:0)-(k.arrowleft?1:0);inp[1].dy=(k.arrowup?1:0)-(k.arrowdown?1:0);
    }else{
      inp[0].dx=((k.d||k.arrowright)?1:0)-((k.a||k.arrowleft)?1:0)+pad.dx;inp[0].dy=((k.w||k.arrowup)?1:0)-((k.s||k.arrowdown)?1:0)+pad.dy;
      inp[0].dx=clamp(inp[0].dx,-1,1);inp[0].dy=clamp(inp[0].dy,-1,1);
    }
  }
  function kd(e){
    if(dead||!G||ui.sdgame.hidden)return;const t=e.target&&e.target.tagName;if(t==='INPUT'||t==='TEXTAREA'||document.querySelector('.rpov:not([hidden])'))return;
    const key=e.key.toLowerCase();
    const ctrl=['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright',' ','f','g','h','j','e','k','l',';',"'",'/'];
    if(ctrl.includes(key)&&G.phase!=='final')e.preventDefault();
    if(e.repeat){keys[key]=true;return}
    keys[key]=true;
    if(G.mode===2){
      if(key==='f')inp[0].a=true;if(key==='g')inp[0].b=true;if(key==='h')inp[0].c=true;if(key==='j')inp[0].d=true;if(key==='e')inp[0].e=true;if(key==='/')inp[1].e=true;if(key==='k')inp[1].a=true;if(key==='l')inp[1].b=true;if(key===';')inp[1].c=true;if(key==="'")inp[1].d=true;
    }else{if(key==='f'||key===' ')inp[0].a=true;if(key==='g'||key==='shift')inp[0].b=true;if(key==='h')inp[0].c=true;if(key==='j')inp[0].d=true;if(key==='e')inp[0].e=true}
    if(G.phase==='select'&&/^[0-9]$/.test(key)){
      const pt=ui.sdplays.querySelector('[data-pt]');if(pt){if(key==='1'||key==='2'){ui.sdplays.querySelector('[data-pt="'+key+'"]').click()}return}
      const dcb=ui.sdplays.querySelectorAll('[data-dc]');
      if(dcb.length){if(+key>=1&&+key<=5)dcb[+key-1].click();else if(key==='6')ui.sdplays.querySelector('[data-pl="auto"]').click();return}
      const bt=ui.sdplays.querySelectorAll('[data-pl]');const want=PLAYORD.concat(['punt','fg'])[key==='0'?9:+key-1];const hit=[...bt].find(x=>x.dataset.pl===want);if(hit)hit.click()}
    if(G.phase==='select'&&(key==='enter')){const h=ui.sdplays.querySelector('[data-pl="auto"]');if(h)h.click()}
  }
  function ku(e){keys[e.key.toLowerCase()]=false}
  window.addEventListener('keydown',kd);window.addEventListener('keyup',ku);
  let ptype='mouse';ui.sdplays.addEventListener('pointerdown',e=>{ptype=e.pointerType||'mouse'});
  const preview=pl=>{if(!G||G.phase!=='select'||!G.wrs)return;if(/^pass/.test(pl)){setRoutes(pl);G.preview=pl}else{if(G.preview){G.wrs=G.rcv.concat([G.te]);G.wrs.forEach(w=>{w.route=null;w.blk=false})}G.preview=null}
    ui.sdplays.querySelectorAll('[data-pl]').forEach(x=>x.classList.toggle('pv',x.dataset.pl===G.preview))};
  ui.sdplays.addEventListener('pointerover',e=>{const b=e.target.closest('[data-pl]');if(b&&e.pointerType==='mouse')preview(b.dataset.pl)});
  ui.sdplays.addEventListener('focusin',e=>{const b=e.target.closest('[data-pl]');if(b&&b.matches(':focus-visible'))preview(b.dataset.pl)});
  ui.sdplays.addEventListener('click',e=>{
    const dcb=e.target.closest('[data-dc]');if(dcb&&G){G.dcall=dcb.dataset.dc;ui.sdplays.querySelectorAll('[data-dc]').forEach(x=>x.classList.toggle('sel',x===dcb));return}
    const ptb=e.target.closest('[data-pt]');if(ptb&&G&&G.pat){if(ptb.dataset.pt==='1')patKick();else patGo();return}
    const b=e.target.closest('[data-pl]');if(!b||!G||G.phase!=='select')return;const pl=b.dataset.pl;
    // on touch screens a pass play shows its routes first; tap again to snap
    if((ptype==='touch'||ptype==='pen'||(window.matchMedia&&matchMedia('(pointer: coarse)').matches&&ptype!=='mouse'))&&/^pass/.test(pl)&&G.preview!==pl){preview(pl);return}
    G.preview=null;snap(pl)});
  const muteB=stage.querySelector('#sdmute');const muteTxt=()=>{muteB.textContent='Sound: '+(snd?'on':'off')};muteTxt();
  muteB.addEventListener('click',()=>{snd=!snd;try{localStorage.setItem('gm.sd.snd',snd?'1':'0')}catch(e){}muteTxt();if(snd)sfx('catch')});
  const camB=stage.querySelector('#sdcam');const camTxt=()=>{camB.textContent='Camera: '+((T3&&T3.wide)||(!T3&&camPref())?'wide':'chase')};camTxt();
  camB.addEventListener('click',()=>{const w=!(T3?T3.wide:camPref());if(T3)T3.wide=w;try{localStorage.setItem('gm.sd.cam',w?'wide':'chase')}catch(e){}camTxt()});
  function showSimBtn(){const b=stage.querySelector('#sdsim');if(b)b.hidden=!G||G.phase==='final'||G.fast}
  stage.querySelector('#sdsim').addEventListener('click',()=>{if(!G||G.phase==='final')return;if(G.pat){G.mode=0;patKick()}G.fast=true;G.mode=0;G.ctrlD=null;pad.dx=0;pad.dy=0;joy.hidden=true;hint.hidden=true;ui.sdover.hidden=true;showSimBtn();
    G.msg='Simulating...';renderScore()});
  ui.sdover.addEventListener('click',e=>{const a=e.target.closest('[data-act]');if(!a)return;if(a.dataset.act==='shub'){showSeason();return}if(a.dataset.act==='again')newGame(G.teams[0],G.teams[1],G.om,G.lvl,G.qlen);else{G=null;showMenu()}});
  // touch controls: drag anywhere on the field = joystick, tap a receiver = throw, A/B buttons
  const padEl=stage.querySelector('#sdpad'),joy=stage.querySelector('#sdjoy'),hint=stage.querySelector('#sdhint');
  let jp=null;
  function world(e){const r=cv.getBoundingClientRect(),px=(e.clientX-r.left)*CW/r.width,py=(e.clientY-r.top)*CH/r.height;if(T3&&T3.on)return unproj(px,py);return{x:px/PX,y:G.cam+(CH/2-py)/PX}}
  cv.addEventListener('pointerdown',e=>{if(!G||G.phase==='final'||e.pointerType==='mouse'&&e.button!==0)return;e.preventDefault();
    try{cv.setPointerCapture(e.pointerId)}catch(er){}
    jp={id:e.pointerId,x:e.clientX,y:e.clientY,t:performance.now(),moved:false,ox:e.clientX,oy:e.clientY};hideHint()});
  cv.addEventListener('pointermove',e=>{if(!jp||e.pointerId!==jp.id)return;
    const dx=e.clientX-jp.ox,dy=e.clientY-jp.oy,m=Math.hypot(dx,dy);
    if(m>10)jp.moved=true;
    if(jp.moved){const R=48,mm=Math.min(m,R),nx=dx/(m||1),ny=dy/(m||1),a=mm/R;
      pad.dx=a>.25?nx*a:0;pad.dy=a>.25?-ny*a:0;
      if(m>R){jp.ox=e.clientX-nx*R;jp.oy=e.clientY-ny*R}   // joystick follows the thumb
      const wr=ui.sdwrap.getBoundingClientRect();joy.hidden=false;joy.style.left=(jp.ox-wr.left)+'px';joy.style.top=(jp.oy-wr.top)+'px';
      const k=joy.firstElementChild;k.style.transform=`translate(${nx*mm}px,${ny*mm}px)`}});
  const up=e=>{if(!jp||e.pointerId!==jp.id)return;
    if(!jp.moved&&performance.now()-jp.t<450&&G&&G.phase==='live')tapAt(world(e));
    jp=null;pad.dx=0;pad.dy=0;joy.hidden=true};
  cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
  cv.addEventListener('contextmenu',e=>e.preventDefault());
  function tapAt(w){
    if(!human(G.off)||G.mode===2&&false)return;
    const b=G.ball;
    if(b.holder===G.qb&&!G.thrown&&!G.play.startsWith('run')){
      let best=null,bd=99;G.wrs.forEach((r,i)=>{const d=Math.hypot(r.x-w.x,r.y-w.y);if(d<bd){bd=d;best=i}});
      if(best!==null&&bd<7){G.target=best;throwTo(G.wrs[best]);return}}
    inp[G.mode===2?G.off:0].a=true;
  }
  padEl.addEventListener('pointerdown',e=>{const b=e.target.closest('button');if(!b)return;e.preventDefault();e.stopPropagation();
    const side=G.mode===2?0:0;inp[side][b.dataset.b]=true});
  padEl.addEventListener('contextmenu',e=>e.preventDefault());
  function hideHint(){hint.hidden=true}
  function showHint(t){hint.textContent=t;hint.hidden=false;clearTimeout(showHint.t);showHint.t=setTimeout(hideHint,3800)}
  function updatePad(){
    if(!G)return;const o=G.off,b=G.ball,bt={a:stage.querySelector('#sdbtnA'),b:stage.querySelector('#sdbtnB'),c:stage.querySelector('#sdbtnC'),d:stage.querySelector('#sdbtnD'),e:stage.querySelector('#sdbtnE')};
    if(G.phase!=='live'){padEl.style.visibility='hidden';return}
    padEl.style.visibility='';let L={a:'',b:'',c:'',d:'',e:'BOOST'};
    if(human(o)){
      if(b.holder===G.qb&&!G.thrown&&!G.play.startsWith('run')){L={a:'THROW',b:'TARGET',c:'',d:'',e:'SCRAMBLE'}}
      else if(b.holder){L={a:'SPIN',b:'STIFF-ARM',c:'TRUCK',d:'',e:'BOOST'}}
    }else L={a:'DIVE',b:'SWITCH',c:'HIT',d:'STRIP',e:'BOOST'};
    const pm=G.pm[human(o)?o:1-o],bsv=G.bs[human(o)?o:1-o];
    for(const k in bt){const el=bt[k];if(el.textContent!==L[k])el.textContent=L[k];el.style.visibility=L[k]?'':'hidden';
      const cost={SPIN:.2,'STIFF-ARM':.3,TRUCK:.45,HIT:.4,STRIP:.25}[L[k]];el.classList.toggle('off',k==='e'?bsv<.28:!!cost&&pm<cost-1e-6)}
  }
  G&&0;

  showMenu();
  return {
    stop(){dead=true;cancelAnimationFrame(raf);window.removeEventListener('keydown',kd);window.removeEventListener('keyup',ku)},
    _t:{P3:(x,y,z)=>P3(x,y,z),newGame,step:n=>{for(let i=0;i<n;i++)step(1/60)},state:()=>G,snap,afterBanner}
  };
};
