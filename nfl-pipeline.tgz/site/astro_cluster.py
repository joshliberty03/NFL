"""Game-level test of the flagged cells: within games on a given day element/sign,
did the side with the larger share of that player group actually win?"""
import json, random, collections
A=json.load(open("astro.json")); S=json.load(open("step2.json")); AP=json.load(open("appear.json"))
P=A["players"]; DT=A["dates"]
games=[g for g in S["games"] if g["played"] and g["winner"]!="TIE"]
gi={g["game_id"]:i for i,g in enumerate(games)}
AG=AP["g"]
roster=collections.defaultdict(list)
for pid,lst in AP["a"].items():
    for gidx,team in lst:
        gid=AG[gidx][0]
        if gid in gi: roster[(gi[gid],team)].append(int(pid))
FLAG=[("yelem",8,"delem","Metal","Wood"),("yelem",8,"delem","Earth","Fire"),("yelem",8,"delem","Fire","Wood"),
      ("sign",6,"sign","Leo","Libra"),("sign",6,"sign","Gemini","Virgo"),("animal",7,"danimal","Rooster","Rooster")]
random.seed(99); N=20000
print(f"{'cell':28s} {'games':>6} {'side w/ more won':>17} {'rate':>7} {'p':>7}  distinct games behind the cell")
res=[]
for name,idx,dkey,pa,pb in FLAG:
    recs=[]; appsum=0; ngame=0
    for i,g in enumerate(games):
        if DT[g["date"]][dkey]!=pb: continue
        h,a=g["home"],g["away"]
        if (i,h) not in roster or (i,a) not in roster: continue
        ngame+=1
        sh={}
        for t in (h,a):
            ps=roster[(i,t)]; sh[t]=sum(1 for j in ps if P[j][idx]==pa)/len(ps)
            appsum+=sum(1 for j in ps if P[j][idx]==pa)
        if sh[h]==sh[a]: continue
        more = h if sh[h]>sh[a] else a
        recs.append(g["winner"]==more)
    w=sum(recs); n=len(recs)
    if n:
        dev=abs(w/n-0.5); ge=0
        for _ in range(N):
            s=[random.random()<0.5 for _ in range(n)]
            if abs(sum(s)/n-0.5)>=dev-1e-12: ge+=1
        p=(ge+1)/(N+1)
    else: p=None
    print(f"{pa+' on '+pb+' day':28s} {n:>6} {str(w)+'-'+str(n-w):>17} {(w/n if n else 0):>7.3f} {p if p is None else round(p,3):>7}  {ngame} games, {appsum} appearances")
    res.append({"cell":f"{pa} on {pb} day","games":n,"wins":w,"rate":w/n if n else None,"p":p,"ngame":ngame,"apps":appsum})
json.dump(res,open("astro_cluster.json","w"),separators=(",",":"))
