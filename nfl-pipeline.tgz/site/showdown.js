/* ===================== GRIDIRON SHOWDOWN (retro head-to-head football) ===================== */
window.__showdown=function(stage,api){
  const PX=8,VW=24,VH=34,CW=VW*PX,CH=VH*PX;
  const rnd=Math.random,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const TEAMS_=Object.keys(TEAMCOL).sort((a,b)=>TEAMCOL[a][2].localeCompare(TEAMCOL[b][2]));
  const LV={0:{n:'Rookie',m:.86,react:.55},1:{n:'Pro',m:.96,react:.25},2:{n:'All-Pro',m:1.05,react:0}};
  const QL={45:'Short (45s quarters)',90:'Normal (90s quarters)',150:'Long (150s quarters)'};
  const S0={rb:7.9,qb:5.8,wr:7.9,ol:4.6,te:6.8,dl:6.6,lb:6.9,cb:7.4,s:7.2};
  let G=null,cv,ctx,raf=0,last=0,acc=0,dead=false,ui={};
  const keys={},inp=[{dx:0,dy:0,a:false,b:false},{dx:0,dy:0,a:false,b:false}];
  const rec=()=>{try{return JSON.parse(localStorage.getItem('gm.sd.rec'))||{w:0,l:0,t:0}}catch(e){return{w:0,l:0,t:0}}};
  const saveRec=r=>{try{localStorage.setItem('gm.sd.rec',JSON.stringify(r))}catch(e){}};
  const tn=a=>TEAMCOL[a][2],tc=(a,i)=>TEAMCOL[a][i||0];
  function lum(h){const n=parseInt(h.slice(1),16);return ((n>>16&255)*.3+(n>>8&255)*.59+(n&255)*.11)}
  function fixCols(a,b){ // avoid two near-identical jerseys
    const ca=tc(a),cb=tc(b);const d=Math.abs(lum(ca)-lum(cb));return d<40?[ca,tc(b,1)]:[ca,cb]}

  /* ------------------------------ setup UI ------------------------------ */
  stage.innerHTML=`<div class="sd">
    <div class="sdmenu" id="sdmenu"></div>
    <div class="sdgame" id="sdgame" hidden>
      <div class="sdscore" id="sdscore" aria-live="polite"></div>
      <div class="sdwrap"><canvas id="sdcv" width="${CW}" height="${CH}" aria-label="Football field"></canvas><div class="sdover" id="sdover" hidden></div></div>
      <div class="sdplays" id="sdplays"></div>
      <div class="sdpad" id="sdpad"><div class="dpad"><button data-d="u" aria-label="Up">▲</button><button data-d="l" aria-label="Left">◀</button><button data-d="r" aria-label="Right">▶</button><button data-d="d" aria-label="Down">▼</button></div><div class="abtns"><button data-b="b" id="sdbtnB">B</button><button data-b="a" id="sdbtnA">A</button></div></div>
      <p class="note" id="sdhelp"></p>
    </div></div>`;
  cv=stage.querySelector('#sdcv');ctx=cv.getContext('2d');ctx.imageSmoothingEnabled=false;
  ['sdmenu','sdgame','sdscore','sdover','sdplays','sdhelp'].forEach(i=>ui[i]=stage.querySelector('#'+i));

  function showMenu(){
    const r=rec(),opts=TEAMS_.map(a=>`<option value="${a}">${NAMES[a]||a}</option>`).join('');
    ui.sdgame.hidden=true;ui.sdmenu.hidden=false;
    ui.sdmenu.innerHTML=`<div class="card sdcard"><h2>Gridiron Showdown</h2>
      <p class="sub">Retro head-to-head football. Pick a play, then run, throw and tackle in real time. Beat the CPU or hand the keyboard to a friend.</p>
      <div class="filters">
        <label for="sdt1">Your team<select id="sdt1">${opts}</select></label>
        <label for="sdt2">Opponent<select id="sdt2">${opts}</select></label>
        <label for="sdmode">Mode<select id="sdmode"><option value="1">1 player vs CPU</option><option value="2">2 players, one device</option><option value="0">Watch CPU vs CPU</option></select></label>
        <label for="sdlvl">CPU level<select id="sdlvl"><option value="0">Rookie</option><option value="1" selected>Pro</option><option value="2">All-Pro</option></select></label>
        <label for="sdlen">Game length<select id="sdlen">${Object.keys(QL).map(k=>`<option value="${k}"${k==90?' selected':''}>${QL[k]}</option>`).join('')}</select></label>
      </div>
      <div class="filters"><button class="btn solid" type="button" id="sdgo">Kick off</button></div>
      <p class="note">Your record vs the CPU: <b>${r.w}-${r.l}${r.t?'-'+r.t:''}</b></p>
      <p class="note"><b>Controls.</b> Move: WASD or arrow keys, or the on-screen pad. <b>A</b> (F or Space): throw, juke, or dive tackle. <b>B</b> (G): switch receiver or defender. 2 players: P1 uses WASD + F/G, P2 uses arrows + K/L. Hotkeys 1-6 pick plays.</p></div>`;
    const t1=stage.querySelector('#sdt1'),t2=stage.querySelector('#sdt2');t1.value=TEAMS_[0];t2.value=TEAMS_[Math.floor(TEAMS_.length/2)];
    stage.querySelector('#sdgo').onclick=()=>newGame(t1.value,t2.value===t1.value?TEAMS_.find(x=>x!==t1.value):t2.value,+stage.querySelector('#sdmode').value,+stage.querySelector('#sdlvl').value,+stage.querySelector('#sdlen').value);
  }

  /* ------------------------------ game state ------------------------------ */
  function newGame(a,b,mode,lvl,qlen){
    const cols=fixCols(a,b);
    G={teams:[a,b],col:[[cols[0],tc(a,1)],[cols[1],tc(b,1)]],mode,lvl,qlen,score:[0,0],q:1,clock:qlen,off:rnd()<.5?0:1,startOff:0,los:25,lineToGain:35,down:1,
       phase:'select',ents:[],O:[],D:[],ball:{holder:null,air:false,x:12,y:25},play:null,t:0,thrown:false,msg:'',ot:false,done:false,cam:25,ctrlD:null,target:0,since:0,stats:{plays:0,yds:[0,0]}};
    G.startOff=G.off;
    ui.sdmenu.hidden=true;ui.sdgame.hidden=false;ui.sdover.hidden=true;ui.sdover.className='sdover';
    ui.sdhelp.textContent=mode===2?'P1: WASD, F (A), G (B).  P2: arrows, K (A), L (B).':'Move: WASD or arrows. A: F or Space. B: G. Hotkeys 1-6 pick plays.';
    stage.querySelector('#sdpad').style.display=mode===2?'none':'';
    setupPlay();goSelect();
    if(!raf){last=0;raf=requestAnimationFrame(loop)}
  }
  const human=t=>G.mode===2||(G.mode===1&&t===0);
  const offT=()=>G.off,defT=()=>1-G.off;

  function mk(role,team,x,y,side){return{role,team,x,y,vx:0,vy:0,sx:x,sy:y,stun:0,eng:false,engT:0,hold:0,free:false,jt:0,jcd:0,dive:0,route:null,ri:0,spd:S0[role],ph:rnd()*6}}
  function setupPlay(){
    const L=G.los,o=G.off,d=1-o,E=[],O=[],D=[];
    const add=(arr,e)=>{E.push(e);arr.push(e);return e};
    const q=add(O,mk('qb',o,12,L-3)),rb=add(O,mk('rb',o,12,L-6.5)),te=add(O,mk('te',o,18.6,L-.7));
    const w1=add(O,mk('wr',o,2.4,L-.8)),w2=add(O,mk('wr',o,21.6,L-.8)),w3=add(O,mk('wr',o,6,L-1.8));
    [8,10,12,14,16].forEach(x=>add(O,mk('ol',o,x,L-.7)));
    [8.6,11,13.2,15.6].forEach(x=>add(D,mk('dl',d,x,L+.9)));
    [7,12,17].forEach(x=>add(D,mk('lb',d,x,L+4.3)));
    [2.4,21.6].forEach(x=>add(D,mk('cb',d,x,L+5)));
    [7.5,16.5].forEach(x=>add(D,mk('s',d,x,L+11)));
    G.O=O;G.D=D;G.ents=E;G.qb=q;G.rb=rb;G.te=te;G.wrs=[w1,w2,w3,te];G.ol=O.slice(6);G.dl=D.slice(0,4);G.lb=D.slice(4,7);G.cb=D.slice(7,9);G.sf=D.slice(9,11);
    G.ball={holder:q,air:false,x:q.x,y:q.y};G.thrown=false;G.t=0;G.target=0;G.ctrlD=null;G.since=0;
    D.forEach(e=>e.spd*=LV[G.lvl].m*(human(d)?1.02:1));
    G.cam=L+2;
  }
  function goSelect(){
    G.phase='select';
    const ot=offT(),L=G.los,toGo=Math.max(1,Math.round(G.lineToGain-L));
    const down=['1st','2nd','3rd','4th'][G.down-1],spot=L<=50?'own '+L:'opp '+(100-L);
    G.msg=`${down} & ${G.lineToGain>=100?'Goal':toGo} at ${spot}`;
    renderScore();ui.sdover.hidden=true;
    const pl=ui.sdplays;
    if(G.mode===0||(!human(ot)&&!human(1-ot))){setTimeout(()=>{if(!dead&&G&&G.phase==='select')snap(cpuCall())},60);pl.innerHTML='';return}
    if(human(ot)){
      const inFG=100-L+17<=56;
      pl.innerHTML=`<div class="sdcall"><b>${tn(G.teams[ot])} ball. Pick a play</b></div>
        <div class="sdbtns"><button class="btn" data-pl="run1">1 Run inside</button><button class="btn" data-pl="run2">2 Run outside</button><button class="btn" data-pl="pass1">3 Short pass</button><button class="btn" data-pl="pass2">4 Deep pass</button>${G.down===4?`<button class="btn" data-pl="punt">5 Punt</button>${inFG?`<button class="btn" data-pl="fg">6 Field goal (${100-L+17} yd)</button>`:''}`:''}</div>`;
    }else{
      pl.innerHTML=`<div class="sdcall"><b>${tn(G.teams[ot])} have the ball.</b> You play defense: the highlighted player is yours. A dives to tackle, B switches players.</div><div class="sdbtns"><button class="btn solid" data-pl="auto">Hike!</button></div>`;
    }
  }
  function cpuCall(){
    const L=G.los,toGo=G.lineToGain-L,me=G.score[G.off]-G.score[1-G.off],late=G.q>=4&&G.clock<60;
    if(G.down===4){
      if(100-L+17<=50&&!(toGo<=1.5&&L>60&&me<0))return'fg';
      if(toGo<=2.5&&L>45&&(me<0||L>70))return rnd()<.5?'run1':'pass1';
      if(L<55)return 'punt';
      return rnd()<.5?'pass1':'run1';
    }
    let pPass=toGo>8?.7:toGo>4?.5:.3;if(late&&me<0)pPass=.85;if(late&&me>0)pPass=.15;
    if(rnd()<pPass)return rnd()<(toGo>12||late&&me<0?.5:.22)?'pass2':'pass1';
    return rnd()<.5?'run1':'run2';
  }
  function snap(call){
    if(G.phase!=='select')return;
    ui.sdplays.innerHTML='';
    if(call==='auto')call=cpuCall();
    if(call==='punt'||call==='fg')return kick(call);
    G.play=call;G.phase='live';G.t=0;G.thrown=false;G.since=0;
    const rb=G.rb,q=G.qb;
    if(call.startsWith('run')){G.ball.holder=rb;rb.spd=S0.rb;if(call==='run2'){rb.route=[[rb.x>12?19:5,rb.y+1.2]]}}
    else{G.ball.holder=q;setRoutes(call)}
    G.hold=call==='run1'?3.1:call==='run2'?1.9:(1.5+rnd()*1.6);
    G.blitz=rnd()<.22;G.defKnow=G.lvl===2||rnd()<.5;
    G.dl.forEach((d,i)=>{d.hold=G.hold*(.8+rnd()*.5)});G.dl[2].hold*=1.4;
    G.lb.forEach(e=>{e.react=LV[G.lvl].react});G.D.forEach(e=>e.react=LV[G.lvl].react*(.6+rnd()*.8));
    G.cpuThrowAt=1.5+rnd()*1.4+(call==='pass2'?.7:0);
    renderScore();
  }
  function setRoutes(call){
    const sp=call==='pass2'
      ?[[[0,28]],[[0,14],[5,24]],[[0,9],[-6,19]],[[0,7],[2,12]]]
      :[[[0,6.5],[.8,5.2]],[[0,2.5],[5,8.5]],[[0,4.5],[-3.5,5.2]],[[-4.5,1.2],[-8,2.2]]];
    G.wrs.forEach((w,i)=>{const side=w.x<12?1:-1,pts=[];let cx=w.x,cy=w.y;
      sp[i].forEach(([dx,dy])=>{pts.push([clamp(w.x+dx*side*(i===3?-1:1),1,23),w.y+dy])});w.route=pts;w.ri=0;w.spd=S0.wr});
  }

  /* ------------------------------ kicks ------------------------------ */
  function kick(call){
    const L=G.los,o=G.off;G.phase='banner';let txt,sub='';
    if(call==='fg'){const d=100-L+17,p=clamp(1.08-(d-18)*.0225,.05,.97),ok=rnd()<p;
      if(ok){G.score[o]+=3;txt='FIELD GOAL IS GOOD!';sub=`${d} yards. +3`;afterScore(o,txt,sub)}
      else{txt='NO GOOD';sub=`${d}-yard attempt missed`;turnover(Math.max(20,100-L),txt,sub)}return}
    const dist=36+rnd()*13,land=L+dist;txt='PUNT';
    if(land>=100){turnover(20,txt,'Touchback')}else{turnover(Math.max(1,Math.round(100-land)),txt,`Downed at the ${Math.round(100-land)<=50?'own '+Math.round(100-land):'opp '+Math.round(land)}`)}
  }
  function turnover(newLos,txt,sub){G.off=1-G.off;G.los=clamp(Math.round(newLos),1,99);G.down=1;G.lineToGain=Math.min(100,G.los+10);banner(txt,sub)}
  function afterScore(o,txt,sub){
    if(G.q>=5){G.done=true}
    G.off=1-o;G.los=25;G.down=1;G.lineToGain=35;banner(txt,sub);
  }

  /* ------------------------------ play outcome ------------------------------ */
  function endPlay(res){
    if(G.phase!=='live')return;G.phase='banner';G.stats.plays++;
    const o=G.off,old=G.los;(G.log=G.log||[]).push([G.play,res.type,res.y===undefined?0:Math.round(res.y-old),+G.t.toFixed(1)]);
    if(res.type==='td'){G.score[o]+=7;return afterScore(o,'TOUCHDOWN!','+7 (extra point good)')}
    if(res.type==='int'){const y=res.y;let nl=y>=100?20:100-Math.round(y);return turnover(clamp(nl,1,99),'INTERCEPTED!',y>=100?'Touchback':'Picked off')}
    let txt,sub;
    if(res.type==='inc'){txt='INCOMPLETE';sub='';G.down++}
    else{const nl=clamp(Math.round(res.y),1,99),gain=nl-old;G.stats.yds[o]+=gain;
      txt=res.type==='sack'?'SACKED!':'TACKLED';sub=(gain>=0?'+':'')+gain+' yards';
      if(nl>=G.lineToGain||nl>=99&&false){G.down=1;G.los=nl;G.lineToGain=Math.min(100,nl+10);txt='FIRST DOWN!';sub=(gain>=0?'+':'')+gain+' yards'}
      else{G.los=nl;G.down++}}
    if(G.down>4){return turnover(100-G.los,'TURNOVER ON DOWNS',sub)}
    banner(txt,sub);
  }
  function banner(txt,sub){
    G.phase='banner';ui.sdover.hidden=false;ui.sdover.className='sdover b';
    ui.sdover.innerHTML=`<div class="sdban"><b>${txt}</b><span>${sub||''}</span></div>`;
    renderScore();G.bt=0;
  }
  function afterBanner(){
    ui.sdover.hidden=true;
    if(G.done&&G.q>=5)return finish();
    if(G.clock<=0){
      if(G.q===2){G.q=3;G.clock=G.qlen;G.off=1-G.startOff;G.los=25;G.down=1;G.lineToGain=35;return interstitial('HALFTIME',`${G.score[0]} - ${G.score[1]}`)}
      if(G.q===4){if(G.score[0]===G.score[1]){G.q=5;G.clock=G.qlen;G.ot=true;G.off=rnd()<.5?0:1;G.los=25;G.down=1;G.lineToGain=35;return interstitial('OVERTIME','Sudden death. First score wins.')}return finish()}
      if(G.q>=5)return finish();
      G.q++;G.clock=G.qlen;return interstitial('END OF QUARTER',`Starting quarter ${G.q}`);
    }
    setupPlay();goSelect();
  }
  function interstitial(a,b){
    G.phase='banner';ui.sdover.hidden=false;ui.sdover.className='sdover b';
    ui.sdover.innerHTML=`<div class="sdban"><b>${a}</b><span>${b}</span></div>`;G.bt=-1.2;renderScore();
  }
  function finish(){
    G.phase='final';const[a,b]=G.score,w=a>b?0:b>a?1:-1;
    if(G.mode===1){const r=rec();if(w===0)r.w++;else if(w===1)r.l++;else r.t++;saveRec(r)}
    ui.sdover.hidden=false;ui.sdover.className='sdover f';ui.sdplays.innerHTML='';
    const who=w<0?'TIE GAME':G.mode===1?(w===0?'YOU WIN!':'CPU WINS'):`${tn(G.teams[w])} WIN!`;
    ui.sdover.innerHTML=`<div class="sdban fin"><span>FINAL</span><b>${who}</b><span class="big">${tn(G.teams[0])} ${a} - ${b} ${tn(G.teams[1])}</span><div class="sdbtns"><button class="btn solid" data-act="again">Play again</button><button class="btn" data-act="menu">Change teams</button></div></div>`;
    renderScore();
  }

  /* ------------------------------ simulation ------------------------------ */
  const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
  function moveTo(e,tx,ty,sp,dt){
    if(e.stun>0){e.stun-=dt;e.vx=e.vy=0;return}
    const dx=tx-e.x,dy=ty-e.y,d=Math.hypot(dx,dy);
    if(d<.05){e.vx=e.vy=0;return}
    const s=Math.min(sp,d/dt);e.vx=dx/d*s;e.vy=dy/d*s;e.x+=e.vx*dt;e.y+=e.vy*dt;
  }
  function drive(e,dx,dy,sp,dt){
    if(e.stun>0){e.stun-=dt;e.vx=e.vy=0;return}
    const m=Math.hypot(dx,dy);if(m<.05){e.vx=e.vy=0;return}
    e.vx=dx/m*sp;e.vy=dy/m*sp;e.x+=e.vx*dt;e.y+=e.vy*dt;
  }
  function getIn(t){return G.mode===2?inp[t]:inp[0]}
  function focus(){const b=G.ball;if(b.holder)return b.holder;if(b.air)return{x:b.tx,y:b.ty};return G.qb}
  function step(dt){
    if(!G)return;
    if(G.phase==='banner'){G.bt=(G.bt||0)+dt;if(G.bt>1.35)afterBanner();return}
    if(G.phase!=='live')return;
    G.t+=dt;const b=G.ball,o=G.off,d=1-o,isRun=G.play.startsWith('run'),L=G.los;
    if(G.clock>0)G.clock=Math.max(0,G.clock-dt);
    // ------- clear edge-triggered buttons into locals
    const iO=human(o)?getIn(o):null,iD=human(d)?getIn(d):null;
    const aO=iO&&iO.a,bO=iO&&iO.b,aD=iD&&iD.a,bD=iD&&iD.b;
    if(iO){iO.a=false;iO.b=false}if(iD){iD.a=false;iD.b=false}
    // ------- offense
    const car=b.holder,qb=G.qb;
    // blockers
    G.ol.forEach((ol,i)=>{
      const dlI=[0,1,2,2,3][i],dl=G.dl[dlI];
      if(!dl.free){const tx=dl.x,ty=dl.y-.95;
        if(Math.abs(dl.x-ol.x)<1.1&&Math.abs(dl.y-ol.y)<1.7){ol.eng=true;dl.engT+=dt/(i===3?1.4:1);ol.vx=ol.vy=0;ol.y=dl.y-.95;
          if(dl.engT>dl.hold){dl.free=true;ol.eng=false}}
        else moveTo(ol,tx,ty,S0.ol,dt)}
      else moveTo(ol,ol.sx,ol.y,1.5,dt);
    });
    // TE blocks edge on runs
    if(isRun&&!car.route&&G.te!==car){const t=G.lb[2];moveTo(G.te,t.x,t.y-1,S0.te,dt)}
    // receivers
    G.wrs.forEach((w,i)=>{
      if(b.holder===w)return;
      if(isRun){if(i<3){const cb=G.cb[i===1?1:0],dd=i===2?G.lb[0]:cb;moveTo(w,dd.x,Math.min(dd.y-1,w.sy+8),6,dt)}return}
      if(w.route&&w.ri<w.route.length){const p=w.route[w.ri];moveTo(w,p[0],p[1],S0.wr,dt);if(Math.hypot(p[0]-w.x,p[1]-w.y)<.25)w.ri++}
      else if(b.air&&G.tgt===w){}
      else{w.vx=w.vy=0}
    });
    // human offense control
    if(iO){
      let ctl=null;if(car)ctl=car;else if(b.air&&G.tgt&&G.tgt.team===o)ctl=G.tgt;
      if(ctl){
        const sp=ctl===qb?S0.qb:ctl.role==='rb'?S0.rb:S0.wr*0.96;
        const jm=ctl.jt>0?1.3:1;drive(ctl,iO.dx,iO.dy,sp*jm*(ctl.stun>0?0:1),dt);
        if(ctl===qb&&!G.thrown&&!isRun){
          if(bO){const ws=G.wrs;G.target=(G.target+1)%ws.length}
          if(aO)throwTo(G.wrs[G.target])
        }else if(ctl===car&&(aO||bO)&&ctl.jcd<=0){ctl.jt=.32;ctl.jcd=1.3}
      }
    }
    // cpu offense
    if(!iO||!(car||b.air)){
      if(car&&!iO){
        if(car===qb&&!G.thrown&&!isRun){
          const press=G.D.some(x=>!x.stun&&dist(x,qb)<2.3&&!(x.role==='dl'&&!x.free&&x.engT>0));
          if(G.t>G.cpuThrowAt||press&&G.t>.9){const tg=bestTarget();if(tg)throwTo(tg);else if(G.t>G.cpuThrowAt+1.6)runAI(car,dt)}
          else{moveTo(qb,qb.x+Math.sin(G.t*2)*.4,Math.max(L-6.5,qb.y-1),3,dt)}
        }else runAI(car,dt);
        if(car.jcd>0)car.jcd-=dt;
      }
    }
    if(car){car.jt=Math.max(0,car.jt-dt);car.jcd=Math.max(0,car.jcd-dt)}
    // RB (pass plays) stays to block/check
    if(!isRun&&G.rb!==car){moveTo(G.rb,G.rb.sx,G.rb.sy,2,dt)}
    if(!isRun&&G.thrown&&!car&&b.air&&!iO){ /* cpu receivers adjust to ball */
      const w=G.tgt;if(w&&w.team===o)moveTo(w,b.tx,b.ty,S0.wr,dt)}
    // ------- ball
    if(b.air){
      b.t+=dt;const k=Math.min(1,b.t/b.T);b.x=b.ax+(b.tx-b.ax)*k;b.y=b.ay+(b.ty-b.ay)*k;b.z=Math.sin(k*Math.PI)*(2+b.dist*.08);
      // swat
      G.D.forEach(df=>{if(df.dive>0&&dist(df,{x:b.x,y:b.y})<1.9&&b.z<2.8&&!b.swat&&k>.35){b.swat=true}});
      if(k>=1)resolveCatch();
    }else if(car){b.x=car.x;b.y=car.y}
    // ------- defense
    updateDefense(dt,iD,aD,bD);
    // ------- tackles
    const c=b.holder;
    if(c&&G.phase==='live'){
      if(c.y>=100){return endPlay({type:'td'})}
      if(c.y<=0&&c===qb&&!G.thrown){/* safety-ish: treat as sack at 1 */}
      for(const df of G.D){
        if(df.stun>0)continue;if(df.role==='dl'&&!df.free&&dist(df,c)>1.3)continue;
        const tr=df.dive>0?1.45:.95;
        if(dist(df,c)<tr){
          if(c.jt>0&&rnd()<.72){df.stun=.8;df.dive=0;continue}
          if(rnd()<(df===G.ctrlD?.1:.27)&&!(c===G.qb&&!G.thrown)){df.stun=.65;df.dive=0;continue}
          const sack=c===qb&&!G.thrown&&!isRun&&c.y<L+.5;
          return endPlay({type:sack?'sack':'tackle',y:Math.max(1,c.y)});
        }}
    }
    // clamp field
    G.ents.forEach(e=>{e.x=clamp(e.x,.6,VW-.6);e.y=clamp(e.y,-9,109)});
    // camera
    const f=focus(),target=clamp(f.y+3.5,-10+VH/2,110-VH/2);G.cam+=(target-G.cam)*Math.min(1,dt*5);
  }
  function runAI(c,dt){
    // pick heading that stays away from defenders ahead
    c.ait=(c.ait||0)-dt;
    if(c.ait<=0||c.ax===undefined){c.ait=.2;let best=-1,bx=c.x;
      for(let dx=-7;dx<=7;dx+=1.75){const tx=clamp(c.x+dx,2,22),ty=c.y+7;let m=99;
        G.D.forEach(df=>{if(df.y<c.y-1.2)return;const ax=c.x,ay=c.y,bx_=tx,by=ty,vx=bx_-ax,vy=by-ay,l2=vx*vx+vy*vy;let t=((df.x-ax)*vx+(df.y-ay)*vy)/l2;t=clamp(t,0,1);const px=ax+vx*t,py=ay+vy*t;m=Math.min(m,Math.hypot(df.x-px,df.y-py)*(df.role==='dl'&&!df.free?1.6:1))});
        const sc=m-Math.abs(dx)*.08;if(sc>best){best=sc;bx=tx}}
      c.ax=bx}
    const sp=(c.role==='qb'?S0.qb:c.role==='rb'?S0.rb:S0.wr*.96);
    drive(c,(c.ax-c.x)*.9,5,sp,dt);
    // juke when a defender is close ahead
    if(c.jcd<=0&&G.D.some(df=>df.stun<=0&&df.y>c.y&&dist(df,c)<2.1)&&rnd()<.4){c.jt=.32;c.jcd=1.3}
  }
  function bestTarget(){
    let best=null,bs=-99;
    G.wrs.forEach(w=>{if(!w.route||w.ri===0&&G.t<.6)return;
      let open=99;G.D.forEach(df=>{open=Math.min(open,dist(df,w))});
      const adv=w.y-G.qb.y,sc=open*1.3+adv*.06-(w.ri<w.route.length&&G.play==='pass2'?0:0)+rnd()*.7;
      if(open>2.0&&w.y>G.los-2&&sc>bs){bs=sc;best=w}});
    return best;
  }
  function throwTo(w){
    const q=G.qb,b=G.ball;if(G.thrown)return;
    let tx=w.x,ty=w.y;const SP=24;
    for(let i=0;i<3;i++){const d=Math.hypot(tx-q.x,ty-q.y),T=d/SP+.15;tx=clamp(w.x+w.vx*T,1,23);ty=w.y+w.vy*T}
    const d=Math.hypot(tx-q.x,ty-q.y);
    G.thrown=true;G.tgt=w;b.holder=null;b.air=true;b.ax=q.x;b.ay=q.y;b.tx=tx;b.ty=ty;b.t=0;b.T=d/SP+.15;b.dist=d;b.swat=false;b.x=q.x;b.y=q.y;
  }
  function resolveCatch(){
    const b=G.ball,land={x:b.tx,y:b.ty};b.air=false;
    if(b.swat){return endPlay({type:'inc'})}
    let rec=null,rd=99,df=null,dd=99;
    G.wrs.concat([G.rb]).forEach(w=>{const d=dist(w,land);if(d<rd){rd=d;rec=w}});
    G.D.forEach(x=>{const d=dist(x,land);if(d<dd&&x.stun<=0){dd=d;df=x}});
    const rOK=rd<2.3,dOK=dd<1.7;
    let res='inc';
    if(rOK&&dOK){const p=clamp(.6+(dd-rd)*.3,.15,.94);if(rnd()<p)res='catch';else res=rnd()<.25?'int':'inc'}
    else if(rOK){res=rnd()<.94?'catch':'inc'}
    else if(dOK&&dd<1.1){res=rnd()<.12?'int':'inc'}
    if(res==='catch'){b.holder=rec;G.thrown=true;rec.jt=0;rec.jcd=0;rec.route=null;return}
    if(res==='int'){return endPlay({type:'int',y:land.y})}
    endPlay({type:'inc'});
  }
  function updateDefense(dt,iD,aD,bD){
    const b=G.ball,L=G.los,o=G.off,d=1-o,c=b.holder,isRun=G.play.startsWith('run'),f=focus();
    const pastLOS=c&&c.y>L+.4,chase=pastLOS||(isRun&&G.defKnow&&G.t>.15)||(isRun&&G.t>.55);
    // human control selection
    let ctl=null;
    if(iD){
      let near=null,nd=99;G.D.forEach(x=>{const dd=dist(x,f)+(x.role==='dl'&&!x.free?4:0);if(dd<nd){nd=dd;near=x}});
      if(!G.ctrlD||bD){
        if(bD&&G.ctrlD){const ord=G.D.filter(x=>x!==G.ctrlD).sort((p,q)=>dist(p,f)-dist(q,f));G.ctrlD=ord[0]}
        else G.ctrlD=near}
      else if(near!==G.ctrlD&&dist(G.ctrlD,f)-nd>1.6)G.ctrlD=near;
      ctl=G.ctrlD;
    }else G.ctrlD=null;
    G.D.forEach((df,i)=>{
      if(df.dive>0){df.dive-=dt;if(df.dive<=0){df.stun=Math.max(df.stun,.55)}}
      if(df===ctl){
        const sp=df.spd*(df.dive>0?1.5:1);
        if(aD&&df.dive<=0&&df.stun<=0){df.dive=.3;df.dvx=iD.dx||0;df.dvy=iD.dy||(f.y>df.y?1:-1)}
        if(df.dive>0){const m=Math.hypot(df.dvx,df.dvy)||1;drive(df,df.dvx,df.dvy,sp,dt)}
        else drive(df,iD.dx,iD.dy,sp,dt);
        return}
      if(G.t<df.react)return;
      if(df.stun>0){df.stun-=dt;return}
      if(df.dive>0){return}
      // CPU defender logic
      let tx,ty;const sp=df.spd;
      if(c&&chase){const v=Math.min(.7,dist(df,c)/sp);tx=c.x+c.vx*v;ty=c.y+c.vy*v;
        if(df.role==='dl'&&!df.free&&dist(df,c)>2.5){moveTo(df,df.x,df.y,0,dt);return}
      }else if(b.air){const dd=dist(df,{x:b.tx,y:b.ty});if(dd<12||df.role==='cb'||df.role==='s'){tx=b.tx;ty=b.ty;moveTo(df,tx,ty,df.spd*.88,dt);return}else{tx=df.x;ty=df.y}}
      else if(c&&!G.thrown&&!isRun){ // pass play pre-throw
        if(df.role==='dl'){tx=G.qb.x;ty=G.qb.y;if(!df.free){moveTo(df,df.x+(tx-df.x)*.1,df.y-.15,df.spd*.25,dt);return}}
        else if(df.role==='lb'){if(G.blitz&&i!==5){tx=G.qb.x;ty=G.qb.y}else{const w=G.wrs[i-4]||G.wrs[3];tx=clamp(w.x*.6+df.sx*.4,2,22);ty=Math.max(G.los+4.2,Math.min(w.y+1,G.los+8))}}
        else if(df.role==='cb'){const w=G.wrs[i-7];tx=w.x;ty=w.y+(G.play==='pass2'?3.2:1.6)}
        else{const w=G.wrs[i-9],dp=G.play==='pass2'?9:3;tx=df.sx;ty=Math.max(df.y,w.y+dp);if(G.play==='pass1'&&w.y>G.los+4){tx=(tx+w.x)/2;ty=w.y+2}}
      }else{tx=df.x;ty=df.y}
      if(df.role==='dl'&&!df.free){moveTo(df,df.x,df.y,0,dt);return}
      moveTo(df,tx,ty,sp,dt);
    });
    G.D.forEach(df=>{if(df.role==='dl'&&!df.free&&df.engT>0){df.y+=.0}});
  }

  /* ------------------------------ rendering ------------------------------ */
  const SKIN='#e0a878';
  function sx(x){return Math.round(x*PX)}
  function sy(y){return Math.round(CH/2-(y-G.cam)*PX)}
  function drawField(){
    const o=G.off,c=G.col;
    ctx.fillStyle='#2e7a38';ctx.fillRect(0,0,CW,CH);
    for(let y=-10;y<110;y+=5){const a=sy(y+5),h=sy(y)-a;if(a>CH||a+h<0)continue;ctx.fillStyle=(Math.floor((y+10)/5)%2)?'#34853f':'#2e7a38';ctx.fillRect(0,a,CW,h)}
    // end zones
    const ez=(y0,y1,k)=>{const a=sy(y1),h=sy(y0)-a;ctx.fillStyle=c[k][0];ctx.fillRect(0,a,CW,h);ctx.fillStyle=c[k][1];ctx.font='bold 9px monospace';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(tn(G.teams[k]).toUpperCase(),CW/2,a+h/2)};
    ez(-10,0,o);ez(100,110,1-o);
    ctx.fillStyle='#fff';
    for(let y=0;y<=100;y+=5){const yy=sy(y);if(yy<-2||yy>CH+2)continue;ctx.fillRect(0,yy,CW,y%10===0?2:1);
      if(y%10===0&&y>0&&y<100){const n=y<=50?y:100-y;ctx.font='bold 8px monospace';ctx.fillStyle='#e9fbe9';ctx.textAlign='left';ctx.fillText(String(n),4,yy+9);ctx.textAlign='right';ctx.fillText(String(n),CW-4,yy+9);ctx.fillStyle='#fff'}}
    ctx.fillRect(0,0,2,CH);ctx.fillRect(CW-2,0,2,CH);
    ctx.globalAlpha=.55;for(let y=0;y<100;y++){const yy=sy(y);if(yy<-2||yy>CH+2)continue;ctx.fillRect(sx(9),yy,2,1);ctx.fillRect(sx(15),yy,2,1)}ctx.globalAlpha=1;
    // LOS and first down
    if(G.phase!=='banner'||true){ctx.fillStyle='#3a7bff';ctx.fillRect(0,sy(G.los)-1,CW,2);
      if(G.lineToGain<100){ctx.fillStyle='#ffd23a';ctx.fillRect(0,sy(G.lineToGain)-1,CW,2)}}
  }
  function drawPlayer(e,col,hl,hasBall){
    const x=sx(e.x),y=sy(e.y);if(y<-12||y>CH+12)return;
    const run=Math.hypot(e.vx,e.vy)>.5,fr=run?Math.floor((G.t*10+e.ph)%2):0,jt=e.jt>0;
    ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(x-3,y+2,7,2);
    ctx.fillStyle='#e8e8ee';ctx.fillRect(x-2,y-1+(fr?0:0),2,3+(fr?1:0));ctx.fillRect(x+1,y-1,2,3+(fr?0:1));// legs/pants
    ctx.fillStyle=e.stun>0&&e.dive<=0?'#8c8c8c':col[0];ctx.fillRect(x-3,y-5,7,5); // jersey
    ctx.fillStyle=col[1];ctx.fillRect(x-3,y-5,7,1);
    ctx.fillStyle=SKIN;ctx.fillRect(x-1,y-7,3,2);
    ctx.fillStyle=col[1]===col[0]?'#fff':col[1];ctx.fillRect(x-2,y-9,5,2);ctx.fillRect(x-2,y-7,1,1);
    if(jt){ctx.fillStyle='rgba(255,255,255,.75)';ctx.fillRect(x-4,y-10,9,1)}
    if(e.dive>0){ctx.fillStyle='rgba(255,255,255,.5)';ctx.fillRect(x-4,y+1,9,1)}
    if(hl){ctx.fillStyle='#ffe14a';ctx.fillRect(x-1,y-14,3,1);ctx.fillRect(x-2,y-13,5,1);ctx.fillRect(x-1,y-12,3,1)}
  }
  function render(){
    if(!G)return;drawField();
    const o=G.off,cO=G.col[o],cD=G.col[1-o],b=G.ball,tgt=G.wrs&&G.wrs[G.target];
    const all=G.ents.slice().sort((p,q)=>q.y-p.y);
    const hum=human(o)&&!b.air?(b.holder||G.qb):null;
    all.forEach(e=>{const isO=e.team===o;drawPlayer(e,isO?cO:cD,(isO&&e===hum)||e===G.ctrlD||(b.air&&G.tgt===e&&human(o)&&e.team===o),false)});
    // target marker for qb
    if(human(o)&&G.phase==='live'&&b.holder===G.qb&&!G.thrown&&!G.play.startsWith('run')&&tgt){const x=sx(tgt.x),y=sy(tgt.y);ctx.strokeStyle='#fff';ctx.strokeRect(x-6,y-12,12,14)}
    // ball
    const hx=b.holder?b.holder.x:b.x,hy=b.holder?b.holder.y:b.y;
    if(G.phase==='live'||G.phase==='banner'||G.phase==='select'){
      const z=b.air?(b.z||0):0,bx=sx(hx)+(b.holder?3:0),by=sy(hy)-(b.holder?4:0)-Math.round(z*PX*.9);
      if(b.air){ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(sx(b.x)-2,sy(b.y),5,2)}
      ctx.fillStyle='#7a4a1e';ctx.fillRect(bx-2,by-1,5,3);ctx.fillStyle='#fff';ctx.fillRect(bx,by,1,1)}
  }
  function renderScore(){
    if(!G)return;const t=G.teams,c=G.col,m=Math.floor(G.clock/60),s=Math.floor(G.clock%60),o=G.off;
    const qn=G.q>=5?'OT':'Q'+G.q;
    ui.sdscore.innerHTML=`<div class="sdt${o===0?' has':''}" style="--tc:${c[0][0]};--tc2:${c[0][1]}"><span class="sdn">${tn(t[0])}${G.mode===1?' (you)':''}</span><b>${G.score[0]}</b></div>
      <div class="sdmid"><b>${qn} ${m}:${String(s).padStart(2,'0')}</b><span>${G.msg||''}</span></div>
      <div class="sdt${o===1?' has':''}" style="--tc:${c[1][0]};--tc2:${c[1][1]}"><b>${G.score[1]}</b><span class="sdn">${tn(t[1])}${G.mode===1?' (CPU)':''}</span></div>`;
  }

  /* ------------------------------ loop + input ------------------------------ */
  function loop(ts){
    if(dead)return;raf=requestAnimationFrame(loop);
    if(!last)last=ts;let dt=Math.min(.05,(ts-last)/1000);last=ts;
    pollKeys();
    if(G&&!stage.hidden){acc+=dt;let n=0;while(acc>=1/60&&n<6){step(1/60);acc-=1/60;n++}if(n===6)acc=0;
      if(G.phase==='live')renderScoreClock();render()}
  }
  let lastClk=-1;function renderScoreClock(){const s=Math.ceil(G.clock);if(s!==lastClk){lastClk=s;renderScore()}}
  function pollKeys(){
    const k=keys;
    if(G&&G.mode===2){
      inp[0].dx=(k.d?1:0)-(k.a?1:0);inp[0].dy=(k.w?1:0)-(k.s?1:0);
      inp[1].dx=(k.arrowright?1:0)-(k.arrowleft?1:0);inp[1].dy=(k.arrowup?1:0)-(k.arrowdown?1:0);
    }else{
      inp[0].dx=((k.d||k.arrowright)?1:0)-((k.a||k.arrowleft)?1:0)+pad.dx;inp[0].dy=((k.w||k.arrowup)?1:0)-((k.s||k.arrowdown)?1:0)+pad.dy;
      inp[0].dx=clamp(inp[0].dx,-1,1);inp[0].dy=clamp(inp[0].dy,-1,1);
    }
  }
  const pad={dx:0,dy:0};
  function kd(e){
    if(dead||!G||ui.sdgame.hidden)return;const t=e.target&&e.target.tagName;if(t==='SELECT'||t==='INPUT'||t==='TEXTAREA')return;
    const key=e.key.toLowerCase();
    const ctrl=['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright',' ','f','g','k','l'];
    if(ctrl.includes(key)&&G.phase!=='final')e.preventDefault();
    if(e.repeat){keys[key]=true;return}
    keys[key]=true;
    if(G.mode===2){
      if(key==='f')inp[0].a=true;if(key==='g')inp[0].b=true;if(key==='k')inp[1].a=true;if(key==='l')inp[1].b=true;
    }else{if(key==='f'||key===' ')inp[0].a=true;if(key==='g'||key==='shift')inp[0].b=true}
    if(G.phase==='select'&&/^[1-6]$/.test(key)){const bt=ui.sdplays.querySelectorAll('[data-pl]');const want=['run1','run2','pass1','pass2','punt','fg'][+key-1];const hit=[...bt].find(x=>x.dataset.pl===want);if(hit)hit.click();else if(key==='1'&&bt.length===1)bt[0].click()}
  }
  function ku(e){keys[e.key.toLowerCase()]=false}
  window.addEventListener('keydown',kd);window.addEventListener('keyup',ku);
  ui.sdplays.addEventListener('click',e=>{const b=e.target.closest('[data-pl]');if(b&&G&&G.phase==='select')snap(b.dataset.pl)});
  ui.sdover.addEventListener('click',e=>{const a=e.target.closest('[data-act]');if(!a)return;if(a.dataset.act==='again')newGame(G.teams[0],G.teams[1],G.mode,G.lvl,G.qlen);else{G=null;showMenu()}});
  // touch pad
  const padEl=stage.querySelector('#sdpad');
  const dmap={u:[0,1],d:[0,-1],l:[-1,0],r:[1,0]};const held={};
  function recalc(){pad.dx=0;pad.dy=0;Object.keys(held).forEach(k=>{if(held[k]){pad.dx+=dmap[k][0];pad.dy+=dmap[k][1]}})}
  padEl.addEventListener('pointerdown',e=>{const b=e.target.closest('button');if(!b)return;e.preventDefault();try{b.setPointerCapture(e.pointerId)}catch(er){}
    if(b.dataset.d){held[b.dataset.d]=true;recalc()}else if(b.dataset.b==='a')inp[0].a=true;else if(b.dataset.b==='b')inp[0].b=true});
  const rel=e=>{const b=e.target.closest('button');if(b&&b.dataset.d){held[b.dataset.d]=false;recalc()}};
  padEl.addEventListener('pointerup',rel);padEl.addEventListener('pointercancel',rel);padEl.addEventListener('lostpointercapture',rel);
  padEl.addEventListener('contextmenu',e=>e.preventDefault());

  showMenu();
  return {
    stop(){dead=true;cancelAnimationFrame(raf);window.removeEventListener('keydown',kd);window.removeEventListener('keyup',ku)},
    _t:{newGame,step:n=>{for(let i=0;i<n;i++)step(1/60)},state:()=>G,snap,afterBanner}
  };
};
