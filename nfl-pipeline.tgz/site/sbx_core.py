"""Super Bowl pattern study: core tables (I-LX), echo mining at every lag, permutation tests, franchise/QB ledgers."""
import json, csv, random, collections, math, datetime, os
HERE=os.path.dirname(os.path.abspath(__file__))
def J(p): return json.load(open(os.path.join(HERE,p)))
SB=J('superbowl.json')['sbs']
QBS="""I|Bart Starr|Len Dawson
II|Bart Starr|Daryle Lamonica
III|Joe Namath|Earl Morrall
IV|Len Dawson|Joe Kapp
V|Johnny Unitas|Craig Morton
VI|Roger Staubach|Bob Griese
VII|Bob Griese|Billy Kilmer
VIII|Bob Griese|Fran Tarkenton
IX|Terry Bradshaw|Fran Tarkenton
X|Terry Bradshaw|Roger Staubach
XI|Ken Stabler|Fran Tarkenton
XII|Roger Staubach|Craig Morton
XIII|Terry Bradshaw|Roger Staubach
XIV|Terry Bradshaw|Vince Ferragamo
XV|Jim Plunkett|Ron Jaworski
XVI|Joe Montana|Ken Anderson
XVII|Joe Theismann|David Woodley
XVIII|Jim Plunkett|Joe Theismann
XIX|Joe Montana|Dan Marino
XX|Jim McMahon|Tony Eason
XXI|Phil Simms|John Elway
XXII|Doug Williams|John Elway
XXIII|Joe Montana|Boomer Esiason
XXIV|Joe Montana|John Elway
XXV|Jeff Hostetler|Jim Kelly
XXVI|Mark Rypien|Jim Kelly
XXVII|Troy Aikman|Jim Kelly
XXVIII|Troy Aikman|Jim Kelly
XXIX|Steve Young|Stan Humphries
XXX|Troy Aikman|Neil O'Donnell
XXXI|Brett Favre|Drew Bledsoe
XXXII|John Elway|Brett Favre
XXXIII|John Elway|Chris Chandler
XXXIV|Kurt Warner|Steve McNair
XXXV|Trent Dilfer|Kerry Collins
XXXVI|Tom Brady|Kurt Warner
XXXVII|Brad Johnson|Rich Gannon
XXXVIII|Tom Brady|Jake Delhomme
XXXIX|Tom Brady|Donovan McNabb
XL|Ben Roethlisberger|Matt Hasselbeck
XLI|Peyton Manning|Rex Grossman
XLII|Eli Manning|Tom Brady
XLIII|Ben Roethlisberger|Kurt Warner
XLIV|Drew Brees|Peyton Manning
XLV|Aaron Rodgers|Ben Roethlisberger
XLVI|Eli Manning|Tom Brady
XLVII|Joe Flacco|Colin Kaepernick
XLVIII|Russell Wilson|Peyton Manning
XLIX|Tom Brady|Russell Wilson
50|Peyton Manning|Cam Newton
LI|Tom Brady|Matt Ryan
LII|Nick Foles|Tom Brady
LIII|Tom Brady|Jared Goff
LIV|Patrick Mahomes|Jimmy Garoppolo
LV|Tom Brady|Patrick Mahomes
LVI|Matthew Stafford|Joe Burrow
LVII|Patrick Mahomes|Jalen Hurts
LVIII|Patrick Mahomes|Brock Purdy
LIX|Jalen Hurts|Patrick Mahomes
LX|Sam Darnold|Drake Maye"""
QB={}
for ln in QBS.split('\n'):
    a,b,c=ln.split('|'); QB[a]=(b,c)
# the source file calls Super Bowl L "50"; normalise to roman numerals
ROM={'50':'L'}
for x in SB:
    if x['n']=='50': x['n']='L'
QB['L']=QB.pop('50')
CODE={'STL':'LA','OAK':'LV','SD':'LAC','LAR':'LA'}
def nc(t): return CODE.get(t,t)
for i,x in enumerate(SB):
    x['k']=i+1; x['y']=int(x['d'][:4]); x['wq'],x['lq']=QB[x['n']]
YEARS=[x['y'] for x in SB]
Wy={x['y']:x['w'] for x in SB}; Ly={x['y']:x['l'] for x in SB}
MASTER={11,22,33}
def red(n):
    while n>9 and n not in MASTER: n=sum(int(d) for d in str(n))
    return n
def lifep(b):
    y,m,d=b.split('-'); return red(red(int(m))+red(int(d))+red(sum(map(int,y))))
def pday(b,date):
    _,bm,bd=b.split('-'); y,m,d=date.split('-')
    py=red(red(int(bm))+red(int(bd))+red(sum(map(int,y)))); return red(red(py+red(int(m)))+red(int(d)))
def echo_counts(W,L,lag,kind,ys):
    c=0
    for y in ys:
        z=y+lag
        if z not in W: continue
        a={'LW':L[y]==W[z],'WW':W[y]==W[z],'LL':L[y]==L[z],'WL':W[y]==L[z]}[kind]
        c+=a
    return c
def longest_run(W,L,lag,ys,kind='LW'):
    best=run=0
    for y in ys:
        z=y+lag
        ok=z in W and (L[y]==W[z] if kind=='LW' else W[y]==W[z])
        run=run+1 if ok else 0
        best=max(best,run)
    return best
def run_echo():
    ys=YEARS
    out={'lags':[],'lag20':[],'runs':[]}
    for lag in range(1,41):
        n=sum(1 for y in ys if y+lag in Wy)
        out['lags'].append({'lag':lag,'n':n,**{k:echo_counts(Wy,Ly,lag,k,ys) for k in ('LW','WW','LL','WL')},'run':longest_run(Wy,Ly,lag,ys)})
    for y in ys:
        z=y+20
        if z in Wy:
            if Ly[y]==Wy[z]: out['lag20'].append([y,z,Wy[z],'LW'])
    # all consecutive runs >=2 at any lag
    for lag in range(1,41):
        run=[]
        for y in ys+[9999]:
            ok=(y+lag in Wy) and Ly.get(y)==Wy.get(y+lag)
            if ok: run.append(y)
            else:
                if len(run)>=2: out['runs'].append({'lag':lag,'from':run[0],'to':run[-1],'team':[Wy[run[0]+lag]]+[Wy[r+lag] for r in run[1:]]})
                run=[]
    # permutation test: shuffle the order of the 60 (winner,loser) pairs across the years
    random.seed(20260217)
    pairs=[(x['w'],x['l']) for x in SB]
    N=4000
    obs20=out['lags'][19]['LW']
    cnt20=[];maxlag=[];maxrun=[];ge7=0;ge7any=0;runge2_20=0;runany=0
    for _ in range(N):
        random.shuffle(pairs)
        W={y:p[0] for y,p in zip(ys,pairs)}; L={y:p[1] for y,p in zip(ys,pairs)}
        cs=[echo_counts(W,L,lag,'LW',ys) for lag in range(1,41)]
        cnt20.append(cs[19]); maxlag.append(max(cs))
        if cs[19]>=obs20: ge7+=1
        if max(cs)>=obs20: ge7any+=1
        r20=longest_run(W,L,20,ys)
        if r20>=2: runge2_20+=1
        mr=max(longest_run(W,L,lag,ys) for lag in range(1,41))
        maxrun.append(mr)
        if mr>=3: runany+=1
    out['perm']={'N':N,'obs20':obs20,'mean20':sum(cnt20)/N,'p20':ge7/N,'pAnyLag':ge7any/N,'meanMaxLag':sum(maxlag)/N,
      'pRun2At20':runge2_20/N,'pRun3AnyLag':runany/N,'meanMaxRun':sum(maxrun)/N}
    # P(a given lag-20 pair echoes): expectation over shuffles equals mean20/40
    return out
if __name__=='__main__':
    e=run_echo()
    print(json.dumps(e['perm'],indent=1)); print(e['lag20']); print(e['runs'])
    print([ (l['lag'],l['LW']) for l in e['lags']])
