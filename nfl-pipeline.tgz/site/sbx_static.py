"""Builds sbx_static.json: facts about Super Bowl history that never change (QB bios and stats, rosters, star players, sky on every game date).
Needs the nflverse downloads in /home/runner/nfl/sbx (run by hand; the weekly refresh only reads the small json this makes)."""
import json,csv,math,datetime,collections,sys,os
import pandas as pd, ephem
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from sbx_core import *
import names
D='/home/runner/nfl/sbx/'
MASTER={11,22,33}
def red(n):
    while n>9 and n not in MASTER: n=sum(int(d) for d in str(n))
    return n
def lifep(b):
    y,m,d=b.split('-'); return red(red(int(m))+red(int(d))+red(sum(map(int,y))))
def pday(b,date):
    _,bm,bd=b.split('-'); y,m,d=date.split('-')
    py=red(red(int(bm))+red(int(bd))+red(sum(map(int,y)))); return red(red(py+red(int(m)))+red(int(d)))
SIGNS=['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces']
ANIM=['Rat','Ox','Tiger','Rabbit','Dragon','Snake','Horse','Goat','Monkey','Rooster','Dog','Pig']
ELEM=['Metal','Metal','Water','Water','Wood','Wood','Fire','Fire','Earth','Earth']
LNY=json.load(open(HERE+'/lny.json'))
def czodiac(date):
    y=int(date[:4]); md=date[5:]
    ly=y if md>=LNY[str(y)] else y-1
    return ANIM[(ly-4)%12],ELEM[ly%10],ly
def sign(l): return SIGNS[int(l%360//30)]
def sky(date,hhmm='23:30'):
    d=ephem.Date(date.replace('-','/')+' '+hhmm); out={}
    L={}
    for nm,B in (('sun',ephem.Sun()),('moon',ephem.Moon()),('mercury',ephem.Mercury()),('venus',ephem.Venus()),('mars',ephem.Mars()),('jupiter',ephem.Jupiter()),('saturn',ephem.Saturn())):
        B.compute(d,epoch=d); L[nm]=math.degrees(ephem.Ecliptic(B).lon)%360
        if nm=='moon': ill=B.phase
    el=(L['moon']-L['sun'])%360
    ph=['New Moon','Waxing Crescent','First Quarter','Waxing Gibbous','Full Moon','Waning Gibbous','Last Quarter','Waning Crescent'][int(((el+22.5)%360)//45)]
    js=(L['saturn']-L['jupiter'])%360
    return {'sun':sign(L['sun']),'sunlon':round(L['sun'],1),'moon':sign(L['moon']),'ill':round(ill),'phase':ph,'el':round(el,1),
            'jup':sign(L['jupiter']),'sat':sign(L['saturn']),'mars':sign(L['mars']),'ven':sign(L['venus']),'mer':sign(L['mercury']),
            'js':round(js,1),'jlon':round(L['jupiter'],1),'slon':round(L['saturn'],1)}
def sunsign_birth(b):
    y,m,d=map(int,b.split('-')); return sign(math.degrees(ephem.Ecliptic(_sun(b)).lon))
def _sun(b):
    s=ephem.Sun(); d=ephem.Date(b.replace('-','/')+' 12:00'); s.compute(d,epoch=d); return s
# ---------- sky for every Super Bowl date + the next one
sbsky={}
for x in SB: sbsky[x['n']]=sky(x['d'])
sbsky['LXI']=sky('2027-02-14')
# ---------- games.csv
G=list(csv.DictReader(open('/home/runner/nfl/games/games.csv')))
for r in G: r['home_team']=nc(r['home_team']); r['away_team']=nc(r['away_team'])
def played(r): return r['home_score'] not in ('','NA')
SBG={int(r['season']):r for r in G if r['game_type']=='SB' and played(r)}
P=pd.read_csv(D+'players.csv',low_memory=False).drop_duplicates('gsis_id').set_index('gsis_id')
PW={}
def pw(season):
    if season not in PW:
        f=D+f'pw{season}.csv' if season<=2025 else '/home/runner/nfl/stats/p26.csv'
        PW[season]=pd.read_csv(f,low_memory=False); PW[season]['team']=PW[season]['team'].map(nc)
    return PW[season]
RO={}
def ro(season):
    if season not in RO:
        RO[season]=pd.read_csv(D+f'ro{season}.csv',low_memory=False); RO[season]['team']=RO[season]['team'].map(nc)
    return RO[season]
def qbrow(gid,season,team):
    p=P.loc[gid] if gid in P.index else None
    if p is None: return None
    d=pw(season); me=d[d.player_id==gid]
    reg=me[me.season_type=='REG']; post=me[me.season_type=='POST']
    def tot(df):
        g=lambda c: int(df[c].fillna(0).sum()) if c in df else 0
        return {'g':int(((df.attempts.fillna(0)>0)|(df.carries.fillna(0)>0)).sum()),'cmp':g('completions'),'att':g('attempts'),'yds':g('passing_yards'),'td':g('passing_tds'),'int':g('passing_interceptions'),
                'sk':g('sacks_suffered'),'car':g('carries'),'ry':g('rushing_yards'),'rtd':g('rushing_tds')}
    r=tot(reg)
    sbline=None
    if season<=2025 and len(post):
        last=post[post.week==post.week.max()]
        if len(last): sbline=tot(last)
    return {'id':gid,'name':p['display_name'],'bd':str(p['birth_date'])[:10],'ht':p['height'],'wt':p['weight'],'col':p['college_name'],
            'dy':None if pd.isna(p['draft_year']) else int(p['draft_year']),'dr':None if pd.isna(p['draft_round']) else int(p['draft_round']),
            'dp':None if pd.isna(p['draft_pick']) else int(p['draft_pick']),'reg':r,'sb':sbline}
# jersey and roster composition for a team in the Super Bowl week
def sbroster(season,team,date):
    r=ro(season); x=r[r.team==team]
    if season<=2025 and 'game_type' in r.columns and (x.game_type=='SB').any(): x=x[x.game_type=='SB']
    elif 'week' in r.columns and len(x): x=x[x.week==x.week.max()]
    x=x[x.status=='ACT'] if 'ACT' in set(x.status) else x
    return x.drop_duplicates('gsis_id')
def comp(x,date):
    d0=datetime.date.fromisoformat(date)
    ages=[(d0-datetime.date.fromisoformat(str(b)[:10])).days/365.25 for b in x.birth_date.dropna()]
    ex=x.years_exp.dropna()
    dn=pd.to_numeric(x.draft_number,errors='coerce')
    return {'n':int(len(x)),'age':round(sum(ages)/len(ages),2) if ages else None,'exp':round(float(ex.mean()),2) if len(ex) else None,
            'rook':int((ex==0).sum()),'vet8':int((ex>=8).sum()),'top32':int((dn<=32).sum()),'undr':int(dn.isna().sum()) if 'draft_number' in x else None,
            'ht':round(float(pd.to_numeric(x.height,errors='coerce').mean()),1),'wt':round(float(pd.to_numeric(x.weight,errors='coerce').mean()),1)}
def stars(season,team):
    d=pw(season); d=d[(d.team==team)&(d.season_type=='REG')]
    gb=d.groupby(['player_id','player_display_name','position'])
    s=gb[['carries','rushing_yards','rushing_tds','receptions','targets','receiving_yards','receiving_tds','def_sacks','def_interceptions','def_tackles_solo','def_tackles_with_assist','passing_yards']].sum().reset_index()
    out={}
    r=s.sort_values('rushing_yards',ascending=False).head(2); out['rush']=[[a.player_display_name,a.position,int(a.carries),int(a.rushing_yards),int(a.rushing_tds)] for a in r.itertuples() if a.rushing_yards>0]
    r=s.sort_values('receiving_yards',ascending=False).head(3); out['rec']=[[a.player_display_name,a.position,int(a.receptions),int(a.receiving_yards),int(a.receiving_tds)] for a in r.itertuples()]
    r=s.sort_values('def_sacks',ascending=False).head(2); out['sack']=[[a.player_display_name,a.position,float(a.def_sacks)] for a in r.itertuples()]
    r=s.sort_values('def_interceptions',ascending=False).head(1); out['int']=[[a.player_display_name,a.position,int(a.def_interceptions)] for a in r.itertuples()]
    return out
QBROWS=[];STAR={};ROST={}
for season in range(1999,2026):
    g=SBG[season]; d=g['gameday']
    for side in ('away','home'):
        t=g[side+'_team']; gid=g[side+'_qb_id']; nm=g[side+'_qb_name']
        own=int(g[side+'_score']); opp=int(g['home_score' if side=='away' else 'away_score'])
        q=qbrow(gid,season,t)
        if not q: print('missing',season,nm,gid); continue
        q.update({'season':season,'team':t,'res':'W' if own>opp else 'L','date':d,'coach':g[side+'_coach']})
        rr=sbroster(season,t,d); m=rr[rr.gsis_id==gid]
        q['jn']=int(m.jersey_number.iloc[0]) if len(m) and not pd.isna(m.jersey_number.iloc[0]) else None
        q['age']=round((datetime.date.fromisoformat(d)-datetime.date.fromisoformat(q['bd'])).days/365.25,1)
        q['lp']=lifep(q['bd']); q['pd']=pday(q['bd'],d)
        nn=names.numbers(q['name']); q['nx']=nn['expression'] if nn else None
        q['sun']=sunsign_birth(q['bd']); an=czodiac(q['bd']); q['cz']=an[0]; q['cze']=an[1]
        q['wd']=datetime.date.fromisoformat(q['bd']).strftime('%A')
        QBROWS.append(q)
        if (season,t) in {(2004,'PHI'),(2005,'SEA'),(2006,'CHI'),(2024,'PHI'),(2025,'SEA'),(2004,'NE'),(2005,'PIT'),(2006,'IND'),(2024,'KC'),(2025,'NE')}:
            STAR[f'{season}{t}']=stars(season,t); ROST[f'{season}{t}']=comp(rr,d)
print('qb rows',len(QBROWS))
W=qbrow('00-0039918',2025,'CHI')  # Caleb Williams: bio and 2025 season for context (2026 stats are read fresh each refresh)
W.update({'season':2025,'team':'CHI','lp':lifep(W['bd']),'sun':sunsign_birth(W['bd']),'cz':czodiac(W['bd'])[0],'cze':czodiac(W['bd'])[1],'wd':datetime.date.fromisoformat(W['bd']).strftime('%A'),'nx':names.numbers(W['name'])['expression']})
out={'cw':W,'qbs':QBROWS,'stars':STAR,'rost':ROST,'sky':sbsky}
json.dump(out,open(HERE+'/sbx_static.json','w'),separators=(',',':'))
print(os.path.getsize(HERE+'/sbx_static.json'))
