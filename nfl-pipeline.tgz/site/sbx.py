"""Builds sbx.json for the Super Bowl Echo tab: the 20-year pattern, echo mining at every lag, ledgers, current Bears status and a season simulation.
Reads sbx_static.json (history that never changes) plus games.csv / p26.csv (refreshed weekly)."""
import json,csv,random,math,collections,datetime,os,sys
import numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from sbx_core import *
ST=J('sbx_static.json'); TI=J('teamsinfo.json'); FOUNDED=J('founded.json')
G=list(csv.DictReader(open('/home/runner/nfl/games/games.csv')))
for r in G: r['home_team']=nc(r['home_team']); r['away_team']=nc(r['away_team'])
def played(r): return r['home_score'] not in ('','NA')
def tg(team,season,types=None):
    return sorted([r for r in G if int(r['season'])==season and team in (r['home_team'],r['away_team']) and (types is None or r['game_type'] in types)],key=lambda r:(r['gameday'],r['gametime']))
def tseason(team,season):
    reg=[r for r in tg(team,season,('REG',)) if played(r)]; w=l=t=pf=pa=0
    for r in reg:
        home=r['home_team']==team; a=int(r['home_score' if home else 'away_score']); b=int(r['away_score' if home else 'home_score'])
        pf+=a;pa+=b
        if a>b:w+=1
        elif a<b:l+=1
        else:t+=1
    po=[]
    for r in tg(team,season,('WC','DIV','CON','SB')):
        if not played(r): continue
        home=r['home_team']==team; a=int(r['home_score' if home else 'away_score']); b=int(r['away_score' if home else 'home_score'])
        po.append({'rd':{'WC':'Wild card','DIV':'Divisional','CON':'Conference','SB':'Super Bowl'}[r['game_type']],'opp':r['away_team' if home else 'home_team'],'h':home,'f':a,'a':b,'d':r['gameday']})
    return {'w':w,'l':l,'t':t,'pf':pf,'pa':pa,'po':po}
def league_rank(team,season):
    d={}
    for r in G:
        if int(r['season'])==season and r['game_type']=='REG' and played(r):
            for t,s,o in ((r['home_team'],int(r['home_score']),int(r['away_score'])),(r['away_team'],int(r['away_score']),int(r['home_score']))): d[t]=d.get(t,0)+s-o
    order=sorted(d,key=lambda t:-d[t]); return order.index(team)+1,len(order),d[team]
def h2h(a,b,since=1999):
    w=l=t=0
    for r in G:
        if not played(r): continue
        if {r['home_team'],r['away_team']}!={a,b}: continue
        hs,as_=int(r['home_score']),int(r['away_score'])
        win=r['home_team'] if hs>as_ else r['away_team'] if as_>hs else None
        if win==a:w+=1
        elif win==b:l+=1
        else:t+=1
    return [w,l,t]
QBR={(q['season'],q['team']):q for q in ST['qbs']}
OUT={'asof':datetime.date.today().isoformat()}
# ------------------------------------------------------------------ the three pairs
PAIRS=[('XXXIX',2004,'PHI','NE','LIX',2024,'PHI','KC'),('XL',2005,'SEA','PIT','LX',2025,'SEA','NE'),('XLI',2006,'CHI','IND','LXI',2026,'CHI',None)]
SBN={x['n']:x for x in SB}
def side(n,season,team,opp,done=True):
    x=SBN.get(n); sk=ST['sky'].get(n)
    d={'n':n,'season':season,'team':team,'opp':opp,'date':x['d'] if x else '2027-02-14','sky':sk}
    if x:
        d['res']='W' if x['w']==team else 'L'; d['sc']=[x['ws'],x['ls']] if d['res']=='W' else [x['ls'],x['ws']]
        d['dn']=x['dn']; d['qb']=x['wq'] if d['res']=='W' else x['lq']; d['oq']=x['lq'] if d['res']=='W' else x['wq']
        gm=[r for r in G if r['game_type']=='SB' and int(r['season'])==season]
        if gm:
            r=gm[0]; home=r['home_team']==team
            d['coach']=r['home_coach' if home else 'away_coach']; d['ocoach']=r['away_coach' if home else 'home_coach']; d['venue']=r['stadium']
    d['ts']=tseason(team,season); d['rank']=league_rank(team,season)
    d['qbrow']=QBR.get((season,team)); d['oqbrow']=QBR.get((season,opp)) if opp else None
    k=f'{season}{team}'; d['stars']=ST['stars'].get(k); d['rost']=ST['rost'].get(k)
    d['oppts']=tseason(opp,season) if opp else None
    return d
PR=[]
for a,s1,t1,o1,b,s2,t2,o2 in PAIRS:
    PR.append({'then':side(a,s1,t1,o1),'now':side(b,s2,t2,o2)})
# 2026 Bears block: live record, QB season, schedule, SB LXI facts
cw=ST['cw']
import pandas as pd
p26=pd.read_csv('/home/runner/nfl/stats/p26.csv',low_memory=False)
m=p26[(p26.player_id==cw['id'])&(p26.season_type=='REG')]
g=lambda c:int(m[c].fillna(0).sum())
PR[2]['now']['qbrow']={**cw,'season':2026,'reg':{'g':int(((m.attempts>0)|(m.carries>0)).sum()),'cmp':g('completions'),'att':g('attempts'),'yds':g('passing_yards'),'td':g('passing_tds'),'int':g('passing_interceptions'),'sk':g('sacks_suffered'),'car':g('carries'),'ry':g('rushing_yards'),'rtd':g('rushing_tds')},'sb':None,'age':round((datetime.date(2027,2,14)-datetime.date.fromisoformat(cw['bd'])).days/365.25,1),'jn':18}
PR[2]['now'].update({'qb':'Caleb Williams','coach':'Ben Johnson','venue':'SoFi Stadium','res':None,'dn':lifep('2027-02-14')})
r26=pd.read_csv('/home/runner/nfl/stats/rosters2026.csv',low_memory=False)
r26=r26[(r26.team=='CHI')&(r26.status=='ACT')].drop_duplicates('gsis_id')
d0=datetime.date.today()
ages=[(d0-datetime.date.fromisoformat(str(b)[:10])).days/365.25 for b in r26.birth_date.dropna()]
dn_=pd.to_numeric(r26.draft_number,errors='coerce'); ex=r26.years_exp.dropna()
PR[2]['now']['rost']={'n':int(len(r26)),'age':round(sum(ages)/len(ages),2),'exp':round(float(ex.mean()),2),'rook':int((ex==0).sum()),'vet8':int((ex>=8).sum()),'top32':int((dn_<=32).sum()),'undr':int(dn_.isna().sum())}
pp=p26[(p26.team=='CHI')&(p26.season_type=='REG')]
s_=pp.groupby(['player_id','player_display_name','position'])[['carries','rushing_yards','rushing_tds','receptions','receiving_yards','receiving_tds','def_sacks']].sum().reset_index()
PR[2]['now']['stars']={'rush':[[a.player_display_name,a.position,int(a.carries),int(a.rushing_yards),int(a.rushing_tds)] for a in s_.sort_values('rushing_yards',ascending=False).head(2).itertuples()],
 'rec':[[a.player_display_name,a.position,int(a.receptions),int(a.receiving_yards),int(a.receiving_tds)] for a in s_.sort_values('receiving_yards',ascending=False).head(3).itertuples()],
 'sack':[[a.player_display_name,a.position,float(a.def_sacks)] for a in s_.sort_values('def_sacks',ascending=False).head(2).itertuples()],'int':[]}
# stats for the three QBs' pairs: per-game rates computed in the UI
OUT['pairs']=PR
OUT['sb']=[{k:x[k] for k in ('n','k','y','d','w','l','ws','ls','wq','lq','dn','wlp','llp','wpd','lpd')} for x in SB]
OUT['sky']=ST['sky']
OUT['found']={t:(lifep(FOUNDED[t]) if FOUNDED.get(t) else None) for t in TI}
OUT['sblxi']={'cpd':pday(FOUNDED['CHI'],'2027-02-14'),'clp':lifep(FOUNDED['CHI']),'dn':lifep('2027-02-14'),'n':'LXI','date':'2027-02-14','venue':'SoFi Stadium','city':'Inglewood, California'}
# ------------------------------------------------------------------ echo mining
E=run_echo()
# extra permutation: three in a row at lag 20 specifically
random.seed(7); pairs=[(x['w'],x['l']) for x in SB]; c3=0; N=4000
for _ in range(N):
    random.shuffle(pairs); W={y:p[0] for y,p in zip(YEARS,pairs)}; L={y:p[1] for y,p in zip(YEARS,pairs)}
    # a run of two resolved echoes at lag 20 (the 2005/2006 shape) is the realistic comparison for "so far"
    if longest_run(W,L,20,YEARS)>=2: c3+=1
E['perm']['pRun2At20b']=c3/N
OUT['echo']=E
# the lag-20 echoes in detail
rows=[]
for y,z,t,_ in E['lag20']:
    a=[x for x in SB if x['y']==y][0]; b=[x for x in SB if x['y']==z][0]
    rows.append({'t':t,'a':{'n':a['n'],'y':y,'d':a['d'],'sc':[a['ls'],a['ws']],'qb':a['lq'],'opp':a['w'],'dn':a['dn'],'wd':datetime.date.fromisoformat(a['d']).strftime('%a')},
                 'b':{'n':b['n'],'y':z,'d':b['d'],'sc':[b['ws'],b['ls']],'qb':b['wq'],'opp':b['l'],'dn':b['dn']},'sky':[ST['sky'][a['n']]['js'],ST['sky'][b['n']]['js'],ST['sky'][a['n']]['phase'],ST['sky'][b['n']]['phase']],
                 'days':(datetime.date.fromisoformat(b['d'])-datetime.date.fromisoformat(a['d'])).days})
OUT['lag20']=rows
# Jupiter-Saturn separation: every Super Bowl vs the one 20 years later (not just the echoes)
js=[]
for x in SB:
    z=[q for q in SB if q['y']==x['y']+20]
    if z:
        a=ST['sky'][x['n']]['js']; b=ST['sky'][z[0]['n']]['js']; d=abs((b-a+180)%360-180); js.append(round(d,1))
OUT['js20']={'mean':round(sum(js)/len(js),1),'max':max(js),'n':len(js)}
# moon phase 20 years later (the Metonic cycle is 19 years, so 20 shifts the phase by about 11 days)
mp=[]
for x in SB:
    z=[q for q in SB if q['y']==x['y']+20]
    if z:
        a=ST['sky'][x['n']]['el']; b=ST['sky'][z[0]['n']]['el']; mp.append(round(abs((b-a+180)%360-180),1))
OUT['mp20']={'mean':round(sum(mp)/len(mp),1),'min':min(mp),'max':max(mp)}
# ------------------------------------------------------------------ franchise ledger
led=collections.defaultdict(lambda:{'a':[], 'w':0,'l':0})
for x in SB:
    led[x['w']]['a'].append((x['y'],'W',x['n'])); led[x['w']]['w']+=1
    led[x['l']]['a'].append((x['y'],'L',x['n'])); led[x['l']]['l']+=1
fr=[]
for t,v in led.items():
    v['a'].sort(); seq=''.join(r for _,r,_ in v['a'])
    wins=[y for y,r,_ in v['a'] if r=='W']; last=wins[-1] if wins else None
    # does a loss ever precede a later win (the "redemption" shape)
    red_=[(y1,y2) for i,(y1,r1,_) in enumerate(v['a']) for (y2,r2,_) in v['a'][i+1:] if r1=='L' and r2=='W']
    fr.append({'t':t,'w':v['w'],'l':v['l'],'seq':seq,'yrs':[y for y,_,_ in v['a']],'last':last,'first':v['a'][0][0],'redeem':red_[0] if red_ else None,'gap':min([b-a for a,b in red_]) if red_ else None})
fr.sort(key=lambda r:(-(r['w']+r['l']),-r['w']))
OUT['fr']=fr
# franchises that have never won, and drought lengths since each team's last title (through the 2026 game)
OUT['never']=[r['t'] for r in fr if r['w']==0]
# ------------------------------------------------------------------ rematches
rem=collections.defaultdict(list)
for x in SB: rem[tuple(sorted((x['w'],x['l'])))].append(x)
OUT['rematch']=[{'pair':list(k),'g':[{'n':x['n'],'y':x['y'],'w':x['w'],'sc':[x['ws'],x['ls']]} for x in v],'revenge':any(v[j]['w']==v[i]['l'] for i in range(len(v)) for j in range(i+1,len(v)))} for k,v in rem.items() if len(v)>1]
# ------------------------------------------------------------------ quarterback ledger
ql=collections.defaultdict(list)
for x in SB:
    ql[x['wq']].append((x['y'],'W',x['w'],x['n'])); ql[x['lq']].append((x['y'],'L',x['l'],x['n']))
qled=[]
for q,v in ql.items():
    v.sort(); seq=''.join(r for _,r,_,_ in v); teams=sorted({t for _,_,t,_ in v})
    lw=[(a[0],b[0],b[2]) for i,a in enumerate(v) for b in v[i+1:] if a[1]=='L' and b[1]=='W']
    qled.append({'q':q,'seq':seq,'yrs':[y for y,_,_,_ in v],'teams':teams,'lw':lw[0] if lw else None,'diff_team':any(a[2]!=b[2] for a in v for b in v if a[1]=='L' and b[1]=='W' and a[0]<b[0])})
qled.sort(key=lambda r:(-len(r['seq']),r['q']))
OUT['qled']=qled
# ------------------------------------------------------------------ coaches who beat a former team
OUT['coachfacts']=[{'who':'Andy Reid','txt':'Coached the Eagles in Super Bowl XXXIX (2005 loss to the Patriots). In Super Bowl LIX (2025) he coached the Chiefs against the Eagles, who won 40-22.'}]
# ------------------------------------------------------------------ score echoes and number facts
sc=collections.defaultdict(list)
for x in SB: sc[(x['ws'],x['ls'])].append(x['n']+' ('+str(x['y'])+')')
OUT['scoredup']=[{'s':list(k),'g':v} for k,v in sc.items() if len(v)>1]
def romval(n):
    v={'I':1,'V':5,'X':10,'L':50}; s=0
    for i,c in enumerate(n): s+= -v[c] if i+1<len(n) and v[c]<v[n[i+1]] else v[c]
    return s
OUT['sbnum']=[{'n':x['n'],'v':romval(x['n']),'r':red(romval(x['n'])),'y':x['y'],'yr':red(sum(map(int,str(x['y'])))),'dn':x['dn'],'ts':red(x['ws']+x['ls']),'mg':x['ws']-x['ls']} for x in SB]+[{'n':'LXI','v':61,'r':7,'y':2027,'yr':red(11),'dn':red(sum(map(int,'20270214'))),'ts':None,'mg':None}]
# ------------------------------------------------------------------ SB team-seasons: records of winners, losers and the next season
rec=[]
for x in SB:
    if x['y']>=2000 and x['y']<=2026:
        s=x['y']-1
        for t,r in ((x['w'],'W'),(x['l'],'L')):
            ts=tseason(t,s); nx=tseason(t,s+1) if s+1<=2025 else None
            rec.append({'n':x['n'],'y':x['y'],'t':t,'r':r,'w':ts['w'],'l':ts['l'],'t_':ts['t'],'pf':ts['pf'],'pa':ts['pa'],'nw':None if not nx else nx['w'],'nl':None if not nx else nx['l']})
OUT['sbrec']=rec
def avg(v): return round(sum(v)/len(v),2) if v else None
OUT['sbrecsum']={'W':avg([r['w'] for r in rec if r['r']=='W']),'L':avg([r['w'] for r in rec if r['r']=='L']),
   'nW':avg([r['nw'] for r in rec if r['r']=='W' and r['nw'] is not None]),'nL':avg([r['nw'] for r in rec if r['r']=='L' and r['nw'] is not None]),
   'dW':avg([r['pf']-r['pa'] for r in rec if r['r']=='W']),'dL':avg([r['pf']-r['pa'] for r in rec if r['r']=='L'])}
# QB table distribution
qs=ST['qbs']
OUT['qbs']=[{k:q[k] for k in ('season','team','res','name','bd','age','jn','lp','pd','nx','sun','cz','dr','dp','ht','wt','col')}|{'reg':q['reg'],'sb':q['sb']} for q in qs]
OUT['lpdist']={'W':sorted(collections.Counter(q['lp'] for q in qs if q['res']=='W').items()),'L':sorted(collections.Counter(q['lp'] for q in qs if q['res']=='L').items())}
# head to head series (all games since 1999, wins and losses only)
OUT['h2h']={'|'.join(sorted((a,b))):h2h(*sorted((a,b))) for a,b in (('PHI','NE'),('SEA','PIT'),('CHI','IND'),('PHI','KC'),('SEA','NE'),('CHI','SEA'),('CHI','PHI'))}
# ------------------------------------------------------------------ current Bears record and schedule
cur={t:tseason(t,2026) for t in ('CHI','PHI','SEA','NE','KC')}
OUT['cur']=cur
sch=[]
for r in tg('CHI',2026,('REG',)):
    home=r['home_team']=='CHI'; opp=r['away_team' if home else 'home_team']
    d={'wk':int(r['week']),'d':r['gameday'],'opp':opp,'h':home}
    if played(r): d['f']=int(r['home_score' if home else 'away_score']); d['a']=int(r['away_score' if home else 'home_score'])
    sch.append(d)
OUT['sched']=sch
# ------------------------------------------------------------------ Elo and a season simulation (a model, not a forecast to bet on)
games=[r for r in G if played(r) and int(r['season'])>=1999]
games.sort(key=lambda r:(r['gameday'],r['gametime']))
elo=collections.defaultdict(lambda:1500.0); cs=None
def upd(r):
    h,a=r['home_team'],r['away_team']; hs,as_=int(r['home_score']),int(r['away_score'])
    neu=r['game_type']=='SB'; d=elo[h]-elo[a]+(0 if neu else 48)
    e=1/(1+10**(-d/400)); s=1 if hs>as_ else 0 if hs<as_ else .5
    mov=abs(hs-as_); mult=math.log(mov+1)*2.2/(((d if s==1 else -d)*.001)+2.2) if mov else 1
    k=20*mult; elo[h]+=k*(s-e); elo[a]-=k*(s-e)
for r in games:
    sn=int(r['season'])
    if cs is not None and sn!=cs:
        for t in list(elo): elo[t]=elo[t]*.67+1500*.33
    cs=sn; upd(r)
TEAMS=sorted(TI)
rem=[r for r in G if int(r['season'])==2026 and r['game_type']=='REG' and not played(r)]
base={t:0.0 for t in TEAMS}
for r in G:
    if int(r['season'])==2026 and r['game_type']=='REG' and played(r):
        hs,as_=int(r['home_score']),int(r['away_score'])
        if hs>as_: base[r['home_team']]+=1
        elif as_>hs: base[r['away_team']]+=1
        else: base[r['home_team']]+=.5; base[r['away_team']]+=.5
idx={t:i for i,t in enumerate(TEAMS)}
NS=6000; rng=np.random.default_rng(2027)
hi=np.array([idx[r['home_team']] for r in rem]); ai=np.array([idx[r['away_team']] for r in rem])
E_=np.array([elo[t] for t in TEAMS])
ph=1/(1+10**(-((E_[hi]-E_[ai])+48)/400))
win_h=rng.random((NS,len(rem)))<ph
W0=np.array([base[t] for t in TEAMS])
wins=np.tile(W0,(NS,1))
for j in range(len(rem)):
    wins[:,hi[j]]+=win_h[:,j]; wins[:,ai[j]]+=~win_h[:,j]
noise=rng.random((NS,len(TEAMS)))*.01
conf={t:TI[t]['conf'] for t in TEAMS}; div={t:TI[t]['div'] for t in TEAMS}
cnt={t:{'po':0,'bye':0,'cc':0,'sb':0,'win':0} for t in TEAMS}
def pw_(a,b,home_a=True):
    d=E_[idx[a]]-E_[idx[b]]+(48 if home_a else 0)
    return 1/(1+10**(-d/400))
rnd=random.Random(11)
def play(a,b,home_a=True): return a if rnd.random()<pw_(a,b,home_a) else b
for s in range(NS):
    champs={}
    for c in ('AFC','NFC'):
        ts=[t for t in TEAMS if conf[t]==c]; sc_={t:wins[s,idx[t]]+noise[s,idx[t]] for t in ts}
        dw=[max([t for t in ts if div[t]==d],key=lambda t:sc_[t]) for d in sorted({div[t] for t in ts})]
        dw.sort(key=lambda t:-sc_[t]); wc=sorted([t for t in ts if t not in dw],key=lambda t:-sc_[t])[:3]
        seeds=dw+wc
        for t in seeds: cnt[t]['po']+=1
        cnt[seeds[0]]['bye']+=1
        w1=[play(seeds[1],seeds[6]),play(seeds[2],seeds[5]),play(seeds[3],seeds[4])]
        rk=lambda t:seeds.index(t)
        w1.sort(key=rk)
        top=seeds[0]; low=w1[-1]
        d1=play(top,low); d2=play(w1[0],w1[1])
        for t in (d1,d2): cnt[t]['cc']+=1
        a,b=sorted([d1,d2],key=rk); champs[c]=play(a,b)
    for c in champs: cnt[champs[c]]['sb']+=1
    a,b=champs['AFC'],champs['NFC']; cnt[play(a,b,False)]['win']+=1
OUT['sim']={'ns':NS,'teams':{t:{'elo':round(float(elo[t])),'w':base[t],**{k:round(v/NS,4) for k,v in cnt[t].items()}} for t in TEAMS}}
# the Bears' remaining schedule with single-game win chances
OUT['bearsrem']=[{'wk':int(r['week']),'d':r['gameday'],'opp':r['away_team'] if r['home_team']=='CHI' else r['home_team'],'h':r['home_team']=='CHI','p':round(float(pw_('CHI',r['away_team'] if r['home_team']=='CHI' else r['home_team'],r['home_team']=='CHI')),3)} for r in rem if 'CHI' in (r['home_team'],r['away_team'])]
OUT['sig']=[(t,round(float(elo[t]))) for t in sorted(TEAMS,key=lambda t:-elo[t])[:5]]
json.dump(OUT,open(HERE+'/sbx.json','w'),separators=(',',':'))
print(os.path.getsize(HERE+'/sbx.json'))
b=OUT['sim']['teams']['CHI']; print('CHI',b,OUT['sig'])
print({k:OUT['sim']['teams'][k]['win'] for k in ('SEA','PHI','KC','NE')})
print(sorted(((v['win'],t) for t,v in OUT['sim']['teams'].items()),reverse=True)[:6])
print(OUT['echo']['perm']); print(OUT['js20'],OUT['mp20'],OUT['sbrecsum'])
