/* ===================== GRIDIRON SHOWDOWN (retro head-to-head football) ===================== */
window.__showdown=function(stage,api){
  const PX=8,VW=24,VH=34,CW=VW*PX,CH=VH*PX;
  const rnd=Math.random,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const TEAMS_=Object.keys(TEAMCOL).sort((a,b)=>TEAMCOL[a][2].localeCompare(TEAMCOL[b][2]));
  const LV={0:{n:'Rookie',m:.86,react:.55},1:{n:'Pro',m:.96,react:.25},2:{n:'All-Pro',m:1.05,react:0}};
  const QL={45:'Short (45s quarters)',90:'Normal (90s quarters)',150:'Long (150s quarters)'};
  const S0={rb:7.9,qb:5.8,wr:7.9,ol:4.6,te:6.8,dl:6.6,lb:6.9,cb:7.4,s:7.2};
  let G=null,cv,ctx,raf=0,last=0,acc=0,dead=false,ui={};
  const pad={dx:0,dy:0};
  const keys={},inp=[{dx:0,dy:0,a:false,b:false,c:false,d:false,e:false},{dx:0,dy:0,a:false,b:false,c:false,d:false,e:false}];
  const rec=()=>{try{return JSON.parse(localStorage.getItem('gm.sd.rec'))||{w:0,l:0,t:0}}catch(e){return{w:0,l:0,t:0}}};
  const saveRec=r=>{try{localStorage.setItem('gm.sd.rec',JSON.stringify(r))}catch(e){}};
  const tn=a=>TEAMCOL[a][2],tc=(a,i)=>TEAMCOL[a][i||0];
  function lum(h){const n=parseInt(h.slice(1),16);return ((n>>16&255)*.3+(n>>8&255)*.59+(n&255)*.11)}
  function fixCols(a,b){ // avoid two near-identical jerseys
    const ca=tc(a),cb=tc(b);const d=Math.abs(lum(ca)-lum(cb));return d<40?[ca,tc(b,1)]:[ca,cb]}

  /* ------------------------------ setup UI ------------------------------ */
  stage.innerHTML=`<div class="sd">
    <div class="sdmenu" id="sdmenu"></div>
    <div class="sdgame" id="sdgame" hidden>
      <div class="sdscore" id="sdscore" aria-live="polite"></div>
      <div class="sdwrap" id="sdwrap"><canvas id="sdcv" width="${CW}" height="${CH}" aria-label="Football field"></canvas><div class="sdover" id="sdover" hidden></div>
        <div class="sdjoy" id="sdjoy" hidden><i></i></div>
        <div class="sdhint" id="sdhint" hidden></div>
        <div class="sdpad" id="sdpad"><div class="abtns"><button data-b="e" id="sdbtnE">BOOST</button><button data-b="d" id="sdbtnD">STRIP</button><button data-b="c" id="sdbtnC">TRUCK</button><button data-b="b" id="sdbtnB">STIFF-ARM</button><button data-b="a" id="sdbtnA">SPIN</button></div></div>
        <div class="sdplays" id="sdplays"></div></div>
      <p class="note" id="sdhelp"></p>
    </div></div>`;
  cv=stage.querySelector('#sdcv');ctx=cv.getContext('2d');ctx.imageSmoothingEnabled=false;
  ['sdmenu','sdgame','sdscore','sdover','sdplays','sdhelp','sdwrap'].forEach(i=>ui[i]=stage.querySelector('#'+i));

  /* ------------------------------ season mode ------------------------------ */
  const SK='gm.sd.season';
  const sget=()=>{try{const v=JSON.parse(localStorage.getItem(SK));return v&&v.team&&TEAMCOL[v.team]?v:null}catch(e){return null}};
  const sset=v=>{try{if(v)localStorage.setItem(SK,JSON.stringify(v));else localStorage.removeItem(SK)}catch(e){}};
  const toS=x=>x==='LAR'?'LA':x,toC=x=>x==='LA'?'LAR':x;
  const sched=t=>{t=toS(t);return SEA.filter(g=>g.h===t||g.a===t).sort((a,b)=>a.wk-b.wk)};
  function srec(S){let w=0,l=0,t=0;Object.values(S.res).forEach(r=>{if(r.us>r.them)w++;else if(r.us<r.them)l++;else t++});return{w,l,t}}
  const srecTxt=S=>{const r=srec(S);return r.w+'-'+r.l+(r.t?'-'+r.t:'')};
  function beginSeason(team){sset({team,lvl:+stage.querySelector('#ssl').value,qlen:+stage.querySelector('#ssq').value,res:{}});showSeason()}
  function simScore(t,o,home){
    const R=RK['2026'],lg=Object.values(R).reduce((a,x)=>a+x.ppg,0)/Object.keys(R).length;
    const m=lg*Math.pow(R[t].ppg/lg,.9)*Math.pow(R[o].papg/lg,.9)*(home?1.03:.97);
    const g=()=>{let u=0,v=0;while(!u)u=Math.random();while(!v)v=Math.random();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)};
    return Math.max(0,Math.round(m+g()*8));
  }
  function simGameRes(S,g){
    const us=toS(S.team),home=g.h===us,opp=home?g.a:g.h;let a=simScore(us,opp,home),b=simScore(opp,us,!home);
    if(a===b){if(Math.random()<.5)a+=3;else b+=3}
    S.res[g.id]={us:a,them:b,sim:1};
  }
  function showSeason(){
    const S=sget();if(!S){showMenu();return}
    if(G){G=null}
    ui.sdgame.hidden=true;ui.sdmenu.hidden=false;
    const T=S.team,Ts=toS(T),gs=sched(T),done=gs.filter(g=>S.res[g.id]),next=gs.find(g=>!S.res[g.id]),r=srec(S);
    const wkAll=gs.map(g=>g.wk),maxW=Math.max(...wkAll),minW=1;
    const rows=[];for(let w=minW;w<=maxW;w++){
      const g=gs.find(x=>x.wk===w);
      if(!g){rows.push(`<tr class="sbye"><td>${w}</td><td colspan="2">BYE WEEK</td><td></td></tr>`);continue}
      const home=g.h===Ts,opp=home?g.a:g.h,x=S.res[g.id];
      const res=x?`<b class="${x.us>x.them?'w':x.us<x.them?'l':''}">${x.us>x.them?'W':x.us<x.them?'L':'T'} ${x.us}-${x.them}</b>${x.sim?' <span class="st">sim</span>':''}`:(next&&next.id===g.id?'<span class="st">up next</span>':'');
      rows.push(`<tr${next&&next.id===g.id?' class="snext"':''}><td>${w}</td><td>${tlogo(opp,18)} ${home?'vs':'at'} <b>${esc(tn(toC(opp)))}</b></td><td>${res}</td><td>${home?'Home':'Away'}</td></tr>`)}
    const pct=done.length?Math.round((r.w+r.t/2)/done.length*100):0;
    const L=S.lvl;
    ui.sdmenu.innerHTML=`<div class="card sdcard"><div class="teamhead"><h2>${tlogo(Ts,30)} ${esc(tn(T))} season</h2><span class="count">${LV[L].n} · ${QL[S.qlen]||''}</span></div>
      <div class="pkstats"><div class="pkstat"><b>${r.w}-${r.l}${r.t?'-'+r.t:''}</b><span>Season record</span></div><div class="pkstat"><b>${done.length?pct+'%':'-'}</b><span>Win %</span></div><div class="pkstat"><b>${done.length}/${gs.length}</b><span>Games played</span></div></div>
      ${next?`<div class="sdnext"><span class="st">Week ${next.wk}</span><b>${tlogo(Ts,22)} ${tn(T)} ${next.h===Ts?'vs':'at'} ${tlogo(next.h===Ts?next.a:next.h,22)} ${esc(tn(toC(next.h===Ts?next.a:next.h)))}</b>
        <div class="filters"><button class="btn solid" type="button" id="ssplay">Play week ${next.wk}</button><button class="btn" type="button" id="sssim">Sim this game</button><button class="btn" type="button" id="sssimall">Sim rest of season</button></div></div>`
        :`<div class="sdnext"><b>Season complete: ${r.w}-${r.l}${r.t?'-'+r.t:''}</b><span class="note">${r.w>=12?'A dominant year.':r.w>=9?'A winning season.':r.w>=7?'Right around .500.':'A rough one. Run it back.'}</span></div>`}
      <div class="tablebox"><table class="sttbl"><thead><tr><th>Wk</th><th>Opponent</th><th>Result</th><th></th></tr></thead><tbody>${rows.join('')}</tbody></table></div>
      <div class="filters"><button class="btn" type="button" id="ssback">Back to menu</button><button class="btn" type="button" id="ssreset">Reset season</button></div>
      <p class="note">Matchups and order follow the real 2026 NFL schedule for ${esc(tn(T))}. Results here are your own and do not change the real standings.</p></div>`;
    const q=id=>ui.sdmenu.querySelector('#'+id);
    if(next){
      q('ssplay').onclick=()=>{const home=next.h===Ts,opp=home?next.a:next.h;newGame(T,toC(opp),1,S.lvl,S.qlen);G.season={id:next.id,home}};
      q('sssim').onclick=()=>{simGameRes(S,next);sset(S);showSeason()};
      q('sssimall').onclick=()=>{gs.filter(g=>!S.res[g.id]).forEach(g=>simGameRes(S,g));sset(S);showSeason()};
    }
    q('ssback').onclick=showMenu;
    let armed=false;q('ssreset').onclick=()=>{if(!armed){armed=true;q('ssreset').textContent='Press again to erase this season';setTimeout(()=>{armed=false;if(q('ssreset'))q('ssreset').textContent='Reset season'},4000);return}sset(null);showMenu()};
  }

  function showMenu(){
    const SS=sget(),r=rec(),opts=TEAMS_.map(a=>`<option value="${a}">${NAMES[a]||a}</option>`).join('');
    ui.sdgame.hidden=true;ui.sdmenu.hidden=false;
    ui.sdmenu.innerHTML=`<div class="card sdcard"><h2>Gridiron Showdown</h2>
      <p class="sub">Retro head-to-head football. Pick a play, then run, throw and tackle in real time. Beat the CPU or hand the keyboard to a friend.</p>
      <div class="filters">
        <label for="sdt1">Your team<select id="sdt1">${opts}</select></label>
        <label for="sdt2">Opponent<select id="sdt2">${opts}</select></label>
        <label for="sdmode">Mode<select id="sdmode"><option value="1">1 player vs CPU</option><option value="2">2 players, one device</option><option value="0">Watch CPU vs CPU</option></select></label>
        <label for="sdlvl">CPU level<select id="sdlvl"><option value="0">Rookie</option><option value="1" selected>Pro</option><option value="2">All-Pro</option></select></label>
        <label for="sdlen">Game length<select id="sdlen">${Object.keys(QL).map(k=>`<option value="${k}"${k==90?' selected':''}>${QL[k]}</option>`).join('')}</select></label>
      </div>
      <div class="filters"><button class="btn solid" type="button" id="sdgo">Kick off</button></div>
      <p class="note">Your record vs the CPU: <b>${r.w}-${r.l}${r.t?'-'+r.t:''}</b></p>
      <p class="note"><b>Controls.</b> Move: WASD or arrow keys, or the on-screen pad. <b>Offense:</b> A (F/Space) throw or SPIN, B (G) STIFF-ARM, C (H) TRUCK. <b>Defense:</b> A dive, B (G) switch player, C (H) BIG HIT, D (J) STRIP. Power moves drain a shared power bar that refills over time. BOOST (E key) is a short sprint with its own thin cyan bar under the power bar; use it on offense or to chase down a runner. Tackles now need a wrap-up, so use moves to break free. 2 players: P1 WASD + F/G/H/J, P2 arrows + K/L/;/'. Hotkeys 1-6 pick plays.</p></div>
    <div class="card sdcard" id="sdseasoncard"><h2>Season mode</h2>
      <p class="sub">Pick your team and play its real 2026 schedule, week by week, against the same opponents the NFL lined up. Your win-loss record is saved on this device.</p>
      <div class="filters"><label for="sst">Your team<select id="sst">${opts}</select></label>
        <label for="ssl">CPU level<select id="ssl"><option value="0">Rookie</option><option value="1" selected>Pro</option><option value="2">All-Pro</option></select></label>
        <label for="ssq">Game length<select id="ssq">${Object.keys(QL).map(k=>`<option value="${k}"${k==45?' selected':''}>${QL[k]}</option>`).join('')}</select></label></div>
      <div class="filters"><button class="btn solid" type="button" id="ssgo">${SS?'Continue season ('+tn(SS.team)+' '+srecTxt(SS)+')':'Start season'}</button>${SS?'<button class="btn" type="button" id="ssnew">New season with these picks</button>':''}</div>
    </div>`;
    const SS2=SS;
    const t1=stage.querySelector('#sdt1'),t2=stage.querySelector('#sdt2');t1.value=TEAMS_[0];t2.value=TEAMS_[Math.floor(TEAMS_.length/2)];
    {const st=stage.querySelector('#sst');st.value=(SS&&SS.team)||(TI&&TEAMS_.includes('KC')?'KC':TEAMS_[0]);
      stage.querySelector('#ssgo').onclick=()=>{if(SS){showSeason();return}beginSeason(st.value)};
      const nb=stage.querySelector('#ssnew');if(nb)nb.onclick=()=>beginSeason(st.value)}
    stage.querySelector('#sdgo').onclick=()=>newGame(t1.value,t2.value===t1.value?TEAMS_.find(x=>x!==t1.value):t2.value,+stage.querySelector('#sdmode').value,+stage.querySelector('#sdlvl').value,+stage.querySelector('#sdlen').value);
  }

  /* ------------------------------ game state ------------------------------ */
  function newGame(a,b,mode,lvl,qlen){
    const cols=fixCols(a,b);
    G={teams:[a,b],col:[[cols[0],tc(a,1)],[cols[1],tc(b,1)]],mode,lvl,qlen,score:[0,0],q:1,clock:qlen,off:mode===1?0:(rnd()<.5?0:1),startOff:0,los:25,lineToGain:35,down:1,
       phase:'select',ents:[],O:[],D:[],ball:{holder:null,air:false,x:12,y:25},play:null,t:0,thrown:false,msg:'',ot:false,done:false,cam:25,ctrlD:null,target:0,since:0,pm:[1,1],bs:[1,1],fx:[],stats:{plays:0,yds:[0,0]}};
    G.startOff=G.off;
    ui.sdmenu.hidden=true;ui.sdgame.hidden=false;ui.sdover.hidden=true;ui.sdover.className='sdover';
    const touch=('ontouchstart' in window)||navigator.maxTouchPoints>0;ui.sdhelp.textContent=mode===2?'P1: WASD, F/G/H/J.  P2: arrows, K/L/;/\'.':touch?'Drag on the field to move. Tap a receiver to throw. Use the round buttons for boost, spin, stiff-arm, truck, dive, hit, strip and switch. Tap a pass play once to preview its routes, tap again to snap.':'Move: WASD or arrows. Offense: F spin, G stiff-arm, H truck, E boost. Defense: F dive, G switch, H hit, J strip, E boost. Keys 1-6 pick plays.';
    try{window.focus();ui.sdgame.scrollIntoView({block:'start'})}catch(er){}
    stage.querySelector('#sdpad').style.display=mode===2?'none':'';stage.querySelector('#sdjoy').hidden=true;
    setupPlay();goSelect();
    if(!raf){last=0;raf=requestAnimationFrame(loop)}
  }
  const human=t=>G.mode===2||(G.mode===1&&t===0);
  const offT=()=>G.off,defT=()=>1-G.off;

  function mk(role,team,x,y,side){return{role,team,x,y,vx:0,vy:0,sx:x,sy:y,stun:0,eng:false,engT:0,hold:0,free:false,jt:0,jcd:0,dive:0,boostT:0,wrapT:0,truckT:0,touch:false,hit:false,route:null,ri:0,spd:S0[role],ph:rnd()*6}}
  function setupPlay(){
    const L=G.los,o=G.off,d=1-o,E=[],O=[],D=[];
    const add=(arr,e)=>{E.push(e);arr.push(e);return e};
    const q=add(O,mk('qb',o,12,L-3)),rb=add(O,mk('rb',o,12,L-6.5)),te=add(O,mk('te',o,18.6,L-.7));
    const w1=add(O,mk('wr',o,2.4,L-.8)),w2=add(O,mk('wr',o,21.6,L-.8)),w3=add(O,mk('wr',o,6,L-1.8));
    [8,10,12,14,16].forEach(x=>add(O,mk('ol',o,x,L-.7)));
    [8.6,11,13.2,15.6].forEach(x=>add(D,mk('dl',d,x,L+.9)));
    [7,12,17].forEach(x=>add(D,mk('lb',d,x,L+4.3)));
    [2.4,21.6].forEach(x=>add(D,mk('cb',d,x,L+5)));
    [7.5,16.5].forEach(x=>add(D,mk('s',d,x,L+11)));
    G.O=O;G.D=D;G.ents=E;G.qb=q;G.rb=rb;G.te=te;G.wrs=[w1,w2,w3,te];G.ol=O.slice(6);G.dl=D.slice(0,4);G.lb=D.slice(4,7);G.cb=D.slice(7,9);G.sf=D.slice(9,11);
    G.pm=[1,1];G.bs=[1,1];G.fx=[];G.ball={holder:q,air:false,x:q.x,y:q.y};G.thrown=false;G.t=0;G.target=0;G.ctrlD=null;G.since=0;
    D.forEach(e=>e.spd*=LV[G.lvl].m*(human(d)?1.02:1));
    G.cam=L+2;
  }
  function goSelect(){
    G.phase='select';G.preview=null;
    const ot=offT(),L=G.los,toGo=Math.max(1,Math.round(G.lineToGain-L));
    const down=['1st','2nd','3rd','4th'][G.down-1],spot=L<=50?'own '+L:'opp '+(100-L);
    G.msg=`${down} & ${G.lineToGain>=100?'Goal':toGo} at ${spot}`;
    renderScore();ui.sdover.hidden=true;
    const pl=ui.sdplays;
    if(G.mode===0||(!human(ot)&&!human(1-ot))){setTimeout(()=>{if(!dead&&G&&G.phase==='select')snap(cpuCall())},60);pl.innerHTML='';return}
    if(human(ot)){
      const inFG=100-L+17<=56;
      pl.innerHTML=`<div class="sdcall"><b>${tn(G.teams[ot])} ball. Pick a play</b></div>
        <div class="sdbtns"><button class="btn" data-pl="run1">1 Run inside</button><button class="btn" data-pl="run2">2 Run outside</button><button class="btn" data-pl="pass1">3 Short pass</button><button class="btn" data-pl="pass2">4 Deep pass</button>${G.down===4?`<button class="btn" data-pl="punt">5 Punt</button>${inFG?`<button class="btn" data-pl="fg">6 Field goal (${100-L+17} yd)</button>`:''}`:''}</div>`;
    }else{
      pl.innerHTML=`<div class="sdcall"><b>${tn(G.teams[ot])} have the ball.</b> You play defense: the highlighted player is yours. A dives, B switches, C is a big hit, D tries to strip the ball.</div><div class="sdbtns"><button class="btn solid" data-pl="auto">Hike!</button></div>`;
    }
  }
  function cpuCall(){
    const L=G.los,toGo=G.lineToGain-L,me=G.score[G.off]-G.score[1-G.off],late=G.q>=4&&G.clock<60;
    if(G.down===4){
      if(100-L+17<=50&&!(toGo<=1.5&&L>60&&me<0))return'fg';
      if(toGo<=2.5&&L>45&&(me<0||L>70))return rnd()<.5?'run1':'pass1';
      if(L<55)return 'punt';
      return rnd()<.5?'pass1':'run1';
    }
    let pPass=toGo>8?.7:toGo>4?.5:.3;if(late&&me<0)pPass=.85;if(late&&me>0)pPass=.15;
    if(rnd()<pPass)return rnd()<(toGo>12||late&&me<0?.5:.22)?'pass2':'pass1';
    return rnd()<.5?'run1':'run2';
  }
  function snap(call){
    if(G.phase!=='select')return;
    ui.sdplays.innerHTML='';
    if(call==='auto')call=cpuCall();
    if(call==='punt'||call==='fg')return kick(call);
    G.play=call;G.phase='live';G.t=0;G.thrown=false;G.since=0;
    if(G.mode!==2){const hu=human(G.off),isP=call.startsWith('pass');if(G.stats.plays<3||true)showHint(hu?(isP?'Drag to move. Tap a receiver to throw!':'Drag to run. A to juke!'):'You are on defense: drag to chase. A to dive!')}
    const rb=G.rb,q=G.qb;
    if(call.startsWith('run')){G.ball.holder=rb;rb.spd=S0.rb;if(call==='run2'){rb.route=[[rb.x>12?19:5,rb.y+1.2]]}}
    else{G.ball.holder=q;setRoutes(call)}
    G.hold=call==='run1'?3.1:call==='run2'?1.9:(1.5+rnd()*1.6);
    G.blitz=rnd()<.22;G.defKnow=G.lvl===2||rnd()<.5;
    G.dl.forEach((d,i)=>{d.hold=G.hold*(.8+rnd()*.5)});G.dl[2].hold*=1.4;
    G.lb.forEach(e=>{e.react=LV[G.lvl].react});G.D.forEach(e=>e.react=LV[G.lvl].react*(.6+rnd()*.8));
    G.cpuThrowAt=1.5+rnd()*1.4+(call==='pass2'?.7:0);
    renderScore();
  }
  function setRoutes(call){
    const sp=call==='pass2'
      ?[[[0,28]],[[0,14],[5,24]],[[0,9],[-6,19]],[[0,7],[2,12]]]
      :[[[0,6.5],[.8,5.2]],[[0,2.5],[5,8.5]],[[0,4.5],[-3.5,5.2]],[[-4.5,1.2],[-8,2.2]]];
    G.wrs.forEach((w,i)=>{const side=w.x<12?1:-1,pts=[];let cx=w.x,cy=w.y;
      sp[i].forEach(([dx,dy])=>{pts.push([clamp(w.x+dx*side*(i===3?-1:1),1,23),w.y+dy])});w.route=pts;w.ri=0;w.r0=[w.x,w.y];w.spd=S0.wr});
  }

  /* ------------------------------ kicks ------------------------------ */
  function kick(call){
    const L=G.los,o=G.off;G.phase='banner';let txt,sub='';
    if(call==='fg'){const d=100-L+17,p=clamp(1.08-(d-18)*.0225,.05,.97),ok=rnd()<p;
      if(ok){G.score[o]+=3;txt='FIELD GOAL IS GOOD!';sub=`${d} yards. +3`;afterScore(o,txt,sub)}
      else{txt='NO GOOD';sub=`${d}-yard attempt missed`;turnover(Math.max(20,100-L),txt,sub)}return}
    const dist=36+rnd()*13,land=L+dist;txt='PUNT';
    if(land>=100){turnover(20,txt,'Touchback')}else{turnover(Math.max(1,Math.round(100-land)),txt,`Downed at the ${Math.round(100-land)<=50?'own '+Math.round(100-land):'opp '+Math.round(land)}`)}
  }
  function turnover(newLos,txt,sub){G.off=1-G.off;G.los=clamp(Math.round(newLos),1,99);G.down=1;G.lineToGain=Math.min(100,G.los+10);banner(txt,sub)}
  function afterScore(o,txt,sub){
    if(G.q>=5){G.done=true}
    G.off=1-o;G.los=25;G.down=1;G.lineToGain=35;banner(txt,sub);
  }

  /* ------------------------------ play outcome ------------------------------ */
  function endPlay(res){
    if(G.phase!=='live')return;G.phase='banner';G.stats.plays++;
    const o=G.off,old=G.los;(G.log=G.log||[]).push([G.play,res.type,res.y===undefined?0:Math.round(res.y-old),+G.t.toFixed(1)]);
    if(res.type==='td'){G.score[o]+=7;return afterScore(o,'TOUCHDOWN!','+7 (extra point good)')}
    if(res.type==='fumble'){const y=res.y;return turnover(clamp(100-Math.round(y),1,99),'FUMBLE!','Defense recovers the ball')}
    if(res.type==='int'){const y=res.y;let nl=y>=100?20:100-Math.round(y);return turnover(clamp(nl,1,99),'INTERCEPTED!',y>=100?'Touchback':'Picked off')}
    let txt,sub;
    if(res.type==='inc'){txt='INCOMPLETE';sub='';G.down++}
    else{const nl=clamp(Math.round(res.y),1,99),gain=nl-old;G.stats.yds[o]+=gain;
      txt=res.type==='sack'?'SACKED!':'TACKLED';sub=(gain>=0?'+':'')+gain+' yards';
      if(nl>=G.lineToGain||nl>=99&&false){G.down=1;G.los=nl;G.lineToGain=Math.min(100,nl+10);txt='FIRST DOWN!';sub=(gain>=0?'+':'')+gain+' yards'}
      else{G.los=nl;G.down++}}
    if(G.down>4){return turnover(100-G.los,'TURNOVER ON DOWNS',sub)}
    banner(txt,sub);
  }
  function banner(txt,sub){
    G.phase='banner';ui.sdover.hidden=false;ui.sdover.className='sdover b';
    ui.sdover.innerHTML=`<div class="sdban"><b>${txt}</b><span>${sub||''}</span></div>`;
    renderScore();G.bt=0;
  }
  function afterBanner(){
    ui.sdover.hidden=true;
    if(G.done&&G.q>=5)return finish();
    if(G.clock<=0){
      if(G.q===2){G.q=3;G.clock=G.qlen;G.off=1-G.startOff;G.los=25;G.down=1;G.lineToGain=35;return interstitial('HALFTIME',`${G.score[0]} - ${G.score[1]}`)}
      if(G.q===4){if(G.score[0]===G.score[1]){G.q=5;G.clock=G.qlen;G.ot=true;G.off=rnd()<.5?0:1;G.los=25;G.down=1;G.lineToGain=35;return interstitial('OVERTIME','Sudden death. First score wins.')}return finish()}
      if(G.q>=5)return finish();
      G.q++;G.clock=G.qlen;return interstitial('END OF QUARTER',`Starting quarter ${G.q}`);
    }
    setupPlay();goSelect();
  }
  function interstitial(a,b){
    G.phase='banner';ui.sdover.hidden=false;ui.sdover.className='sdover b';
    ui.sdover.innerHTML=`<div class="sdban"><b>${a}</b><span>${b}</span></div>`;G.bt=-1.2;renderScore();
  }
  function finish(){
    G.phase='final';const[a,b]=G.score,w=a>b?0:b>a?1:-1;
    if(G.season){const S=sget();if(S){S.res[G.season.id]={us:a,them:b};sset(S)}}else if(G.mode===1){const r=rec();if(w===0)r.w++;else if(w===1)r.l++;else r.t++;saveRec(r)}
    ui.sdover.hidden=false;ui.sdover.className='sdover f';ui.sdplays.innerHTML='';
    const who=w<0?'TIE GAME':G.mode===1?(w===0?'YOU WIN!':'CPU WINS'):`${tn(G.teams[w])} WIN!`;
    ui.sdover.innerHTML=`<div class="sdban fin"><span>FINAL</span><b>${who}</b><span class="big">${tn(G.teams[0])} ${a} - ${b} ${tn(G.teams[1])}</span>${G.season?`<div class="sdbtns"><button class="btn solid" data-act="shub">Back to season</button></div>`:'<div class="sdbtns"><button class="btn solid" data-act="again">Play again</button><button class="btn" data-act="menu">Change teams</button></div>'}</div>`;
    if(G.season){const S=sget();if(S)ui.sdover.querySelector('.big').insertAdjacentHTML('afterend',`<span>Season record ${srecTxt(S)}</span>`)}
    renderScore();
  }

  /* ------------------------------ simulation ------------------------------ */
  const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
  function moveTo(e,tx,ty,sp,dt){
    if(e.stun>0){e.stun-=dt;e.vx=e.vy=0;return}
    const dx=tx-e.x,dy=ty-e.y,d=Math.hypot(dx,dy);
    if(d<.05){e.vx=e.vy=0;return}
    const s=Math.min(sp,d/dt);e.vx=dx/d*s;e.vy=dy/d*s;e.x+=e.vx*dt;e.y+=e.vy*dt;
  }
  function drive(e,dx,dy,sp,dt){
    if(e.stun>0){e.stun-=dt;e.vx=e.vy=0;return}
    const m=Math.hypot(dx,dy);if(m<.05){e.vx=e.vy=0;return}
    e.vx=dx/m*sp;e.vy=dy/m*sp;e.x+=e.vx*dt;e.y+=e.vy*dt;
  }
  function pw(team,cost){if(G.pm[team]>=cost-1e-6){G.pm[team]-=cost;return true}return false}
  function fx(x,y,txt,col){G.fx.push({x,y,txt,col:col||'#fff',t:0})}
  function doBoost(e){if(!e||e.boostT>0||e.stun>0||G.bs[e.team]<.28)return;G.bs[e.team]-=.28;e.boostT=1.15;fx(e.x,e.y,'BOOST!','#6ee7ff')}
  function doSpin(c){if(c.jt>0||c.jcd>0||!pw(c.team,.2))return;c.jt=.34;c.jcd=.3;c.wrapT=0;fx(c.x,c.y,'SPIN','#fff')}
  function doStiff(c){
    if(!pw(c.team,.3))return;let near=null,nd=2.4;G.D.forEach(df=>{const d=dist(df,c);if(d<nd){nd=d;near=df}});
    c.wrapT=0;
    if(!near){fx(c.x,c.y,'STIFF-ARM','#fff');return}
    near.stun=1.1;near.dive=0;near.hit=false;near.touch=false;const dx=near.x-c.x,dy=near.y-c.y,m=Math.hypot(dx,dy)||1;near.x+=dx/m*1.6;near.y+=dy/m*1.6;
    G.D.forEach(df=>{if(df!==near&&dist(df,c)<1.3)df.touch=false});
    fx(near.x,near.y,'STIFF-ARM!','#ffd23a');
  }
  function doTruck(c){if(c.truckT>0||!pw(c.team,.45))return;c.truckT=.45;c.wrapT=0;fx(c.x,c.y,'TRUCK!','#ff8a5c')}
  function doHit(df){if(df.dive>0||df.stun>0||!pw(df.team,.4))return false;df.hit=true;df.dive=.3;fx(df.x,df.y,'HIT!','#ffd23a');return true}
  function doStrip(df,c){
    if(!c||dist(df,c)>2||!pw(df.team,.25))return;
    if(rnd()<.38){fx(c.x,c.y,'STRIPPED!','#ff6b5c');endPlay({type:'fumble',y:Math.max(1,c.y)})}else{df.stun=.45;fx(df.x,df.y,'NO LUCK','#cfe6ff')}
  }
  function getIn(t){return G.mode===2?inp[t]:inp[0]}
  function focus(){const b=G.ball;if(b.holder)return b.holder;if(b.air)return{x:b.tx,y:b.ty};return G.qb}
  function step(dt){
    if(!G)return;
    if(G.phase==='banner'){G.bt=(G.bt||0)+dt;if(G.bt>1.35)afterBanner();return}
    if(G.phase!=='live')return;
    G.t+=dt;const b=G.ball,o=G.off,d=1-o,isRun=G.play.startsWith('run'),L=G.los;
    if(G.clock>0)G.clock=Math.max(0,G.clock-dt);
    // ------- clear edge-triggered buttons into locals
    const iO=human(o)?getIn(o):null,iD=human(d)?getIn(d):null;
    const aO=iO&&iO.a,bO=iO&&iO.b,cO=iO&&iO.c,eO=iO&&iO.e,aD=iD&&iD.a,bD=iD&&iD.b,cD=iD&&iD.c,dD=iD&&iD.d,eD=iD&&iD.e;
    if(iO){iO.a=false;iO.b=false;iO.c=false;iO.d=false;iO.e=false}if(iD){iD.a=false;iD.b=false;iD.c=false;iD.d=false;iD.e=false}
    for(let i=0;i<2;i++){G.pm[i]=Math.min(1,G.pm[i]+dt*.14);G.bs[i]=Math.min(1,G.bs[i]+dt*.11)}
    G.ents.forEach(e=>{if(e.boostT>0)e.boostT=Math.max(0,e.boostT-dt)});
    G.fx=G.fx.filter(f=>(f.t+=dt)<.95);
    // ------- offense
    const car=b.holder,qb=G.qb;
    // blockers
    G.ol.forEach((ol,i)=>{
      const dlI=[0,1,2,2,3][i],dl=G.dl[dlI];
      if(!dl.free){const tx=dl.x,ty=dl.y-.95;
        if(Math.abs(dl.x-ol.x)<1.1&&Math.abs(dl.y-ol.y)<1.7){ol.eng=true;dl.engT+=dt/(i===3?1.4:1);ol.vx=ol.vy=0;ol.y=dl.y-.95;
          if(dl.engT>dl.hold){dl.free=true;ol.eng=false}}
        else moveTo(ol,tx,ty,S0.ol,dt)}
      else moveTo(ol,ol.sx,ol.y,1.5,dt);
    });
    // TE blocks edge on runs
    if(isRun&&!car.route&&G.te!==car){const t=G.lb[2];moveTo(G.te,t.x,t.y-1,S0.te,dt)}
    // receivers
    G.wrs.forEach((w,i)=>{
      if(b.holder===w)return;
      if(isRun){if(i<3){const cb=G.cb[i===1?1:0],dd=i===2?G.lb[0]:cb;moveTo(w,dd.x,Math.min(dd.y-1,w.sy+8),6,dt)}return}
      if(w.route&&w.ri<w.route.length){const p=w.route[w.ri];moveTo(w,p[0],p[1],S0.wr,dt);if(Math.hypot(p[0]-w.x,p[1]-w.y)<.25)w.ri++}
      else if(b.air&&G.tgt===w){}
      else{w.vx=w.vy=0}
    });
    // human offense control
    if(iO){
      let ctl=null;if(car)ctl=car;else if(b.air&&G.tgt&&G.tgt.team===o)ctl=G.tgt;
      if(ctl){
        const sp=ctl===qb?S0.qb:ctl.role==='rb'?S0.rb:S0.wr*0.96;
        if(eO)doBoost(ctl);const jm=(ctl.boostT>0?1.4:1)*(ctl.jt>0?1.3:1)*(ctl.truckT>0?1.28:1)*(ctl.wrapT>.02?.55:1);drive(ctl,iO.dx,iO.dy,sp*jm*(ctl.stun>0?0:1),dt);
        if(ctl===qb&&!G.thrown&&!isRun){
          if(bO){const ws=G.wrs;G.target=(G.target+1)%ws.length}
          if(aO)throwTo(G.wrs[G.target])
        }else if(ctl===car){if(aO)doSpin(ctl);if(bO)doStiff(ctl);if(cO)doTruck(ctl)}
      }
    }
    // cpu offense
    if(!iO||!(car||b.air)){
      if(car&&!iO){
        if(car===qb&&!G.thrown&&!isRun){
          const press=G.D.some(x=>!x.stun&&dist(x,qb)<2.3&&!(x.role==='dl'&&!x.free&&x.engT>0));
          if(G.t>G.cpuThrowAt||press&&G.t>.9){const tg=bestTarget();if(tg)throwTo(tg);else if(G.t>G.cpuThrowAt+1.6)runAI(car,dt)}
          else{moveTo(qb,qb.x+Math.sin(G.t*2)*.4,Math.max(L-6.5,qb.y-1),3,dt)}
        }else runAI(car,dt);
        if(car.jcd>0)car.jcd-=dt;
      }
    }
    if(car){car.jt=Math.max(0,car.jt-dt);car.jcd=Math.max(0,car.jcd-dt);car.truckT=Math.max(0,car.truckT-dt)}
    // RB (pass plays) stays to block/check
    if(!isRun&&G.rb!==car){moveTo(G.rb,G.rb.sx,G.rb.sy,2,dt)}
    if(!isRun&&G.thrown&&!car&&b.air&&!iO){ /* cpu receivers adjust to ball */
      const w=G.tgt;if(w&&w.team===o)moveTo(w,b.tx,b.ty,S0.wr,dt)}
    // ------- ball
    if(b.air){
      b.t+=dt;const k=Math.min(1,b.t/b.T);b.x=b.ax+(b.tx-b.ax)*k;b.y=b.ay+(b.ty-b.ay)*k;b.z=Math.sin(k*Math.PI)*(2+b.dist*.08);if(b.trail){b.trail.push([b.x,b.y,b.z]);if(b.trail.length>14)b.trail.shift()}
      // swat
      G.D.forEach(df=>{if(df.dive>0&&dist(df,{x:b.x,y:b.y})<1.9&&b.z<2.8&&!b.swat&&k>.35){b.swat=true}});
      if(k>=1)resolveCatch();
    }else if(car){b.x=car.x;b.y=car.y}
    // ------- defense
    updateDefense(dt,iD,aD,bD,cD,dD);
    // ------- tackles
    const c=b.holder;
    if(c&&G.phase==='live'){
      if(c.y>=100){return endPlay({type:'td'})}
      if(c.y<=0&&c===qb&&!G.thrown){/* safety-ish: treat as sack at 1 */}
      const qbPre=c===qb&&!G.thrown,LV_=G.lvl;let n=0;
      for(const df of G.D){
        if(df.stun>0){df.touch=false;continue}
        if(df.role==='dl'&&!df.free&&dist(df,c)>1.3)continue;
        const tr=df.dive>0?1.5:1.0,dd=dist(df,c);
        if(dd>=tr){if(dd>tr+.5)df.touch=false;continue}
        if(c.jt>0){if(!df.touch){df.touch=true;if(rnd()<.72){df.stun=.8;df.dive=0;df.hit=false;fx(c.x,c.y,'SPIN!','#fff')}}continue}
        if(!df.touch){
          df.touch=true;
          if(c.truckT>0&&!(df.hit&&rnd()<.4)){if(rnd()<.72){df.stun=1.4;df.dive=0;df.hit=false;fx(df.x,df.y,'TRUCKED!','#ff8a5c');continue}}
          const human_=df===G.ctrlD,hitChance=df.hit?1:human_?0:[.05,.11,.2][LV_];
          if(hitChance>0&&rnd()<hitChance&&!qbPre){fx(c.x,c.y,'BIG HIT!','#ffd23a');if(rnd()<(df.hit?.24:.18)){return endPlay({type:'fumble',y:Math.max(1,c.y)})}return endPlay({type:'tackle',y:Math.max(1,c.y)})}
          const miss=qbPre?0:human_?.12:[.45,.36,.28][LV_];
          if(rnd()<miss){df.stun=.7;df.dive=0;df.hit=false;fx(df.x,df.y,'MISSED!','#cfe6ff');continue}
          if(df.dive>0)c.wrapT+=.22;
        }
        n++;
      }
      if(n>0){c.wrapT+=dt*(1+(n-1)*.9);
        // cpu strip attempts while being wrapped
        if(!qbPre&&G.D.some(x=>x.touch&&x!==G.ctrlD)&&rnd()<dt*[.2,.4,.65][LV_]&&rnd()<.33){fx(c.x,c.y,'STRIPPED!','#ff6b5c');return endPlay({type:'fumble',y:Math.max(1,c.y)})}
      }
      else c.wrapT=Math.max(0,c.wrapT-dt*1.8);
      if(c.wrapT>=(qbPre?.4:.5)){
        const sack=qbPre&&!isRun&&c.y<L+.5;
        return endPlay({type:sack?'sack':'tackle',y:Math.max(1,c.y)});
      }
    }
    // clamp field
    G.ents.forEach(e=>{e.x=clamp(e.x,.6,VW-.6);e.y=clamp(e.y,-9,109)});
    // camera
    const f=focus();let ty0=f.y+3.5;
    if(!b.air&&!b.holder&&false){}
    if(human(o)&&b.holder===G.qb&&!G.thrown&&!isRun0()&&G.wrs[G.target]){ty0=Math.max(f.y+3.5,(G.qb.y+G.wrs[G.target].y)/2+3)}
    else if(b.air){ty0=Math.max(f.y+3.5,(b.y*.4+b.ty*.6)+3.5)}
    else if(b.holder&&b.holder.team===o){ty0=f.y+3.5+clamp(b.holder.vy*.35,-1,3)}
    const target=clamp(ty0,-10+VH/2,110-VH/2);G.cam+=(target-G.cam)*Math.min(1,dt*5);
  }
  const isRun0=()=>G.play&&G.play.startsWith('run');
  function runAI(c,dt){
    // pick heading that stays away from defenders ahead
    c.ait=(c.ait||0)-dt;
    if(c.ait<=0||c.ax===undefined){c.ait=.2;let best=-1,bx=c.x;
      for(let dx=-7;dx<=7;dx+=1.75){const tx=clamp(c.x+dx,2,22),ty=c.y+7;let m=99;
        G.D.forEach(df=>{if(df.y<c.y-1.2)return;const ax=c.x,ay=c.y,bx_=tx,by=ty,vx=bx_-ax,vy=by-ay,l2=vx*vx+vy*vy;let t=((df.x-ax)*vx+(df.y-ay)*vy)/l2;t=clamp(t,0,1);const px=ax+vx*t,py=ay+vy*t;m=Math.min(m,Math.hypot(df.x-px,df.y-py)*(df.role==='dl'&&!df.free?1.6:1))});
        const sc=m-Math.abs(dx)*.08;if(sc>best){best=sc;bx=tx}}
      c.ax=bx}
    if(c.boostT<=0&&c.y>G.los+2&&G.bs[c.team]>.6&&rnd()<dt*0)doBoost(c);const sp=(c.role==='qb'?S0.qb:c.role==='rb'?S0.rb:S0.wr*.96)*(c.boostT>0?1.38:1)*(c.truckT>0?1.28:1)*(c.wrapT>.02?.55:1);
    drive(c,(c.ax-c.x)*.9,5,sp,dt);
    // juke when a defender is close ahead
    if(c.jcd<=0&&c.jt<=0&&G.D.some(df=>df.stun<=0&&df.y>c.y&&dist(df,c)<2.1)&&rnd()<.4)doSpin(c);
    if(c.wrapT>.1&&rnd()<dt*4)doStiff(c);
    if(c.truckT<=0&&G.D.filter(df=>df.stun<=0&&df.y>=c.y-.5&&dist(df,c)<3.6).length>=1&&rnd()<dt*1.1)doTruck(c);
  }
  function bestTarget(){
    let best=null,bs=-99;
    G.wrs.forEach(w=>{if(!w.route||w.ri===0&&G.t<.6)return;
      let open=99;G.D.forEach(df=>{open=Math.min(open,dist(df,w))});
      const adv=w.y-G.qb.y,sc=open*1.3+adv*.06-(w.ri<w.route.length&&G.play==='pass2'?0:0)+rnd()*.7;
      if(open>2.0&&w.y>G.los-2&&sc>bs){bs=sc;best=w}});
    return best;
  }
  function predictLand(w){
    const q=G.qb,SP=24;let tx=w.x,ty=w.y;
    for(let i=0;i<3;i++){const d=Math.hypot(tx-q.x,ty-q.y),T=d/SP+.15;tx=clamp(w.x+w.vx*T,1,23);ty=w.y+w.vy*T}
    const d=Math.hypot(tx-q.x,ty-q.y);return{tx,ty,d,T:d/SP+.15}
  }
  function throwTo(w){
    const q=G.qb,b=G.ball;if(G.thrown)return;
    const P=predictLand(w),tx=P.tx,ty=P.ty,SP=24,d=P.d;b.trail=[];b.rel={x:q.x,y:q.y};
    G.thrown=true;G.tgt=w;b.holder=null;b.air=true;b.ax=q.x;b.ay=q.y;b.tx=tx;b.ty=ty;b.t=0;b.T=d/SP+.15;b.dist=d;b.swat=false;b.x=q.x;b.y=q.y;
  }
  function resolveCatch(){
    const b=G.ball,land={x:b.tx,y:b.ty};b.air=false;
    if(b.swat){return endPlay({type:'inc'})}
    let rec=null,rd=99,df=null,dd=99;
    G.wrs.concat([G.rb]).forEach(w=>{const d=dist(w,land);if(d<rd){rd=d;rec=w}});
    G.D.forEach(x=>{const d=dist(x,land);if(d<dd&&x.stun<=0){dd=d;df=x}});
    const rOK=rd<2.3,dOK=dd<1.5;
    let res='inc';
    if(rOK&&dOK){const p=clamp(.7+(dd-rd)*.3,.3,.96);if(rnd()<p)res='catch';else res=rnd()<(human(G.off)?.12:.25)?'int':'inc'}
    else if(rOK){res=rnd()<.94?'catch':'inc'}
    else if(dOK&&dd<.9){res=rnd()<(human(G.off)?.04:.11)?'int':'inc'}
    if(res==='catch'){const ay=Math.round(land.y-G.los);fx(land.x,land.y,(ay>=0?'CAUGHT '+ay:'BEHIND LOS '+(-ay))+' YD','#9fe8b0');G.catchY=land.y;b.holder=rec;G.thrown=true;rec.jt=0;rec.jcd=0;rec.wrapT=0;rec.truckT=0;rec.route=null;return}
    if(res==='int'){return endPlay({type:'int',y:land.y})}
    endPlay({type:'inc'});
  }
  function updateDefense(dt,iD,aD,bD,cD,dD){
    const b=G.ball,L=G.los,o=G.off,d=1-o,c=b.holder,isRun=G.play.startsWith('run'),f=focus();
    const pastLOS=c&&c.y>L+.4,chase=pastLOS||(isRun&&G.defKnow&&G.t>.15)||(isRun&&G.t>.55);
    // human control selection
    let ctl=null;
    if(iD){
      let near=null,nd=99;G.D.forEach(x=>{const dd=dist(x,f)+(x.role==='dl'&&!x.free?4:0);if(dd<nd){nd=dd;near=x}});
      if(!G.ctrlD||bD){
        if(bD&&G.ctrlD){const ord=G.D.filter(x=>x!==G.ctrlD).sort((p,q)=>dist(p,f)-dist(q,f));G.ctrlD=ord[0]}
        else G.ctrlD=near}
      else if(near!==G.ctrlD&&dist(G.ctrlD,f)-nd>1.6)G.ctrlD=near;
      ctl=G.ctrlD;
    }else G.ctrlD=null;
    G.D.forEach((df,i)=>{
      if(df.dive>0){df.dive-=dt;if(df.dive<=0){df.stun=Math.max(df.stun,df.hit?1.0:.55);df.hit=false}}
      if(df===ctl){
        const sp=df.spd*(df.dive>0?(df.hit?1.9:1.5):1)*(df.boostT>0?1.35:1);
        if(aD&&df.dive<=0&&df.stun<=0){df.dive=.3;df.dvx=iD.dx||0;df.dvy=iD.dy||(f.y>df.y?1:-1)}
        if(cD&&df.dive<=0&&df.stun<=0&&doHit(df)){df.dvx=iD.dx||(f.x-df.x);df.dvy=iD.dy||(f.y-df.y)}
        if(dD&&df.stun<=0)doStrip(df,c);if(eD)doBoost(df)
        if(df.dive>0){const m=Math.hypot(df.dvx,df.dvy)||1;drive(df,df.dvx,df.dvy,sp,dt)}
        else drive(df,iD.dx,iD.dy,sp,dt);
        return}
      if(G.t<df.react)return;
      if(df.stun>0){df.stun-=dt;return}
      if(df.dive>0){return}
      // CPU defender logic
      let tx,ty;const sp=df.spd;
      if(c&&chase){const v=Math.min(.7,dist(df,c)/sp);tx=c.x+c.vx*v;ty=c.y+c.vy*v;
        if(df.role==='dl'&&!df.free&&dist(df,c)>2.5){moveTo(df,df.x,df.y,0,dt);return}
      }else if(b.air){const dd=dist(df,{x:b.tx,y:b.ty});if(b.t<.08){tx=df.x;ty=df.y}else if(dd<12||df.role==='cb'||df.role==='s'){tx=b.tx;ty=b.ty;moveTo(df,tx,ty,df.spd*.88,dt);return}else{tx=df.x;ty=df.y}}
      else if(c&&!G.thrown&&!isRun){ // pass play pre-throw
        if(df.role==='dl'){tx=G.qb.x;ty=G.qb.y;if(!df.free){moveTo(df,df.x+(tx-df.x)*.1,df.y-.15,df.spd*.25,dt);return}}
        else if(df.role==='lb'){if(G.blitz&&i!==5){tx=G.qb.x;ty=G.qb.y}else{const w=G.wrs[i-4]||G.wrs[3];tx=clamp(w.x*.6+df.sx*.4,2,22);ty=Math.max(G.los+4.2,Math.min(w.y+1,G.los+8))}}
        else if(df.role==='cb'){const w=G.wrs[i-7];tx=w.x;ty=w.y+(G.play==='pass2'?3.2:1.6)}
        else{const w=G.wrs[i-9],dp=G.play==='pass2'?9:3;tx=df.sx;ty=Math.max(df.y,w.y+dp);if(G.play==='pass1'&&w.y>G.los+4){tx=(tx+w.x)/2;ty=w.y+2}}
      }else{tx=df.x;ty=df.y}
      if(df.role==='dl'&&!df.free){moveTo(df,df.x,df.y,0,dt);return}
      if(df.boostT<=0&&c&&c.team!==df.team&&dist(df,c)>4.5&&G.bs[df.team]>.6&&rnd()<dt*[.12,.3,.6][G.lvl])doBoost(df);
      moveTo(df,tx,ty,sp*(df.boostT>0?1.3:1),dt);
    });
    G.D.forEach(df=>{if(df.role==='dl'&&!df.free&&df.engT>0){df.y+=.0}});
  }

  /* ------------------------------ rendering ------------------------------ */
  const SKIN='#e0a878';
  function sx(x){return Math.round(x*PX)}
  function sy(y){return Math.round(CH/2-(y-G.cam)*PX)}
  function drawField(){
    const o=G.off,c=G.col;
    ctx.fillStyle='#2e7a38';ctx.fillRect(0,0,CW,CH);
    for(let y=-10;y<110;y+=5){const a=sy(y+5),h=sy(y)-a;if(a>CH||a+h<0)continue;ctx.fillStyle=(Math.floor((y+10)/5)%2)?'#34853f':'#2e7a38';ctx.fillRect(0,a,CW,h)}
    // end zones
    const ez=(y0,y1,k)=>{const a=sy(y1),h=sy(y0)-a;ctx.fillStyle=c[k][0];ctx.fillRect(0,a,CW,h);ctx.fillStyle=c[k][1];ctx.font='bold 9px monospace';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(tn(G.teams[k]).toUpperCase(),CW/2,a+h/2)};
    ez(-10,0,o);ez(100,110,1-o);
    ctx.fillStyle='#fff';
    for(let y=0;y<=100;y+=5){const yy=sy(y);if(yy<-2||yy>CH+2)continue;ctx.fillRect(0,yy,CW,y%10===0?2:1);
      if(y%10===0&&y>0&&y<100){const n=y<=50?y:100-y;ctx.font='bold 8px monospace';ctx.fillStyle='#e9fbe9';ctx.textAlign='left';ctx.fillText(String(n),4,yy+9);ctx.textAlign='right';ctx.fillText(String(n),CW-4,yy+9);ctx.fillStyle='#fff'}}
    ctx.fillRect(0,0,2,CH);ctx.fillRect(CW-2,0,2,CH);
    ctx.globalAlpha=.55;for(let y=0;y<100;y++){const yy=sy(y);if(yy<-2||yy>CH+2)continue;ctx.fillRect(sx(9),yy,2,1);ctx.fillRect(sx(15),yy,2,1)}ctx.globalAlpha=1;
    // LOS and first down
    if(G.phase!=='banner'||true){ctx.fillStyle='#3a7bff';ctx.fillRect(0,sy(G.los)-1,CW,2);
      if(G.lineToGain<100){ctx.fillStyle='#ffd23a';ctx.fillRect(0,sy(G.lineToGain)-1,CW,2)}}
  }
  function drawPlayer(e,col,hl,hasBall){
    const x=sx(e.x),y=sy(e.y);if(y<-12||y>CH+12)return;
    const run=Math.hypot(e.vx,e.vy)>.5,fr=run?Math.floor((G.t*10+e.ph)%2):0,jt=e.jt>0;
    ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(x-3,y+2,7,2);
    ctx.fillStyle='#e8e8ee';ctx.fillRect(x-2,y-1+(fr?0:0),2,3+(fr?1:0));ctx.fillRect(x+1,y-1,2,3+(fr?0:1));// legs/pants
    ctx.fillStyle=e.stun>0&&e.dive<=0?'#8c8c8c':col[0];ctx.fillRect(x-3,y-5,7,5); // jersey
    ctx.fillStyle=col[1];ctx.fillRect(x-3,y-5,7,1);
    ctx.fillStyle=SKIN;ctx.fillRect(x-1,y-7,3,2);
    ctx.fillStyle=col[1]===col[0]?'#fff':col[1];ctx.fillRect(x-2,y-9,5,2);ctx.fillRect(x-2,y-7,1,1);
    if(jt){ctx.fillStyle='rgba(255,255,255,.75)';ctx.fillRect(x-4,y-10,9,1)}
    if(e.dive>0){ctx.fillStyle='rgba(255,255,255,.5)';ctx.fillRect(x-4,y+1,9,1)}
    if(hl){ctx.fillStyle='#ffe14a';ctx.fillRect(x-1,y-17,3,1);ctx.fillRect(x-2,y-16,5,1);ctx.fillRect(x-3,y-15,7,1);ctx.fillRect(x-4,y-14,9,1);ctx.fillStyle='#000';ctx.fillRect(x-4,y-13,9,1);ctx.strokeStyle='#ffe14a';ctx.strokeRect(x-5.5,y-10.5,11,13)}
  }
  function render(){
    if(!G)return;drawField();
    const o=G.off,cO=G.col[o],cD=G.col[1-o],b=G.ball,tgt=G.wrs&&G.wrs[G.target];
    const all=G.ents.slice().sort((p,q)=>q.y-p.y);
    const hum=human(o)&&!b.air?(b.holder||G.qb):null;
    all.forEach(e=>{const isO=e.team===o;drawPlayer(e,isO?cO:cD,(isO&&e===hum)||e===G.ctrlD||(b.air&&G.tgt===e&&human(o)&&e.team===o),false)});
    // target marker for qb
    if(human(o)&&G.phase==='live'&&b.holder===G.qb&&!G.thrown&&!G.play.startsWith('run')&&tgt){const x=sx(tgt.x),y=sy(tgt.y);ctx.strokeStyle='#fff';ctx.strokeRect(x-6,y-12,12,14)}
    // ball
    const hx=b.holder?b.holder.x:b.x,hy=b.holder?b.holder.y:b.y;
    if(G.phase==='live'||G.phase==='banner'||G.phase==='select'){
      const z=b.air?(b.z||0):0,bx=sx(hx)+(b.holder?3:0),by=sy(hy)-(b.holder?4:0)-Math.round(z*PX*.9);
      if(b.air){ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(sx(b.x)-2,sy(b.y),5,2)}
      ctx.fillStyle='#7a4a1e';ctx.fillRect(bx-2,by-1,5,3);ctx.fillStyle='#fff';ctx.fillRect(bx,by,1,1)}
    // ---- receiver routes ----
    const drawRoutes=(wrs,cols,live)=>{
      wrs.forEach((w,i)=>{if(!w.route||!w.r0)return;const pts=[[w.r0[0],w.r0[1]]].concat(w.route);
        const tgtw=G.wrs[G.target]===w&&live,col=tgtw?'#ffffff':cols;
        for(let k=0;k<pts.length-1;k++){
          const done=live&&w.ri>k,a=sx(pts[k][0]),bx=sx(pts[k+1][0]),ya=sy(pts[k][1]),yb=sy(pts[k+1][1]);
          ctx.globalAlpha=done?.18:(tgtw?.95:.6);ctx.fillStyle=col;
          const n=Math.max(2,Math.round(Math.hypot(bx-a,yb-ya)/4));
          for(let j=0;j<n;j++){if(j%2)continue;const t=j/n;ctx.fillRect(Math.round(a+(bx-a)*t),Math.round(ya+(yb-ya)*t),2,2)}}
        const e=pts[pts.length-1],ex=sx(e[0]),ey=sy(e[1]),p=pts[pts.length-2],ang=Math.atan2(sy(e[1])-sy(p[1]),sx(e[0])-sx(p[0]));
        ctx.globalAlpha=tgtw?1:.8;ctx.fillStyle=col;ctx.beginPath();ctx.moveTo(ex+Math.cos(ang)*4,ey+Math.sin(ang)*4);ctx.lineTo(ex+Math.cos(ang+2.5)*4,ey+Math.sin(ang+2.5)*4);ctx.lineTo(ex+Math.cos(ang-2.5)*4,ey+Math.sin(ang-2.5)*4);ctx.fill();
        ctx.globalAlpha=1;ctx.font='bold 7px monospace';ctx.textAlign='center';ctx.fillStyle='rgba(0,0,0,.7)';ctx.fillText(String(i+1),ex+1,ey-5);ctx.fillStyle=col;ctx.fillText(String(i+1),ex,ey-6)});ctx.globalAlpha=1};
    if(G.wrs&&G.wrs.length&&G.play&&!G.play.startsWith('run')&&G.phase==='live'&&!G.thrown&&b.holder===G.qb){drawRoutes(G.wrs,'#ffe14a',true)}
    if(G.phase==='select'&&G.preview&&G.wrs&&G.wrs[0].route)drawRoutes(G.wrs,'#ffe14a',false);
    // ---- QB aim preview, flight path, yard readouts ----
    if(G.phase==='live'){
      const arcPt=(ax,ay,bx,by,k,dd)=>({x:ax+(bx-ax)*k,y:ay+(by-ay)*k,z:Math.sin(k*Math.PI)*(2+dd*.08)});
      const dash=(ax,ay,bx,by,dd,col,alpha,full)=>{ctx.fillStyle=col;ctx.globalAlpha=alpha;for(let i=1;i<=20;i++){if(!full&&i%2)continue;const p=arcPt(ax,ay,bx,by,i/20,dd);ctx.fillRect(sx(p.x),sy(p.y)-Math.round(p.z*PX*.9),2,2)}ctx.globalAlpha=1};
      const qbHold=human(o)&&b.holder===G.qb&&!G.thrown&&!G.play.startsWith('run');
      if(qbHold){
        G.wrs.forEach((w,i)=>{const ay=Math.round(w.y-G.los);ctx.font='bold 7px monospace';ctx.textAlign='center';ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillText(ay+'',sx(w.x)+1,sy(w.y)-17);ctx.fillStyle=i===G.target?'#fff':'rgba(255,255,255,.55)';ctx.fillText(ay+'',sx(w.x),sy(w.y)-18)});
        const w=G.wrs[G.target];
        if(w){const P=predictLand(w);let open=99;G.D.forEach(df=>{open=Math.min(open,dist(df,{x:P.tx,y:P.ty}))});
          const col=open>3.2?'#6dff8a':open>2.1?'#ffe14a':'#ff6b5c';
          dash(G.qb.x,G.qb.y,P.tx,P.ty,P.d,col,.9,false);
          const px=sx(P.tx),py=sy(P.ty);ctx.strokeStyle=col;ctx.lineWidth=1;ctx.strokeRect(px-4.5,py-3.5,9,7);
          const air=Math.round(P.ty-G.los);ctx.font='bold 8px monospace';ctx.textAlign='center';const lab=air+' YD'+(open>3.2?' OPEN':open>2.1?'':' TIGHT');
          const lx=clamp(px,26,CW-26);ctx.fillStyle='rgba(0,0,0,.65)';ctx.fillText(lab,lx+1,py-7);ctx.fillStyle=col;ctx.fillText(lab,lx,py-8)}
      }
      if(b.air&&b.rel){
        dash(b.rel.x,b.rel.y,b.tx,b.ty,b.dist,'#ffffff',.45,true);
        (b.trail||[]).forEach((p,i,a)=>{ctx.globalAlpha=.12+.5*i/a.length;ctx.fillStyle='#ffe9b0';ctx.fillRect(sx(p[0])-1,sy(p[1])-Math.round(p[2]*PX*.9)-1,2,2)});ctx.globalAlpha=1;
        const k=Math.min(1,b.t/b.T),px=sx(b.tx),py=sy(b.ty),r=3+Math.round((1-k)*5);ctx.strokeStyle='#fff';ctx.globalAlpha=.8;ctx.strokeRect(px-r,py-r*.7,r*2,r*1.4);ctx.globalAlpha=1;
        const air=Math.round(b.ty-G.los);ctx.font='bold 8px monospace';ctx.textAlign='center';const lx=clamp(px,28,CW-28);ctx.fillStyle='rgba(0,0,0,.65)';ctx.fillText('AIR '+air+' YD',lx+1,py-9);ctx.fillStyle='#fff';ctx.fillText('AIR '+air+' YD',lx,py-10)}
      const h=b.holder;
      if(h&&h.team===o&&h!==G.qb||h&&h===G.qb&&h.y>G.los+.5){
        const gain=Math.round(h.y-G.los),first=h.y>=G.lineToGain,txt=first?'1ST DOWN +'+gain:(gain>=0?'+':'')+gain+' YD';
        ctx.font='bold 8px monospace';ctx.textAlign='center';const hx2=clamp(sx(h.x),24,CW-24),hy2=sy(h.y)-22;ctx.fillStyle='rgba(0,0,0,.7)';ctx.fillRect(hx2-ctx.measureText(txt).width/2-2,hy2-7,ctx.measureText(txt).width+4,9);ctx.fillStyle=first?'#ffd23a':gain<0?'#ff8a7a':'#fff';ctx.fillText(txt,hx2,hy2)}
      // mini field strip on the right edge: where the ball is on the 100 yards
      const sh=CH-40,s0=20,my=y=>s0+sh-(clamp(y,0,100)/100)*sh;
      ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(CW-7,s0-2,6,sh+4);ctx.fillStyle='rgba(255,255,255,.25)';for(let y=0;y<=100;y+=10)ctx.fillRect(CW-7,Math.round(my(y)),6,1);
      ctx.fillStyle='#3a7bff';ctx.fillRect(CW-8,Math.round(my(G.los)),8,1);if(G.lineToGain<100){ctx.fillStyle='#ffd23a';ctx.fillRect(CW-8,Math.round(my(G.lineToGain)),8,1)}
      ctx.strokeStyle='rgba(255,255,255,.35)';ctx.strokeRect(CW-7.5,Math.round(my(G.cam+VH/2)),6,Math.round(VH/100*sh));
      const bp=b.holder||{y:b.y};ctx.fillStyle='#fff';ctx.fillRect(CW-6,Math.round(my(bp.y))-1,4,3)}
    // power meters + effects
    if(G.phase==='live'){
      for(let t=0;t<2;t++){const x=t===0?3:CW-3-40,v=G.pm[t];ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(x-1,CH-9,42,6);ctx.fillStyle=G.col[t][0];ctx.fillRect(x,CH-8,Math.round(40*v),4);ctx.fillStyle='rgba(255,255,255,.7)';ctx.fillRect(x+Math.round(40*.2),CH-8,1,4);ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(x-1,CH-3,42,3);ctx.fillStyle='#6ee7ff';ctx.fillRect(x,CH-2,Math.round(40*G.bs[t]),1)}
      ctx.font='bold 9px monospace';ctx.textAlign='center';
      G.fx.forEach(f=>{const a=1-f.t/.95,x=sx(f.x),y=sy(f.y)-14-f.t*16;ctx.globalAlpha=Math.max(0,a);ctx.fillStyle='#000';ctx.fillText(f.txt,x+1,y+1);ctx.fillStyle=f.col;ctx.fillText(f.txt,x,y)});
      ctx.globalAlpha=1;ctx.textAlign='left'}
  }
  function renderScore(){
    if(!G)return;const t=G.teams,c=G.col,m=Math.floor(G.clock/60),s=Math.floor(G.clock%60),o=G.off;
    const qn=G.q>=5?'OT':'Q'+G.q;
    ui.sdscore.innerHTML=`<div class="sdt${o===0?' has':''}" style="--tc:${c[0][0]};--tc2:${c[0][1]}"><span class="sdn">${tn(t[0])}${G.mode===1?' (you)':''}</span><b>${G.score[0]}</b></div>
      <div class="sdmid"><b>${qn} ${m}:${String(s).padStart(2,'0')}</b><span>${G.msg||''}</span></div>
      <div class="sdt${o===1?' has':''}" style="--tc:${c[1][0]};--tc2:${c[1][1]}"><b>${G.score[1]}</b><span class="sdn">${tn(t[1])}${G.mode===1?' (CPU)':''}</span></div>`;
  }

  /* ------------------------------ loop + input ------------------------------ */
  function loop(ts){
    if(dead)return;raf=requestAnimationFrame(loop);
    if(!last)last=ts;let dt=Math.min(.05,(ts-last)/1000);last=ts;
    pollKeys();
    if(G&&!stage.hidden){acc+=dt;let n=0;while(acc>=1/60&&n<6){step(1/60);acc-=1/60;n++}if(n===6)acc=0;
      if(G.phase==='live')renderScoreClock();updatePad();render()}
  }
  let lastClk=-1;function renderScoreClock(){const s=Math.ceil(G.clock);if(s!==lastClk){lastClk=s;renderScore()}}
  function pollKeys(){
    const k=keys;
    if(G&&G.mode===2){
      inp[0].dx=(k.d?1:0)-(k.a?1:0);inp[0].dy=(k.w?1:0)-(k.s?1:0);
      inp[1].dx=(k.arrowright?1:0)-(k.arrowleft?1:0);inp[1].dy=(k.arrowup?1:0)-(k.arrowdown?1:0);
    }else{
      inp[0].dx=((k.d||k.arrowright)?1:0)-((k.a||k.arrowleft)?1:0)+pad.dx;inp[0].dy=((k.w||k.arrowup)?1:0)-((k.s||k.arrowdown)?1:0)+pad.dy;
      inp[0].dx=clamp(inp[0].dx,-1,1);inp[0].dy=clamp(inp[0].dy,-1,1);
    }
  }
  function kd(e){
    if(dead||!G||ui.sdgame.hidden)return;const t=e.target&&e.target.tagName;if(t==='INPUT'||t==='TEXTAREA'||document.querySelector('.rpov:not([hidden])'))return;
    const key=e.key.toLowerCase();
    const ctrl=['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright',' ','f','g','h','j','e','k','l',';',"'",'/'];
    if(ctrl.includes(key)&&G.phase!=='final')e.preventDefault();
    if(e.repeat){keys[key]=true;return}
    keys[key]=true;
    if(G.mode===2){
      if(key==='f')inp[0].a=true;if(key==='g')inp[0].b=true;if(key==='h')inp[0].c=true;if(key==='j')inp[0].d=true;if(key==='e')inp[0].e=true;if(key==='/')inp[1].e=true;if(key==='k')inp[1].a=true;if(key==='l')inp[1].b=true;if(key===';')inp[1].c=true;if(key==="'")inp[1].d=true;
    }else{if(key==='f'||key===' ')inp[0].a=true;if(key==='g'||key==='shift')inp[0].b=true;if(key==='h')inp[0].c=true;if(key==='j')inp[0].d=true;if(key==='e')inp[0].e=true}
    if(G.phase==='select'&&/^[1-6]$/.test(key)){const bt=ui.sdplays.querySelectorAll('[data-pl]');const want=['run1','run2','pass1','pass2','punt','fg'][+key-1];const hit=[...bt].find(x=>x.dataset.pl===want);if(hit)hit.click();else if(key==='1'&&bt.length===1)bt[0].click()}
  }
  function ku(e){keys[e.key.toLowerCase()]=false}
  window.addEventListener('keydown',kd);window.addEventListener('keyup',ku);
  let ptype='mouse';ui.sdplays.addEventListener('pointerdown',e=>{ptype=e.pointerType||'mouse'});
  const preview=pl=>{if(!G||G.phase!=='select'||!G.wrs)return;if(pl==='pass1'||pl==='pass2'){setRoutes(pl);G.preview=pl}else{G.preview=null}
    ui.sdplays.querySelectorAll('[data-pl]').forEach(x=>x.classList.toggle('pv',x.dataset.pl===G.preview))};
  ui.sdplays.addEventListener('pointerover',e=>{const b=e.target.closest('[data-pl]');if(b&&e.pointerType==='mouse')preview(b.dataset.pl)});
  ui.sdplays.addEventListener('focusin',e=>{const b=e.target.closest('[data-pl]');if(b&&b.matches(':focus-visible'))preview(b.dataset.pl)});
  ui.sdplays.addEventListener('click',e=>{const b=e.target.closest('[data-pl]');if(!b||!G||G.phase!=='select')return;const pl=b.dataset.pl;
    // on touch screens a pass play shows its routes first; tap again to snap
    if((ptype==='touch'||ptype==='pen'||(window.matchMedia&&matchMedia('(pointer: coarse)').matches&&ptype!=='mouse'))&&(pl==='pass1'||pl==='pass2')&&G.preview!==pl){preview(pl);return}
    G.preview=null;snap(pl)});
  ui.sdover.addEventListener('click',e=>{const a=e.target.closest('[data-act]');if(!a)return;if(a.dataset.act==='shub'){showSeason();return}if(a.dataset.act==='again')newGame(G.teams[0],G.teams[1],G.mode,G.lvl,G.qlen);else{G=null;showMenu()}});
  // touch controls: drag anywhere on the field = joystick, tap a receiver = throw, A/B buttons
  const padEl=stage.querySelector('#sdpad'),joy=stage.querySelector('#sdjoy'),hint=stage.querySelector('#sdhint');
  let jp=null;
  function world(e){const r=cv.getBoundingClientRect(),px=(e.clientX-r.left)*CW/r.width,py=(e.clientY-r.top)*CH/r.height;return{x:px/PX,y:G.cam+(CH/2-py)/PX}}
  cv.addEventListener('pointerdown',e=>{if(!G||G.phase==='final'||e.pointerType==='mouse'&&e.button!==0)return;e.preventDefault();
    try{cv.setPointerCapture(e.pointerId)}catch(er){}
    jp={id:e.pointerId,x:e.clientX,y:e.clientY,t:performance.now(),moved:false,ox:e.clientX,oy:e.clientY};hideHint()});
  cv.addEventListener('pointermove',e=>{if(!jp||e.pointerId!==jp.id)return;
    const dx=e.clientX-jp.ox,dy=e.clientY-jp.oy,m=Math.hypot(dx,dy);
    if(m>10)jp.moved=true;
    if(jp.moved){const R=48,mm=Math.min(m,R),nx=dx/(m||1),ny=dy/(m||1),a=mm/R;
      pad.dx=a>.25?nx*a:0;pad.dy=a>.25?-ny*a:0;
      if(m>R){jp.ox=e.clientX-nx*R;jp.oy=e.clientY-ny*R}   // joystick follows the thumb
      const wr=ui.sdwrap.getBoundingClientRect();joy.hidden=false;joy.style.left=(jp.ox-wr.left)+'px';joy.style.top=(jp.oy-wr.top)+'px';
      const k=joy.firstElementChild;k.style.transform=`translate(${nx*mm}px,${ny*mm}px)`}});
  const up=e=>{if(!jp||e.pointerId!==jp.id)return;
    if(!jp.moved&&performance.now()-jp.t<450&&G&&G.phase==='live')tapAt(world(e));
    jp=null;pad.dx=0;pad.dy=0;joy.hidden=true};
  cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
  cv.addEventListener('contextmenu',e=>e.preventDefault());
  function tapAt(w){
    if(!human(G.off)||G.mode===2&&false)return;
    const b=G.ball;
    if(b.holder===G.qb&&!G.thrown&&!G.play.startsWith('run')){
      let best=null,bd=99;G.wrs.forEach((r,i)=>{const d=Math.hypot(r.x-w.x,r.y-w.y);if(d<bd){bd=d;best=i}});
      if(best!==null&&bd<7){G.target=best;throwTo(G.wrs[best]);return}}
    inp[G.mode===2?G.off:0].a=true;
  }
  padEl.addEventListener('pointerdown',e=>{const b=e.target.closest('button');if(!b)return;e.preventDefault();e.stopPropagation();
    const side=G.mode===2?0:0;inp[side][b.dataset.b]=true});
  padEl.addEventListener('contextmenu',e=>e.preventDefault());
  function hideHint(){hint.hidden=true}
  function showHint(t){hint.textContent=t;hint.hidden=false;clearTimeout(showHint.t);showHint.t=setTimeout(hideHint,3800)}
  function updatePad(){
    if(!G)return;const o=G.off,b=G.ball,bt={a:stage.querySelector('#sdbtnA'),b:stage.querySelector('#sdbtnB'),c:stage.querySelector('#sdbtnC'),d:stage.querySelector('#sdbtnD'),e:stage.querySelector('#sdbtnE')};
    if(G.phase!=='live'){padEl.style.visibility='hidden';return}
    padEl.style.visibility='';let L={a:'',b:'',c:'',d:'',e:'BOOST'};
    if(human(o)){
      if(b.holder===G.qb&&!G.thrown&&!G.play.startsWith('run')){L={a:'THROW',b:'TARGET',c:'',d:'',e:'SCRAMBLE'}}
      else if(b.holder){L={a:'SPIN',b:'STIFF-ARM',c:'TRUCK',d:'',e:'BOOST'}}
    }else L={a:'DIVE',b:'SWITCH',c:'HIT',d:'STRIP',e:'BOOST'};
    const pm=G.pm[human(o)?o:1-o],bsv=G.bs[human(o)?o:1-o];
    for(const k in bt){const el=bt[k];if(el.textContent!==L[k])el.textContent=L[k];el.style.visibility=L[k]?'':'hidden';
      const cost={SPIN:.2,'STIFF-ARM':.3,TRUCK:.45,HIT:.4,STRIP:.25}[L[k]];el.classList.toggle('off',k==='e'?bsv<.28:!!cost&&pm<cost-1e-6)}
  }
  G&&0;

  showMenu();
  return {
    stop(){dead=true;cancelAnimationFrame(raf);window.removeEventListener('keydown',kd);window.removeEventListener('keyup',ku)},
    _t:{newGame,step:n=>{for(let i=0;i<n;i++)step(1/60)},state:()=>G,snap,afterBanner}
  };
};
