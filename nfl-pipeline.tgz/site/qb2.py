import json, csv, collections, random, sys, os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from names import reduce_keep
Q=json.load(open("qb.json")); QB=Q["qbs"]
games=[]
for r in csv.DictReader(open("/home/runner/nfl/games/games.csv")):
    if not r["home_score"] or r["home_score"]==r["away_score"]: continue
    h,a=r["home_qb_id"],r["away_qb_id"]
    if h in QB and a in QB:
        games.append((h,a,int(r["home_score"])>int(r["away_score"]),r["gameday"]))
rec=collections.defaultdict(lambda:[0,0])
for h,a,hw,_ in games:
    rec[h][0]+=hw; rec[h][1]+=1; rec[a][0]+=(not hw); rec[a][1]+=1
def show(field,val,lab):
    qs=[q for q in QB if QB[q][field]==val]
    tot=sum(rec[q][1] for q in qs); wins=sum(rec[q][0] for q in qs)
    top=sorted(qs,key=lambda q:-rec[q][0])[:6]
    print(f"\n{lab} = {val}: {wins}-{tot-wins} = {100*wins/tot:.1f}% over {len(qs)} quarterbacks")
    print("  biggest contributors:")
    for q in top:
        w,n=rec[q]; print(f"    {QB[q]['name']:22s} {w}-{n-w} ({100*w/n:.0f}%)  {n} starts")
show("bday",2,"Birthday number"); show("bday",4,"Birthday number")
show("expr",6,"Expression"); show("expr",9,"Expression")
show("lp",5,"Life path"); show("lp",1,"Life path")
# the proper test: weight every quarterback equally instead of by how often he started
print("\n=== each quarterback counted once (min 16 starts), averaging his own win rate ===")
import statistics
for field,lab in [("bday","Birthday"),("expr","Expression"),("lp","Life path"),("soul","Soul urge"),("pers","Personality")]:
    by=collections.defaultdict(list)
    for q in QB:
        if rec[q][1]>=16: by[QB[q][field]].append(rec[q][0]/rec[q][1])
    rows=[(v,statistics.mean(x),len(x)) for v,x in by.items() if len(x)>=8]
    rows.sort(key=lambda r:-r[1])
    spread=rows[0][1]-rows[-1][1]
    print(f"  {lab:12s} range {100*rows[-1][1]:.1f}% to {100*rows[0][1]:.1f}% (spread {100*spread:.1f} pts) across {len(rows)} values")
    print(f"               top {rows[0][0]} at {100*rows[0][1]:.1f}% (n={rows[0][2]} QBs), bottom {rows[-1][0]} at {100*rows[-1][1]:.1f}% (n={rows[-1][2]} QBs)")
# permutation: shuffle the numbers among quarterbacks, keep their records
print("\n=== shuffle numbers among quarterbacks, keep each man's real record (2000 runs) ===")
random.seed(17)
qs=[q for q in QB if rec[q][1]>=16]
rates=[rec[q][0]/rec[q][1] for q in qs]
for field,lab in [("bday","Birthday"),("expr","Expression"),("lp","Life path")]:
    labels=[QB[q][field] for q in qs]
    def spread_of(lb):
        g=collections.defaultdict(list)
        for l,r in zip(lb,rates): g[l].append(r)
        v=[statistics.mean(x) for x in g.values() if len(x)>=8]
        return max(v)-min(v)
    obs=spread_of(labels); ge=0
    for _ in range(2000):
        random.shuffle(labels)
        if spread_of(labels)>=obs-1e-12: ge+=1
    print(f"  {lab:12s} observed spread {100*obs:.1f} pts -> p={(ge+1)/2001:.3f}")
