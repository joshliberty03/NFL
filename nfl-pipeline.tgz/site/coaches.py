import csv,json
MAP={'OAK':'LV','SD':'LAC','STL':'LA','LAR':'LA'}
m=lambda t:MAP.get(t,t)
R=[r for r in csv.DictReader(open('/home/runner/nfl/games/games.csv')) if r['home_score'] not in ('','NA')]
cur={};rec={};s26={}
for r in sorted(R,key=lambda r:(r['gameday'])):
    for side,opp in (('home','away'),('away','home')):
        c=r[side+'_coach'];t=m(r[side+'_team']);me=float(r[side+'_score']);op=float(r[opp+'_score'])
        if not c:continue
        x=rec.setdefault(c,[0,0,0]);i=0 if me>op else 1 if me<op else 2;x[i]+=1
        if r['season']=='2026':
            cur[t]=c;y=s26.setdefault(c,[0,0,0]);y[i]+=1
# current coaches also for teams with no 2026 game yet
out=[]
for t,c in cur.items():
    a=rec[c];g=sum(a);b=s26.get(c,[0,0,0])
    out.append([c,t,a[0],a[1],a[2],round((a[0]+a[2]/2)/g,3) if g else 0,b[0],b[1],b[2]])
json.dump(out,open('coaches.json','w'),separators=(',',':'))
print(len(out),sorted(out,key=lambda x:-x[2])[:3])
