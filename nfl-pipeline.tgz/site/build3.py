import json,re
m={'__BETTING__':'betting.json','__JERSEY__':'jersey.json','__LNY__':'lny.json','__MOON__':'moon.json','__TEAMSINFO__':'teamsinfo.json','__SEASON__':'season.json','__PSTATS__':'pstats.json','__DEFPTS__':'defpts.json','__RANK__':'rank.json','__H2H__':'h2h_all.json','__PVT__':'pvt.json','__LOGOS__':'logos.json','__INJ__':'inj.json','__HIST__':'hist.json','__AWARDS__':'awards.json','__DRAFT__':'draft.json','__COACHES__':'coaches.json','__SEASON25__':'season25.json','__GAMEDET__':'gamedet.json','__TOP__':'top.json'}
base=json.load(open('h2h_base.json'));cur=json.load(open('h2h.json'))
json.dump({k:[base.get(k,[0,0,0])[i]+cur.get(k,[0,0,0])[i] for i in range(3)] for k in set(base)|set(cur)},open('h2h_all.json','w'),separators=(',',':'))
import time
t=open('template3.html').read().replace('__BUILT__',str(int(time.time()*1000)))
import gzip,base64
ZD={}
si=t.index('<script>\n')+len('<script>\n');sj=t.rindex('</script>')
head,body,tail=t[:si],t[si:sj],t[sj:]
for k,f in m.items():
    assert k in body,k
    raw=open(f).read().strip()
    if len(raw)>15000:
        ZD[k]=base64.b64encode(gzip.compress(raw.encode(),9,mtime=0)).decode()
        body=body.replace(k,'__Z["%s"]'%k.strip('_'))
    else:
        body=body.replace(k,raw)
pre="(async()=>{\nconst __ZD="+json.dumps(ZD,separators=(',',':'))+";\nconst __Z={};\nasync function __inf(b){const u=Uint8Array.from(atob(b),c=>c.charCodeAt(0));return JSON.parse(await new Response(new Blob([u]).stream().pipeThrough(new DecompressionStream('gzip'))).text())}\ntry{for(const k of Object.keys(__ZD))__Z[k.replace(/^__|__$/g,'')]=await __inf(__ZD[k])}catch(e){document.body.insertAdjacentHTML('afterbegin','<p style=\"padding:16px\">This page needs a newer browser to unpack its data. Please update your browser and reload.</p>');return}\n"
post="\n})().catch(e=>{try{console.error(e)}catch(_){}});\n"
t=head+pre+body+post+tail
print('unfilled',set(re.findall(r'__[A-Z0-9]+__',t)))
open('betting-by-numbers.html','w').write(t); print(len(t))
