# Builds inj.json: {gsis_id:[status,injury,week]} from the latest report week, plus meta.
import csv,json,os,time
f='inj26.csv';out={'p':{},'wk':0,'at':int(time.time())}
if os.path.exists(f):
    r=[x for x in csv.DictReader(open(f)) if x['game_type']=='REG']
    if r:
        w=max(int(x['week']) for x in r);out['wk']=w
        for x in r:
            if int(x['week'])==w and x['report_status']:
                out['p'][x['gsis_id']]=[x['report_status'],(x['report_primary_injury'] or '').strip(),w]
json.dump(out,open('inj.json','w'),separators=(',',':'));print(len(out['p']),'flags week',out['wk'])
