import csv, collections, re, statistics, random
MASTER={11,22,33}
def red(n):
    while n>9 and n not in MASTER: n=sum(int(d) for d in str(n))
    return n
def lifep(b):
    y,m,d=b.split("-"); return red(red(int(m))+red(int(d))+red(sum(map(int,y))))
def norm(n):
    n=re.sub(r"[^a-z ]","",n.lower().replace("-"," "))
    return " ".join(w for w in n.split() if w not in {"jr","sr","ii","iii","iv","v"})
GM={}
for r in csv.DictReader(open("/home/runner/nfl/games/games.csv")):
    if r["home_score"] and r["away_score"] and r["home_score"]!=r["away_score"]:
        GM[r["game_id"]]={"s":int(r["season"]),"win":r["home_team"] if int(r["home_score"])>int(r["away_score"]) else r["away_team"]}
units=collections.defaultdict(dict)
for y in range(2013,2026):
    bd={}; nm={}
    for r in csv.DictReader(open(f"/home/runner/nfl/hist/roster_{y}.csv",encoding="utf-8")):
        if not r.get("birth_date"): continue
        if r.get("pfr_id"): bd[r["pfr_id"]]=r["birth_date"]
        nm[(norm(r["full_name"]),r["team"])]=r["birth_date"]; nm.setdefault(norm(r["full_name"]),r["birth_date"])
    for r in csv.DictReader(open(f"/home/runner/nfl/hist/snaps_{y}.csv",encoding="utf-8")):
        gid=r["game_id"]
        if gid not in GM: continue
        if sum(float(r[k] or 0) for k in ("offense_snaps","defense_snaps","st_snaps"))<=0: continue
        b=bd.get(r["pfr_player_id"]) or nm.get((norm(r["player"]),r["team"])) or nm.get(norm(r["player"]))
        if b: units[gid].setdefault(r["team"],[]).append(b)
good=[g for g,v in units.items() if len(v)==2 and all(len(x)>=20 for x in v.values())]
LP={}
def lp(b):
    if b not in LP: LP[b]=lifep(b)
    return LP[b]
V=5
# team-season level: does a roster's 5-share predict that team-season's win rate?
ts=collections.defaultdict(lambda:{"w":0,"n":0,"sh":[]})
obs=[]
for gid in good:
    s=GM[gid]["s"]
    for t,bl in units[gid].items():
        sh=sum(1 for b in bl if lp(b)==V)/len(bl)
        k=(t,s); ts[k]["w"]+=GM[gid]["win"]==t; ts[k]["n"]+=1; ts[k]["sh"].append(sh)
        obs.append((t,s,sh,GM[gid]["win"]==t))
rows=[(statistics.mean(v["sh"]),v["w"]/v["n"]) for v in ts.values() if v["n"]>=12]
mx=statistics.mean(x for x,_ in rows); my=statistics.mean(y for _,y in rows)
num=sum((x-mx)*(y-my) for x,y in rows); den=(sum((x-mx)**2 for x,_ in rows)*sum((y-my)**2 for _,y in rows))**.5
print(f"A) across {len(rows)} team-seasons: correlation between 5-share and win rate = {num/den:+.3f}")
lo=[y for x,y in rows if x<mx]; hi=[y for x,y in rows if x>=mx]
print(f"   team-seasons below average 5-share: {100*statistics.mean(lo):.1f}% wins (n={len(lo)})")
print(f"   team-seasons above average 5-share: {100*statistics.mean(hi):.1f}% wins (n={len(hi)})")
# WITHIN team-season: team identity and quality removed entirely
w=n=0
base={k:statistics.mean(v["sh"]) for k,v in ts.items()}
for t,s,sh,won in obs:
    if ts[(t,s)]["n"]<12: continue
    d=sh-base[(t,s)]
    if abs(d)<1e-9: continue
    n+=1; w+= (won if d>0 else not won)
print()
print(f"B) within each team-season (team quality removed): a team's games with an above-average 5-share")
print(f"   won {w}-{n-w} = {100*w/n:.2f}%  across {n} team-games")
random.seed(3); N=5000; dev=abs(w/n-0.5); ge=sum(1 for _ in range(N) if abs(sum(random.random()<0.5 for _ in range(n))/n-0.5)>=dev-1e-12)
print(f"   p = {(ge+1)/(N+1):.3f}")
# label permutation at game level, team strength fixed
allb=[b for gid in good for t,bl in units[gid].items() for b in bl]
pool=list({b for b in allb})
def gamelevel(labmap):
    w=n=0
    for gid in good:
        sh={t:sum(1 for b in bl if labmap[b]==V)/len(bl) for t,bl in units[gid].items()}
        k=list(sh)
        if sh[k[0]]==sh[k[1]]: continue
        more=k[0] if sh[k[0]]>sh[k[1]] else k[1]
        n+=1; w+=(GM[gid]["win"]==more)
    return w,n
real={b:lp(b) for b in pool}
rw,rn=gamelevel(real)
print()
print(f"C) game level, real labels: {rw}-{rn-rw} = {100*rw/rn:.2f}%")
vals=[lp(b) for b in pool]; cnt=0; TR=400
random.seed(8)
hits=0
for _ in range(TR):
    random.shuffle(vals); m=dict(zip(pool,vals))
    sw,sn=gamelevel(m)
    if abs(sw/sn-0.5)>=abs(rw/rn-0.5)-1e-12: hits+=1
print(f"   shuffling life-path labels among players ({TR} runs): matched or beat it {hits} times -> p={(hits+1)/(TR+1):.4f}")
