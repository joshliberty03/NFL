"""Prediction models for remaining 2026 games, backtested honestly on held-out seasons."""
import json, sys, collections, math

MASTER={11,22,33}
ORDER=[1,2,3,4,5,6,7,8,9,11,22,33]
def red(n):
    while n>9 and n not in MASTER: n=sum(int(d) for d in str(n))
    return n
def lifep(b):
    y,m,d=b.split("-"); return red(red(int(m))+red(int(d))+red(sum(map(int,y))))
def pday(b,date):
    _,bm,bd=b.split("-"); y,m,d=date.split("-")
    py=red(red(int(bm))+red(int(bd))+red(sum(map(int,y))))
    return red(red(py+red(int(m)))+red(int(d)))

FOUNDED=json.load(open("founded.json"))
H=json.load(open("history.json"))
S=json.load(open("step2.json"))

# games: [season, week, type, date, home, away, hs, as, hcoach, acoach, dn, hpd, apd]
G=[g for g in H["games"] if g[6]!=g[7]]

def team_rates(games):
    """historical win rates by (team, date_number) and (team, team_personal_day), with shrinkage"""
    dn=collections.defaultdict(lambda:[0,0]); pd=collections.defaultdict(lambda:[0,0]); tm=collections.defaultdict(lambda:[0,0])
    for g in games:
        for t,s,o,p in ((g[4],g[6],g[7],g[11]),(g[5],g[7],g[6],g[12])):
            w=1 if s>o else 0
            tm[t][0]+=w; tm[t][1]+=1
            dn[(t,g[10])][0]+=w; dn[(t,g[10])][1]+=1
            if p is not None: pd[(t,p)][0]+=w; pd[(t,p)][1]+=1
    return dn,pd,tm

def shrunk(cell,base,k):
    w,n=cell
    return (w+k*base)/(n+k) if n or k else base

def numerology_score(t,date,dnR,pdR,tmR,base,K=25):
    """pure numerology: ignore team strength, use only date-number and personal-day history"""
    dn=lifep(date); p=pday(FOUNDED[t],date) if FOUNDED[t] else None
    a=shrunk(dnR[(t,dn)],base,K)
    b=shrunk(pdR[(t,p)],base,K) if p is not None else base
    return (a+b)/2

def baseline_score(t,date,tmR,base,K=10):
    return shrunk(tmR[t],base,K)

def backtest(train_end,test_start,test_end):
    train=[g for g in G if g[0]<=train_end]
    test=[g for g in G if test_start<=g[0]<=test_end]
    dnR,pdR,tmR=team_rates(train)
    base=sum(1 for g in train if g[6]>g[7])/len(train)   # home win rate
    res={"numerology":[0,0],"baseline":[0,0],"home":[0,0],"both":[0,0]}
    for g in test:
        h,a,hw=g[4],g[5],g[6]>g[7]
        nh=numerology_score(h,g[3],dnR,pdR,tmR,base); na=numerology_score(a,g[3],dnR,pdR,tmR,base)
        bh=baseline_score(h,g[3],tmR,base); ba=baseline_score(a,g[3],tmR,base)
        # numerology-only pick (no home edge, no strength)
        if nh!=na:
            res["numerology"][0]+= (hw if nh>na else not hw); res["numerology"][1]+=1
        # baseline: team record + home field
        ph=bh+0.06   # home field bump
        if ph!=ba:
            res["baseline"][0]+= (hw if ph>ba else not hw); res["baseline"][1]+=1
        res["home"][0]+=hw; res["home"][1]+=1
        # blended
        ch=0.5*(bh+0.06)+0.5*nh; ca=0.5*ba+0.5*na
        if ch!=ca:
            res["both"][0]+= (hw if ch>ca else not hw); res["both"][1]+=1
    return res,len(train),len(test)

print("=== backtests (train on everything before, test on held-out seasons) ===")
for te,ts,tt in [(2012,2013,2017),(2017,2018,2021),(2021,2022,2025)]:
    r,ntr,nte=backtest(te,ts,tt)
    print(f"train<={te} test {ts}-{tt} ({nte} games, {ntr} train)")
    for k,(w,n) in r.items():
        print(f"   {k:11s} {w}/{n} = {w/n:.3f}")

print()
print("=== isolating the pure numerology signal ===")
print("Centering each team's date-number record on that team's OWN overall win rate,")
print("so the score measures only 'does this date help this team more than usual'.")
def pure_numerology(t,date,dnR,pdR,tmR,base,K=25):
    dn=lifep(date); p=pday(FOUNDED[t],date) if FOUNDED[t] else None
    tb=shrunk(tmR[t],base,10)
    a=shrunk(dnR[(t,dn)],tb,K)-tb
    b=(shrunk(pdR[(t,p)],tb,K)-tb) if p is not None else 0.0
    return (a+b)/2
for te,ts,tt in [(2012,2013,2017),(2017,2018,2021),(2021,2022,2025)]:
    train=[g for g in G if g[0]<=te]; test=[g for g in G if ts<=g[0]<=tt]
    dnR,pdR,tmR=team_rates(train); base=sum(1 for g in train if g[6]>g[7])/len(train)
    w=n=0; wb=nb=0
    for g in test:
        hw=g[6]>g[7]
        nh=pure_numerology(g[4],g[3],dnR,pdR,tmR,base); na=pure_numerology(g[5],g[3],dnR,pdR,tmR,base)
        if nh!=na: w+=(hw if nh>na else not hw); n+=1
        # numerology used only to break ties on top of the baseline
        bh=shrunk(tmR[g[4]],base,10)+0.06; ba=shrunk(tmR[g[5]],base,10)
        ch=bh+nh; ca=ba+na
        if ch!=ca: wb+=(hw if ch>ca else not hw); nb+=1
    print(f" test {ts}-{tt}:  pure numerology {w}/{n} = {w/n:.3f}   |   baseline+numerology {wb}/{nb} = {wb/nb:.3f}")
