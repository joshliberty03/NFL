# awards.json: normalized name -> list of [award, year]. Sources: SI Heisman list (2000-2024), Wikipedia (Heisman 2025),
# AP NFL MVP 1999-2024 widely published list + Stafford 2025 (confirmed by news), Super Bowl MVP list (Wikipedia).
import json,re
def norm(n):
    n=re.sub(r"[^a-z ]","",n.lower().replace('-',' '));t=[w for w in n.split() if w not in('jr','sr','ii','iii','iv','v')];return ' '.join(t)
A={}
def add(n,a,y):A.setdefault(norm(n),[]).append([a,y])
heis="""2000|Chris Weinke
2001|Eric Crouch
2002|Carson Palmer
2003|Jason White
2004|Matt Leinart
2005|Reggie Bush
2006|Troy Smith
2007|Tim Tebow
2008|Sam Bradford
2009|Mark Ingram
2010|Cam Newton
2011|Robert Griffin III
2012|Johnny Manziel
2013|Jameis Winston
2014|Marcus Mariota
2015|Derrick Henry
2016|Lamar Jackson
2017|Baker Mayfield
2018|Kyler Murray
2019|Joe Burrow
2020|DeVonta Smith
2021|Bryce Young
2022|Caleb Williams
2023|Jayden Daniels
2024|Travis Hunter
2025|Fernando Mendoza"""
for l in heis.splitlines():y,n=l.split('|');add(n,'Heisman Trophy',int(y))
mvp={1999:['Kurt Warner'],2000:['Marshall Faulk'],2001:['Kurt Warner'],2002:['Rich Gannon'],2003:['Peyton Manning','Steve McNair'],2004:['Peyton Manning'],2005:['Shaun Alexander'],2006:['LaDainian Tomlinson'],2007:['Tom Brady'],2008:['Peyton Manning'],2009:['Peyton Manning'],2010:['Tom Brady'],2011:['Aaron Rodgers'],2012:['Adrian Peterson'],2013:['Peyton Manning'],2014:['Aaron Rodgers'],2015:['Cam Newton'],2016:['Matt Ryan'],2017:['Tom Brady'],2018:['Patrick Mahomes'],2019:['Lamar Jackson'],2020:['Aaron Rodgers'],2021:['Aaron Rodgers'],2022:['Patrick Mahomes'],2023:['Lamar Jackson'],2024:['Josh Allen'],2025:['Matthew Stafford']}
for y,ns in mvp.items():
    for n in ns:add(n,'AP NFL MVP',y)
sb="""I|Bart Starr|1966
II|Bart Starr|1967
III|Joe Namath|1968
IV|Len Dawson|1969
V|Chuck Howley|1970
VI|Roger Staubach|1971
VII|Jake Scott|1972
VIII|Larry Csonka|1973
IX|Franco Harris|1974
X|Lynn Swann|1975
XI|Fred Biletnikoff|1976
XII|Harvey Martin|1977
XII|Randy White|1977
XIII|Terry Bradshaw|1978
XIV|Terry Bradshaw|1979
XV|Jim Plunkett|1980
XVI|Joe Montana|1981
XVII|John Riggins|1982
XVIII|Marcus Allen|1983
XIX|Joe Montana|1984
XX|Richard Dent|1985
XXI|Phil Simms|1986
XXII|Doug Williams|1987
XXIII|Jerry Rice|1988
XXIV|Joe Montana|1989
XXV|Ottis Anderson|1990
XXVI|Mark Rypien|1991
XXVII|Troy Aikman|1992
XXVIII|Emmitt Smith|1993
XXIX|Steve Young|1994
XXX|Larry Brown|1995
XXXI|Desmond Howard|1996
XXXII|Terrell Davis|1997
XXXIII|John Elway|1998
XXXIV|Kurt Warner|1999
XXXV|Ray Lewis|2000
XXXVI|Tom Brady|2001
XXXVII|Dexter Jackson|2002
XXXVIII|Tom Brady|2003
XXXIX|Deion Branch|2004
XL|Hines Ward|2005
XLI|Peyton Manning|2006
XLII|Eli Manning|2007
XLIII|Santonio Holmes|2008
XLIV|Drew Brees|2009
XLV|Aaron Rodgers|2010
XLVI|Eli Manning|2011
XLVII|Joe Flacco|2012
XLVIII|Malcolm Smith|2013
XLIX|Tom Brady|2014
50|Von Miller|2015
LI|Tom Brady|2016
LII|Nick Foles|2017
LIII|Julian Edelman|2018
LIV|Patrick Mahomes|2019
LV|Tom Brady|2020
LVI|Cooper Kupp|2021
LVII|Patrick Mahomes|2022
LVIII|Patrick Mahomes|2023
LIX|Jalen Hurts|2024
LX|Kenneth Walker III|2025"""
for l in sb.splitlines():g,n,y=l.split('|');add(n,'Super Bowl MVP',int(y))

PFR={
'AP Offensive Player of the Year':"25Jaxon Smith-Njigba;24Saquon Barkley;23Christian McCaffrey;22Justin Jefferson;21Cooper Kupp;20Derrick Henry;19Michael Thomas;18Patrick Mahomes;17Todd Gurley;16Matt Ryan;15Cam Newton;14DeMarco Murray;13Peyton Manning;12Adrian Peterson;11Drew Brees;10Tom Brady;09Chris Johnson;08Drew Brees;07Tom Brady;06LaDainian Tomlinson;05Shaun Alexander;04Peyton Manning;03Jamal Lewis;02Priest Holmes;01Marshall Faulk;00Marshall Faulk;99Marshall Faulk",
'AP Defensive Player of the Year':"25Myles Garrett;24Patrick Surtain II;23Myles Garrett;22Nick Bosa;21T.J. Watt;20Aaron Donald;19Stephon Gilmore;18Aaron Donald;17Aaron Donald;16Khalil Mack;15J.J. Watt;14J.J. Watt;13Luke Kuechly;12J.J. Watt;11Terrell Suggs;10Troy Polamalu;09Charles Woodson;08James Harrison;07Bob Sanders;06Jason Taylor;05Brian Urlacher;04Ed Reed;03Ray Lewis;02Derrick Brooks;01Michael Strahan;00Ray Lewis;99Warren Sapp",
'AP Offensive Rookie of the Year':"25Tetairoa McMillan;24Jayden Daniels;23C.J. Stroud;22Garrett Wilson;21Ja'Marr Chase;20Justin Herbert;19Kyler Murray;18Saquon Barkley;17Alvin Kamara;16Dak Prescott;15Todd Gurley;14Odell Beckham Jr.;13Eddie Lacy;12Robert Griffin III;11Cam Newton;10Sam Bradford;09Percy Harvin;08Matt Ryan;07Adrian Peterson;06Vince Young;05Cadillac Williams;04Ben Roethlisberger;03Anquan Boldin;02Clinton Portis;01Anthony Thomas;00Mike Anderson;99Edgerrin James",
'AP Defensive Rookie of the Year':"25Carson Schwesinger;24Jared Verse;23Will Anderson;22Sauce Gardner;21Micah Parsons;20Chase Young;19Nick Bosa;18Shaquille Leonard;17Marshon Lattimore;16Joey Bosa;15Marcus Peters;14Aaron Donald;13Sheldon Richardson;12Luke Kuechly;11Von Miller;10Ndamukong Suh;09Brian Cushing;08Jerod Mayo;07Patrick Willis;06DeMeco Ryans;05Shawne Merriman;04Jonathan Vilma;03Terrell Suggs;02Julius Peppers;01Kendrell Bell;00Brian Urlacher;99Jevon Kearse",
'AP Comeback Player of the Year':"25Christian McCaffrey;24Joe Burrow;23Joe Flacco;22Geno Smith;21Joe Burrow;20Alex Smith;19Ryan Tannehill;18Andrew Luck;17Keenan Allen;16Jordy Nelson;15Eric Berry;14Rob Gronkowski;13Philip Rivers;12Peyton Manning;11Matthew Stafford;10Michael Vick;09Tom Brady;08Chad Pennington;07Greg Ellis;06Chad Pennington;05Steve Smith Sr.;05Tedy Bruschi;04Drew Brees;03Jon Kitna;02Tommy Maddox;01Garrison Hearst;00Joe Johnson;99Bryant Young"}
for a,l in PFR.items():
    for it in l.split(';'):
        yy=int(it[:2]);add(it[2:],a,(2000+yy) if yy<90 else 1900+yy)

json.dump(A,open('awards.json','w'),separators=(',',':'));print(len(A))
