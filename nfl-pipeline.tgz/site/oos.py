"""Decisive out-of-sample test: the six flagged patterns, on 2012-2025 (never searched)."""
import json, csv, math, datetime, collections, random, re, glob
import ephem
from lunardate import LunarDate
SIGNS=['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces']
AN=['Rat','Ox','Tiger','Rabbit','Dragon','Snake','Horse','Goat','Monkey','Rooster','Dog','Pig']
WX=['Wood','Wood','Fire','Fire','Earth','Earth','Metal','Metal','Water','Water']
_l={}
def lny(y):
    if y not in _l: _l[y]=LunarDate(y,1,1).to_solar_date()
    return _l[y]
_sl={}
def sunsign(ds):
    if ds in _sl: return _sl[ds]
    y,m,d=map(int,ds.split('-')); s=ephem.Sun(); s.compute(ephem.Date(datetime.datetime(y,m,d,12,0)))
    v=SIGNS[int((math.degrees(ephem.Ecliptic(s).lon)%360)//30)]; _sl[ds]=v; return v
def jdn(y,m,d):
    a=(14-m)//12; yy=y+4800-a; mm=m+12*a-3
    return d+(153*mm+2)//5+365*yy+yy//4-yy//100+yy//400-32045
def prof(ds):
    y,m,d=map(int,ds.split('-'))
    zy=y if datetime.date(y,m,d)>=lny(y) else y-1
    J=jdn(y,m,d)
    return {"sign":sunsign(ds),"animal":AN[(zy-1984)%12],"yelem":WX[(zy-1984)%10],
            "danimal":AN[(J+1)%12],"delem":WX[(J+9)%10]}
def norm(n):
    n=re.sub(r"[^a-z ]","",n.lower().replace("-"," "))
    return " ".join(w for w in n.split() if w not in {"jr","sr","ii","iii","iv","v"})
# game results by game_id
GM={}
for r in csv.DictReader(open("/home/runner/nfl/games/games.csv")):
    if r["home_score"] and r["away_score"] and r["home_score"]!=r["away_score"]:
        GM[r["game_id"]]={"d":r["gameday"],"h":r["home_team"],"a":r["away_team"],
                          "win":r["home_team"] if int(r["home_score"])>int(r["away_score"]) else r["away_team"]}
# per season: birthdates then rosters-on-field
units=collections.defaultdict(dict)   # game_id -> team -> list of birthdates
for y in range(2012,2026):
    bd={}; nm={}
    for r in csv.DictReader(open(f"/home/runner/nfl/hist/roster_{y}.csv",encoding="utf-8")):
        if not r.get("birth_date"): continue
        if r.get("pfr_id"): bd[r["pfr_id"]]=r["birth_date"]
        nm[(norm(r["full_name"]),r["team"])]=r["birth_date"]
        nm.setdefault(norm(r["full_name"]),r["birth_date"])
    hit=miss=0
    for r in csv.DictReader(open(f"/home/runner/nfl/hist/snaps_{y}.csv",encoding="utf-8")):
        gid=r["game_id"]
        if gid not in GM: continue
        if sum(float(r[k] or 0) for k in ("offense_snaps","defense_snaps","st_snaps"))<=0: continue
        b=bd.get(r["pfr_player_id"]) or nm.get((norm(r["player"]),r["team"])) or nm.get(norm(r["player"]))
        if not b: miss+=1; continue
        hit+=1
        units[gid].setdefault(r["team"],[]).append(b)
    print(f"  {y}: matched {hit} appearances, unmatched {miss}")
good=[g for g,v in units.items() if len(v)==2 and all(len(x)>=20 for x in v.values())]
print("usable games 2012-2025:",len(good))
# profiles cache
PB={}
def pb(b):
    if b not in PB: PB[b]=prof(b)
    return PB[b]
PD={}
def pd_(d):
    if d not in PD: PD[d]=prof(d)
    return PD[d]
FLAG=[("yelem","delem","Metal","Wood"),("yelem","delem","Earth","Fire"),("yelem","delem","Fire","Wood"),
      ("sign","sign","Leo","Libra"),("sign","sign","Gemini","Virgo"),("animal","danimal","Rooster","Rooster")]
IN_SAMPLE={"Metal on Wood day":(4,17),"Earth on Fire day":(11,16),"Fire on Wood day":(13,16),
           "Leo on Libra day":(32,44),"Gemini on Virgo day":(10,30),"Rooster on Rooster day":(2,13)}
random.seed(5); N=20000
print()
print(f"{'pattern':26s} {'2026 (searched)':>16} {'2012-2025 out-of-sample':>26} {'p':>7}")
res=[]
for pk,dk,pa,pb_ in FLAG:
    w=n=0
    for gid in good:
        D=pd_(GM[gid]["d"])
        if D[dk]!=pb_: continue
        sh={}
        for t,bl in units[gid].items():
            sh[t]=sum(1 for b in bl if pb(b)[pk]==pa)/len(bl)
        ts=list(sh)
        if sh[ts[0]]==sh[ts[1]]: continue
        more=ts[0] if sh[ts[0]]>sh[ts[1]] else ts[1]
        n+=1; w+= (GM[gid]["win"]==more)
    label=f"{pa} on {pb_} day"
    iw,ino=IN_SAMPLE[label]
    if n:
        dev=abs(w/n-0.5); ge=sum(1 for _ in range(N) if abs(sum(random.random()<0.5 for _ in range(n))/n-0.5)>=dev-1e-12)
        p=(ge+1)/(N+1)
    else: p=None
    print(f"{label:26s} {str(iw)+'-'+str(ino-iw)+' ('+format(iw/ino*100,'.0f')+'%)':>16} {str(w)+'-'+str(n-w)+' ('+format(w/n*100,'.1f')+'%)':>26} {round(p,3):>7}")
    res.append({"pattern":label,"in_w":iw,"in_n":ino,"oos_w":w,"oos_n":n,"oos_rate":w/n if n else None,"p":p})
json.dump({"flags":res,"games":len(good)},open("oos.json","w"),separators=(",",":"))
