"""Label-permutation test: shuffle zodiac/sign labels among players, keep real outcomes and rosters.
This holds team strength fixed, so only the attribute itself can create a signal."""
import json, random, collections
A=json.load(open("astro.json")); S=json.load(open("step2.json")); AP=json.load(open("appear.json"))
P=A["players"]; DT=A["dates"]
games=[g for g in S["games"] if g["played"] and g["winner"]!="TIE"]
gi={g["game_id"]:i for i,g in enumerate(games)}
AG=AP["g"]
roster=collections.defaultdict(list)
for pid,lst in AP["a"].items():
    for gidx,team in lst:
        gid=AG[gidx][0]
        if gid in gi: roster[(gi[gid],team)].append(int(pid))
units=[]   # (player_idx, date, won)
for i,g in enumerate(games):
    h,a=g["home"],g["away"]
    if (i,h) not in roster or (i,a) not in roster: continue
    for t in (h,a):
        won = (g["winner"]==t)
        for j in roster[(i,t)]: units.append((j,g["date"],won))
print("player-game units:",len(units))
FIELD={"sign":6,"animal":7,"yelem":8}
DKEY={"sign":"sign","animal":"danimal","yelem":"delem"}
def cells(labels,field):
    k=DKEY[field]; win=collections.Counter(); tot=collections.Counter()
    for j,date,won in units:
        c=(labels[j],DT[date][k]); tot[c]+=1; win[c]+=won
    return win,tot
random.seed(321); N=4000
out={}
for field,idx in FIELD.items():
    base={j:P[j][idx] for j in range(len(P))}
    gw,gt=cells(base,field)
    tested=[c for c in gt if gt[c]>=40]
    dev={c:abs(gw[c]/gt[c]-0.5) for c in tested}
    # pool of labels actually held by players who appear
    appeared=sorted({j for j,_,_ in units})
    pool=[P[j][idx] for j in appeared]
    ge=collections.Counter()
    for _ in range(N):
        random.shuffle(pool)
        lab=dict(zip(appeared,pool))
        sw,st=cells(lab,field)
        for c in tested:
            if st[c] and abs(sw[c]/st[c]-0.5)>=dev[c]-1e-12: ge[c]+=1
    rows=[]
    for c in sorted(gt):
        r={"a":c[0],"b":c[1],"wins":gw[c],"apps":gt[c],"rate":gw[c]/gt[c]}
        if c in tested: r["p"]=(ge[c]+1)/(N+1)
        rows.append(r)
    t=[r for r in rows if "p" in r]; sig=[r for r in t if r["p"]<0.05]
    print(f"{field}: tested {len(t)}  p<.05 {len(sig)}  expected {0.05*len(t):.1f}")
    for r in sorted(sig,key=lambda r:r["p"])[:5]: print("    ",r)
    out[field]={"rows":rows,"tested":len(t),"sig":len(sig),"expected":0.05*len(t)}
json.dump(out,open("astro_label.json","w"),separators=(",",":"))
