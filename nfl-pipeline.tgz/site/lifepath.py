import csv, sys, collections

MASTER = {11, 22, 33}

def reduce(n, keep_master=True):
    while n > 9 and not (keep_master and n in MASTER):
        n = sum(int(d) for d in str(n))
    return n

def life_path(date_str):
    """Standard method: reduce month, day, year separately (keeping masters), then sum and reduce."""
    y, m, d = date_str.split("-")
    total = reduce(int(m)) + reduce(int(d)) + reduce(sum(int(c) for c in y))
    return reduce(total)

src, out = sys.argv[1], sys.argv[2]
rows = list(csv.DictReader(open(src, newline="", encoding="utf-8")))
# keep the latest week's entry per player
latest = {}
for r in rows:
    k = r["gsis_id"] or r["full_name"]
    if k not in latest or int(r["week"] or 0) >= int(latest[k]["week"] or 0):
        latest[k] = r

result, missing = [], 0
for r in latest.values():
    if not r["birth_date"]:
        missing += 1
        continue
    result.append({
        "player": r["full_name"], "team": r["team"], "position": r["position"],
        "status": r["status"], "birth_date": r["birth_date"],
        "life_path": life_path(r["birth_date"]), "gsis_id": r["gsis_id"],
    })
result.sort(key=lambda x: (x["team"], x["player"]))
with open(out, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(result[0].keys()))
    w.writeheader(); w.writerows(result)

print("players:", len(result), "missing birthdate:", missing)
print("statuses:", collections.Counter(r["status"] for r in result).most_common())
print("max week:", max(int(r["week"] or 0) for r in rows))
print("life path distribution:", sorted(collections.Counter(r["life_path"] for r in result).items()))
# sanity checks
for d, exp in [("1983-12-02", None), ("1996-09-17", None)]:
    print(d, life_path(d))
