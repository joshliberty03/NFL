"""Sun signs, Chinese zodiac (year + day pillar) for players, coaches, teams and game dates."""
import json, csv, math, datetime, collections, sys
import ephem
from lunardate import LunarDate

SIGNS=['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces']
ELEM_OF_SIGN={'Aries':'Fire','Leo':'Fire','Sagittarius':'Fire','Taurus':'Earth','Virgo':'Earth','Capricorn':'Earth',
 'Gemini':'Air','Libra':'Air','Aquarius':'Air','Cancer':'Water','Scorpio':'Water','Pisces':'Water'}
MODE_OF_SIGN={'Aries':'Cardinal','Cancer':'Cardinal','Libra':'Cardinal','Capricorn':'Cardinal',
 'Taurus':'Fixed','Leo':'Fixed','Scorpio':'Fixed','Aquarius':'Fixed',
 'Gemini':'Mutable','Virgo':'Mutable','Sagittarius':'Mutable','Pisces':'Mutable'}
AN=['Rat','Ox','Tiger','Rabbit','Dragon','Snake','Horse','Goat','Monkey','Rooster','Dog','Pig']
WX=['Wood','Wood','Fire','Fire','Earth','Earth','Metal','Metal','Water','Water']
TRINE={}
for grp in [('Rat','Dragon','Monkey'),('Ox','Snake','Rooster'),('Tiger','Horse','Dog'),('Rabbit','Goat','Pig')]:
    for a in grp: TRINE[a]=grp[0]
GEN={'Wood':'Fire','Fire':'Earth','Earth':'Metal','Metal':'Water','Water':'Wood'}   # produces
CTRL={'Wood':'Earth','Earth':'Water','Water':'Fire','Fire':'Metal','Metal':'Wood'}  # controls

_lny={}
def lny(y):
    if y not in _lny: _lny[y]=LunarDate(y,1,1).to_solar_date()
    return _lny[y]
def sunlon(y,m,d):
    s=ephem.Sun(); s.compute(ephem.Date(datetime.datetime(y,m,d,12,0)))
    return math.degrees(ephem.Ecliptic(s).lon)%360
def jdn(y,m,d):
    a=(14-m)//12; yy=y+4800-a; mm=m+12*a-3
    return d+(153*mm+2)//5+365*yy+yy//4-yy//100+yy//400-32045
def profile(datestr):
    y,m,d=map(int,datestr.split('-'))
    lon=sunlon(y,m,d); sign=SIGNS[int(lon//30)]
    deg=lon%30
    zy=y if datetime.date(y,m,d)>=lny(y) else y-1
    J=jdn(y,m,d)
    return {"sign":sign,"elem":ELEM_OF_SIGN[sign],"mode":MODE_OF_SIGN[sign],"cusp":round(min(deg,30-deg),1),
            "animal":AN[(zy-1984)%12],"yelem":WX[(zy-1984)%10],"zyear":zy,
            "danimal":AN[(J+1)%12],"delem":WX[(J+9)%10]}

players=json.load(open("data.json"))       # [name, team, pos, status, birth, lp]
S=json.load(open("step2.json")); H=json.load(open("history.json")); FOUNDED=json.load(open("founded.json"))
P=[]
for p in players:
    pr=profile(p[4]); P.append(p+[pr["sign"],pr["animal"],pr["yelem"],pr["elem"],pr["mode"],pr["cusp"]])
print("players profiled:",len(P))
print("sun signs:",sorted(collections.Counter(x[6] for x in P).items(),key=lambda t:-t[1])[:4])
print("animals:",sorted(collections.Counter(x[7] for x in P).items(),key=lambda t:-t[1])[:4])
print("cusp within 1 degree:",sum(1 for x in P if x[11]<=1.0),"of",len(P))
coaches={c["team"]:{**c,**profile(c["birth_date"])} for c in S["coaches"]}
teams={t:(profile(FOUNDED[t]) if FOUNDED[t] else None) for t in FOUNDED}
dates={}
for g in S["games"]: dates[g["date"]]=profile(g["date"])
for g in H["games"]: dates.setdefault(g[3],None)
json.dump({"players":P,"coaches":coaches,"teams":teams,
           "dates":{k:v for k,v in dates.items() if v}},open("astro.json","w"),separators=(",",":"))
print("coaches:",{c:(v["sign"],v["yelem"],v["animal"]) for c,v in list(coaches.items())[:3]})
print("teams sample:",{t:(v["sign"],v["yelem"],v["animal"]) for t,v in list(teams.items())[:3] if v})
print("2026-10-18:",dates["2026-10-18"])
