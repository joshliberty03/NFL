#!/bin/bash
# Weekly rebuild of Betting by Numbers. Run from /home/runner/nfl/site. Output: betting-by-numbers.html
set -e
cd "$(dirname "$0")"
R=https://github.com/nflverse/nflverse-data/releases/download; D=/home/runner/nfl/stats
curl -sfL --max-time 300 -o $D/games_new.csv $R/schedules/games.csv
cp $D/games_new.csv /home/runner/nfl/games/games.csv
python3 apply_override.py
for y in 2026 2025; do s=${y: -2}
  curl -sfL --max-time 300 -o $D/p$s.csv $R/stats_player/stats_player_week_$y.csv
  curl -sfL --max-time 300 -o $D/t$s.csv $R/stats_team/stats_team_week_$y.csv
  curl -sfL --max-time 600 -o $D/pbp$s.csv $R/pbp/play_by_play_$y.csv
  curl -sfL --max-time 120 -o $D/rosters$y.csv $R/rosters/roster_$y.csv
done
curl -sfL --max-time 300 -o /home/runner/nfl/depth_2026.csv $R/depth_charts/depth_charts_2026.csv
cp $D/rosters2026.csv /home/runner/nfl/roster_2026_new.csv
curl -sfL --max-time 120 -o inj26.csv $R/injuries/injuries_2026.csv || true
curl -sfL --max-time 120 -o draft.csv $R/draft_picks/draft_picks.csv || true
curl -sfL --max-time 60 -o $D/teams.csv $R/teams/teams_colors_logos.csv
python3 -I stats.py && python3 -I pvt.py && python3 -I coaches.py && python3 -I inj.py && python3 -I hist.py && python3 -I gamedet.py && python3 -I logos.py logos && python3 -I betting.py && python3 -I moon.py && python3 assemble.py && python3 build3.py && python3 -I make_index.py
ls -la betting-by-numbers.html
