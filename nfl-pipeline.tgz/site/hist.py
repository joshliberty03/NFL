# Builds hist.json (records, super bowls, rivalries) and draft.json
import csv,json,glob,collections,os
TM={'SD':'LAC','OAK':'LV','STL':'LA','LAR':'LA','LVR':'LV','GNB':'GB','KAN':'KC','NOR':'NO','NWE':'NE','SFO':'SF','TAM':'TB','SDG':'LAC','LV':'LV'}
fx=lambda t:TM.get(t,t)
TI=json.load(open('teamsinfo.json'))
# ---------- draft ----------
d=[]
for x in csv.DictReader(open('draft.csv')):
    s=int(x['season'])
    if s<2000:continue
    d.append([s,int(x['round']),int(x['pick']),fx(x['team']),x['pfr_player_name'],x['position'],x['college'],int(x['allpro'] or 0),int(x['probowls'] or 0),1 if x['hof']=='TRUE' else 0,int(float(x['car_av'])) if x['car_av'] else None])
json.dump(d,open('draft.json','w'),separators=(',',':'))
# ---------- player records ----------
STATS=[('passing_yards','Passing yards'),('passing_tds','Passing touchdowns'),('rushing_yards','Rushing yards'),('rushing_tds','Rushing touchdowns'),('receptions','Receptions'),('receiving_yards','Receiving yards'),('receiving_tds','Receiving touchdowns'),('def_sacks','Sacks'),('def_interceptions','Interceptions'),('fg_made','Field goals made')]
rows=[]
files=sorted(glob.glob('pw/pw*.csv'))+['/home/runner/nfl/stats/p25.csv','/home/runner/nfl/stats/p26.csv']
seen=set()
for f in files:
    for x in csv.DictReader(open(f)):
        if x.get('season_type')!='REG':continue
        k=(x['player_id'],x['season'],x['week'])
        if k in seen:continue
        seen.add(k);rows.append(x)
def num(v):
    try:return float(v)
    except:return 0.0
season=collections.defaultdict(lambda:collections.defaultdict(float));career=collections.defaultdict(lambda:collections.defaultdict(float));meta={}
game=collections.defaultdict(list)
for x in rows:
    pid=x['player_id'];nm=x['player_display_name'] or x['player_name'];tm=fx(x['team'])
    meta[pid]=meta.get(pid,{'n':nm,'s':int(x['season']),'e':int(x['season'])})
    meta[pid]['s']=min(meta[pid]['s'],int(x['season']));meta[pid]['e']=max(meta[pid]['e'],int(x['season']))
    for c,_ in STATS:
        v=num(x.get(c));
        if not v:continue
        season[(c,pid,x['season'],tm)]['v']+=v;career[(c,pid)]['v']+=v
        game[c].append((v,nm,tm,fx(x['opponent_team']),int(x['season']),int(x['week']),pid))
stint=collections.defaultdict(dict)
for (c,pid,sea,tm),v in season.items():
    d_=stint[(c,pid)].setdefault(tm,[9999,0]);d_[0]=min(d_[0],int(sea));d_[1]=max(d_[1],int(sea))
def teams_of(c,pid):
    return ', '.join(f"{t} {a}" if a==b else f"{t} {a}-{b}" for t,(a,b) in sorted(stint[(c,pid)].items(),key=lambda z:z[1][0]))
rec={}
for c,lab in STATS:
    S=sorted(((v['v'],k) for k,v in season.items() if k[0]==c),reverse=True)[:10]
    C=sorted(((v['v'],k) for k,v in career.items() if k[0]==c),reverse=True)[:10]
    G=sorted(game[c],reverse=True)[:10]
    r1=lambda v:int(v) if v==int(v) else round(v,1)
    rec[c]={'l':lab,
     's':[[meta[k[1]]['n'],int(k[2]),k[3],r1(v),k[1]] for v,k in S],
     'c':[[meta[k[1]]['n'],meta[k[1]]['s'],meta[k[1]]['e'],r1(v),k[1],teams_of(c,k[1])] for v,k in C],
     'g':[[g[1],g[4],g[5],g[2],g[3],r1(g[0]),g[6]] for g in G]}
# ---------- franchise records (since 1999) ----------
fr={}
car_t=collections.defaultdict(lambda:{'v':0.0,'s':9999,'e':0})
for (c,pid,sea,tm),v in season.items():
    d=car_t[(c,tm,pid)];d['v']+=v['v'];d['s']=min(d['s'],int(sea));d['e']=max(d['e'],int(sea))
r1=lambda v:int(v) if v==int(v) else round(v,1)
for c,_ in STATS:
    for tm in set(k[3] for k in season if k[0]==c):
        ss=max(((v['v'],k) for k,v in season.items() if k[0]==c and k[3]==tm),key=lambda z:z[0])
        cs=max(((d['v'],k,d) for k,d in car_t.items() if k[0]==c and k[1]==tm),key=lambda z:z[0])
        gg=max((g for g in game[c] if g[2]==tm),key=lambda g:g[0])
        fr.setdefault(tm,{})[c]={'s':[meta[ss[1][1]]['n'],int(ss[1][2]),r1(ss[0]),ss[1][1]],'c':[meta[cs[1][2]]['n'],cs[2]['s'],cs[2]['e'],r1(cs[0]),cs[1][2]],'g':[gg[1],gg[4],gg[5],gg[3],r1(gg[0]),gg[6]]}
# ---------- team stat records (sum of player rows) ----------
TS=[('passing_yards','Passing yards'),('rushing_yards','Rushing yards'),('passing_tds','Passing touchdowns'),('rushing_tds','Rushing touchdowns'),('def_sacks','Sacks'),('def_interceptions','Interceptions')]
tseas=collections.defaultdict(float);tgame=collections.defaultdict(float)
for x in rows:
    tm=fx(x['team'])
    for c,_ in TS:
        v=num(x.get(c))
        if v:tseas[(c,tm,int(x['season']))]+=v;tgame[(c,tm,int(x['season']),int(x['week']),fx(x['opponent_team']))]+=v
tstat={}
for c,lab in TS:
    # complete seasons only for season totals
    S=sorted(((v,k) for k,v in tseas.items() if k[0]==c and k[2]<=2025),reverse=True)[:10]
    G=sorted(((v,k) for k,v in tgame.items() if k[0]==c),reverse=True)[:10]
    tstat[c]={'l':lab,'s':[[k[1],k[2],r1(v)] for v,k in S],'g':[[k[1],k[2],k[3],k[4],r1(v)] for v,k in G]}
# ---------- unusual records (since 1999, nflverse) ----------
ODD=[('ints_thrown','Most interceptions thrown',['passing_interceptions'],None),
('sacked','Most times sacked',['sacks_suffered'],None),
('fumbles','Most fumbles',['fumbles_total'],None),
('fumbles_lost','Most fumbles lost',['fumbles_lost_total'],None),
('qb_rush','Quarterback rushing yards',['rushing_yards'],'QB'),
('qb_rush_td','Quarterback rushing touchdowns',['rushing_tds'],'QB'),
('te_yds','Tight end receiving yards',['receiving_yards'],'TE'),
('te_rec','Tight end receptions',['receptions'],'TE'),
('rb_yds','Running back receiving yards',['receiving_yards'],'RB'),
('rb_rec','Running back receptions',['receptions'],'RB'),
('targets','Most targets',['targets'],None),
('carries','Most carries',['carries'],None),
('attempts','Most pass attempts',['attempts'],None),
('two_pt','Most two-point conversions',['passing_2pt_conversions','rushing_2pt_conversions','receiving_2pt_conversions'],None),
('ret_td','Most return touchdowns',['special_teams_tds'],None),
('def_td','Most defensive touchdowns',['def_tds'],None),
('ff','Most forced fumbles',['def_fumbles_forced'],None),
('fr','Most fumble recoveries',['fumble_recovery_own','fumble_recovery_opp'],None),
('tfl','Most tackles for loss',['def_tackles_for_loss'],None),
('pd','Most passes defended',['def_pass_defended'],None),
('qbh','Most quarterback hits',['def_qb_hits'],None),
('safe','Most safeties',['def_safeties'],None),
('blk','Most blocked kicks',['def_fg_blocks','def_punt_blocks','def_pat_blocks'],None),
('kr','Most kickoff return yards',['kickoff_return_yards'],None),
('pr','Most punt return yards',['punt_return_yards'],None),
('pen','Most penalties',['penalties'],None),
('penyd','Most penalty yards',['penalty_yards'],None),
('missed','Most field goals missed',['fg_missed'],None),
('punts','Most punts',['pt_att'],None),
('in20','Most punts inside the 20',['pt_inside_20'],None)]
odd=[]
for key,lab,cols,pos in ODD:
    ss=collections.defaultdict(float);gg=[]
    for x in rows:
        if pos and x.get('position')!=pos:continue
        v=sum(num(x.get(c)) for c in cols)
        if not v:continue
        nm=x['player_display_name'] or x['player_name'];tm=fx(x['team'])
        ss[(nm,int(x['season']),tm)]+=v;gg.append((v,nm,int(x['season']),int(x['week']),tm,fx(x['opponent_team'])))
    S=sorted(((v,k) for k,v in ss.items() if k[1]<=2025),reverse=True)[:10]
    G=sorted(gg,reverse=True)[:5]
    odd.append({'k':key,'l':lab,'s':[[k[0],k[1],k[2],r1(v)] for v,k in S],'g':[[g[1],g[2],g[3],g[4],g[5],r1(g[0])] for g in G]})
# longest field goals (single game max)
lf=[]
for x in rows:
    v=num(x.get('fg_long'))
    if v:lf.append((v,x['player_display_name'] or x['player_name'],int(x['season']),int(x['week']),fx(x['team']),fx(x['opponent_team'])))
lf.sort(reverse=True);seen_=set();top=[]
for g in lf:
    if (g[1],g[2],g[3]) in seen_:continue
    seen_.add((g[1],g[2],g[3]));top.append(g)
    if len(top)>=10:break
odd.append({'k':'fg_long','l':'Longest field goals','s':[],'g':[[g[1],g[2],g[3],g[4],g[5],r1(g[0])] for g in top]})
# ---------- new highs by year (since 1999 baseline, nflverse) ----------
CATS=[(c,l,[c],None) for c,l in STATS]+[(k,l,cols,p) for k,l,cols,p in ODD]
newhi={}
for key,lab,cols,pos in CATS:
    ss=collections.defaultdict(float);gm=[]
    for x in rows:
        if pos and x.get('position')!=pos:continue
        v=sum(num(x.get(c)) for c in cols)
        if not v:continue
        nm=x['player_display_name'] or x['player_name'];tm=fx(x['team']);y=int(x['season'])
        ss[(nm,y,tm)]+=v;gm.append((v,nm,y,int(x['week']),tm))
    for kind,items in (('season',[(v,k[0],k[1],0,k[2]) for k,v in ss.items()]),('game',gm)):
        by=collections.defaultdict(list)
        for it in items:by[it[2]].append(it)
        best=0.0
        for y in range(1999,2027):
            if y not in by:continue
            top=max(by[y],key=lambda z:z[0])
            if y>=2004 and top[0]>best and best>0 and not(y==2026 and kind=='season'):
                newhi.setdefault(str(y),[]).append([lab,kind,top[1],top[4],r1(top[0]),r1(best)])
            best=max(best,top[0])
# ---------- team records & games ----------
G=[x for x in csv.DictReader(open('/home/runner/nfl/games/games.csv')) if x['home_score']!='']
ts=collections.defaultdict(lambda:{'w':0,'l':0,'t':0,'pf':0,'pa':0})
games=[]
for x in G:
    h,a=fx(x['home_team']),fx(x['away_team']);hs,as_=int(x['home_score']),int(x['away_score']);s=int(x['season'])
    games.append((s,x['game_type'],int(x['week']),h,hs,a,as_))
    if x['game_type']=='REG':
        for t,f,o in((h,hs,as_),(a,as_,hs)):
            r=ts[(t,s)];r['pf']+=f;r['pa']+=o
            if f>o:r['w']+=1
            elif f<o:r['l']+=1
            else:r['t']+=1
def pct(r):return (r['w']+r['t']/2)/max(1,r['w']+r['l']+r['t'])
full={k:v for k,v in ts.items() if v['w']+v['l']+v['t']>=16}
TR=lambda it:[[k[0],k[1],v['w'],v['l'],v['t'],v['pf'],v['pa']] for k,v in it]
team={'best':TR(sorted(full.items(),key=lambda kv:(-pct(kv[1]),-(kv[1]['pf']-kv[1]['pa'])))[:10]),
 'worst':TR(sorted(full.items(),key=lambda kv:(pct(kv[1]),kv[1]['pf']-kv[1]['pa']))[:10]),
 'pts':TR(sorted(full.items(),key=lambda kv:-kv[1]['pf'])[:10]),
 'stingy':TR(sorted(full.items(),key=lambda kv:kv[1]['pa'])[:10]),
 'diff':TR(sorted(full.items(),key=lambda kv:-(kv[1]['pf']-kv[1]['pa']))[:10])}
gm=lambda g:[g[0],g[1],g[2],g[3],g[4],g[5],g[6]]
team['hi']=[gm(g) for g in sorted(games,key=lambda g:-(g[4]+g[6]))[:10]]
team['blow']=[gm(g) for g in sorted(games,key=lambda g:-abs(g[4]-g[6]))[:10]]
# ---------- rivalries ----------
pairs=collections.defaultdict(list)
for g in sorted(games,key=lambda g:(g[0],{'REG':0,'WC':1,'DIV':2,'CON':3,'SB':4}[g[1]],g[2])):
    k='|'.join(sorted([g[3],g[5]]));pairs[k].append(g)
riv={}
for k,L in pairs.items():
    a,b=k.split('|');wa=sum(1 for g in L if (g[3]==a and g[4]>g[6]) or (g[5]==a and g[6]>g[4]));wb=sum(1 for g in L if (g[3]==b and g[4]>g[6]) or (g[5]==b and g[6]>g[4]))
    last=[[g[0],g[1],g[2],g[3],g[4],g[5],g[6]] for g in L[-8:]]
    st=None;cnt=0
    for g in reversed(L):
        w=g[3] if g[4]>g[6] else g[5] if g[6]>g[4] else 'T'
        if st is None:st=w;cnt=1
        elif w==st:cnt+=1
        else:break
    riv[k]={'st':[st,cnt],'n':len(L),'a':wa,'b':wb,'t':len(L)-wa-wb,'last':last,'pa':sum((g[4] if g[3]==a else g[6]) for g in L),'pb':sum((g[4] if g[3]==b else g[6]) for g in L)}
# ---------- all-time leaders (Pro Football Reference, scraped via the user's Chrome) ----------
PM={'pass_yds':'passing_yards','pass_td':'passing_tds','rush_yds':'rushing_yards','rush_td':'rushing_tds','rec':'receptions','rec_yds':'receiving_yards','rec_td':'receiving_tds','sacks':'def_sacks','def_int':'def_interceptions','fgm':'fg_made'}
PT={'CLT':'IND','RAI':'LV','OTI':'TEN','PHO':'ARI','HTX':'HOU','NOR':'NO','KAN':'KC','TAM':'TB','NWE':'NE','GNB':'GB','SFO':'SF','SDG':'LAC','LVR':'LV','OAK':'LV','STL':'LA','LAR':'LA','RAM':'LA','CRD':'ARI','NYY':'','HOU':'HOU'}
allt={}
PTM=json.load(open('pfr_teams.json')) if os.path.exists('pfr_teams.json') else {}
def tstr(nm):
    return PTM.get(nm,'')
if os.path.exists('pfr_leaders.txt'):
    for ln in open('pfr_leaders.txt'):
        k,v=ln.rstrip('\n').split('=',1)
        if k not in PM:continue
        d2={}
        for part in v.split('|'):
            kind,rows=part.split(':',1);L=[]
            for r in rows.split(';'):
                f=r.split('~')
                num_=float(f[1]);num_=int(num_) if num_==int(num_) else num_
                if kind=='S':L.append([f[0],num_,int(f[2]),PT.get(f[3],f[3])])
                elif kind=='C':L.append([f[0],num_,f[2],tstr(f[0])])
                else:L.append([f[0],num_,PT.get(f[2],f[2]),f[3][-4:]])
            d2[kind.lower()]=L
        allt[PM[k]]=d2
sb=json.load(open('superbowl.json'))['sbs']
json.dump({'newhi':newhi,'odd':odd,'all':allt,'tstat':tstat,'fr':fr,'rec':rec,'team':team,'riv':riv,'sb':sb,'range':[1999,max(int(x['season']) for x in G)]},open('hist.json','w'),separators=(',',':'))
print(os.path.getsize('hist.json'),os.path.getsize('draft.json'),len(d),len(riv))
