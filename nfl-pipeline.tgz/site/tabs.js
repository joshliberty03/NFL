/* ===================== shared football data ===================== */
const TI=__TEAMSINFO__, SEA=__SEASON__, PS=__PSTATS__, DEFP=__DEFPTS__, RK=__RANK__, H2H=__H2H__,PVT=__PVT__,COACHES=__COACHES__,BUILT=__BUILT__,LOGOS=__LOGOS__,INJ=__INJ__, SEA25=__SEASON25__;
const PKEYS=PS.keys, KI={};PKEYS.forEach((k,i)=>KI[k]=i);
const tname=t=>(TI[t]&&TI[t].name)||t;
const tlogo=(t,s)=>{const i=TI[t];if(!i)return '';return `<span class="tlg" style="--s:${s||24}px;--c1:${i.c1};--c2:${i.c2}"><img src="${LOGOS[t]||i.logo}" alt="" loading="lazy" referrerpolicy="no-referrer"><b>${t}</b></span>`};
document.addEventListener('error',e=>{const im=e.target;if(im&&im.tagName==='IMG'){const l=im.closest&&im.closest('.tlg');if(l)l.classList.add('nolog')}},true);
const h2h=(a,b)=>{const k=[a,b].sort().join('|'),v=H2H[k]||[0,0,0];return a<b?{a:v[0],b:v[1],t:v[2]}:{a:v[1],b:v[0],t:v[2]}};
const lsGet=(k,d)=>{try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}};
const lsSet=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
/* US Eastern offset for a date (games kick off after noon, so the changeover hour never matters) */
function etKick(date,time){const[y,m,d]=date.split('-').map(Number);const nth=(yy,mm,dow,n)=>{let c=0;for(let day=1;day<=31;day++){const dt=new Date(Date.UTC(yy,mm-1,day));if(dt.getUTCMonth()!==mm-1)break;if(dt.getUTCDay()===dow&&++c===n)return day}};
  const s=nth(y,3,0,2),e=nth(y,11,0,1);const v=y*10000+m*100+d;const dst=v>=y*10000+300+s&&v<y*10000+1100+e;
  const[hh,mm]=(time||'13:00').split(':').map(Number);return Date.UTC(y,m-1,d,hh+(dst?4:5),mm)}
const SEAPLAYED=SEA.filter(g=>g.hs!=null);
const TREC={};Object.keys(TI).forEach(t=>TREC[t]=[0,0,0]);
SEAPLAYED.forEach(g=>{if(g.hs===g.as){TREC[g.h][2]++;TREC[g.a][2]++}else{const w=g.hs>g.as?g.h:g.a,l=g.hs>g.as?g.a:g.h;TREC[w][0]++;TREC[l][1]++}});
const TSTK={};Object.keys(TI).forEach(t=>TSTK[t]=null);
SEAPLAYED.slice().sort((a,b)=>etKick(a.d,a.t)-etKick(b.d,b.t)).forEach(g=>{[[g.h,g.hs,g.as],[g.a,g.as,g.hs]].forEach(([tm,me,op])=>{const k=me>op?'W':me<op?'L':'T',s=TSTK[tm];TSTK[tm]=(s&&s.k===k)?{k,n:s.n+1}:{k,n:1}})});
const tstreak=t=>{const s=TSTK[t];return s?`<b class="stk ${s.k}" title="Current streak: ${s.n} ${s.k==='W'?'win':s.k==='L'?'loss':'tie'}${s.n>1?(s.k==='T'?'s':s.k==='W'?'s in a row':'es in a row'):''}">${s.k}${s.n}</b>`:''};
const MFO={},MFD={},MFL={};
(()=>{const R=RK['2026'];if(!R)return;const ts=Object.keys(R),o=ts.slice().sort((a,b)=>R[b].ppg-R[a].ppg),d=ts.slice().sort((a,b)=>R[a].papg-R[b].papg);o.forEach((t,i)=>MFO[t]=i+1);d.forEach((t,i)=>MFD[t]=i+1);
 const g=SEAPLAYED.slice().sort((a,b)=>etKick(a.d,a.t)-etKick(b.d,b.t));ts.forEach(t=>{MFL[t]=g.filter(x=>x.h===t||x.a===t).slice(-3).map(x=>{const me=x.h===t?x.hs:x.as,op=x.h===t?x.as:x.hs;return me>op?'W':me<op?'L':'T'}).join('')})})();
const mfact=t=>{if(!MFO[t])return '';const l=(MFL[t]||'').split('').map(c=>`<i class="${c==='W'?'w':c==='L'?'l':'t'}">${c}</i>`).join('')||'–';
  return `<span class="mf"><span class="mfr"><em>Offense</em><b>#${MFO[t]}</b></span><span class="mfr"><em>Defense</em><b>#${MFD[t]}</b></span><span class="mfr"><em>Last 3</em><b class="mfl">${l}</b></span></span>`};

/* per-game team stat comparison for the Pick tickets */
const PGS=[
 ['Record & scoring',[['wp','Win %',0,d=>d.g?(d.w+d.t/2)/d.g*100:0,v=>v.toFixed(0)+'%'],['ppg','Points scored',0,d=>d.ppg,v=>v.toFixed(1)],['papg','Points allowed',1,d=>d.papg,v=>v.toFixed(1)],['dg','Point margin',0,d=>d.g?d.diff/d.g:0,v=>(v>0?'+':'')+v.toFixed(1)]]],
 ['Offense',[['ypg','Total yards',0,d=>d.ypg,v=>v.toFixed(1)],['pypg','Passing yards',0,d=>d.pypg,v=>v.toFixed(1)],['rypg','Rushing yards',0,d=>d.rypg,v=>v.toFixed(1)],['fdpg','First downs',0,d=>d.fdpg,v=>v.toFixed(1)],['epaO','EPA per play',0,d=>d.epaO,v=>(v>0?'+':'')+v.toFixed(2)],['t3p','3rd-down conversion',0,d=>d.t3p,v=>v.toFixed(1)+'%'],['rzp','Red-zone TD rate',0,d=>d.rzp,v=>v.toFixed(1)+'%']]],
 ['Defense',[['ypga','Yards allowed',1,d=>d.ypga,v=>v.toFixed(1)],['pypga','Pass yards allowed',1,d=>d.pypga,v=>v.toFixed(1)],['rypga','Rush yards allowed',1,d=>d.rypga,v=>v.toFixed(1)],['fdpga','First downs allowed',1,d=>d.fdpga,v=>v.toFixed(1)],['epaD','EPA allowed per play',1,d=>d.epaD,v=>(v>0?'+':'')+v.toFixed(2)],['t3pA','3rd-down % allowed',1,d=>d.t3pA,v=>v.toFixed(1)+'%'],['rzpA','Red-zone TD % allowed',1,d=>d.rzpA,v=>v.toFixed(1)+'%'],['sckg','Sacks',0,d=>d.g?d.sck/d.g:0,v=>v.toFixed(2)],['intg','Interceptions',0,d=>d.g?d.int/d.g:0,v=>v.toFixed(2)]]],
 ['Ball security & discipline',[['sckAg','Sacks allowed',1,d=>d.g?d.sckA/d.g:0,v=>v.toFixed(2)],['gvg','Giveaways',1,d=>d.g?d.gv/d.g:0,v=>v.toFixed(2)],['tkg','Takeaways',0,d=>d.g?d.tk/d.g:0,v=>v.toFixed(2)],['tovg','Turnover margin',0,d=>d.g?d.tov/d.g:0,v=>(v>0?'+':'')+v.toFixed(2)],['peng','Penalties',1,d=>d.g?d.pen/d.g:0,v=>v.toFixed(1)],['penyg','Penalty yards',1,d=>d.g?d.peny/d.g:0,v=>v.toFixed(1)]]]];
const PGR={};(()=>{const R=RK['2026'];if(!R)return;PGS.forEach(([,rows])=>rows.forEach(([k,,low,fn])=>{const arr=Object.keys(R).filter(t=>R[t].g>0).map(t=>[t,fn(R[t])]).sort((a,b)=>low?a[1]-b[1]:b[1]-a[1]);const rk={};let last=null,lr=0;arr.forEach(([t,v],i)=>{if(v!==last){lr=i+1;last=v}rk[t]=lr});PGR[k]=rk}))})();
const PGF={};PGS.forEach(([,rows])=>rows.forEach(r=>PGF[r[0]]=r));
const GB15=['ppg','papg','ypg','pypg','rypg','fdpg','ypga','pypga','rypga','t3p','rzp','sckg','tkg','gvg','peng'];
const hexRgb=h=>{const m=/^#?([0-9a-f]{6})$/i.exec(h||'');if(!m)return [120,120,120];const n=parseInt(m[1],16);return [n>>16,(n>>8)&255,n&255]};
const lum=c=>(0.299*c[0]+0.587*c[1]+0.114*c[2]);
const mixW=(c,p)=>c.map(x=>Math.round(x+(255-x)*p));
function barCols(a,h){let ca=hexRgb(TI[a].c1),ch=hexRgb(TI[h].c1);const d=(x,y)=>Math.hypot(x[0]-y[0],x[1]-y[1],x[2]-y[2]);
  if(d(ca,ch)<110)ch=hexRgb(TI[h].c2);if(d(ca,ch)<110)ch=[255,170,40];
  const fix=c=>lum(c)<70?mixW(c,.45):c;ca=fix(ca);ch=fix(ch);if(d(ca,ch)<80)ch=mixW(ch,.5);
  return [`rgb(${ca})`,`rgb(${ch})`]}
function moreStats(g){const R=RK['2026'],a=R[g.a],h=R[g.h];if(!a||!h||!a.g||!h.g)return '<p class="note">Not enough games played yet for team averages.</p>';
  const [ca,ch]=barCols(g.a,g.h);
  const rows=GB15.map(k=>{const [,lab,low,fn,fmt]=PGF[k],va=fn(a),vh=fn(h),m=Math.max(Math.abs(va),Math.abs(vh),1e-9),ba=va===vh?false:low?va<vh:va>vh,bh=va===vh?false:!ba;
    const bar=(t,v,c,best)=>`<div class="gbr"><i style="width:${Math.max(3,Math.abs(v)/m*78)}%;background:${c}"></i><span class="gbv${best?' best':''}">${fmt(v)}<s>#${PGR[k][t]}</s></span></div>`;
    return `<div class="gbrow"><div class="gbl">${lab}${low?'<small>lower wins</small>':''}</div><div class="gbbars">${bar(g.a,va,ca,ba)}${bar(g.h,vh,ch,bh)}</div></div>`}).join('');
  return `<div class="gbleg"><span><i style="background:${ca}"></i>${esc(TI[g.a].nick)} <small>${a.g} games</small></span><span><i style="background:${ch}"></i>${esc(TI[g.h].nick)} <small>${h.g} games</small></span></div>
  <div class="gbchart">${rows}</div>
  <p class="note">2026 per-game averages through week ${LASTWK}. Each stat has its own scale: in every row the longer bar is the bigger number, and the two teams are measured against each other. Bold marks the better team in that stat (lower is better for points allowed, yards allowed, giveaways and penalties). The small # is the league rank out of 32.</p>`}
const INJS=(id)=>{const x=INJ.p[id];return x?{s:x[0],i:x[1]}:null};
const BYE={};(()=>{const wks=[...new Set(SEA.map(g=>g.wk))];wks.forEach(w=>{const on=new Set();SEA.filter(g=>g.wk===w).forEach(g=>{on.add(g.h);on.add(g.a)});Object.keys(TI).forEach(t=>{if(!on.has(t))BYE[t]=w})})})();
const injchip=id=>{const x=INJS(id);return x?`<span class="inj ${x.s[0]}" title="${esc(x.s)}${x.i?': '+esc(x.i):''} (week ${INJ.wk} report)">${x.s==='Questionable'?'Q':x.s==='Doubtful'?'D':x.s==='Out'?'OUT':esc(x.s)}${x.i?' · '+esc(x.i):''}</span>`:''};
const trec=t=>{const r=TREC[t];return `${r[0]}–${r[1]}${r[2]?'–'+r[2]:''}`};
const LASTWK=SEAPLAYED.length?Math.max(...SEAPLAYED.map(g=>g.wk)):0;
const wkState=w=>{const gs=SEA.filter(g=>g.wk===w),n=gs.filter(g=>g.hs!=null).length;return n===0?'·':n===gs.length?'final':'live'};
const fmtDay=d=>new Date(d+'T12:00:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});

/* ===================== PICK YOUR WINS ===================== */
(function(){
  const KEY='bbn.picks.v1';
  let P=lsGet(KEY,{}); // gameId -> {t:team, at:ms}
  const weeks=[...new Set(SEA.map(g=>g.wk))].sort((a,b)=>a-b);
  let wk=(()=>{const f=SEA.find(g=>g.hs==null);return f?f.wk:weeks[weeks.length-1]})();
  const now=()=>Date.now();
  const locked=g=>g.hs!=null||now()>=etKick(g.d,g.t);
  const fav=g=>g.sp==null||g.sp===0?null:(g.sp>0?g.h:g.a);
  function grade(g){const p=P[g.id];if(!p||g.hs==null)return null;if(g.hs===g.as)return 't';const w=g.hs>g.as?g.h:g.a;return p.t===w?'w':'l'}
  function save(){lsSet(KEY,P)}
  $('pkeyebrow').textContent=`2026 NFL season · ${SEA.length} games · weeks ${weeks[0]}–${weeks[weeks.length-1]} · ${SEAPLAYED.length} final`;
  function weekStats(w){const gs=SEA.filter(g=>g.wk===w);let r=0,x=0,p=0,n=0;gs.forEach(g=>{if(P[g.id]){n++;const gr=grade(g);if(gr==='w')r++;else if(gr==='l')x++;else if(!gr)p++}});return {n,r,x,p,tot:gs.length}}
  function drawWeeks(){
    $('pkweeks').innerHTML=weeks.map(w=>{const s=weekStats(w);return `<button class="wkb" type="button" data-w="${w}" aria-pressed="${w===wk}">${w}<s>${s.n?`${s.r}-${s.x}`:'·'}</s></button>`}).join('');
    $('pkwkcount').textContent=`Week ${wk} of ${weeks.length}`;
  }
  const MORE={};
  function drawTickets(){
    const gs=SEA.filter(g=>g.wk===wk).sort((a,b)=>etKick(a.d,a.t)-etKick(b.d,b.t));
    $('pktickets').innerHTML=gs.map(g=>{
      const lk=locked(g),p=P[g.id],gr=grade(g),f=fav(g);
      const win=g.hs==null?null:g.hs===g.as?null:(g.hs>g.as?g.h:g.a);
      const side=(t,home)=>{const picked=p&&p.t===t;return `<button class="tk-side${picked?' pk':''}${picked&&gr==='w'?' ok':''}${picked&&gr==='l'?' bad':''}${win===t?' win':''}" type="button" data-g="${g.id}" data-t="${t}" ${lk?'disabled':''} aria-pressed="${!!picked}">
        ${tlogo(t,46)}<span class="tn">${tname(t)}</span><span class="rc">${trec(t)}${TSTK[t]?' · '+tstreak(t):''} · ${home?'home':'away'}${f===t?' · favorite':''}</span>${mfact(t)}${g.hs!=null?`<b class="finalline">${home?g.hs:g.as}</b>`:''}</button>`};
      const mid=g.hs!=null?`<b>FINAL</b><span>${fmtDay(g.d)}</span>`:lk?`<span class="lock">LOCKED</span><span>${fmtDay(g.d)}</span><span>${g.t}</span>`:`<b>${g.t}</b><span>${fmtDay(g.d)}</span><span>ET</span>${g.sp!=null?`<span>${g.sp>0?g.h:g.sp<0?g.a:'Pick'} ${g.sp===0?'em':'-'+Math.abs(g.sp)}</span>`:''}`;
      let nl='';if(NUMON&&window.__numbersLean){try{const n=window.__numbersLean(g.id);if(n)nl=`<div class="nlean">Numbers lean: ${n.pick?`<b>${n.pick}</b> (${n.a}–${n.b})`:`no lean (${n.a}–${n.b})`}</div>`}catch(e){}}
      return `<div class="ticketw"><div class="ticket">${side(g.a,false)}<div class="tk-mid">${mid}<button type="button" class="mvbtn" data-more="${g.id}" aria-expanded="${!!MORE[g.id]}">${MORE[g.id]?'Hide':'View more'}</button></div>${side(g.h,true)}</div>${nl}${MORE[g.id]?`<div class="mvpanel">${moreStats(g)}</div>`:''}</div>`}).join('');
  }
  function drawSummary(){
    let r=0,x=0,t=0,pend=0,n=0,fr=0,fx=0,hr=0,hx=0;const seq=[];
    SEA.slice().sort((a,b)=>etKick(a.d,a.t)-etKick(b.d,b.t)).forEach(g=>{const p=P[g.id];if(!p)return;n++;const gr=grade(g);if(!gr){pend++;return}
      if(gr==='t'){t++;return}
      if(gr==='w')r++;else x++;seq.push(gr);
      const f=fav(g);if(f){if(p.t===f)fr++;else fx++}; // you went with the favorite
      });
    // baselines on the same graded games you picked
    let bf=0,bn=0,bh=0,bhn=0;SEA.forEach(g=>{const p=P[g.id];if(!p||g.hs==null||g.hs===g.as)return;const w=g.hs>g.as?g.h:g.a,f=fav(g);if(f){bn++;if(f===w)bf++}bhn++;if(w===g.h)bh++});
    let st=0,stt='';for(let i=seq.length-1;i>=0;i--){if(!stt)stt=seq[i];if(seq[i]===stt)st++;else break}
    const pct=(a,b)=>b?Math.round(a/b*100)+'%':'–';
    $('pkstats').innerHTML=[
      [`${r}–${x}${t?'–'+t:''}`,'Your record'],[pct(r,r+x),'Right'],[st?`${st}${stt==='w'?'W':'L'}`:'–','Streak'],[n,'Picks made'],[pend,'Waiting on a final'],
      [bn?`${bf}–${bn-bf}`:'–','Always favorite, same games'],[bhn?`${bh}–${bhn-bh}`:'–','Always home team, same games']
    ].map(([a,b])=>`<div class="pkstat"><b>${a}</b><span>${b}</span></div>`).join('');
    $('pksumcount').textContent=`${n} pick${n===1?'':'s'} saved`;
    $('pkhist').innerHTML=weeks.map(w=>{const s=weekStats(w);if(!s.n)return '';return `<tr><td>Week ${w}</td><td>${s.n} of ${s.tot}</td><td class="w">${s.r}</td><td>${s.x}</td><td>${s.p}</td><td>${s.r+s.x?Math.round(s.r/(s.r+s.x)*100)+'%':'–'}</td></tr>`}).join('')||'<tr><td colspan="6" class="st">No picks yet. Choose a team on any ticket above.</td></tr>';
  }
  let draw=function(){drawWeeks();drawTickets();drawSummary()};
  $('pkweeks').addEventListener('click',e=>{const b=e.target.closest('.wkb');if(!b)return;wk=+b.dataset.w;draw()});
  $('pktickets').addEventListener('click',e=>{const m=e.target.closest('[data-more]');if(m){MORE[m.dataset.more]=!MORE[m.dataset.more];const y=window.scrollY;drawTickets();try{window.scrollTo(0,y)}catch(er){}return}const b=e.target.closest('.tk-side');if(!b||b.disabled)return;const g=SEA.find(x=>x.id===b.dataset.g);if(!g||locked(g))return;
    if(P[g.id]&&P[g.id].t===b.dataset.t)delete P[g.id];else P[g.id]={t:b.dataset.t,at:Date.now()};save();draw()});
  $('pkexp').addEventListener('click',()=>{try{$('pkcode').value=btoa(unescape(encodeURIComponent(JSON.stringify(P))));$('pkmsg').textContent='Copy this code and keep it somewhere safe.'}catch(e){$('pkmsg').textContent='Could not make a code.'}});
  $('pkimp').addEventListener('click',()=>{try{const o=JSON.parse(decodeURIComponent(escape(atob($('pkcode').value.trim()))));if(!o||typeof o!=='object')throw 0;Object.keys(o).forEach(k=>{if(o[k]&&TI[o[k].t])P[k]=o[k]});save();draw();$('pkmsg').textContent='Picks loaded.'}catch(e){$('pkmsg').textContent='That code could not be read.'}});
  let armed=false;$('pkclr').addEventListener('click',()=>{if(!armed){armed=true;$('pkclr').textContent='Press again to erase all picks';setTimeout(()=>{armed=false;$('pkclr').textContent='Clear all picks'},4000);return}P={};save();armed=false;$('pkclr').textContent='Clear all picks';draw()});

  /* ---- numbers toggle (opt-in) ---- */
  let NUMON=false;try{NUMON=localStorage.getItem('bbn.pknum')==='1'}catch(e){}
  $('pknum').checked=NUMON;
  $('pknum').addEventListener('change',()=>{NUMON=$('pknum').checked;try{localStorage.setItem('bbn.pknum',NUMON?'1':'0')}catch(e){}drawTickets()});
  /* ---- friends board ---- */
  const FK='bbn.friends';let F=lsGet(FK,{}),ME='';try{ME=localStorage.getItem('bbn.myname')||''}catch(e){}
  $('pkname').value=ME;
  const enc=o=>btoa(unescape(encodeURIComponent(JSON.stringify(o)))),dec=s=>JSON.parse(decodeURIComponent(escape(atob(s.trim()))));
  const gradeT=(g,team)=>{if(g.hs==null||!team)return null;if(g.hs===g.as)return 't';return team===(g.hs>g.as?g.h:g.a)?'w':'l'};
  function people(){
    const mine={};Object.keys(P).forEach(k=>mine[k]=P[k].t);
    const L=[{n:(ME||'You'),p:mine,me:1}];Object.keys(F).forEach(k=>L.push({n:k,p:F[k]}));
    L.forEach(x=>{x.r=0;x.x=0;x.k=0;SEA.forEach(g=>{const tm=x.p[g.id];if(!tm)return;x.k++;const gr=gradeT(g,tm);if(gr==='w')x.r++;else if(gr==='l')x.x++})});
    return L.sort((a,b)=>(b.r-a.r)||(a.x-b.x)||a.n.localeCompare(b.n));
  }
  function drawFriends(){
    const L=people();$('pkfcount').textContent=`${L.length} player${L.length===1?'':'s'}`;
    $('pkfboard').innerHTML=L.map((x,i)=>`<tr><td>${i+1}</td><td><b>${esc(x.n)}</b>${x.me?' (you)':''}</td><td class="w">${x.r}</td><td>${x.x}</td><td>${x.r+x.x?Math.round(x.r/(x.r+x.x)*100)+'%':'–'}</td><td>${x.k}</td><td>${x.me?'':`<button class="btn" type="button" data-rm="${esc(x.n)}">Remove</button>`}</td></tr>`).join('');
    const gs=SEA.filter(g=>g.wk===wk).sort((a,b)=>etKick(a.d,a.t)-etKick(b.d,b.t));
    $('pkfmat').innerHTML=`<thead><tr><th>Week ${wk}</th>${L.map(x=>`<th>${esc(x.n)}</th>`).join('')}</tr></thead><tbody>${gs.map(g=>`<tr><td>${g.a} @ ${g.h}${g.hs!=null?` <span class="st">${g.as}–${g.hs}</span>`:''}</td>${L.map(x=>{const tm=x.p[g.id],gr=gradeT(g,tm);const hide=!x.me&&tm&&!locked(g);return `<td class="mono${gr==='w'?' w':''}">${!tm?'·':hide?'picked':tm+(gr==='w'?' ✓':gr==='l'?' ✗':'')}</td>`}).join('')}</tr>`).join('')}</tbody>`;
  }
  $('pkname').addEventListener('input',()=>{ME=$('pkname').value.trim();try{localStorage.setItem('bbn.myname',ME)}catch(e){}drawFriends()});
  $('pkshare').addEventListener('click',()=>{if(!ME){$('pkfmsg').textContent='Type your name first.';return}const p={};Object.keys(P).forEach(k=>p[k]=P[k].t);const c=enc({n:ME,p});$('pkmycode').hidden=false;$('pkmycode').value=c;$('pkmycode').select();
    try{navigator.clipboard.writeText(c).then(()=>{$('pkfmsg').textContent='Code copied. Send it to your friends.'},()=>{$('pkfmsg').textContent='Copy the code above and send it to your friends.'})}catch(e){$('pkfmsg').textContent='Copy the code above and send it to your friends.'}});
  $('pkfadd').addEventListener('click',()=>{try{const o=dec($('pkfcode').value);if(!o||!o.n||typeof o.p!=='object')throw 0;const p={};Object.keys(o.p).forEach(k=>{if(TI[o.p[k]])p[k]=o.p[k]});F[String(o.n).slice(0,20)]=p;lsSet(FK,F);$('pkfcode').value='';$('pkfmsg').textContent=`Added ${String(o.n).slice(0,20)}.`;drawFriends()}catch(e){$('pkfmsg').textContent='That code did not work. Ask your friend to make a new one.'}});
  $('pkfboard').addEventListener('click',e=>{const b=e.target.closest('[data-rm]');if(!b)return;delete F[b.dataset.rm];lsSet(FK,F);drawFriends()});
  const _draw=draw;draw=function(){_draw();drawFriends()};
  window.__pkDraw=draw;draw();setInterval(()=>{if(!$('picks').hidden)drawTickets()},60000);
})();

/* ===================== PLAYER STATS ===================== */
const PSL={cmp:'Completions',att:'Pass att',pyd:'Pass yds',ptd:'Pass TD',int:'INT thrown',sck:'Sacked',pfd:'Pass 1st downs',pepa:'Pass EPA',p2:'2-pt pass',car:'Carries',ryd:'Rush yds',rtd:'Rush TD',rfd:'Rush 1st downs',repa:'Rush EPA',rfl:'Rush fum lost',tgt:'Targets',rec:'Receptions',yds:'Rec yds',td:'Rec TD',yac:'Yds after catch',ayd:'Air yards',rcfd:'Rec 1st downs',rcepa:'Rec EPA',rcfl:'Rec fum lost',sfl:'Sack fum lost',stt:'ST TD',tks:'Solo tackles',tka:'Assisted tkl',tfl:'Tackles for loss',qbh:'QB hits',dsk:'Sacks',dint:'Interceptions',pd:'Passes defended',ff:'Forced fumbles',dtd:'Defensive TD',dsf:'Safeties',fr:'Fumble recov',pen:'Penalties',peny:'Penalty yds',prt:'Punt returns',pry:'Punt ret yds',krt:'Kick returns',kry:'Kick ret yds',fgm:'FG made',fga:'FG att',fg40:'FG 40–49',fg50:'FG 50–59',fg60:'FG 60+',fgl:'Long FG',xpm:'XP made',xpa:'XP att',pnt:'Punts',pnty:'Punt yds',pni:'Punts in 20',pnl:'Long punt'};
const PSG=[['Passing',['cmp','att','pyd','ptd','int','sck','pfd','pepa','p2']],['Rushing',['car','ryd','rtd','rfd','repa','rfl']],['Receiving',['tgt','rec','yds','td','yac','ayd','rcfd','rcepa','rcfl']],['Defense',['tks','tka','tfl','qbh','dsk','dint','pd','ff','dtd','dsf','fr']],['Kicking',['fgm','fga','fg40','fg50','fg60','fgl','xpm','xpa']],['Punting',['pnt','pnty','pni','pnl']],['Returns',['prt','pry','krt','kry','stt']],['Other',['sfl','pen','peny']]];
const PGRP=pos=>({QB:'QB',RB:'RB',FB:'RB',HB:'RB',WR:'WR',TE:'TE',T:'OL',G:'OL',C:'OL',OT:'OL',OG:'OL',OL:'OL',DE:'DL',DT:'DL',NT:'DL',DL:'DL',LB:'LB',ILB:'LB',OLB:'LB',MLB:'LB',CB:'DB',S:'DB',FS:'DB',SS:'DB',DB:'DB',K:'K',P:'P',LS:'LS'})[pos]||pos||'–';
const kickPts=(row)=>{const g=k=>row[KI[k]]||0;return 3*(g('fgm')-g('fg40')-g('fg50')-g('fg60'))+4*g('fg40')+5*(g('fg50')+g('fg60'))+g('xpm')-(g('fga')-g('fgm'))};
(function(){
  const sel=(id,opts)=>$(id).innerHTML=opts.map(([v,l])=>`<option value="${v}">${l}</option>`).join('');
  sel('psteam',[['','All teams'],...Object.keys(TI).sort().map(t=>[t,tname(t)])]);
  sel('pspos',[['','All positions'],['QB','Quarterbacks'],['RB','Running backs'],['WR','Wide receivers'],['TE','Tight ends'],['OL','Offensive line'],['DL','Defensive line'],['LB','Linebackers'],['DB','Defensive backs'],['K','Kickers'],['P','Punters'],['LS','Long snappers']]);
  const SORTS=[['rank','Rank at position'],['gp','Games played'],['pyd','Passing yards'],['ptd','Passing TD'],['ryd','Rushing yards'],['rtd','Rushing TD'],['rec','Receptions'],['yds','Receiving yards'],['td','Receiving TD'],['tgt','Targets'],['dsk','Sacks'],['dint','Interceptions'],['tkl','Total tackles'],['tfl','Tackles for loss'],['pd','Passes defended'],['fgm','Field goals made'],['name','Name']];
  sel('pssort',SORTS);
  let shown=48,open=null;
  const T=r=>r[8],g=(r,k)=>r[8][KI[k]]||0;
  const val=(r,k)=>k==='gp'?r[5]:k==='tkl'?g(r,'tks')+g(r,'tka'):g(r,k);
  const f1=x=>Number.isInteger(x)?x:(Math.round(x*10)/10);
  function line(r){const grp=PGRP(r[2]);const c=k=>f1(g(r,k));const t=(a,b)=>[a,b];
    if(grp==='QB')return [[`${c('cmp')}/${c('att')}`,'C/A'],[c('pyd'),'Yds'],[c('ptd'),'TD'],[c('int'),'INT']];
    if(grp==='RB')return [[c('car'),'Car'],[c('ryd'),'Yds'],[c('rtd'),'TD'],[c('rec'),'Rec']];
    if(grp==='WR'||grp==='TE')return [[c('rec'),'Rec'],[c('tgt'),'Tgt'],[c('yds'),'Yds'],[c('td'),'TD']];
    if(grp==='DL'||grp==='LB'||grp==='DB')return [[g(r,'tks')+g(r,'tka'),'Tkl'],[c('dsk'),'Sack'],[c('dint'),'INT'],[c('pd'),'PD']];
    if(grp==='K')return [[`${c('fgm')}/${c('fga')}`,'FG'],[c('fgl')||'–','Long'],[`${c('xpm')}/${c('xpa')}`,'XP'],[c('fg40')+c('fg50')+c('fg60'),'FG 40+']];
    if(grp==='P')return [[c('pnt'),'Punts'],[c('pnt')?Math.round(c('pnty')/c('pnt')*10)/10:'–','Avg'],[c('pni'),'In 20'],[c('pnl')||'–','Long']];
    return [[r[5],'GP'],[c('pen'),'Pen'],[c('tks'),'Tkl'],['–','']];}
  function rows(){
    const S=PS[$('psseason').value],tm=$('psteam').value,po=$('pspos').value,q=$('psq').value.trim().toLowerCase(),only=$('psgp').value,sk=$('pssort').value;
    let a=S.filter(r=>(!tm||r[3]===tm)&&(!po||PGRP(r[2])===po)&&(!q||r[1].toLowerCase().includes(q))&&(!only||r[5]>0));
    a=a.slice().sort((x,y)=>sk==='name'?x[1].localeCompare(y[1]):sk==='rank'?((rankOf(x)?rankOf(x).pos:1e9)-(rankOf(y)?rankOf(y).pos:1e9))||(keyVal(y)-keyVal(x))||x[1].localeCompare(y[1]):(val(y,sk)-val(x,sk))||(keyVal(y)-keyVal(x)));
    return a;
  }
  function initials(n){const p=n.split(/\s+/).filter(Boolean);return ((p[0]||'')[0]||'')+((p[p.length-1]||'')[0]||'')}
  let cmp=[];
  function item(r){const i=TI[r[3]]||{c1:'#555',c2:'#222'},ln=line(r),id=r[0];
    return `<div class="pl-item${open===id?' open':''}" style="--c1:${i.c1};--c2:${i.c2}"><button class="pl-row" type="button" data-id="${id}" aria-expanded="${open===id}"><span class="pl-rank" title="Rank among players at the same position, by the position's key stat">${(()=>{const k=rankOf(r);return k?`<b>#${k.pos}</b><i>${k.grp} of ${k.posN}</i><em>${esc(k.short)}</em>`:`<b>–</b><i>${KEY[PGRP(r[2])]?'no games':'not ranked'}</i>`})()}</span><span class="pl-badge"><span class="ini">${esc(initials(r[1]))}</span></span><span class="pl-who"><span class="pn">${esc(r[1])}</span><span class="pm">${tlogo(r[3],16)} ${r[3]||'FA'} · ${esc(r[2]||'–')}${r[4]?' · #'+esc(r[4]):''} · ${r[5]} GP${injchip(r[0])}</span></span>${ln.map(([v,l])=>`<span class="pl-st"><b>${v}</b>${l}</span>`).join('')}<span class="pl-chev" aria-hidden="true">›</span></button><label class="pl-cmp"><input type="checkbox" data-cmp="${id}"${cmp.includes(id)?' checked':''}> Compare</label>${open===id?detail(id):''}</div>`}
  const LOWER=new Set(['int','sck','rfl','rcfl','sfl','pen','peny']);
  function compareHtml(){
    if(!cmp.length)return '';const S=PS[$('psseason').value],P=cmp.map(id=>S.find(x=>x[0]===id));
    if(cmp.length<2||!P[0]||!P[1])return `<div class="card"><div class="teamhead"><h2>Compare</h2><button class="btn" type="button" id="pscmpclr">Clear</button></div><p class="note">${P[0]?esc(P[0][1])+' is selected. ':''}Tick Compare on one more player to see them side by side.</p></div>`;
    const [a,b]=P,ga=(r,k)=>r[8][KI[k]]||0,rows=[['Games played',a[5],b[5],0]];
    PSG.forEach(([n,ks])=>ks.forEach(k=>{if(ga(a,k)||ga(b,k))rows.push([PSL[k],f1(ga(a,k)),f1(ga(b,k)),LOWER.has(k)?1:0])}));
    const cell=(x,y,low)=>`<td class="mono${(low?x<y:x>y)?' w':''}">${x}</td>`;
    const hd=r=>{const i=TI[r[3]]||{c1:'#555',c2:'#222'};return `<th style="--c1:${i.c1};--c2:${i.c2}" class="cmph">${esc(r[1])}<br><span class="st">${r[3]||'FA'} · ${esc(r[2]||'–')}</span></th>`};
    return `<div class="card"><div class="teamhead"><h2>Compare · ${$('psseason').value}</h2><button class="btn" type="button" id="pscmpclr">Clear</button></div><div class="tablebox"><table class="cmpt"><thead><tr><th></th>${hd(a)}${hd(b)}</tr></thead><tbody>${rows.map(([l,x,y,low])=>`<tr><td>${l}</td>${cell(x,y,low)}${cell(y,x,low)}</tr>`).join('')}</tbody></table></div><p class="note">The better figure in each row is in bold green. For interceptions thrown, sacks taken, fumbles lost and penalties, lower is better.</p></div>`}
  function draw(){
    const a=rows();$('pscount').textContent=`${a.length.toLocaleString()} player${a.length===1?'':'s'}`;
    $('pscards').innerHTML=a.slice(0,shown).map(item).join('')||'<p class="note">No players match these filters.</p>';
    $('psmore').hidden=a.length<=shown;
    $('psdetail').innerHTML=compareHtml();
  }
  const RMAP={};
  const KEY={QB:['pyd','Passing yards','pass yds'],RB:['ryd','Rushing yards','rush yds'],WR:['yds','Receiving yards','rec yds'],TE:['yds','Receiving yards','rec yds'],K:['fgm','Field goals made','FG made'],P:['pnt','Punts','punts'],DL:['dsk','Sacks','sacks'],LB:['tkl','Tackles','tackles'],DB:['tkl','Tackles','tackles']};
  const keyVal=r=>{const k=KEY[PGRP(r[2])];return k?val(r,k[0]):0};
  function rmap(s){if(RMAP[s])return RMAP[s];const m=new Map(),by={};
    PS[s].filter(x=>x[5]>0&&KEY[PGRP(x[2])]).forEach(x=>(by[PGRP(x[2])]=by[PGRP(x[2])]||[]).push(x));
    Object.keys(by).forEach(p=>{const L=by[p].slice().sort((a,b)=>keyVal(b)-keyVal(a)),N=L.length;
      L.forEach(x=>{m.set(x[0],{pos:L.findIndex(y=>keyVal(y)<=keyVal(x))+1,posN:N,grp:p,label:KEY[p][1],short:KEY[p][2],v:keyVal(x)})});
      const G=L.filter(x=>x[5]>=3).sort((a,b)=>keyVal(b)/b[5]-keyVal(a)/a[5]);G.forEach(x=>{const o=m.get(x[0]);o.pg=G.findIndex(y=>keyVal(y)/y[5]<=keyVal(x)/x[5])+1;o.pgN=G.length})});
    return RMAP[s]=m}
  const rankOf=r=>rmap($('psseason').value).get(r[0]);
  const RCACHE={};
  function prank(r,k){const s=$('psseason').value,key=s+'|'+r[2]+'|'+k;
    if(!RCACHE[key]){const lo=LOWER.has(k);RCACHE[key]={lo,v:PS[s].filter(x=>x[2]===r[2]&&x[5]>0&&(x[8][KI[k]]||0)!==0).map(x=>x[8][KI[k]]||0).sort((a,b)=>lo?a-b:b-a)}}
    const c=RCACHE[key],v=r[8][KI[k]]||0,i=c.v.findIndex(x=>c.lo?x>=v:x<=v);return `#${(i<0?c.v.length:i)+1} of ${c.v.length} ${r[2]}`}
  function detail(id){
    const S=PS[$('psseason').value],r=S.find(x=>x[0]===id);if(!r)return '';
    const i=TI[r[3]]||{c1:'#555',c2:'#222'};
    const grps=PSG.map(([n,ks])=>{const items=ks.filter(k=>g(r,k)).map(k=>`<div><span>${PSL[k]}</span><b>${f1(g(r,k))}</b><em class="rk">${prank(r,k)}</em></div>`);return items.length?`<div class="sgrp"><h4>${n}</h4><div class="sgrid">${items.join('')}</div></div>`:''}).join('')||'<p class="note">No recorded stats this season.</p>';
    const wks=Object.keys(r[9]).map(Number).sort((a,b)=>a-b);
    const CORE={QB:['cmp','att','pyd','ptd','int','sck','car','ryd','rtd'],RB:['car','ryd','rtd','tgt','rec','yds','td'],WR:['tgt','rec','yds','td','car','ryd','rtd'],TE:['tgt','rec','yds','td'],K:['fgm','fga','fg40','fg50','fg60','xpm','xpa'],P:['pnt','pnty','pni'],DL:['tks','tka','tfl','dsk','qbh','pd','ff','fr','dtd'],LB:['tks','tka','tfl','dsk','qbh','pd','dint','ff','fr','dtd'],DB:['tks','tka','tfl','pd','dint','ff','fr','dtd','dsk'],OL:['pen','peny'],LS:['pen','peny']};
    const FAM={QB:['Passing','Rushing'],RB:['Rushing','Receiving'],WR:['Receiving','Rushing'],TE:['Receiving','Rushing'],K:['Kicking'],P:['Punting'],DL:['Defense'],LB:['Defense'],DB:['Defense'],OL:[],LS:[]}[PGRP(r[2])]||[];
    const base=CORE[PGRP(r[2])]||[],any=k=>wks.some(w=>r[9][w][3][KI[k]]);
    const fam=PSG.filter(([n])=>FAM.includes(n)).flatMap(([,ks])=>ks),core=fam.length?fam.filter(k=>base.includes(k)||any(k)):base;
    const odd=PSG.flatMap(([,ks])=>ks).filter(k=>!core.includes(k)&&any(k)),cols=[...core.filter(k=>base.includes(k)?(any(k)||['QB','RB','WR','TE','K'].includes(PGRP(r[2]))):true),...odd];
    const log=wks.length?`<div class="sgrp"><h4>Game log</h4><div class="tablebox"><table><thead><tr><th>Wk</th><th>Opp</th>${cols.map(k=>`<th${odd.includes(k)?' class="oddc"':''}>${PSL[k]}</th>`).join('')}</tr></thead><tbody>${wks.map(w=>{const x=r[9][w];return `<tr><td>${w}</td><td class="mono">${x[0]}</td>${cols.map(k=>`<td class="mono${odd.includes(k)?' oddc':''}">${f1(x[3][KI[k]]||0)||'·'}</td>`).join('')}</tr>`}).join('')}</tbody></table></div>${odd.length?'<p class="note">Shaded columns are stats outside this player\'s usual role, shown only because they happened.</p>':''}</div>`:'';
    const kk=rankOf(r),rstrip=kk?`<div class="rkstrip"><div class="big"><b>#${kk.pos}</b><span>${esc(kk.grp)} rank by ${esc(kk.label.toLowerCase())}<small>${f1(kk.v)} · of ${kk.posN} ${esc(kk.grp)}s with games played</small></span></div><div class="big"><b>${kk.pg?'#'+kk.pg:'–'}</b><span>${esc(kk.grp)} rank, ${esc(kk.label.toLowerCase())} per game<small>${kk.pg?'of '+kk.pgN+' with 3+ games':'needs 3 games'}</small></span></div></div>`:`<p class="note">${KEY[PGRP(r[2])]?'Not ranked: no games played this season.':'This position has no counting stat to rank by.'}</p>`;
    const pv=PVT[id],pvh=pv?`<div class="sgrp"><h4>Team record against each opponent, 1999 on</h4><p class="note">Wins and losses of this player's team in the games he appeared in. Nothing else.</p><div class="tablebox"><table><thead><tr><th>Opponent</th><th>Record</th><th>Win %</th></tr></thead><tbody>${Object.keys(pv).sort((a,b)=>(pv[b][0]+pv[b][1]+pv[b][2])-(pv[a][0]+pv[a][1]+pv[a][2])).map(o=>{const v=pv[o],n=v[0]+v[1]+v[2];return `<tr><td>${tlogo(o,18)} ${o}</td><td class="mono">${v[0]}–${v[1]}${v[2]?'–'+v[2]:''}</td><td class="mono">${Math.round((v[0]+v[2]/2)/n*100)}%</td></tr>`}).join('')}</tbody></table></div></div>`:'';
    const oth=PS[$('psseason').value==='2026'?'2025':'2026'].find(x=>x[0]===id),os=$('psseason').value==='2026'?'2025':'2026';
    const vs=oth?`<div class="sgrp"><h4>${$('psseason').value} against ${os}</h4><div class="tablebox"><table><thead><tr><th></th><th>${$('psseason').value}</th><th>${os}</th></tr></thead><tbody>${[['Games played',r[5],oth[5]]].map(x=>`<tr><td>${x[0]}</td><td class="mono">${x[1]}</td><td class="mono">${x[2]}</td></tr>`).join('')}${line(r).map((x,ix)=>`<tr><td>${x[1]}</td><td class="mono">${x[0]}</td><td class="mono">${line(oth)[ix][0]}</td></tr>`).join('')}</tbody></table></div></div>`:`<p class="note">No ${os} stats on file for this player.</p>`;
    return `<div class="pdetail" style="--c1:${i.c1};--c2:${i.c2}"><div class="ph"><div><h2>${esc(r[1])}</h2><div class="pm" style="color:#fff;font-family:var(--mono);font-size:12px">${tname(r[3])} · ${esc(r[2]||'–')}${r[4]?' · #'+esc(r[4]):''} · ${$('psseason').value} season · ${r[5]} games</div></div><button class="btn solid" type="button" id="psclose">Close</button></div><div class="body">${window.__recs?window.__recs(r[0],r[1]):''}${(()=>{const x=INJS(r[0]),b=BYE[r[3]];if(!x&&!b)return '';return `<p class="availnote">${x?`<b>Injury report, week ${INJ.wk}:</b> ${esc(x.s)}${x.i?' - '+esc(x.i):''}. `:''}${b?`Team bye: week ${b}${b<=LASTWK?' (already played)':''}.`:''}</p>`})()}${rstrip}${grps}${vs}${pvh}${log}</div></div>`;
  }
  ['psseason','psteam','pspos','pssort','psq','psgp'].forEach(id=>$(id).addEventListener('input',()=>{shown=48;open=null;draw()}));
  $('psmore').addEventListener('click',()=>{shown+=96;draw()});
  $('pscards').addEventListener('click',e=>{
    const cb=e.target.closest('[data-cmp]');
    if(cb){const id=cb.dataset.cmp;cmp=cmp.includes(id)?cmp.filter(x=>x!==id):[...cmp.slice(-1),id];draw();return}
    if(e.target.closest('#psclose')){open=null;draw();return}
    const row=e.target.closest('.pl-row');if(!row)return;
    open=open===row.dataset.id?null:row.dataset.id;draw();
    const el=document.querySelector('.pl-item.open');if(el)try{el.scrollIntoView({behavior:'smooth',block:'nearest'})}catch(er){}});
  $('psdetail').addEventListener('click',e=>{if(e.target.closest('#pscmpclr')){cmp=[];draw()}});
  $('psyeyebrow').textContent=`2026 through week ${LASTWK} · 2025 full season · ${PS['2026'].length.toLocaleString()} players on 2026 rosters`;
  draw();
})();


  /* ---- head coaches ---- */
  (function(){
    const C=COACHES.map(c=>({n:c[0],t:c[1],w:c[2],l:c[3],ti:c[4],p:c[5],w6:c[6],l6:c[7],t6:c[8]}));
    const p6=c=>{const g=c.w6+c.l6+c.t6;return g?(c.w6+c.t6/2)/g:-1};
    const rk=(f)=>{const s=C.slice().sort((a,b)=>f(b)-f(a));const m={};C.forEach(c=>{m[c.n]=s.findIndex(x=>f(x)===f(c))+1});return m};
    const rw=rk(c=>c.w),rp=rk(c=>c.p),r6=rk(p6);
    const rec=(w,l,t)=>`${w}–${l}${t?'–'+t:''}`;
    $('pscoachtb').innerHTML=C.slice().sort((a,b)=>rp[a.n]-rp[b.n]).map(c=>`<tr><td><b>${esc(c.n)}</b></td><td>${tlogo(c.t,18)} ${c.t}</td><td class="mono">${rec(c.w,c.l,c.ti)}</td><td class="mono">#${rw[c.n]}</td><td class="mono">${(c.p*100).toFixed(1)}%</td><td class="mono">#${rp[c.n]}</td><td class="mono">${rec(c.w6,c.l6,c.t6)}</td><td class="mono">#${r6[c.n]}</td></tr>`).join('');
  })();

/* ===================== NFL RANKINGS ===================== */
(function(){
  // [key,label,group,lowerIsBetter,fmt]
  const pc=v=>v.toFixed(3).replace(/^0/,'');
  const CATS=[
   ['wp','Winning %','Standings',0,pc],['diff','Point differential','Standings',0,v=>(v>0?'+':'')+v],['sos','Strength of schedule (opponents’ win %)','Standings',0,pc],
   ['ppg','Points per game','Offense',0,v=>v],['ypg','Total yards per game','Offense',0,v=>v],['pypg','Passing yards per game','Offense',0,v=>v],['rypg','Rushing yards per game','Offense',0,v=>v],['fdpg','First downs per game','Offense',0,v=>v],['epaO','EPA per play','Offense',0,v=>(v>0?'+':'')+v.toFixed(2)],['t3p','Third-down conversion %','Offense',0,v=>v+'%'],['rzp','Red-zone touchdown %','Offense',0,v=>v+'%'],['sckA','Sacks allowed','Offense',1,v=>v],['gv','Giveaways','Offense',1,v=>v],
   ['papg','Points allowed per game','Defense',1,v=>v],['ypga','Yards allowed per game','Defense',1,v=>v],['pypga','Pass yards allowed per game','Defense',1,v=>v],['rypga','Rush yards allowed per game','Defense',1,v=>v],['fdpga','First downs allowed per game','Defense',1,v=>v],['epaD','EPA allowed per play','Defense',1,v=>(v>0?'+':'')+v.toFixed(2)],['t3pA','Third-down % allowed','Defense',1,v=>v+'%'],['rzpA','Red-zone TD % allowed','Defense',1,v=>v+'%'],['sck','Sacks','Defense',0,v=>v],['int','Interceptions','Defense',0,v=>v],['tk','Takeaways','Defense',0,v=>v],
   ['tov','Turnover margin','Ball security',0,v=>(v>0?'+':'')+v],['pen','Penalties','Ball security',1,v=>v],['peny','Penalty yards','Ball security',1,v=>v]];
  const NOTE={sos:'Rank 1 is the toughest schedule so far: the highest average win % among the opponents played.',epaO:'EPA is expected points added per play, from the play-by-play data.',epaD:'Lower is better: opponents gained fewer expected points per play.'};
  Object.values(RK).forEach(S=>Object.values(S).forEach(t=>{t.wp=t.g?(t.w+t.t/2)/t.g:0}));
  let cat='wp',season='2026',hl='',trendKey='wp';
  const cache={};
  const ranks=(s,key)=>{const ck=s+key;if(cache[ck])return cache[ck];const low=CATS.find(c=>c[0]===key)[3];const arr=Object.entries(RK[s]).map(([t,d])=>[t,d[key]]).sort((a,b)=>low?a[1]-b[1]:b[1]-a[1]);const rk={};let last=null,lr=0;arr.forEach(([t,v],i)=>{if(v!==last){lr=i+1;last=v}rk[t]=lr});return cache[ck]={arr,rk}};
  const other=()=>season==='2026'?'2025':'2026';
  function drawCats(){let g='';$('rkcats').innerHTML=CATS.map(c=>{const h=c[2]!==g?(g=c[2],`<div class="catgrp">${g}</div>`):'';return h+`<button class="catb" type="button" data-c="${c[0]}" aria-pressed="${c[0]===cat}">${c[1]}</button>`}).join('')}
  function drawBoard(){
    const c=CATS.find(x=>x[0]===cat),{arr,rk}=ranks(season,cat),ro=ranks(other(),cat).rk;
    const vals=arr.map(a=>a[1]),mx=Math.max(...vals.map(Math.abs),1e-9),mn=Math.min(...vals);
    const w=v=>{const lo=Math.min(0,mn);return Math.max(3,Math.round((v-lo)/(mx-lo||1)*100))};
    $('rkboard').innerHTML=`<div class="teamhead"><h2>${c[1]}</h2><span class="count">${cat==='sos'?'Higher is tougher':c[3]?'Lower is better':'Higher is better'} · ${season}${season==='2026'?' through week '+LASTWK:''}</span></div>${NOTE[cat]?`<p class="note">${NOTE[cat]}</p>`:''}`+
      `<div class="lbrow lbh" style="border-bottom:2px solid var(--line);font-family:var(--mono);font-size:10px;color:var(--muted);text-transform:uppercase"><span></span><span></span><span>Team</span><span></span><span style="text-align:right">${season}</span><span style="text-align:right;line-height:1.15">${season==='2026'?'Previous<br>rank':other()+'<br>rank'}</span></div>`+
      arr.map(([t,v])=>{const d=ro[t]-rk[t];return `<div class="lbrow${t===hl?' hl':''}" data-team="${t}"><span class="rk">${rk[t]}</span>${tlogo(t,26)}<span class="tnm">${tname(t)}</span><span class="rbar"><i style="width:${w(v)}%"></i></span><span class="val">${c[4](v)}</span><span class="mv ${d>0?'up':d<0?'dn':''}" title="Rank in ${other()}: ${ro[t]}">${other()} #${ro[t]}</span></div>`}).join('')}
  /* ---- one team across the whole league ---- */
  const TRENDS=[['wp','Winning %',0],['diff','Point differential',0],['ppg','Points per game',0],['papg','Points allowed per game',1]];
  function trendSeries(team,key){
    const gs=(season==='2026'?SEA.filter(g=>g.hs!=null):SEA25).map(g=>({wk:g.wk,h:g.h,a:g.a,hs:g.hs,as:g.as}));
    const weeks=[...new Set(gs.map(g=>g.wk))].sort((a,b)=>a-b),low=TRENDS.find(t=>t[0]===key)[2],out=[];
    weeks.forEach(w=>{const T={};Object.keys(TI).forEach(t=>T[t]={g:0,w:0,t:0,pf:0,pa:0});
      gs.filter(g=>g.wk<=w).forEach(g=>{[[g.h,g.hs,g.as],[g.a,g.as,g.hs]].forEach(([t,f,x])=>{const d=T[t];d.g++;d.pf+=f;d.pa+=x;if(f>x)d.w++;else if(f===x)d.t++})});
      const val=d=>key==='wp'?(d.w+d.t/2)/d.g:key==='diff'?d.pf-d.pa:key==='ppg'?d.pf/d.g:d.pa/d.g;
      const arr=Object.entries(T).filter(([t,d])=>d.g>0).map(([t,d])=>[t,val(d)]).sort((x,y)=>low?x[1]-y[1]:y[1]-x[1]);
      const i=arr.findIndex(x=>x[0]===team);if(i<0)return;let r=i+1;while(r>1&&arr[r-2][1]===arr[i][1])r--;out.push({w,r})});
    return out}
  function trendSvg(team){
    const pts=trendSeries(team,trendKey);if(pts.length<2)return '<p class="note">Not enough games yet for a trend.</p>';
    const W=640,H=210,L=34,R=14,T=14,B=26,xs=i=>L+(W-L-R)*(pts.length===1?0:i/(pts.length-1)),ys=r=>T+(H-T-B)*(r-1)/31;
    const grid=[1,8,16,24,32].map(r=>`<line x1="${L}" x2="${W-R}" y1="${ys(r)}" y2="${ys(r)}" stroke="var(--line)"/><text x="${L-6}" y="${ys(r)+4}" text-anchor="end" fill="var(--muted)" font-size="10">${r}</text>`).join('');
    const line=pts.map((p,i)=>`${i?'L':'M'}${xs(i).toFixed(1)} ${ys(p.r).toFixed(1)}`).join(' ');
    const dots=pts.map((p,i)=>`<circle cx="${xs(i).toFixed(1)}" cy="${ys(p.r).toFixed(1)}" r="3.5" fill="var(--accent)"><title>Week ${p.w}: #${p.r}</title></circle>`).join('');
    const xl=pts.map((p,i)=>(pts.length<=12||i%2===0)?`<text x="${xs(i).toFixed(1)}" y="${H-8}" text-anchor="middle" fill="var(--muted)" font-size="10">${p.w}</text>`:'').join('');
    const last=pts[pts.length-1];
    return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Rank by week" style="width:100%;height:auto;max-width:720px">${grid}<path d="${line}" fill="none" stroke="var(--accent)" stroke-width="2.2"/>${dots}${xl}<text x="${xs(pts.length-1)-6}" y="${ys(last.r)-9}" text-anchor="end" fill="var(--fg)" font-size="12" font-weight="600">#${last.r}</text></svg>`}
  function drawProfile(){
    const el=$('rkprofile');
    if(!hl){el.innerHTML='<div class="teamhead"><h2>Team profile</h2></div><p class="note">Choose a team above to see where it ranks among all 32 in every category, this season against last, and how its rank moved week by week.</p>';return}
    const d=RK[season][hl],rows=CATS.map(c=>({c,r:ranks(season,c[0]).rk[hl],r2:ranks(other(),c[0]).rk[hl],v:d[c[0]]}));
    const core=rows.filter(x=>x.c[0]!=='sos'),avg=core.reduce((a,x)=>a+x.r,0)/core.length,srt=core.slice().sort((a,b)=>a.r-b.r);
    const best=srt.slice(0,3),worst=srt.slice(-3).reverse(),groups=[...new Set(CATS.map(c=>c[2]))];
    const tile=x=>{const tier=x.c[0]==='sos'?'mid':x.r<=10?'good':x.r>=23?'bad':'mid',dl=x.r2-x.r;
      return `<button class="rtile ${tier}" type="button" data-c="${x.c[0]}" title="Open the full ${esc(x.c[1])} leaderboard"><span class="rl">${x.c[1]}</span><b class="rn">#${x.r}</b><span class="rv">${x.c[4](x.v)} · of 32</span><span class="rb"><i style="width:${(33-x.r)/32*100}%"></i></span><span class="rm">${other()} #${x.r2} ${dl>0?`<em class="up">▲${dl}</em>`:dl<0?`<em class="dn">▼${-dl}</em>`:'·'}</span></button>`};
    const rec=season==='2026'?`${d.w}–${d.l}${d.t?'–'+d.t:''} through week ${LASTWK}`:`${d.w}–${d.l}${d.t?'–'+d.t:''}, 2025 final`;
    el.innerHTML=`<div class="rkhead">${tlogo(hl,64)}<div><h2 style="font-size:26px">${tname(hl)}</h2><div class="note">${TI[hl].conf} · ${TI[hl].div.replace(/^(AFC|NFC) /,'')} · ${rec}</div><div class="note">Average rank across ${core.length} categories: <b>${avg.toFixed(1)}</b> of 32</div></div></div>
      <div class="rkbw"><div><span class="st">Best</span>${best.map(x=>`<b>${x.c[1]} #${x.r} <i>${x.c[4](x.v)}</i></b>`).join('')}</div><div><span class="st">Weakest</span>${worst.map(x=>`<b>${x.c[1]} #${x.r} <i>${x.c[4](x.v)}</i></b>`).join('')}</div></div>
      ${groups.map(g=>`<h4 class="rkg">${g}</h4><div class="rtiles">${rows.filter(x=>x.c[2]===g).map(tile).join('')}</div>`).join('')}
      <h4 class="rkg">Rank by week</h4><div class="filters"><label>Measure<select id="rktrend">${TRENDS.map(t=>`<option value="${t[0]}"${t[0]===trendKey?' selected':''}>${t[1]}</option>`).join('')}</select></label></div>${trendSvg(hl)}<p class="note">Where the team stood among all 32 after each week of ${season}, from game results (1 is best).</p>`}

  let stView='division',BK={},stSeason='2026';
  const stPct=(R,t)=>{const d=R[t],g=d.w+d.l+d.t;return g?(d.w+d.t/2)/g:0};
  const stCmp=R=>(a,b)=>stPct(R,b)-stPct(R,a)||(R[b].pf-R[b].pa)-(R[a].pf-R[a].pa)||(a<b?-1:1);
  function seedsOf(R,c){const cmp=stCmp(R),ts=Object.keys(R).filter(t=>TI[t].conf===c),divs=[...new Set(ts.map(t=>TI[t].div))];
    const win=divs.map(d=>ts.filter(t=>TI[t].div===d).sort(cmp)[0]).sort(cmp),wc=ts.filter(t=>!win.includes(t)).sort(cmp);return [...win,...wc.slice(0,3)]}
  function drawStand(){
    const el=$('rkstand');if(!el)return;const R=RK[stSeason],cmp=stCmp(R),rec=t=>`${R[t].w}–${R[t].l}${R[t].t?'–'+R[t].t:''}`;
    const sd={};['AFC','NFC'].forEach(c=>seedsOf(R,c).forEach((t,i)=>sd[t]=i+1));
    const tbl=(title,ts)=>`<h4 class="rkg">${title}</h4><div class="stwrap"><table class="sttbl"><thead><tr><th>Team</th><th>W–L–T</th><th>Pct</th><th>PF</th><th>PA</th><th>Diff</th><th>Strk</th></tr></thead><tbody>${ts.sort(cmp).map(t=>`<tr><td>${tlogo(t,18)} <b>${TI[t].nick}</b></td><td>${rec(t)}</td><td>${stPct(R,t).toFixed(3).replace(/^0/,'')}</td><td>${R[t].pf}</td><td>${R[t].pa}</td><td>${R[t].pf-R[t].pa>0?'+':''}${R[t].pf-R[t].pa}</td><td>${stSeason==='2026'&&TSTK[t]?tstreak(t):'–'}</td></tr>`).join('')}</tbody></table></div>`;
    const all=Object.keys(R);let body='';
    if(stView==='division'){const dv=[...new Set(all.map(t=>TI[t].div))].sort();body=`<div class="stgrid">${dv.map(d=>`<div>${tbl(d,all.filter(t=>TI[t].div===d))}</div>`).join('')}</div>`}
    else if(stView==='conference')body=`<div class="stgrid">${['AFC','NFC'].map(c=>`<div>${tbl(c,all.filter(t=>TI[t].conf===c))}</div>`).join('')}</div>`;
    else if(stView==='league')body=tbl('League',all.slice());
    else body=bracket(R,sd);
    const lab={division:'Division',conference:'Conference',league:'League',bracket:'Playoff bracket'};
    el.innerHTML=`<div class="teamhead"><h2>Standings</h2><span class="note">${stSeason==='2026'?`2026 through week ${LASTWK}`:'2025 final'}</span></div><div class="filters stviews" role="group" aria-label="Standings view">${Object.keys(lab).map(k=>`<button type="button" class="btn${stView===k?' solid':''}" data-stv="${k}" aria-pressed="${stView===k}">${lab[k]}</button>`).join('')}</div>${body}<p class="note">Ranked by winning percentage, then point differential. Official tiebreakers (head-to-head, division record) are not applied.</p>`;
  }
  function bracket(R,sd){
    const S={AFC:seedsOf(R,'AFC'),NFC:seedsOf(R,'NFC')},sdn=t=>sd[t],pick=id=>BK[id]||null;
    const btn=(id,t)=>`<button type="button" class="bkt${pick(id)===t?' won':''}${pick(id)&&pick(id)!==t?' lost':''}" data-bk="${id}" data-bt="${t}">${tlogo(t,18)}<span class="seedchip">${sdn(t)}</span><b>${TI[t].nick}</b><span class="st">${R[t].w}–${R[t].l}${R[t].t?'–'+R[t].t:''}</span></button>`;
    const match=(id,a,b)=>`<div class="bkm">${a?btn(id,a):'<div class="bkt tbd">Awaiting result</div>'}${b?btn(id,b):'<div class="bkt tbd">Awaiting result</div>'}</div>`;
    const conf=c=>{const s=S[c],wc=[['W1',s[1],s[6]],['W2',s[2],s[5]],['W3',s[3],s[4]]];
      const w=wc.map(m=>pick(c+m[0])),all=w.every(Boolean),rem=all?[s[0],...w].sort((a,b)=>sdn(a)-sdn(b)):null;
      const d1=rem?[rem[0],rem[3]]:[s[0],null],d2=rem?[rem[1],rem[2]]:[null,null];
      const cw=[pick(c+'D1'),pick(c+'D2')];
      return `<div class="bkcol"><h4 class="rkg">${c}</h4><div class="note">Wild card round (seed 1 has a bye)</div>${wc.map(m=>match(c+m[0],m[1],m[2])).join('')}<div class="note">Divisional round</div>${match(c+'D1',d1[0],d1[1])}${match(c+'D2',d2[0],d2[1])}<div class="note">${c} championship</div>${match(c+'C',cw[0],cw[1])}</div>`};
    const a=pick('AFCC'),n=pick('NFCC'),sb=pick('SB');
    return `<p class="note">A what-if bracket built from the current seeds, not a forecast. Tap a team to advance it; later rounds fill in as you go. The higher seed hosts.</p><div class="stgrid">${conf('AFC')}${conf('NFC')}</div><div class="bksb"><h4 class="rkg">Super Bowl</h4>${match('SB',a,n)}${sb?`<p class="bkchamp">${tlogo(sb,28)} <b>${tname(sb)}</b> in your bracket</p>`:''}</div><div class="btnrow"><button class="btn" type="button" id="bkreset">Clear bracket</button></div>`;
  }
  function drawPlayoff(){
    const el=$('rkplayoff');if(!el)return;
    const R=RK['2026'];if(!R){el.innerHTML='';return}
    const pct=t=>{const d=R[t],g=d.w+d.l+d.t;return g?(d.w+d.t/2)/g:0};
    const cmp=(a,b)=>pct(b)-pct(a)||(R[b].pf-R[b].pa)-(R[a].pf-R[a].pa)||(a<b?-1:1);
    const left={};Object.keys(R).forEach(t=>left[t]=[]);SEA.filter(g=>g.hs==null).forEach(g=>{left[g.h].push(g.a);left[g.a].push(g.h)});
    const sosL=t=>left[t].length?left[t].reduce((a,o)=>a+pct(o),0)/left[t].length:null;
    const conf=c=>{const ts=Object.keys(R).filter(t=>TI[t].conf===c),divs=[...new Set(ts.map(t=>TI[t].div))];
      const win=divs.map(d=>ts.filter(t=>TI[t].div===d).sort(cmp)[0]).sort(cmp);
      const wc=ts.filter(t=>!win.includes(t)).sort(cmp);
      return {seeds:[...win,...wc.slice(0,3)],out:wc.slice(3)}};
    const rec=t=>`${R[t].w}–${R[t].l}${R[t].t?'–'+R[t].t:''}`;
    const row=(t,i,tag)=>`<div class="pfrow${i===6?' cut':''}"><span class="pfn">${i+1}</span>${tlogo(t,22)}<b>${TI[t].nick}</b><span class="st">${rec(t)}${tag?' · '+tag:''}</span><span class="st pfs">${left[t].length?'left: '+left[t].length+' · opp. win% '+Math.round(sosL(t)*100)+'%':'done'}</span></div>`;
    const col=c=>{const x=conf(c);return `<div><h4 class="rkg">${c}</h4>${x.seeds.map((t,i)=>row(t,i,i<4?'division leader':'wild card')).join('')}<div class="note" style="margin:6px 0 2px">Just outside</div>${x.out.slice(0,3).map((t,i)=>row(t,7+i,'')).join('')}</div>`};
    el.innerHTML=`<div class="teamhead"><h2>Playoff picture</h2><span class="note">2026 through week ${LASTWK}</span></div><div class="pfgrid">${col('AFC')}${col('NFC')}</div><p class="note">Simplified: seeds 1–4 are division leaders, 5–7 are the best other records. Ties are broken by win percentage, then point differential only — the real NFL tiebreakers (head-to-head, division record and so on) are not applied, so close calls may differ from the official standings. "Opp. win%" is the average winning percentage of the opponents still left to play.</p>`;
  }
  function drawLeaders(){
    if(!$('rkleaders'))return;
    const S=PS[season],g=(r,k)=>k==='tkl'?(r[8][KI.tks]||0)+(r[8][KI.tka]||0):(r[8][KI[k]]||0);
    $('rkleadcount').textContent=`${season} · top 8 in each category`;
    $('rkleaders').innerHTML=LEAD.map(([n,k])=>{const top=S.filter(r=>g(r,k)>0).sort((a,b)=>g(b,k)-g(a,k)).slice(0,8);
      return `<div class="leader"><h4>${n}</h4>${top.map((r,i)=>`<div class="r"><span class="k">${i+1}</span><span>${tlogo(r[3],16)} ${esc(r[1])} <span class="st">${r[3]}</span></span><b>${Math.round(g(r,k)*10)/10}</b></div>`).join('')||'<span class="st">No data yet</span>'}</div>`}).join('')}
  const LEAD=[['Passing yards','pyd'],['Passing TD','ptd'],['Rushing yards','ryd'],['Rushing TD','rtd'],['Receptions','rec'],['Receiving yards','yds'],['Receiving TD','td'],['Sacks','dsk'],['Interceptions','dint'],['Total tackles','tkl'],['Tackles for loss','tfl'],['Field goals made','fgm'],['Punt return yards','pry'],['Kick return yards','kry']];
  const teams=Object.keys(TI).sort();
  $('rkteam').innerHTML='<option value="">Choose a team</option>'+teams.map(t=>`<option value="${t}">${tname(t)}</option>`).join('');
  const all=()=>{drawBoard();drawProfile();drawLeaders()};
  $('rkcats').addEventListener('click',e=>{const b=e.target.closest('.catb');if(!b)return;cat=b.dataset.c;drawCats();drawBoard()});
  $('rkseason').addEventListener('input',()=>{season=$('rkseason').value;all()});
  $('stseason').addEventListener('input',()=>{stSeason=$('stseason').value;BK={};drawStand()});
  $('rkstand').addEventListener('click',e=>{const v=e.target.closest('[data-stv]');if(v){stView=v.dataset.stv;drawStand();return}
    const b=e.target.closest('[data-bk]');if(b){const id=b.dataset.bk;BK[id]=BK[id]===b.dataset.bt?null:b.dataset.bt;
      if(id!=='SB'){const c=id.slice(0,3),r=id[3];if(r==='W')['D1','D2','C'].forEach(k=>delete BK[c+k]);if(r==='D')delete BK[c+'C'];delete BK.SB}
      drawStand();return}
    if(e.target.id==='bkreset'){BK={};drawStand()}});
  $('rkteam').addEventListener('input',()=>{hl=$('rkteam').value;drawBoard();drawProfile()});
  $('rkprofile').addEventListener('click',e=>{const b=e.target.closest('.rtile');if(!b)return;cat=b.dataset.c;drawCats();drawBoard();try{$('rkboard').scrollIntoView({behavior:'smooth',block:'start'})}catch(er){}});
  $('rkprofile').addEventListener('input',e=>{if(e.target.id==='rktrend'){trendKey=e.target.value;drawProfile()}});
  $('rkboard').addEventListener('click',e=>{const r=e.target.closest('.lbrow[data-team]');if(!r)return;hl=r.dataset.team;$('rkteam').value=hl;drawBoard();drawProfile();try{$('rkprofile').scrollIntoView({behavior:'smooth',block:'start'})}catch(er){}});
  $('rkeyebrow').textContent=`${CATS.length} team categories · 2026 through week ${LASTWK} · 2025 full season`;
  $('steyebrow').textContent=`2026 through week ${LASTWK} · ${Object.keys(TI).length} teams`;drawStand();drawCats();drawBoard();drawProfile();drawLeaders();drawPlayoff();
})();

/* ===================== FANTASY FOOTBALL ===================== */
(function(){
  const KEY='bbn.fantasy.v1';
  const SLOTS=[['QB',['QB']],['RB1',['RB']],['RB2',['RB']],['WR1',['WR']],['WR2',['WR']],['TE',['TE']],['FLEX',['RB','WR','TE']],['K',['K']],['DEF',['DEF']]];
  const CAP={QB:3,RB:7,WR:7,TE:3,K:2,DEF:2},ROUNDS=12;
  const P26=new Map(PS['2026'].map(r=>[r[0],r])),P25=new Map(PS['2025'].map(r=>[r[0],r]));
  function ptsRow(r,wk,sc){ // fantasy points for one player-week
    const x=r[9][wk];if(!x)return 0;
    if(r[2]==='K'){const row=PKEYS.map((k,i)=>x[3][i]||0);return kickPts(row)}
    return sc==='ppr'?x[2]:sc==='half'?Math.round((x[1]+x[2])*50)/100:x[1];
  }
  const POOL=(()=>{
    const out=[];
    PS['2026'].forEach(r=>{const pos=r[2];if(!['QB','RB','WR','TE','K'].includes(pos)||!TI[r[3]])return;
      const o=P25.get(r[0]);const g26=r[5],pp26=pos==='K'?Object.keys(r[9]).reduce((a,w)=>a+ptsRow(r,w,'ppr'),0):r[7],pp25=o?(pos==='K'?Object.keys(o[9]).reduce((a,w)=>a+ptsRow(o,w,'ppr'),0):o[7]):0,g25=o?o[5]:0;
      const v=g26>=3?pp26/g26*0.7+(g25>=5?pp25/g25*0.3:pp26/g26*0.3):(g25>=5?pp25/g25*0.8:0);
      if(v<=0&&g26===0)return;out.push({id:r[0],n:r[1],pos,tm:r[3],v:Math.round(v*100)/100,g:g26})});
    Object.keys(TI).forEach(t=>{const d=DEFP['2026'][t]||{},ws=Object.values(d);const v=ws.length?ws.reduce((a,b)=>a+b,0)/ws.length:0;out.push({id:'DEF-'+t,n:tname(t)+' D/ST',pos:'DEF',tm:t,v:Math.round(v*100)/100,g:ws.length})});
    out.sort((a,b)=>b.v-a.v);return out})();
  const PIDX=new Map(POOL.map(p=>[p.id,p]));
  const lastWeek=Math.max(...SEA.map(g=>g.wk));
  const defaultStart=(()=>{const f=SEA.find(g=>g.hs==null);return f?f.wk:1})();
  let L=lsGet(KEY,null);
  const save=()=>lsSet(KEY,L);
  function wkPts(pid,wk,sc){if(pid.startsWith('DEF-')){const d=DEFP['2026'][pid.slice(4)];return d&&d[wk]!=null?d[wk]:0}const r=P26.get(pid);return r?ptsRow(r,wk,sc):0}
  function bestLineup(roster,wk,sc){ // greedy optimal for fixed slots
    const items=roster.map(id=>({id,p:PIDX.get(id),pts:wkPts(id,wk,sc)})).filter(x=>x.p).sort((a,b)=>b.pts-a.pts);const used=new Set(),lu=[];
    [...SLOTS].sort((a,b)=>a[1].length-b[1].length).forEach(([slot,allowed])=>{const it=items.find(x=>!used.has(x.id)&&allowed.includes(x.p.pos));if(it){used.add(it.id);lu.push({slot,...it})}else lu.push({slot,id:null,p:null,pts:0})});
    const order=SLOTS.map(s=>s[0]);lu.sort((a,b)=>order.indexOf(a.slot)-order.indexOf(b.slot));
    return {lu,total:Math.round(lu.reduce((a,b)=>a+b.pts,0)*100)/100,bench:items.filter(x=>!used.has(x.id))};
  }
  function snake(n,i){const r=Math.floor(i/n),k=i%n;return r%2===0?k:n-1-k}
  function schedule(n,start){ // circle method; weeks start..16
    const ids=[...Array(n).keys()];if(n%2)ids.push(-1);const m=ids.length,rounds=m-1,wks=[];
    for(let r=0;r<rounds;r++){const pairs=[];for(let i=0;i<m/2;i++){const a=ids[i],b=ids[m-1-i];pairs.push([a,b])}wks.push(pairs);ids.splice(1,0,ids.pop())}
    const out={};let w=start,i=0;while(w<=lastWeek-1&&w<=17){out[w]=wks[i%rounds];w++;i++}return out;
  }
  function newLeague(cfg){return {name:cfg.name||'Our League',sc:cfg.sc,start:cfg.start,mgr:cfg.mgr,phase:'draft',picks:[],view:'draft',wk:cfg.start}}
  function needOK(L,mi,p){const have=L.picks.filter(x=>x.m===mi).map(x=>PIDX.get(x.id));const cnt=have.filter(h=>h.pos===p.pos).length;if(cnt>=CAP[p.pos])return false;return true}
  function autoPick(L,mi){
    const taken=new Set(L.picks.map(x=>x.id)),have=L.picks.filter(x=>x.m===mi).map(x=>PIDX.get(x.id));
    const cnt=pos=>have.filter(h=>h.pos===pos).length,left=ROUNDS-have.length;
    const needs=[];if(!cnt('QB'))needs.push('QB');if(cnt('RB')<2)needs.push('RB');if(cnt('WR')<2)needs.push('WR');if(!cnt('TE'))needs.push('TE');if(!cnt('K'))needs.push('K');if(!cnt('DEF'))needs.push('DEF');
    const pickable=POOL.filter(p=>!taken.has(p.id)&&cnt(p.pos)<CAP[p.pos]);
    // K and DEF wait until late unless forced
    const late=left<=needs.length+1;
    let c=pickable.filter(p=>(p.pos!=='K'&&p.pos!=='DEF')||late||left<=3);
    if(left<=needs.length)c=pickable.filter(p=>needs.includes(p.pos));
    return (c[0]||pickable[0]);
  }
  function standings(L,upto){
    const n=L.mgr.length,rows=L.mgr.map((m,i)=>({i,name:m,w:0,l:0,t:0,pf:0,pa:0}));
    const sch=schedule(n,L.start);
    Object.keys(sch).map(Number).forEach(w=>{if(w>LASTWK)return;sch[w].forEach(([a,b])=>{if(a<0||b<0)return;const ra=rosterOf(L,a),rb=rosterOf(L,b);const x=bestLineup(ra,w,L.sc).total,y=bestLineup(rb,w,L.sc).total;rows[a].pf+=x;rows[a].pa+=y;rows[b].pf+=y;rows[b].pa+=x;if(wkState(w)!=='final')return;if(x>y){rows[a].w++;rows[b].l++}else if(y>x){rows[b].w++;rows[a].l++}else{rows[a].t++;rows[b].t++}})});
    rows.forEach(r=>{r.pf=Math.round(r.pf*100)/100;r.pa=Math.round(r.pa*100)/100});
    return rows.sort((a,b)=>(b.w+b.t/2)-(a.w+a.t/2)||b.pf-a.pf);
  }
  const rosterOf=(L,mi)=>L.picks.filter(x=>x.m===mi).map(x=>x.id);
  let q='',fpos='';
  function render(){
    const el=$('ffbody');
    $('ffeyebrow').textContent=L?`${L.name} · ${L.mgr.length} managers · ${L.sc==='ppr'?'PPR':L.sc==='half'?'Half PPR':'Standard'} scoring`:`Set up a league · weeks ${defaultStart}–${Math.min(17,lastWeek-1)} available`;
    if(!L){ el.innerHTML=setupHtml();return}
    if(L.phase==='draft'){el.innerHTML=draftHtml();return}
    el.innerHTML=seasonHtml();
  }
  function setupHtml(){
    return `<div class="card"><h2>New league</h2>
    <div class="setup">
      <label>League name<input id="ffname" value="Sunday League" maxlength="30"></label>
      <label>Managers<select id="ffn">${[2,3,4,5,6].map(n=>`<option value="${n}"${n===4?' selected':''}>${n} managers</option>`).join('')}</select></label>
      <label>Scoring<select id="ffsc"><option value="ppr">PPR (1 per catch)</option><option value="half">Half PPR</option><option value="std">Standard</option></select></label>
      <label>Season starts in week<select id="ffstart">${Array.from({length:Math.min(17,lastWeek-1)},(_,i)=>i+1).map(w=>`<option value="${w}"${w===defaultStart?' selected':''}>Week ${w}${w<=LASTWK?' (already played)':''}</option>`).join('')}</select></label>
    </div>
    <div class="setup" id="ffnames">${namesInputs(4)}</div>
    <p class="note">Each team starts one QB, two RB, two WR, one TE, one flex (RB, WR or TE), one K and one team defense, with three bench spots. After the snake draft, each week's best lineup is set for you from your roster and scored with that week's real stats. Weeks that have not been played score zero until the stats arrive. Defense scores sacks, takeaways, touchdowns, safeties, blocked kicks and points allowed; kickers score 3/4/5 for field goals by distance, 1 per extra point and −1 per miss.</p>
    <div class="btnrow"><button class="btn solid" type="button" id="ffgo">Start the draft</button></div></div>`}
  function namesInputs(n){return Array.from({length:n},(_,i)=>`<label>Manager ${i+1}<input class="ffmn" value="${['Alex','Blake','Casey','Drew','Emery','Finley'][i]}" maxlength="18"></label>`).join('')}
  function draftHtml(){
    const n=L.mgr.length,total=n*ROUNDS,cur=L.picks.length,done=cur>=total;
    const turn=done?-1:snake(n,cur),taken=new Set(L.picks.map(x=>x.id));
    const head=`<div class="brow">${L.mgr.map(m=>`<div class="bhd">${esc(m)}</div>`).join('')}</div>`;
    let boardRows='';for(let r=0;r<ROUNDS;r++){const cells=Array(n).fill('');for(let k=0;k<n;k++){const idx=r*n+(r%2===0?k:n-1-k);const pk=L.picks[idx];const m=r%2===0?k:n-1-k;
      cells[m]=pk?(()=>{const p=PIDX.get(pk.id);return `<div class="bcell ${p.pos}"><b>${esc(p.n.split(' ').slice(-1)[0])}</b><small>${p.pos} · ${p.tm}</small></div>`})():`<div class="bcell${idx===cur?' now':''}"><small>R${r+1}·${idx+1}</small></div>`}
      boardRows+=`<div class="brow">${cells.join('')}</div>`}
    const avail=POOL.filter(p=>!taken.has(p.id)&&(!fpos||p.pos===fpos)&&(!q||p.n.toLowerCase().includes(q))).slice(0,60);
    const myTurn=turn>=0?L.mgr[turn]:'';
    return `<div class="card"><div class="teamhead"><h2>Draft room</h2><span class="count">${done?'Draft complete':`Pick ${cur+1} of ${total} · round ${Math.floor(cur/n)+1}`}</span></div>
      ${done?`<div class="btnrow"><button class="btn solid" type="button" id="ffseason">Open the season</button></div>`:`<p class="note" style="font-size:15px;color:var(--fg)"><b>${esc(myTurn)}</b> is on the clock.</p><div class="btnrow"><button class="btn" type="button" id="ffauto">Auto-pick for ${esc(myTurn)}</button><button class="btn" type="button" id="ffautoall">Auto-draft the rest</button><button class="btn" type="button" id="ffundo" ${cur?'':'disabled'}>Undo last pick</button></div>`}
    </div>
    <div class="warroom"><div class="card" style="overflow:auto"><h2>Board</h2><div class="board">${head}${boardRows}</div></div>
    <div class="card"><h2>Players available</h2><div class="filters"><label>Position<select id="ffpos"><option value="">All</option>${['QB','RB','WR','TE','K','DEF'].map(p=>`<option value="${p}"${fpos===p?' selected':''}>${p}</option>`).join('')}</select></label><label>Search<input id="ffq" type="search" value="${esc(q)}" placeholder="Name"></label></div>
      <div class="pool-list">${avail.map(p=>`<div class="poolrow"><span class="pos">${p.pos}</span><span class="nm">${esc(p.n)}<small>${p.tm}</small></span><span class="pv" title="Points per game, weighted to this season">${p.v.toFixed(1)}</span><button class="btn" type="button" data-pick="${p.id}" ${done||!needOK(L,turn,p)?'disabled':''}>Draft</button></div>`).join('')||'<p class="note">Nobody matches.</p>'}</div></div></div>
    <div class="card"><div class="btnrow"><button class="btn danger" type="button" id="ffreset">Scrap this league</button></div></div>`;
  }
  function seasonHtml(){
    const n=L.mgr.length,sch=schedule(n,L.start),wks=Object.keys(sch).map(Number),wk=Math.min(Math.max(L.wk,wks[0]),wks[wks.length-1]);
    const st=standings(L);
    const match=(sch[wk]||[]).map(([a,b])=>{
      const side=i=>{if(i<0)return `<div class="mu-side"><h3>Bye week</h3></div>`;const bl=bestLineup(rosterOf(L,i),wk,L.sc),op=(sch[wk].find(p=>p.includes(i))||[]).find(x=>x!==i);const ob=op>=0?bestLineup(rosterOf(L,op),wk,L.sc).total:-1;
        return `<div class="mu-side${wk<=LASTWK&&bl.total>ob?' won':''}"><h3><span>${esc(L.mgr[i])}</span><span>${bl.total.toFixed(1)}</span></h3>${bl.lu.map(s=>`<div class="mu-row"><span class="pos">${s.slot.replace(/\d/,'')}</span><span>${s.p?esc(s.p.n)+` <span class="st">${s.p.tm}</span>`:'<span class="st">empty</span>'}</span><b class="mono">${s.pts.toFixed(1)}</b></div>`).join('')}</div>`};
      return `<div class="matchup">${side(a)}<div class="mu-vs">vs</div>${side(b)}</div>`}).join('');
    const rosters=L.mgr.map((m,i)=>`<details class="card"><summary><b>${esc(m)}</b> <span class="st">${rosterOf(L,i).length} players</span></summary><div class="tablebox"><table><tbody>${rosterOf(L,i).map(id=>PIDX.get(id)).sort((a,b)=>['QB','RB','WR','TE','K','DEF'].indexOf(a.pos)-['QB','RB','WR','TE','K','DEF'].indexOf(b.pos)).map(p=>`<tr><td class="mono">${p.pos}</td><td>${esc(p.n)}</td><td class="mono">${p.tm}</td></tr>`).join('')}</tbody></table></div></details>`).join('');
    return `<div class="card"><div class="teamhead"><h2>Standings</h2><span class="count">${wks.length} weeks scheduled · stats through week ${LASTWK}${wkState(LASTWK)==='live'?' (in progress)':''}</span></div>
      <div class="tablebox"><table class="stand"><thead><tr><th>#</th><th>Manager</th><th>W</th><th>L</th><th>T</th><th>Points for</th><th>Points against</th></tr></thead><tbody>${st.map((r,i)=>`<tr><td>${i+1}</td><td><b>${esc(r.name)}</b></td><td class="w">${r.w}</td><td>${r.l}</td><td>${r.t}</td><td class="mono">${r.pf.toFixed(1)}</td><td class="mono">${r.pa.toFixed(1)}</td></tr>`).join('')}</tbody></table></div></div>
      <div class="card"><div class="teamhead"><h2>Matchups</h2><span class="count">Week ${wk}${wkState(wk)==='live'?' · in progress':wkState(wk)==='·'?' · not played yet':''}</span></div>
      <div class="wkstrip">${wks.map(w=>`<button class="wkb" type="button" data-fw="${w}" aria-pressed="${w===wk}">${w}<s>${wkState(w)}</s></button>`).join('')}</div>${match}</div>
      <div class="card"><h2>Rosters</h2>${rosters}</div>
      <div class="card"><h2>Back up or move this league</h2><textarea class="code" id="ffcode" aria-label="League code"></textarea><div class="btnrow"><button class="btn" type="button" id="ffexp">Make code</button><button class="btn" type="button" id="ffimp">Load code</button><button class="btn danger" type="button" id="ffreset">Scrap this league</button></div><p class="note" id="ffmsg"></p></div>`;
  }
  const root=$('ffbody');
  let armed=false;
  root.addEventListener('input',e=>{
    if(e.target.id==='ffn'){$('ffnames').innerHTML=namesInputs(+e.target.value)}
    if(e.target.id==='ffpos'){fpos=e.target.value;render()}
    if(e.target.id==='ffq'){q=e.target.value.trim().toLowerCase();const pos=e.target.selectionStart;render();const x=$('ffq');if(x){x.focus();try{x.setSelectionRange(pos,pos)}catch(er){}}}
  });
  root.addEventListener('click',e=>{
    const t=e.target.closest('button');if(!t)return;
    if(t.id==='ffgo'){const mg=[...document.querySelectorAll('.ffmn')].map(i=>i.value.trim()||'Manager');L=newLeague({name:$('ffname').value.trim(),sc:$('ffsc').value,start:+$('ffstart').value,mgr:mg});save();render();return}
    if(t.dataset.pick){const n=L.mgr.length;if(L.picks.length>=n*ROUNDS)return;const m=snake(n,L.picks.length);const p=PIDX.get(t.dataset.pick);if(!needOK(L,m,p))return;L.picks.push({m,id:p.id});save();render();return}
    if(t.id==='ffauto'){const n=L.mgr.length;const m=snake(n,L.picks.length);const p=autoPick(L,m);if(p){L.picks.push({m,id:p.id});save();render()}return}
    if(t.id==='ffautoall'){const n=L.mgr.length;while(L.picks.length<n*ROUNDS){const m=snake(n,L.picks.length);const p=autoPick(L,m);if(!p)break;L.picks.push({m,id:p.id})}save();render();return}
    if(t.id==='ffundo'){L.picks.pop();save();render();return}
    if(t.id==='ffseason'){L.phase='season';save();render();return}
    if(t.dataset.fw){L.wk=+t.dataset.fw;save();render();return}
    if(t.id==='ffreset'){if(!armed){armed=true;t.textContent='Press again to scrap it';setTimeout(()=>{armed=false;if(t.isConnected)t.textContent='Scrap this league'},4000);return}L=null;armed=false;try{localStorage.removeItem(KEY)}catch(er){}render();return}
    if(t.id==='ffexp'){try{$('ffcode').value=btoa(unescape(encodeURIComponent(JSON.stringify(L))));$('ffmsg').textContent='Copy this code to keep or move the league.'}catch(er){}return}
    if(t.id==='ffimp'){try{const o=JSON.parse(decodeURIComponent(escape(atob($('ffcode').value.trim()))));if(!o||!Array.isArray(o.mgr)||!Array.isArray(o.picks))throw 0;L=o;save();render()}catch(er){$('ffmsg').textContent='That code could not be read.'}return}
  });
  window.__ffRender=render;
  render();
})();

