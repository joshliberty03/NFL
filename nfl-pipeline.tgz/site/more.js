
/* ===================== MORE TABS: SCORES, DRAFT, HISTORY, SANDBOX ===================== */
const GD=__GAMEDET__,TOPS=__TOP__,HIST=__HIST__,DRAFT=__DRAFT__,AW=__AWARDS__;
const nrm=n=>String(n||'').toLowerCase().replace(/-/g,' ').replace(/[^a-z ]/g,'').split(' ').filter(w=>w&&!['jr','sr','ii','iii','iv','v'].includes(w)).join(' ');
const DRN={};DRAFT.forEach(r=>(DRN[nrm(r[4])]=DRN[nrm(r[4])]||[]).push(r));
const STATLAB={};Object.keys(HIST.rec).forEach(c=>STATLAB[c]=HIST.rec[c].l.toLowerCase());
const fmtN=v=>typeof v==='number'?v.toLocaleString('en-US'):v;
/* honors: [{t:'Heisman Trophy',y:2009}], plus Pro Bowl / All-Pro / HOF from draft data when the name matches one 2000+ pick */
function honorsFor(name){const k=nrm(name),d=DRN[k]&&DRN[k].length===1?DRN[k][0]:null,out=[];
  (AW[k]||[]).forEach(([a,y])=>{if(a==='Heisman Trophy'&&!(d&&d[0]>=y&&d[0]<=y+3))return;out.push({t:a,y})});
  return {awards:out,draft:d}}
window.__honors=honorsFor;
const awChips=name=>honorsFor(name).awards.map(a=>`<span class="hof aw">${esc(a.t)} ${a.y}</span>`).join('');
/* record holders (since 1999): league top-10 and franchise records */
function recsFor(pid,name){const lg=[],fr=[],k=nrm(name);
  if(HIST.all&&name)Object.entries(HIST.all).forEach(([c,x])=>[['s','single-season'],['c','career'],['g','single-game']].forEach(([kd,lab])=>{(x[kd]||[]).forEach((r,i)=>{if(nrm(r[0])!==k)return;const yr=kd==='s'?r[2]:kd==='c'?r[2]:r[3];lg.push({rank:i+1,txt:`${lab} ${STATLAB[c]}: ${fmtN(r[1])} (${yr})`})})}));
  Object.entries(HIST.fr).forEach(([tm,st])=>Object.entries(st).forEach(([c,x])=>{
    if(x.s[3]===pid)fr.push({tm,txt:`single-season ${STATLAB[c]}: ${fmtN(x.s[2])} (${x.s[1]})`});
    if(x.c[4]===pid)fr.push({tm,txt:`career with the team ${STATLAB[c]}: ${fmtN(x.c[3])} (${x.c[1]}–${x.c[2]})`});
    if(x.g[5]===pid)fr.push({tm,txt:`single-game ${STATLAB[c]}: ${fmtN(x.g[4])} (${x.g[1]} wk ${x.g[2]})`})}));
  lg.sort((a,b)=>a.rank-b.rank);return {lg,fr}}
window.__recs=(pid,name)=>{const h=honorsFor(name),R=recsFor(pid,name),d=h.draft;
  const tags=[...h.awards.map(a=>`<span class="hof aw">${esc(a.t)} ${a.y}</span>`)];
  if(d){if(d[9])tags.push('<span class="hof">Hall of Fame</span>');if(d[7])tags.push(`<span class="hon">${d[7]}× All-Pro</span>`);if(d[8])tags.push(`<span class="hon">${d[8]}× Pro Bowl</span>`)}
  if(!tags.length&&!R.lg.length&&!R.fr.length)return '';
  const lgl=R.lg.map(x=>`<li><b>${x.since?(x.rank===1?'League record since 1999':'#'+x.rank+' since 1999'):(x.rank===1?'League record':'#'+x.rank+' all-time')}</b> · ${esc(x.txt)}</li>`).join(''),
    frl=R.fr.map(x=>`<li><b>${esc(TI[x.tm]?TI[x.tm].nick:x.tm)} franchise record</b> · ${esc(x.txt)}</li>`).join('');
  return `<div class="recbox"><h4>Honors &amp; records</h4>${tags.length?`<div class="rectags">${tags.join('')}</div>`:''}${lgl?`<ul>${lgl}</ul>`:''}${frl?`<ul>${frl}</ul>`:''}<p class="note">League records are all-time (Pro Football Reference). Franchise records cover ${HIST.range[0]} to now only, from nflverse data. Awards listed: Heisman, AP MVP, offensive and defensive player of the year, both rookie awards, comeback player and Super Bowl MVP. Pro Bowl, All-Pro and Hall of Fame counts cover players drafted in 2000 or later.</p></div>`};
const TMS=Object.keys(TI).sort();
const optsTeams=sel=>{sel.insertAdjacentHTML('beforeend',TMS.map(t=>`<option value="${t}">${esc(tname(t))}</option>`).join(''))};
const kickTxt=(d,t)=>{if(!d)return '';const [h,m]=(t||'00:00').split(':').map(Number);return `${fmtDay(d)} · ${((h+11)%12)+1}:${String(m).padStart(2,'0')} ${h<12?'AM':'PM'} ET`};
const wl=(a,b,t)=>`${a}–${b}${t?'–'+t:''}`;
/* ---------- Schedule & Scores ---------- */
(function(){
  let season='2026';
  const games=()=>season==='2026'?SEA:SEA25;
  const weeks=()=>[...new Set(games().map(g=>g.wk))].sort((a,b)=>a-b);
  const defWeek=()=>{if(season!=='2026')return weeks()[0];const up=SEA.filter(g=>g.hs==null).map(g=>g.wk);return up.length?Math.min(...up):LASTWK};
  function fillWeeks(w){$('scweek').innerHTML='<option value="">All weeks</option>'+weeks().map(x=>`<option value="${x}">Week ${x}</option>`).join('');$('scweek').value=String(w)}
  function draw(){
    const wk=$('scweek').value,tm=$('scteam').value;
    let L=games().filter(g=>(!wk||g.wk==wk)&&(!tm||g.h===tm||g.a===tm));
    if(season==='2026')L=L.slice().sort((a,b)=>a.wk-b.wk||etKick(a.d,a.t)-etKick(b.d,b.t));
    const byWk={};L.forEach(g=>(byWk[g.wk]=byWk[g.wk]||[]).push(g));
    const row=g=>{const fin=g.hs!=null,hw=fin&&g.hs>g.as,aw=fin&&g.as>g.hs;
      const side=(t,s,w)=>`<div class="scs${w?' win':''}">${tlogo(t,26)}<span class="scn">${esc(TI[t].nick)}</span><b class="scv">${fin?s:''}</b></div>`;
      const hasD=fin&&season==='2026'&&GD[g.id];
      return `<div class="scg${fin?' fin':''}${hasD?' clk':''}"${hasD?` role="button" tabindex="0" data-gd="${g.id}" aria-label="Open game review"`:''}><div class="sck">${fin?'Final':'Upcoming'}${g.d?` · ${kickTxt(g.d,g.t)}`:''}</div>${side(g.a,g.as,aw)}${side(g.h,g.hs,hw)}${hasD?'<div class="gdhint">Game review ›</div>':''}</div>`};
    $('scbody').innerHTML=Object.keys(byWk).map(w=>{
      const on=new Set();games().filter(g=>g.wk==w).forEach(g=>{on.add(g.h);on.add(g.a)});const bye=TMS.filter(t=>!on.has(t));
      return `<h3 class="scwk">Week ${w}</h3><div class="scgrid">${byWk[w].map(row).join('')}</div>${bye.length&&!tm&&bye.length<16?`<p class="note">Bye: ${bye.map(t=>esc(TI[t].nick)).join(', ')}</p>`:''}`}).join('')||'<p class="note">No games match.</p>';
    $('sceyebrow').textContent=season==='2026'?`2026 season · ${SEAPLAYED.length} of ${SEA.length} games final`:'2025 season · final scores';
  }

  /* game review (2026 games already played) */
  const nm=t=>esc(TI[t]?TI[t].nick:t);
  function wpSvg(wp,H,A){if(!wp||wp.length<3)return '';const W=300,Ht=70,n=wp.length,pts=wp.map((v,i)=>`${(i/(n-1)*W).toFixed(1)},${(Ht-v/100*Ht).toFixed(1)}`).join(' ');
    return `<svg class="wpsvg" viewBox="0 0 ${W} ${Ht}" preserveAspectRatio="none" role="img" aria-label="Win probability for ${esc(TI[H].nick)} through the game"><line x1="0" y1="${Ht/2}" x2="${W}" y2="${Ht/2}" class="wpmid"/><polyline points="${pts}" class="wpline"/></svg><div class="wplab"><span>${nm(H)} win chance (top = ${nm(H)})</span><span>${nm(A)} (bottom)</span></div>`}
  function detail(g){const d=GD[g.id],H=g.h,A=g.a,ql=d.q.h.map((_,i)=>i<4?'Q'+(i+1):'OT');
    const trow=(t,arr,tot)=>`<tr><td>${tlogo(t,18)} <b>${nm(t)}</b></td>${arr.map(v=>`<td>${v}</td>`).join('')}<td><b>${tot}</b></td></tr>`;
    const bx=`<div class="tablebox"><table class="sttbl gdbx"><thead><tr><th>Team</th>${ql.map(q=>`<th>${q}</th>`).join('')}<th>Final</th></tr></thead><tbody>${trow(A,d.q.a,g.as)}${trow(H,d.q.h,g.hs)}</tbody></table></div>`;
    const sp=d.sp.length?d.sp.map(e=>`<li class="gdsp"><span class="gdq">${e[0]>4?'OT':'Q'+e[0]} ${esc(e[1])}</span> <b>${nm(e[2])}</b> <span class="gdk">${e[3]}</span> ${esc(e[4])} <span class="gdsc">${nm(A)} ${e[6]}, ${nm(H)} ${e[5]}</span></li>`).join(''):'<li class="note">No scoring plays recorded.</li>';
    const ts=d.ts,rw=(l,a,h)=>`<tr><td>${a}</td><td class="gdl">${l}</td><td>${h}</td></tr>`;
    const stats=`<table class="gdt"><thead><tr><th>${nm(A)}</th><th></th><th>${nm(H)}</th></tr></thead><tbody>
      ${rw('Total yards',ts.a.yds,ts.h.yds)}${rw('Net passing yards',ts.a.py,ts.h.py)}${rw('Rushing yards',ts.a.ry,ts.h.ry)}${rw('First downs',ts.a.fd,ts.h.fd)}${rw('Offensive plays',ts.a.ply,ts.h.ply)}
      ${rw('3rd down',ts.a.t3.join('/'),ts.h.t3.join('/'))}${rw('4th down',ts.a.t4.join('/'),ts.h.t4.join('/'))}${rw('Turnovers',ts.a.to,ts.h.to)}${rw('Sacks taken',ts.a.sk,ts.h.sk)}${rw('Penalties-yards',ts.a.pen.join('-'),ts.h.pen.join('-'))}</tbody></table>`;
    const perf=(t,L)=>`<div><h4 class="rkg">${nm(t)}</h4>${L.length?`<ul class="gdp">${L.map(x=>`<li><span class="gdk">${x[0]}</span> <b>${esc(x[1])}</b> <span class="st">${esc(x[2])}</span></li>`).join('')}</ul>`:'<p class="note">No individual stats listed.</p>'}</div>`;
    return `<button type="button" class="btn" id="gdback">← Back to scores</button>
      <div class="teamhead"><h2>${tlogo(A,26)} ${nm(A)} at ${tlogo(H,26)} ${nm(H)}</h2><span class="count">Week ${g.wk} · Final</span></div>
      <p class="note">${esc(kickTxt(g.d,g.t))}${d.wx?' · '+esc(d.wx):''}${d.co[0]||d.co[1]?` · Coaches: ${esc(d.co[0])} / ${esc(d.co[1])}`:''}</p>
      ${bx}<h3 class="scwk">Scoring plays</h3><ul class="gdlist">${sp}</ul>
      <h3 class="scwk">Team stats</h3>${stats}
      <h3 class="scwk">How the game flowed</h3>${wpSvg(d.wp,H,A)}
      <h3 class="scwk">Top performers</h3><div class="stgrid">${perf(A,d.pf.a)}${perf(H,d.pf.h)}</div>
      <p class="note">Built from play-by-play and box-score data (nflverse). Win chance is the model estimate at each play. Totals can differ slightly from the official box score.</p>`}
  function openGame(id){const g=SEA.find(x=>x.id===id);if(!g||!GD[id])return;const y=window.scrollY;$('scbody').innerHTML=detail(g);
    try{$('scbody').scrollIntoView({block:'start'})}catch(e){}
    $('gdback').addEventListener('click',()=>{draw();try{window.scrollTo(0,y)}catch(e){}})}
  window.__openGame=id=>{try{document.querySelector('.navbtn[data-nav="scores"]').click()}catch(e){}openGame(id)};
  $('scbody').addEventListener('click',e=>{const c=e.target.closest('[data-gd]');if(c)openGame(c.dataset.gd)});
  $('scbody').addEventListener('keydown',e=>{if(e.key!=='Enter'&&e.key!==' ')return;const c=e.target.closest('[data-gd]');if(c){e.preventDefault();openGame(c.dataset.gd)}});
  optsTeams($('scteam'));fillWeeks(defWeek());
  $('scseason').addEventListener('input',()=>{season=$('scseason').value;fillWeeks(defWeek());draw()});
  $('scweek').addEventListener('input',draw);$('scteam').addEventListener('input',draw);
  draw();
})();
/* ---------- Draft ---------- */
(function(){
  const yrs=[...new Set(DRAFT.map(r=>r[0]))].sort((a,b)=>b-a);
  $('dryear').innerHTML=yrs.map(y=>`<option value="${y}">${y}</option>`).join('');
  optsTeams($('drteam'));
  $('drpos').insertAdjacentHTML('beforeend',[...new Set(DRAFT.map(r=>r[5]))].filter(Boolean).sort().map(p=>`<option>${esc(p)}</option>`).join(''));
  $('drround').insertAdjacentHTML('beforeend',[1,2,3,4,5,6,7].map(r=>`<option value="${r}">Round ${r}</option>`).join(''));
  function draw(){
    const y=+$('dryear').value,tm=$('drteam').value,ps=$('drpos').value,rd=$('drround').value;
    const L=DRAFT.filter(r=>r[0]===y&&(!tm||r[3]===tm)&&(!ps||r[5]===ps)&&(!rd||r[1]==rd)).sort((a,b)=>a[2]-b[2]);
    const hon=r=>[awChips(r[4]).replace(/(Heisman Trophy )(\d+)/g,'$1$2'),r[9]?'<span class="hof">HOF</span>':'',r[7]?`<span class="hon">${r[7]}× All-Pro</span>`:'',r[8]?`<span class="hon">${r[8]}× Pro Bowl</span>`:''].join('');
    $('dreyebrow').textContent=`${y} draft · ${DRAFT.filter(r=>r[0]===y).length} picks`;
    $('drbody').innerHTML=L.length?`<div class="stwrap"><table class="sttbl drt"><thead><tr><th>Pick</th><th>Rd</th><th>Team</th><th>Player</th><th>Pos</th><th>College</th><th>Honors</th></tr></thead><tbody>${L.map(r=>`<tr><td>${r[2]}</td><td>${r[1]}</td><td>${tlogo(r[3],18)} ${esc(TI[r[3]]?TI[r[3]].nick:r[3])}</td><td><b>${esc(r[4])}</b></td><td>${esc(r[5])}</td><td>${esc(r[6]||'')}</td><td>${hon(r)}</td></tr>`).join('')}</tbody></table></div><p class="note">Teams are shown by their current names, so a pick made by the Oakland Raiders appears under Las Vegas. Honors come from Pro Football Reference data through the last season it covers.</p>`:'<p class="note">No picks match.</p>';
  }
  ['dryear','drteam','drpos','drround'].forEach(i=>$(i).addEventListener('input',draw));draw();
})();
/* ---------- Records & History ---------- */
(function(){
  let view='players',rteam='',rsub='s',rsub2='s',rscope='all',openR=null,rpos='',rstat='',rq='';
  const POSMAP={QB:['passing_yards','passing_tds'],RB:['rushing_yards','rushing_tds','receptions','receiving_yards','receiving_tds'],WR:['receptions','receiving_yards','receiving_tds'],TE:['receptions','receiving_yards','receiving_tds'],Defense:['def_sacks','def_interceptions'],Kicker:['fg_made']};
  const T=t=>`${tlogo(t,16)} ${esc(TI[t]?TI[t].nick:t)}`;
  const list=(title,rows)=>`<div class="hcard"><h4>${title}</h4><ol>${rows.map(r=>`<li>${r}</li>`).join('')}</ol></div>`;
  function players(){
    const kind=rsub,all=rscope==='all';
    const rowA=(r,k)=>k==='s'?`<b>${esc(r[0])}</b> <span class="st">${r[2]} · ${T(r[3])}</span><em>${fmtN(r[1])}</em>`:k==='c'?`<b>${esc(r[0])}</b> <span class="st">${r[2]}${r[3]?' · '+esc(r[3]):''}</span><em>${fmtN(r[1])}</em>`:`<b>${esc(r[0])}</b> <span class="st">${r[3]} · ${T(r[2])}</span><em>${fmtN(r[1])}</em>`;
    const rowN=(r,k)=>k==='s'?`<b>${esc(r[0])}</b> <span class="st">${r[1]} · ${T(r[2])}</span><em>${fmtN(r[3])}</em>`:k==='c'?`<b>${esc(r[0])}</b> <span class="st">${r[1]}–${r[2]}</span><em>${fmtN(r[3])}</em>`:`<b>${esc(r[0])}</b> <span class="st">${r[1]} wk ${r[2]} · ${T(r[3])} vs ${esc(r[4])}</span><em>${fmtN(r[5])}</em>`;
    const q=nrm(rq),keep=c=>(!rpos||POSMAP[rpos].includes(c))&&(!rstat||rstat===c);
    const nm=(r,a)=>!q||nrm(a?r[0]:r[0]).includes(q);
    const cards=Object.keys(HIST.rec).filter(keep).map(c=>{const x=all?HIST.all[c]:HIST.rec[c];if(!x||!x[kind])return '';const rows=x[kind].filter(r=>nm(r,all));if(!rows.length)return '';return list(HIST.rec[c].l,rows.map(r=>all?rowA(r,kind):rowN(r,kind)))});
    return `<div class="filters stviews">${['s','c','g'].map(k=>`<button class="btn${rsub===k?' solid':''}" type="button" data-rs="${k}">${{s:'Single season',c:'Career',g:'Single game'}[k]}</button>`).join('')}</div><div class="filters"><label for="rfpos">Position<select id="rfpos"><option value="">All positions</option>${Object.keys(POSMAP).map(p=>`<option${p===rpos?' selected':''}>${p}</option>`).join('')}</select></label><label for="rfstat">Stat<select id="rfstat"><option value="">All stats</option>${Object.keys(HIST.rec).filter(c=>!rpos||POSMAP[rpos].includes(c)).map(c=>`<option value="${c}"${c===rstat?' selected':''}>${HIST.rec[c].l}</option>`).join('')}</select></label><label for="rfq">Find a player<input id="rfq" type="search" placeholder="Type a name" value="${esc(rq)}" autocomplete="off"></label></div>${cards.join('').length?`<div class="hgrid">${cards.join('')}</div>`:'<p class="note">No records match those filters.</p>'}<p class="note">All-time lists come from Pro Football Reference and are the official league numbers (single-game lists show the top five). Sacks and interceptions follow its record keeping.</p>`}
  function teams(){const T2=r=>`<b>${r[1]} ${T(r[0])}</b><em>${r[2]}</em>`,TG=r=>`<b>${r[1]} wk ${r[2]}</b> <span class="st">${T(r[0])} vs ${esc(r[3])}</span><em>${r[4]}</em>`,G=r=>`<b>${r[0]} ${r[1]==='REG'?'wk '+r[2]:r[1]}</b> <span class="st">${T(r[5])} ${r[6]}, ${T(r[3])} ${r[4]}</span><em>${r[4]+r[6]}</em>`,B=r=>`<b>${r[0]} ${r[1]==='REG'?'wk '+r[2]:r[1]}</b> <span class="st">${T(r[5])} ${r[6]}, ${T(r[3])} ${r[4]}</span><em>${Math.abs(r[4]-r[6])}</em>`,P=r=>`<b>${r[1]} ${T(r[0])}</b> <span class="st">${r[5]} scored, ${r[6]} allowed</span><em>${r[5]}</em>`,A=r=>`<b>${r[1]} ${T(r[0])}</b> <span class="st">${r[5]} scored, ${r[6]} allowed</span><em>${r[6]}</em>`;
    const t=HIST.team,ts=Object.values(HIST.tstat);
    return `<div class="filters stviews">${['s','g'].map(k=>`<button class="btn${rsub2===k?' solid':''}" type="button" data-rs2="${k}">${{s:'Single season',g:'Single game'}[k]}</button>`).join('')}</div><div class="hgrid">${rsub2==='s'?list('Most points scored',t.pts.map(P))+list('Fewest points allowed',t.stingy.map(A))+ts.map(x=>list('Team '+x.l.toLowerCase(),x.s.map(T2))).join(''):list('Highest-scoring games (combined)',t.hi.map(G))+list('Biggest margins of victory',t.blow.map(B))+ts.map(x=>list('Team '+x.l.toLowerCase()+' in a game',x.g.map(TG))).join('')}</div><p class="note">Team totals are built from player stats, ${HIST.range[0]} to now, and can differ slightly from official league totals. Season lists use completed seasons only.</p>`}
  let oscope='s',oq='',oyear=String(HIST.range[1]-1);
  function odd(){
    const q=nrm(oq);
    const cards=HIST.odd.map(x=>{const rows=(oscope==='s'?x.s:x.g).filter(r=>!q||nrm(r[0]).includes(q));if(!rows.length)return '';
      return list(x.l,rows.map(r=>oscope==='s'?`<b>${esc(r[0])}</b> <span class="st">${r[1]} · ${T(r[2])}</span><em>${fmtN(r[3])}</em>`:`<b>${esc(r[0])}</b> <span class="st">${r[1]} wk ${r[2]} · ${T(r[3])} vs ${esc(r[4])}</span><em>${fmtN(r[5])}</em>`))}).join('');
    return `<div class="filters stviews">${[['s','Single season'],['g','Single game']].map(([k,l])=>`<button class="btn${oscope===k?' solid':''}" type="button" data-os="${k}">${l}</button>`).join('')}</div><div class="filters"><label for="ofq">Find a player<input id="ofq" type="search" placeholder="Type a name" value="${esc(oq)}" autocomplete="off"></label></div>${cards?`<div class="hgrid">${cards}</div>`:'<p class="note">No records match.</p>'}<p class="note">Off-the-beaten-path stats: turnovers, quarterback rushing, special teams, penalties, blocked kicks and more. Regular season ${HIST.range[0]} to now from nflverse play data, so totals can differ slightly from official numbers. Longest field goals are single-game only.</p>`}
  function year(){
    const ys=Object.keys(HIST.newhi).map(Number).concat([2004,2025]);const yrs=[...new Set(ys)].filter(y=>y>=2004).sort((a,b)=>b-a);
    const Y=+oyear,nh=HIST.newhi[Y]||[];
    const stand=[],top10=[];
    Object.entries(HIST.all).forEach(([c,x])=>[['s','single-season'],['g','single-game']].forEach(([k,lab])=>(x[k]||[]).forEach((r,i)=>{const yr=k==='s'?r[2]:+r[3];if(yr===Y){const t={n:r[0],lab:`${lab} ${STATLAB[c]}`,v:fmtN(r[1]),rank:i+1,tied:i===0&&x[k][1]&&x[k][1][1]===r[1]};(i===0?stand:top10).push(t)}})));
    const row=t=>`<b>${esc(t.n)}</b> <span class="st">${esc(t.lab)}</span><em>${t.v}${t.rank>1?' · #'+t.rank:t.tied?' · tied':''}</em>`;
    return `<div class="filters"><label for="oyr">Year<select id="oyr">${yrs.map(y=>`<option${y===Y?' selected':''}>${y}</option>`).join('')}</select></label></div>
    <div class="yrsum"><div><b>${nh.length}</b><span>new highs since ${HIST.range[0]}</span></div><div><b>${stand.length}</b><span>all-time records set</span></div><div><b>${top10.length}</b><span>other all-time top-10 marks</span></div></div>
    <div class="hgrid">${list('New highs set in '+Y+' (beat every earlier season since '+HIST.range[0]+')',nh.map(r=>`<b>${esc(r[2])}</b> <span class="st">${esc(r[0].toLowerCase())}, ${r[1]} · ${T(r[3])} · was ${fmtN(r[5])}</span><em>${fmtN(r[4])}</em>`))||''}${list('All-time records set in '+Y,stand.map(row))}${list('Cracked the all-time top 10 in '+Y,top10.map(row))}</div>
    <p class="note">"New highs" compare each year's best single season or single game with every earlier year since ${HIST.range[0]} in this site's nflverse data, across ${HIST.odd.length+10} stat categories, starting in 2004 so the early years don't count by default. "All-time records set" are the standing league records (Pro Football Reference) whose record-setting year is the one chosen, across the ten main stats. A year with none listed means no current record was set that year, not that no record fell.</p>`}
  function sb(){return `<div class="stwrap"><table class="sttbl drt"><thead><tr><th>Game</th><th>Date</th><th>Winner</th><th>Score</th><th>Runner-up</th></tr></thead><tbody>${HIST.sb.slice().reverse().map(g=>`<tr><td><b>${esc(g.n)}</b></td><td>${esc(g.d)}</td><td>${tlogo(g.w,18)} ${esc(g.wn)}</td><td>${g.ws}–${g.ls}</td><td>${tlogo(g.l,18)} ${esc(g.ln)}</td></tr>`).join('')}</tbody></table></div>`}
  const rk=(a,b)=>[a,b].sort().join('|');
  const lead=(a,b)=>{const h=h2h(a,b);return h.a===h.b?`Series tied ${wl(h.a,h.b,h.t)}`:h.a>h.b?`${TI[a].nick} lead ${wl(h.a,h.b,h.t)}`:`${TI[b].nick} lead ${wl(h.b,h.a,h.t)}`};
  const meet=(g,hl)=>`<li><span class="st">${g[0]}${g[1]==='REG'?' wk '+g[2]:' '+g[1]}</span> ${T(g[5])} ${g[6]} at ${T(g[3])} ${g[4]}</li>`;
  function rivRow(a,b){const r=HIST.riv[rk(a,b)];if(!r)return '';const st=r.st[0]==='T'?'Last game a tie':`${TI[r.st[0]].nick} ${r.st[1]>1?'have won '+r.st[1]+' straight':'won the last meeting'}`;const key=rk(a,b)+(rteam?'':'x');
    const sa=a<b?[r.a,r.b]:[r.b,r.a];
    return `<div class="rvrow"><button type="button" class="rvb" data-rv="${key}" aria-expanded="${openR===key}">${tlogo(b,26)}<span class="rvn"><b>${esc(tname(b))}</b><span class="st">${lead(a,b)} all-time · since ${HIST.range[0]}: ${TI[a].nick} ${a<b?r.a:r.b}, ${TI[b].nick} ${a<b?r.b:r.a}${r.t?`, ${r.t} tie${r.t>1?'s':''}`:''}</span></span><span class="rvrec"><b>${(()=>{const h=h2h(a,b);return wl(h.a,h.b,h.t)})()}</b><span class="st">${esc(TI[a].nick)} all-time</span><span class="st">${st}</span></span></button>${openR===key?`<ul class="rvl">${r.last.slice().reverse().map(g=>meet(g)).join('')}</ul>`:''}</div>`}
  function riv(){
    const pick=`<div class="filters"><label for="rvteam">Team<select id="rvteam"><option value="">Overview</option>${TMS.map(t=>`<option value="${t}"${t===rteam?' selected':''}>${esc(tname(t))}</option>`).join('')}</select></label></div>`;
    if(rteam){const a=rteam,opp=TMS.filter(t=>t!==a),dv=opp.filter(t=>TI[t].div===TI[a].div),rest=opp.filter(t=>TI[t].div!==TI[a].div).sort((x,y)=>{const f=t=>{const h=h2h(a,t);return h.a+h.b+h.t};return f(y)-f(x)});
      return `${pick}<h3 class="scwk">Division rivals</h3>${dv.map(t=>rivRow(a,t)).join('')}<h3 class="scwk">Everyone else, most-played first</h3>${rest.map(t=>rivRow(a,t)).join('')}<p class="note">Tap a matchup for the last eight meetings. All-time series counts wins and losses only, from each franchise's first game.</p>`}
    const rec2=x=>{const h=h2h(x.a,x.b);return `${x.a} ${wl(h.a,h.b,h.t)}`};
    const all=Object.keys(HIST.riv).map(k=>{const [a,b]=k.split('|'),h=h2h(a,b);return {a,b,n:h.a+h.b+h.t,d:Math.abs(h.a-h.b)}});
    const li=(x,txt)=>`<li><button type="button" class="rvq" data-q="${x.a}|${x.b}">${tlogo(x.a,16)} ${esc(TI[x.a].nick)} vs ${tlogo(x.b,16)} ${esc(TI[x.b].nick)}</button><em>${txt}</em></li>`;
    const most=all.slice().sort((x,y)=>y.n-x.n).slice(0,10),close=all.filter(x=>x.n>=30).sort((x,y)=>x.d-y.d||y.n-x.n).slice(0,10),streak=Object.entries(HIST.riv).filter(([k,r])=>r.st[0]!=='T'&&r.n>=4).sort((x,y)=>y[1].st[1]-x[1].st[1]).slice(0,10);
    const dvr=all.filter(x=>TI[x.a].div===TI[x.b].div).sort((x,y)=>y.n-x.n).slice(0,10);
    return `${pick}<div class="hgrid"><div class="hcard"><h4>Most-played series</h4><ol>${most.map(x=>li(x,rec2(x)+' · '+x.n+' games')).join('')}</ol></div><div class="hcard"><h4>Closest series (30+ games)</h4><ol>${close.map(x=>li(x,rec2(x))).join('')}</ol></div><div class="hcard"><h4>Longest active winning streaks</h4><ol>${streak.map(([k,r])=>{const [a,b]=k.split('|');return `<li><button type="button" class="rvq" data-q="${k}">${tlogo(a,16)} ${esc(TI[a].nick)} vs ${tlogo(b,16)} ${esc(TI[b].nick)}</button><em>${TI[r.st[0]].nick} ${r.st[1]}</em></li>`}).join('')}</ol></div><div class="hcard"><h4>Division rivalries, most played</h4><ol>${dvr.map(x=>li(x,rec2(x)+' · '+x.n+' games')).join('')}</ol></div></div><p class="note">Streaks and recent meetings use games since ${HIST.range[0]}, including playoffs. Pick a team above to see every one of its rivalries.</p>`}
  function draw(){
    $('hiviews').querySelectorAll('[data-hv]').forEach(b=>b.classList.toggle('solid',b.dataset.hv===view));
    $('hieyebrow').textContent=`Records since ${HIST.range[0]} · Super Bowls I–${HIST.sb[HIST.sb.length-1].n}`;
    $('hibody').innerHTML={players,odd,year,teams,sb,riv}[view]();
  }
  $('hiviews').addEventListener('click',e=>{const b=e.target.closest('[data-hv]');if(b){view=b.dataset.hv;draw()}});
  $('hibody').addEventListener('click',e=>{
    const s=e.target.closest('[data-rs]');if(s){rsub=s.dataset.rs;draw();return}
    const os=e.target.closest('[data-os]');if(os){oscope=os.dataset.os;draw();return}
    const sc=e.target.closest('[data-rsc]');if(sc){rscope=sc.dataset.rsc;draw();return}
    const s2=e.target.closest('[data-rs2]');if(s2){rsub2=s2.dataset.rs2;draw();return}
    const r=e.target.closest('[data-rv]');if(r){openR=openR===r.dataset.rv?null:r.dataset.rv;draw();return}
    const q=e.target.closest('[data-q]');if(q){const [a,b]=q.dataset.q.split('|');rteam=a;openR=rk(a,b);draw()}});
  $('hibody').addEventListener('input',e=>{const id=e.target.id;
    if(id==='rvteam'){rteam=e.target.value;openR=null;draw()}
    else if(id==='rfpos'){rpos=e.target.value;if(rstat&&rpos&&!POSMAP[rpos].includes(rstat))rstat='';draw()}
    else if(id==='rfstat'){rstat=e.target.value;draw()}
    else if(id==='oyr'){oyear=e.target.value;draw()}
    else if(id==='ofq'){oq=e.target.value;const p=e.target.selectionStart;draw();const n=$('ofq');if(n){n.focus();try{n.setSelectionRange(p,p)}catch(er){}}}
    else if(id==='rfq'){rq=e.target.value;const p=e.target.selectionStart;draw();const n=$('rfq');if(n){n.focus();try{n.setSelectionRange(p,p)}catch(er){}}}});
  draw();
})();
/* ---------- What-if (inside Pick Your Wins) ---------- */
(function(){
  $('sbtoggle').addEventListener('click',()=>{const w=$('sbwrap');w.hidden=!w.hidden;$('sbtoggle').setAttribute('aria-expanded',String(!w.hidden));$('sbtoggle').textContent=w.hidden?'Open the what-if':'Close the what-if'});
  const KEY='bbn.sandbox.v1';let P={};try{P=JSON.parse(localStorage.getItem(KEY))||{}}catch(e){}
  const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(P))}catch(e){}};
  const R0=RK['2026'],rem=SEA.filter(g=>g.hs==null),wks=[...new Set(rem.map(g=>g.wk))].sort((a,b)=>a-b);
  rem.forEach(g=>{if(P[g.id]&&P[g.id]!==g.h&&P[g.id]!==g.a)delete P[g.id]});
  $('sbweek').innerHTML=wks.map(w=>`<option value="${w}">Week ${w}</option>`).join('');if(wks.length)$('sbweek').value=String(wks[0]);
  function rec(){const R={};Object.keys(R0).forEach(t=>R[t]={w:R0[t].w,l:R0[t].l,t:R0[t].t,pf:R0[t].pf,pa:R0[t].pa});
    rem.forEach(g=>{const w=P[g.id];if(!w)return;const l=w===g.h?g.a:g.h;R[w].w++;R[l].l++});return R}
  const pct=(R,t)=>{const d=R[t],n=d.w+d.l+d.t;return n?(d.w+d.t/2)/n:0};
  const cmp=R=>(a,b)=>pct(R,b)-pct(R,a)||(R[b].pf-R[b].pa)-(R[a].pf-R[a].pa)||(a<b?-1:1);
  const seeds=(R,c)=>{const f=cmp(R),ts=Object.keys(R).filter(t=>TI[t].conf===c),dv=[...new Set(ts.map(t=>TI[t].div))];
    const win=dv.map(d=>ts.filter(t=>TI[t].div===d).sort(f)[0]).sort(f),wc=ts.filter(t=>!win.includes(t)).sort(f);return {s:[...win,...wc.slice(0,3)],out:wc.slice(3,6),win}};
  function games(){const w=+$('sbweek').value;
    $('sbgames').innerHTML=`<h3 class="scwk">Week ${w}</h3><div class="scgrid">${rem.filter(g=>g.wk===w).map(g=>{const p=P[g.id];
      const b=t=>`<button type="button" class="sbt${p===t?' won':''}${p&&p!==t?' lost':''}" data-g="${g.id}" data-t="${t}">${tlogo(t,24)}<b>${esc(TI[t].nick)}</b><span class="st">${wl(R0[t].w,R0[t].l,R0[t].t)}</span></button>`;
      return `<div class="scg"><div class="sck">${kickTxt(g.d,g.t)}</div>${b(g.a)}<div class="at">at</div>${b(g.h)}</div>`}).join('')}</div>`}
  function out(){
    const R=rec(),n=Object.keys(P).length;
    $('sbcount').textContent=`${n} of ${rem.length} remaining games picked. Unpicked games count as not yet played.`;
    const tbl=c=>{const x=seeds(R,c),was=seeds(R0,c).s;
      const row=(t,i,tag)=>{const old=was.indexOf(t)+1,mv=old&&old!==i+1?(old>i+1?`<span class="up">▲${old-(i+1)}</span>`:`<span class="dn">▼${(i+1)-old}</span>`):old?'':'<span class="up">new</span>';
        return `<tr${i===6?' class="cutl"':''}><td>${i+1}</td><td>${tlogo(t,18)} <b>${esc(TI[t].nick)}</b> <span class="st">${tag}</span></td><td>${wl(R[t].w,R[t].l,R[t].t)}</td><td>${mv}</td></tr>`};
      return `<div><h4 class="rkg">${c}</h4><div class="stwrap"><table class="sttbl"><thead><tr><th>Seed</th><th>Team</th><th>Record</th><th>vs now</th></tr></thead><tbody>${x.s.map((t,i)=>row(t,i,i<4?'division winner':'wild card')).join('')}${x.out.map((t,i)=>row(t,7+i,'')).join('')}</tbody></table></div></div>`};
    $('sbout').innerHTML=`<div class="teamhead"><h2>Projected seeds</h2><span class="note">from your picks</span></div><div class="stgrid">${tbl('AFC')}${tbl('NFC')}</div><p class="note">Seeds use winning percentage, then point differential as it stands today (your picks change records only). Real tiebreakers are not applied.</p>`}
  $('sbgames').addEventListener('click',e=>{const b=e.target.closest('[data-g]');if(!b)return;const id=b.dataset.g;if(P[id]===b.dataset.t)delete P[id];else P[id]=b.dataset.t;save();games();out()});
  $('sbweek').addEventListener('input',games);
  $('sbclear').addEventListener('click',()=>{P={};save();games();out()});
  $('sbeyebrow').textContent=`${rem.length} games left · weeks ${wks[0]||'–'}–${wks[wks.length-1]||'–'}`;
  if(wks.length){games();out()}else{$('sbgames').innerHTML='<p class="note">The season is complete: no games left to pick.</p>'}
})();

/* ---------- My Team ---------- */
(function(){
  const KEY='bbn.myteam.v1';let team='',sec='overview',pos='QB';
  try{team=localStorage.getItem(KEY)||''}catch(e){}if(!TI[team])team='';
  const R=RK['2026'],tms=Object.keys(TI).sort((a,b)=>TI[a].name<TI[b].name?-1:1);
  const rec=(w,l,t)=>`${w}–${l}${t?'–'+t:''}`;
  const pct=(d)=>{const g=d.w+d.l+d.t;return g?(d.w+d.t/2)/g:0};
  const cmp=(a,b)=>pct(R[b])-pct(R[a])||(R[b].pf-R[b].pa)-(R[a].pf-R[a].pa)||(a<b?-1:1);
  function seedsOf(c){const ts=Object.keys(R).filter(t=>TI[t].conf===c),dv=[...new Set(ts.map(t=>TI[t].div))];
    const win=dv.map(d=>ts.filter(t=>TI[t].div===d).sort(cmp)[0]).sort(cmp),wc=ts.filter(t=>!win.includes(t)).sort(cmp);return [...win,...wc.slice(0,3)]}
  const ord=n=>{const s=['th','st','nd','rd'],v=n%100;return n+(s[(v-20)%10]||s[v]||s[0])};
  const topF=t=>{const x=TOPS[t];if(!x)return '–';return Math.floor(x.s/60)+':'+String(x.s%60).padStart(2,'0')};
  const tier=r=>r<=8?'g2':r<=16?'g1':r>=25?'b2':r>=17?'b1':'';
  const mine=()=>SEA.filter(g=>g.h===team||g.a===team).sort((a,b)=>a.wk-b.wk);
  const res=g=>{const home=g.h===team,me=home?g.hs:g.as,op=home?g.as:g.hs;return {k:me>op?'W':me<op?'L':'T',me,op,opp:home?g.a:g.h,home}};
  const ids=()=>PS['2026'].filter(r=>r[3]===team);
  function standing(){const d=Object.keys(R).filter(t=>TI[t].div===TI[team].div).sort(cmp),i=d.indexOf(team),s=seedsOf(TI[team].conf),si=s.indexOf(team);
    return {div:d,dpos:i+1,seed:si>=0?si+1:0,sd:s}}
  /* ---- picker ---- */
  function picker(){return `<div class="card"><div class="teamhead"><h2>Choose your team</h2><span class="count">saved on this device</span></div>
    <div class="mtgrid">${tms.map(t=>`<button type="button" class="mtchip" data-pick="${t}" style="--c1:${TI[t].c1};--c2:${TI[t].c2}">${tlogo(t,44)}<b>${esc(TI[t].nick)}</b><span>${rec(R[t].w,R[t].l,R[t].t)}</span></button>`).join('')}</div></div>`}
  /* ---- sections ---- */
  function overview(){
    const d=R[team],s=standing(),g=d.g||1,co=COACHES.find(c=>c[1]===team),all=mine(),fin=all.filter(x=>x.hs!=null),next=all.find(x=>x.hs==null);
    const core=PGS.flatMap(x=>x[1]).filter(r=>PGR[r[0]]&&PGR[r[0]][team]);const avg=core.reduce((a,r)=>a+PGR[r[0]][team],0)/(core.length||1);
    const tile=(a,b,c)=>`<div class="mtile"><b>${a}</b><span>${b}</span>${c?`<em>${c}</em>`:''}</div>`;
    const rk=k=>PGR[k]&&PGR[k][team];
    const form=fin.slice(-5).map(x=>{const r=res(x);return `<button type="button" class="mtform ${r.k}" ${GD[x.id]?`data-gr="${x.id}"`:''} title="Week ${x.wk}"><i>${r.k}</i><span>${r.home?'vs':'at'} ${TI[r.opp].nick}</span><b>${r.me}–${r.op}</b></button>`}).join('')||'<p class="note">No games played yet.</p>';
    let nx='<p class="note">No more games on the schedule.</p>';
    if(next){const home=next.h===team,opp=home?next.a:next.h,hh=h2h(team,opp),mf=t=>MFO[t]?`Offense #${MFO[t]} · Defense #${MFD[t]}`:'';
      nx=`<div class="mtnext"><div class="mtvs">${tlogo(team,52)}<b>${home?'vs':'at'}</b>${tlogo(opp,52)}</div><h3>Week ${next.wk}: ${esc(TI[opp].name)}</h3>
        <p class="note">${esc(kickTxt(next.d,next.t))} · ${home?'home':'away'}${next.sp!=null?` · ${next.sp===0?'pick-em':(next.sp>0?TI[next.h].nick:TI[next.a].nick)+' favored by '+Math.abs(next.sp)}`:''}</p>
        <p class="note">${esc(TI[opp].nick)} are ${rec(R[opp].w,R[opp].l,R[opp].t)} · ${mf(opp)} &nbsp;|&nbsp; You: ${mf(team)}</p>
        <p class="note">All-time series since 1999 (regular season and playoffs): ${hh.a}–${hh.b}${hh.t?'–'+hh.t:''}</p>
        <button type="button" class="btn" id="mtcmp">Compare per-game stats</button><div id="mtcmpbox" hidden></div></div>`}
    const rows=core.map(r=>({l:r[1],r:PGR[r[0]][team],v:r[4](r[3](d))})).sort((a,b)=>a.r-b.r);
    const chip=x=>`<li class="mtc ${tier(x.r)}"><span>${x.l}</span><b>#${x.r}</b><em>${x.v}</em></li>`;
    const dt=s.div.map((t,i)=>`<tr${t===team?' class="me"':''}><td>${i+1}</td><td>${tlogo(t,18)} <b>${esc(TI[t].nick)}</b></td><td>${rec(R[t].w,R[t].l,R[t].t)}</td><td>${R[t].pf}</td><td>${R[t].pa}</td><td>${(R[t].pf-R[t].pa>0?'+':'')+(R[t].pf-R[t].pa)}</td><td>${topF(t)}</td></tr>`).join('');
    return `<div class="mtgrid2">
      ${tile(rec(d.w,d.l,d.t),'Record',ord(s.dpos)+' in '+TI[team].div)}${tile(s.seed?'#'+s.seed:'—','Playoff seed',s.seed?(s.seed<=4?'division leader':'wild card'):'outside the top 7')}
      ${tile((d.pf/g).toFixed(1),'Points per game',rk('ppg')?'#'+rk('ppg')+' of 32':'')}${tile((d.pa/g).toFixed(1),'Allowed per game',rk('papg')?'#'+rk('papg')+' of 32':'')}
      ${tile((d.pf-d.pa>0?'+':'')+(d.pf-d.pa),'Point differential','#'+(1+Object.keys(R).filter(t=>R[t].pf-R[t].pa>d.pf-d.pa).length)+' of '+Object.keys(R).length)}${tile(avg.toFixed(1),'Average stat rank','of 32, lower is better')}</div>
      <div class="card"><h3 class="mth">Next up</h3>${nx}</div>
      <div class="card"><h3 class="mth">Last five games <span class="note">tap one for the game review</span></h3><div class="mtforms">${form}</div></div>
      <div class="mtcols"><div class="card"><h3 class="mth">Strengths</h3><ul class="mtcl">${rows.slice(0,6).map(chip).join('')}</ul></div><div class="card"><h3 class="mth">Weaknesses</h3><ul class="mtcl">${rows.slice(-6).reverse().map(chip).join('')}</ul></div></div>
      <div class="card"><h3 class="mth">${esc(TI[team].div)}</h3><div class="stwrap"><table class="sttbl mtdiv"><thead><tr><th>#</th><th>Team</th><th>W–L–T</th><th title="Points for">PF</th><th title="Points against">PA</th><th>Diff</th><th title="Average time of possession per game">TOP</th></tr></thead><tbody>${dt}</tbody></table></div>${co?`<p class="note">Head coach: <b>${esc(co[0])}</b> · career ${rec(co[2],co[3],co[4])} (${(co[5]*100).toFixed(1)}%) · last six seasons ${rec(co[6],co[7],co[8])}</p>`:''}</div>`}
  function schedule(){
    const all=mine(),byWk={};all.forEach(g=>byWk[g.wk]=g);const wks=[...new Set(SEA.map(g=>g.wk))].sort((a,b)=>a-b);
    let w=0,l=0,t=0;const sp={home:[0,0],away:[0,0],div:[0,0],conf:[0,0]};
    const rows=wks.map(wk=>{const g=byWk[wk];if(!g)return `<div class="mtsr bye"><span class="mtw">${wk}</span><span class="mto">Bye week</span></div>`;
      const home=g.h===team,opp=home?g.a:g.h,fin=g.hs!=null;
      if(fin){const r=res(g);if(r.k==='W')w++;else if(r.k==='L')l++;else t++;
        const i=r.k==='W'?0:r.k==='L'?1:-1;if(i>=0){sp[home?'home':'away'][i]++;if(TI[opp].div===TI[team].div)sp.div[i]++;if(TI[opp].conf===TI[team].conf)sp.conf[i]++}
        return `<button type="button" class="mtsr fin ${r.k}" ${GD[g.id]?`data-gr="${g.id}"`:''}><span class="mtw">${wk}</span><span class="mto">${tlogo(opp,24)} <b>${home?'vs':'at'} ${esc(TI[opp].name)}</b></span><span class="mtres"><i>${r.k}</i> ${r.me}–${r.op}</span><span class="mtrec">${rec(w,l,t)}</span></button>`}
      return `<div class="mtsr up"><span class="mtw">${wk}</span><span class="mto">${tlogo(opp,24)} <b>${home?'vs':'at'} ${esc(TI[opp].name)}</b></span><span class="mtres">${esc(fmtDay(g.d))}</span><span class="mtrec">${g.sp!=null?(g.sp===0?'pick-em':(g.sp>0?TI[g.h].nick:TI[g.a].nick)+' -'+Math.abs(g.sp)):''}</span></div>`}).join('');
    const split=(n,v)=>`<div class="mtile"><b>${v[0]}–${v[1]}</b><span>${n}</span></div>`;
    return `<div class="mtgrid2">${split('At home',sp.home)}${split('On the road',sp.away)}${split('In the division',sp.div)}${split('In the conference',sp.conf)}</div>
      <div class="card"><h3 class="mth">2026 schedule <span class="note">tap a finished game for its review</span></h3><div class="mtsch">${rows}</div></div>`}
  function stats(){
    const d=R[team];
    return `<div class="card"><div class="teamhead"><h2>Per-game stats</h2><span class="count">through week ${LASTWK} · ${d.g} games</span></div><p class="note">Bar length shows league rank: a full bar is #1 of 32. Green is top tier, red is bottom tier.</p>`+
      PGS.map(([grp,rows])=>`<h4 class="rkg">${grp}</h4><div class="mtbars">${rows.map(([k,lab,low,fn,fmt])=>{const r=PGR[k][team];return `<div class="mtb"><span class="mtbl">${lab}${low?'<small> lower is better</small>':''}</span><span class="mtbt"><i class="${tier(r)}" style="width:${Math.max(4,(33-r)/32*100)}%"></i></span><span class="mtbv"><b>${fmt(fn(d))}</b><s>#${r}</s></span></div>`}).join('')}</div>`).join('')+`</div>`}
  const POSG={QB:['QB'],RB:['RB','FB'],WR:['WR'],TE:['TE'],DEF:['DL','DE','DT','LB','OLB','ILB','MLB','DB','CB','S','FS','SS','NT','EDGE'],K:['K','P']};
  const g=(r,k)=>r[8][KI[k]]||0;
  function line(r,p){
    if(p==='QB')return `${g(r,'cmp')}/${g(r,'att')}, ${g(r,'pyd')} yds, ${g(r,'ptd')} TD, ${g(r,'int')} INT`+(g(r,'ryd')?` · ${g(r,'ryd')} rush`:'');
    if(p==='RB')return `${g(r,'car')} car, ${g(r,'ryd')} yds, ${g(r,'rtd')} TD · ${g(r,'rec')} rec, ${g(r,'yds')} yds`;
    if(p==='WR'||p==='TE')return `${g(r,'rec')} rec / ${g(r,'tgt')} tgt, ${g(r,'yds')} yds, ${g(r,'td')} TD`;
    if(p==='DEF')return `${g(r,'tks')+g(r,'tka')} tkl, ${g(r,'dsk')} sck, ${g(r,'dint')} int, ${g(r,'pd')} pd`;
    return `FG ${g(r,'fgm')}/${g(r,'fga')} (50+: ${g(r,'fg50')+g(r,'fg60')}) · XP ${g(r,'xpm')}/${g(r,'xpa')}`}
  const key=(r,p)=>p==='QB'?g(r,'pyd'):p==='RB'?g(r,'ryd')+g(r,'yds')*.5:p==='DEF'?g(r,'tks')+g(r,'tka')+g(r,'dsk')*4+g(r,'dint')*5:p==='K'?g(r,'fgm')*3+g(r,'xpm'):g(r,'yds');
  function players(){
    const list=ids().filter(r=>r[5]>0&&(POSG[pos]||[]).includes(r[2])).sort((a,b)=>key(b,pos)-key(a,pos)).slice(0,pos==='DEF'?20:10);
    const pills=Object.keys(POSG).map(p=>`<button type="button" class="btn${p===pos?' solid':''}" data-mpos="${p}">${p==='DEF'?'Defense':p==='K'?'Kickers':p}</button>`).join('');
    const top=['QB','RB','WR','DEF'].map(p=>{const r=ids().filter(x=>x[5]>0&&POSG[p].includes(x[2])).sort((a,b)=>key(b,p)-key(a,p))[0];return r?`<div class="mtile mtlead"><span>${p==='DEF'?'Defensive leader':p+' leader'}</span><b>${esc(r[1])}</b><em>${esc(line(r,p))}</em></div>`:''}).join('');
    return `<div class="mtgrid2 two">${top}</div><div class="card"><div class="teamhead"><h2>Roster stats</h2><span class="count">2026 · games played</span></div><div class="filters stviews">${pills}</div>
      <div class="mtpl">${list.map((r,i)=>`<div class="mtp"><span class="mtn">${i+1}</span><div><b>${esc(r[1])}</b> <span class="st">${esc(r[2])}${r[4]?' · #'+esc(r[4]):''} · ${r[5]} gp</span> ${injchip(r[0])}<div class="note">${esc(line(r,pos))}</div></div></div>`).join('')||'<p class="note">No stats for this group yet.</p>'}</div></div>`}
  function injuries(){
    const L=ids().map(r=>({r,x:INJS(r[0])})).filter(o=>o.x),order={Out:0,Doubtful:1,Questionable:2};
    L.sort((a,b)=>(order[a.x.s]??3)-(order[b.x.s]??3)||b.r[6]-a.r[6]);
    return `<div class="card"><div class="teamhead"><h2>Injury report</h2><span class="count">week ${INJ.wk} report</span></div>${L.length?`<div class="mtpl">${L.map(o=>`<div class="mtp"><span class="mtn">${esc(o.r[2])}</span><div><b>${esc(o.r[1])}</b> ${injchip(o.r[0])}<div class="note">${o.r[5]} games played this season</div></div></div>`).join('')}</div>`:'<p class="note">No players listed on the latest report.</p>'}
      <p class="note">From the most recent official injury report in the data feed. Check the team for the latest status before kickoff.</p></div>`}
  function history(){
    const fr=HIST.fr[team]||{},fl=Object.entries(fr).map(([c,x])=>`<tr><td>${esc(HIST.rec[c]?HIST.rec[c].l:c)}</td><td><b>${esc(x.s[0])}</b><br><span class="st">${fmtN(x.s[2])} (${x.s[1]})</span></td><td><b>${esc(x.c[0])}</b><br><span class="st">${fmtN(x.c[3])} (${x.c[1]}–${x.c[2]})</span></td><td><b>${esc(x.g[0])}</b><br><span class="st">${fmtN(x.g[4])} (${x.g[1]})</span></td></tr>`).join('');
    const riv=Object.entries(HIST.riv).filter(([k])=>k.split('|').includes(team)).map(([k,v])=>{const [a,b]=k.split('|'),me=a===team,opp=me?b:a,w=me?v.a:v.b,l=me?v.b:v.a,lm=v.last[v.last.length-1];return {opp,w,l,t:v.t,n:v.n,lm}}).sort((x,y)=>y.n-x.n).slice(0,8);
    const rv=riv.map(x=>`<tr><td>${tlogo(x.opp,18)} <b>${esc(TI[x.opp].nick)}</b></td><td class="mono">${rec(x.w,x.l,x.t)}</td><td class="st">${x.lm?`${lm0(x.lm)}`:''}</td></tr>`).join('');
    function lm0(m){const mine=m[3]===team?[m[4],m[6]]:[m[6],m[4]];return `${m[0]} wk ${m[2]}: ${mine[0]>mine[1]?'W':mine[0]<mine[1]?'L':'T'} ${mine[0]}–${mine[1]}`}
    const sb=HIST.sb.filter(s=>s.w===team||s.l===team),sbw=sb.filter(s=>s.w===team);
    const dr=DRAFT.filter(r=>r[0]===2026&&r[3]===team).sort((a,b)=>a[2]-b[2]);
    return `<div class="mtgrid2 two"><div class="mtile"><b>${sbw.length}</b><span>Super Bowl wins</span><em>${sbw.map(s=>s.n).join(', ')||'none yet'}</em></div><div class="mtile"><b>${sb.length}</b><span>Super Bowl appearances</span><em>${sb.map(s=>s.n+(s.w===team?' W':' L')).join(', ')||'none yet'}</em></div></div>
      <div class="card"><h3 class="mth">Franchise records <span class="note">since ${HIST.range[0]}</span></h3><div class="tablebox"><table class="sttbl"><thead><tr><th>Stat</th><th>Season</th><th>Career with team</th><th>Single game</th></tr></thead><tbody>${fl}</tbody></table></div></div>
      <div class="card"><h3 class="mth">Biggest rivalries <span class="note">most meetings since 1999</span></h3><div class="stwrap"><table class="sttbl"><thead><tr><th>Opponent</th><th>Your record</th><th>Last meeting</th></tr></thead><tbody>${rv}</tbody></table></div></div>
      ${dr.length?`<div class="card"><h3 class="mth">2026 draft class</h3><div class="mtpl">${dr.map(r=>`<div class="mtp"><span class="mtn">R${r[1]}</span><div><b>${esc(r[4])}</b> <span class="st">${esc(r[5])} · ${esc(r[6])} · pick ${r[2]}</span></div></div>`).join('')}</div></div>`:''}`}
  const SECS=[['overview','Overview'],['schedule','Schedule'],['stats','Stats'],['players','Players'],['injuries','Injuries'],['history','History']];
  function draw(){const el=$('mtbody');
    if(!team){$('mthero').innerHTML='';$('mtnav').innerHTML='';el.innerHTML=picker();return}
    const d=R[team],s=standing(),i=TI[team],co=COACHES.find(c=>c[1]===team);
    $('mthero').innerHTML=`<div class="mthero" style="--c1:${i.c1};--c2:${i.c2}">${tlogo(team,84)}<div><div class="mteye">${i.conf} · ${i.div.replace(/^(AFC|NFC) /,'')}</div><h2>${esc(i.name)}</h2><div class="mtsub"><b>${rec(d.w,d.l,d.t)}</b> · ${ord(s.dpos)} in division${s.seed?` · #${s.seed} seed`:''} ${TSTK[team]?tstreak(team):''}</div>${co?`<div class="mtsub">Coach ${esc(co[0])}</div>`:''}</div><button type="button" class="btn" id="mtchange">Change team</button></div>`;
    $('mtnav').innerHTML=SECS.map(([k,l])=>`<button type="button" class="btn${k===sec?' solid':''}" data-msec="${k}">${l}</button>`).join('');
    el.innerHTML=({overview,schedule,stats,players,injuries,history})[sec]();
  }
  $('myteam').addEventListener('click',e=>{
    const p=e.target.closest('[data-pick]');if(p){team=p.dataset.pick;try{localStorage.setItem(KEY,team)}catch(er){}sec='overview';draw();window.scrollTo(0,0);return}
    if(e.target.closest('#mtchange')){team='';draw();return}
    const s=e.target.closest('[data-msec]');if(s){sec=s.dataset.msec;draw();return}
    const m=e.target.closest('[data-mpos]');if(m){pos=m.dataset.mpos;draw();return}
    const gr=e.target.closest('[data-gr]');if(gr&&window.__openGame){window.__openGame(gr.dataset.gr);return}
    if(e.target.id==='mtcmp'){const nx=mine().find(x=>x.hs==null),b=$('mtcmpbox');if(nx){b.hidden=!b.hidden;if(!b.hidden)b.innerHTML=moreStats(nx)}}});
  draw();
})();

/* ---------- sideways-scroll hints for wide tables ---------- */
(function(){
  const SEL='.stwrap,.tablebox,.gridwrap';let q=false;
  const touch=('ontouchstart' in window)||navigator.maxTouchPoints>0;
  function upd(el){
    const over=el.scrollWidth-el.clientWidth>6,left=el.scrollLeft>6,right=el.scrollLeft+el.clientWidth<el.scrollWidth-6;
    el.classList.toggle('hs-l',over&&left);el.classList.toggle('hs-r',over&&right);
    let h=el.previousElementSibling;if(h&&!h.classList.contains('swhint'))h=null;
    if(over&&!h){h=document.createElement('div');h.className='swhint';h.setAttribute('aria-hidden','true');el.parentNode.insertBefore(h,el)}
    if(h){h.innerHTML=right?`<span>${left?'‹ ':''}${touch?'Swipe':'Scroll'} sideways for more <b>›</b></span>`:`<span>‹ ${touch?'Swipe':'Scroll'} back to see the first columns</span>`;h.hidden=!over||(!right&&!left)}
  }
  function navh(){const n=document.querySelector('.sitenav');document.documentElement.style.setProperty('--navh',(n?n.offsetHeight:0)+'px')}
  function all(){q=false;navh();document.querySelectorAll(SEL).forEach(el=>{if(el.offsetParent!==null)upd(el)})}
  const sched=()=>{if(!q){q=true;requestAnimationFrame(all)}};
  new MutationObserver(sched).observe(document.body,{childList:true,subtree:true});
  window.addEventListener('resize',sched);
  document.addEventListener('scroll',e=>{const t=e.target;if(t&&t.matches&&t.matches(SEL))upd(t)},true);
  document.addEventListener('click',()=>setTimeout(sched,50));
  sched();
})();

/* ---------- share button ---------- */
(function(){
  const URL_='https://joshliberty03.github.io/NFL/',TITLE="Tyler's NFL APP",TEXT='Scores, standings, stats, picks and fantasy for the 2026 NFL season:';
  const btn=document.getElementById('sharebtn');if(!btn)return;
  const p=document.createElement('div');p.className='sharepanel';p.hidden=true;p.setAttribute('role','dialog');p.setAttribute('aria-label','Share this app');
  const canShare=typeof navigator.share==='function';
  p.innerHTML='<h3>Share with friends</h3><p>Send this link. No sign-in needed, it opens right in their browser.</p><input id="shurl" readonly value="'+URL_+'" aria-label="Link"><div class="shrow">'+(canShare?'<button class="pri" id="shnative" type="button">Share…</button>':'')+'<button id="shcopy" class="'+(canShare?'':'pri')+'" type="button">Copy link</button></div><div class="shmsg" id="shmsg" role="status"></div>';
  document.body.appendChild(p);
  const msg=t=>{const m=document.getElementById('shmsg');m.textContent=t;clearTimeout(msg.t);msg.t=setTimeout(()=>{m.textContent=''},2500)};
  const close=()=>{p.hidden=true;btn.setAttribute('aria-expanded','false')};
  btn.addEventListener('click',e=>{e.stopPropagation();p.hidden=!p.hidden;btn.setAttribute('aria-expanded',String(!p.hidden));if(!p.hidden){const n=document.querySelector('.sitenav');document.documentElement.style.setProperty('--navh',(n?n.offsetHeight:56)+'px')}});
  document.addEventListener('click',e=>{if(!p.hidden&&!p.contains(e.target))close()});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
  p.addEventListener('click',async e=>{
    const inp=document.getElementById('shurl');
    if(e.target.id==='shnative'){try{await navigator.share({title:TITLE,text:TEXT,url:URL_})}catch(er){}return}
    if(e.target.id==='shcopy'){
      let ok=false;try{await navigator.clipboard.writeText(URL_);ok=true}catch(er){}
      if(!ok){try{inp.focus();inp.select();inp.setSelectionRange(0,999);ok=document.execCommand('copy')}catch(er){}}
      if(ok)msg('Link copied. Paste it in a text or chat.');else{inp.focus();inp.select();msg('Press and hold the link, then choose Copy.')}
    }});
  var inp_=document.getElementById('shurl');inp_.addEventListener('focus',()=>inp_.select());
})();
