import json, random, collections, sys
H = json.load(open(sys.argv[1]))
MASTER={11,22,33}
def red(n):
    while n>9 and n not in MASTER: n=sum(int(d) for d in str(n))
    return n
def lifep(b):
    y,m,d=b.split("-"); return red(red(int(m))+red(int(d))+red(sum(map(int,y))))
exec(open(sys.argv[2]).read().split("RELOC")[0].split("FOUNDED = ",1)[0])  # nothing
FOUNDED = eval(open(sys.argv[2]).read().split("FOUNDED = ",1)[1].split("\n}\n")[0]+"\n}")
LP = {t: lifep(b) for t,b in FOUNDED.items() if b}
w=collections.Counter(); n=collections.Counter()
for s,wk,ty,d,h,a,hs,as_,*_ in H["games"]:
    if s>=2026 or hs==as_: continue
    w[h]+=hs>as_; w[a]+=as_>hs; n[h]+=1; n[a]+=1
teams=sorted(LP); rate={t:w[t]/n[t] for t in teams}
def spread(lab):
    g=collections.defaultdict(list)
    for t in teams: g[lab[t]].append(rate[t])
    m=sum(rate.values())/len(teams)
    return sum(len(v)*(sum(v)/len(v)-m)**2 for v in g.values())
obs=spread(LP); labels=[LP[t] for t in teams]; ge=0; random.seed(7)
for _ in range(20000):
    random.shuffle(labels); ge+= spread(dict(zip(teams,labels)))>=obs-1e-12
print("team-level p:", (ge+1)/20001)
g=collections.defaultdict(list)
for t in teams: g[LP[t]].append((t,round(rate[t],3)))
for k in sorted(g): print(k, g[k])
