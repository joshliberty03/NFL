/* ===================== REPORT A PROBLEM ===================== */
(function(){
  const REPORT_KEY='';   // Web3Forms access key (public by design); empty = copy / GitHub-issue fallback only
  const REPO='https://github.com/joshliberty03/NFL/issues/new';
  const btn=document.getElementById('reportbtn');if(!btn)return;
  const errs=[];
  window.addEventListener('error',e=>{errs.push((e.message||'error')+(e.filename?' @'+String(e.filename).split('/').pop()+':'+e.lineno:''));if(errs.length>6)errs.shift()});
  window.addEventListener('unhandledrejection',e=>{errs.push('promise: '+String(e.reason&&e.reason.message||e.reason).slice(0,160));if(errs.length>6)errs.shift()});
  const CATS=['Wrong or missing data','Something looks broken','A game is buggy','Slow or crashing','Idea or request','Other'];
  const ov=document.createElement('div');ov.className='rpov';ov.hidden=true;
  ov.innerHTML=`<div class="rpbox" role="dialog" aria-modal="true" aria-labelledby="rptitle">
    <button class="rpx" type="button" id="rpclose" aria-label="Close">×</button>
    <h2 id="rptitle">Report a problem</h2>
    <p class="rpsub">Tell me what went wrong and I'll look into it. Details about your screen are added for you.</p>
    <form id="rpform" novalidate>
      <label>What kind of problem?<select id="rpcat">${CATS.map(c=>`<option>${c}</option>`).join('')}</select></label>
      <label>What happened?<textarea id="rptext" rows="5" maxlength="2000" placeholder="Example: On Standings, the Eagles show 5-2 but the Scores tab says 4-3." required></textarea></label>
      <label>Your name or email <span class="rpopt">(optional, only if you want a reply)</span><input id="rpcontact" type="text" maxlength="120" autocomplete="off"></label>
      <input id="rpbot" type="text" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px;opacity:0;height:0">
      <details class="rpdet"><summary>Details that will be included</summary><pre id="rpinfo"></pre></details>
      <div class="rpact"><button class="btn solid" type="submit" id="rpsend">Send report</button><button class="btn" type="button" id="rpcancel">Cancel</button></div>
      <p class="rpmsg" id="rpmsg" role="status" aria-live="polite"></p>
    </form>
    <div class="rpfall" id="rpfall" hidden>
      <p><b>Couldn't send it automatically.</b> You can still get it to me:</p>
      <textarea id="rpout" rows="6" readonly></textarea>
      <div class="rpact"><button class="btn solid" type="button" id="rpcopy">Copy report</button><a class="btn" id="rpgh" target="_blank" rel="noopener">Open on GitHub</a></div>
      <p class="rpsub">Paste the copied text into a message to Tyler, or post it on GitHub if you have an account.</p>
    </div>
  </div>`;
  document.body.appendChild(ov);
  const $=id=>ov.querySelector('#'+id);
  function screenName(){const s=document.querySelector('section.screen:not([hidden])');return s?s.id:'?'}
  function diag(){
    let built='';try{built=typeof BUILT!=='undefined'?new Date(+BUILT).toISOString().replace('T',' ').slice(0,16)+' UTC':''}catch(e){}
    let game='';try{if(window.__gm&&window.__gm.run()&&window.__gm.run()._t){const G=window.__gm.run()._t.state();if(G)game=` showdown q${G.q} ${G.score.join('-')} phase:${G.phase}`}}catch(e){}
    return [`Tab: ${screenName()}${location.hash||''}`,`Page: ${location.origin}${location.pathname}`,`Data built: ${built||'unknown'}`,
      `Screen: ${innerWidth}x${innerHeight} @${devicePixelRatio||1}x${matchMedia('(display-mode: standalone)').matches?' (installed app)':''}`,
      `Browser: ${navigator.userAgent}`,`Online: ${navigator.onLine}`,errs.length?`Recent errors: ${errs.join(' | ')}`:'Recent errors: none'+(game?'':'')].concat(game?[`Game:${game}`]:[]).join('\n');
  }
  function build(){return `[${$('rpcat').value}]\n${$('rptext').value.trim()}\n\nContact: ${$('rpcontact').value.trim()||'(none)'}\n\n--- details ---\n${diag()}`}
  function open(){ov.hidden=false;$('rpform').hidden=false;$('rpfall').hidden=true;$('rpmsg').textContent='';$('rpinfo').textContent=diag();document.body.style.overflow='hidden';setTimeout(()=>$('rptext').focus(),30)}
  function close(){ov.hidden=true;document.body.style.overflow='';btn.focus()}
  btn.addEventListener('click',open);
  $('rpclose').onclick=close;$('rpcancel').onclick=close;
  ov.addEventListener('click',e=>{if(e.target===ov)close()});
  document.addEventListener('keydown',e=>{if(!ov.hidden&&e.key==='Escape')close()});
  function fallback(){
    const t=build();$('rpform').hidden=true;$('rpfall').hidden=false;$('rpout').value=t;
    const body=t.replace(/\nContact:.*\n/,'\n');
    $('rpgh').href=REPO+'?title='+encodeURIComponent('Problem: '+$('rpcat').value)+'&body='+encodeURIComponent(body.slice(0,5500));
  }
  $('rpcopy').onclick=async()=>{const ta=$('rpout');let ok=false;try{await navigator.clipboard.writeText(ta.value);ok=true}catch(e){}
    if(!ok){ta.focus();ta.select();try{ok=document.execCommand('copy')}catch(e){}}$('rpcopy').textContent=ok?'Copied!':'Press and hold the text to copy'};
  $('rpform').addEventListener('submit',async e=>{
    e.preventDefault();const msg=$('rpmsg');
    if($('rpbot').value)return;
    if($('rptext').value.trim().length<8){msg.textContent='Please describe what went wrong (a sentence is fine).';$('rptext').focus();return}
    let last=0;try{last=+localStorage.getItem('rp.last')||0}catch(er){}
    if(Date.now()-last<30000){msg.textContent='Thanks. Please wait a few seconds before sending another one.';return}
    if(!REPORT_KEY||!navigator.onLine){return fallback()}
    $('rpsend').disabled=true;msg.textContent='Sending…';
    try{
      const r=await fetch('https://api.web3forms.com/submit',{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({access_key:REPORT_KEY,subject:"[NFL APP report] "+$('rpcat').value+" ("+screenName()+")",from_name:$('rpcontact').value.trim()||'NFL APP visitor',message:build(),botcheck:''})});
      const j=await r.json();
      if(j&&j.success){try{localStorage.setItem('rp.last',String(Date.now()))}catch(er){}$('rpform').reset();msg.textContent='';$('rpform').hidden=true;
        const d=document.createElement('div');d.className='rpdone';d.innerHTML='<b>Thank you!</b><p>Your report was sent. I will take a look.</p><button class="btn solid" type="button">Close</button>';d.querySelector('button').onclick=()=>{d.remove();close()};$('rpform').after(d)}
      else throw new Error('rejected')
    }catch(er){$('rpsend').disabled=false;msg.textContent='';fallback()}
  });
})();
