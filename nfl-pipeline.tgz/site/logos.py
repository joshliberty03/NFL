# Builds logos.json: {ABBR: data-URI} from a folder of PNGs named like KC.png. Empty {} when no folder.
import os,json,base64,io,sys
out={}
d=sys.argv[1] if len(sys.argv)>1 else 'logos'
if os.path.isdir(d):
    from PIL import Image
    for f in sorted(os.listdir(d)):
        b,e=os.path.splitext(f)
        if e.lower() not in('.png','.webp','.jpg','.jpeg','.svg'):continue
        try:
            im=Image.open(os.path.join(d,f)).convert('RGBA');im.thumbnail((128,128))
            buf=io.BytesIO();im.save(buf,'PNG',optimize=True)
            out[b.upper()]='data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode()
        except Exception as ex:print('skip',f,ex)
json.dump(out,open('logos.json','w'),separators=(',',':'))
print(len(out),'logos')
