"""Index who played in each 2026 game, keyed to the player list used by the page."""
import csv, json, sys, re, collections
roster_csv, snaps_csv, players_json, step2_json, out = sys.argv[1:6]
def norm(n):
    n = re.sub(r"[^a-z ]", "", n.lower().replace("-", " "))
    return " ".join(w for w in n.split() if w not in {"jr", "sr", "ii", "iii", "iv", "v"})
P = json.load(open(players_json))           # [name, team, pos, status, birth, lp]
games = [g for g in json.load(open(step2_json))["games"] if g["played"]]
gidx = {g["game_id"]: i for i, g in enumerate(games)}
# map pfr id -> roster identity (name, birth) so traded players resolve to their current row
pfr = {}
for r in csv.DictReader(open(roster_csv, newline="", encoding="utf-8")):
    if r["pfr_id"] and r["birth_date"]: pfr[r["pfr_id"]] = (norm(r["full_name"]), r["birth_date"])
key = {}
for i, p in enumerate(P): key.setdefault((norm(p[0]), p[4]), i)
byname = collections.defaultdict(list)
for i, p in enumerate(P): byname[norm(p[0])].append(i)
apps = collections.defaultdict(list); unmatched = 0; total = 0
for r in csv.DictReader(open(snaps_csv, newline="", encoding="utf-8")):
    if r["game_id"] not in gidx: continue
    if sum(float(r[k] or 0) for k in ("offense_snaps", "defense_snaps", "st_snaps")) <= 0: continue
    total += 1
    i = None
    if r["pfr_player_id"] in pfr: i = key.get(pfr[r["pfr_player_id"]])
    if i is None:
        c = byname.get(norm(r["player"]), [])
        c2 = [j for j in c if P[j][1] == r["team"]]
        i = (c2 or c or [None])[0] if len(c2) == 1 or len(c) == 1 else None
    if i is None: unmatched += 1; continue
    apps[i].append([gidx[r["game_id"]], r["team"]])
print("appearances", total, "matched to current players", total - unmatched, "players with games", len(apps))
json.dump({"g": [[g["game_id"], g["date"], g["away"], g["home"], g["away_score"], g["home_score"], g["winner"], g["universal_day"]] for g in games],
           "a": {str(k): v for k, v in apps.items()}}, open(out, "w"), separators=(",", ":"))
