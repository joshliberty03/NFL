/* ===================== GAME ROOM (hub + mini-games) ===================== */
const TEAMCOL=__TEAMCOL__;
(function(){
  const sec=document.getElementById('games');if(!sec)return;
  const rnd=Math.random,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const bestGet=id=>{try{return +localStorage.getItem('gm.best.'+id)||0}catch(e){return 0}};
  const bestSet=(id,v)=>{try{localStorage.setItem('gm.best.'+id,String(v))}catch(e){}};
  const WEB='https://joshliberty03.github.io/NFL/';
  function cvs(stage,w,h){stage.innerHTML='';const c=document.createElement('canvas');c.width=w;c.height=h;c.className='gmcv';c.style.maxWidth=w+'px';stage.appendChild(c);return[c,c.getContext('2d')]}
  function loopFn(fn){let id=0,last=0,dead=false;const f=ts=>{if(dead)return;id=requestAnimationFrame(f);if(!last)last=ts;const dt=Math.min(.05,(ts-last)/1000);last=ts;fn(dt)};id=requestAnimationFrame(f);return()=>{dead=true;cancelAnimationFrame(id)}}
  function txt(ctx,s,x,y,sz,col,al,bold){ctx.font=(bold===false?'':'bold ')+sz+'px "Oswald","Arial Narrow",sans-serif';ctx.fillStyle=col||'#fff';ctx.textAlign=al||'center';ctx.textBaseline='middle';ctx.fillText(s,x,y)}
  function ptr(c,e){const r=c.getBoundingClientRect();return[(e.clientX-r.left)*c.width/r.width,(e.clientY-r.top)*c.height/r.height]}

  /* ---------------- 1. Field Goal Kicker ---------------- */
  function kicker(stage,api){
    const W=320,H=440,[c,ctx]=cvs(stage,W,H);let stopL;
    const S={i:0,n:5,score:0,phase:'aim',t:0,aim:0,pow:0,dist:30,wind:0,fl:0,res:null,msgT:0,best:api.best()};
    function newKick(){S.dist=Math.round(24+rnd()*34);S.wind=Math.round((rnd()*2-1)*14);S.phase='aim';S.t=0;S.res=null}
    newKick();
    const goalS=()=>clamp(44/S.dist,.55,1.3);
    function act(){
      if(S.phase==='aim'){S.aimv=S.aim;S.phase='power';S.t=0}
      else if(S.phase==='power'){S.powv=S.pow;resolve();S.phase='fly';S.fl=0}
      else if(S.phase==='result'&&S.msgT>.5){S.i++;if(S.i>=S.n){S.phase='end';if(S.score>S.best){S.best=S.score;api.save(S.score)}}else newKick()}
      else if(S.phase==='end'&&S.msgT>.4){S.i=0;S.score=0;newKick()}
    }
    function resolve(){
      const pn=Math.min(.97,.42+S.dist/100),over=Math.max(0,S.powv-pn);
      const drift=S.wind/14*(S.dist/55)*.34,hook=over*(S.aimv>=0?1:-1)*.7*(S.dist>40?1:.8);
      S.lat=S.aimv*.5+drift+hook;S.short=S.powv<pn-.07;
      const half=.22;
      if(S.short)S.res={ok:false,txt:'SHORT. Not enough leg.'};
      else if(Math.abs(S.lat)<half){const bonus=(S.dist>=45?2:0)+(Math.abs(S.lat)<.07?1:0);S.pts=3+bonus;S.res={ok:true,txt:`IT'S GOOD! +${S.pts}`}}
      else if(Math.abs(S.lat)<half+.07)S.res={ok:false,txt:'DOINK! Off the upright.'};
      else S.res={ok:false,txt:S.lat>0?'WIDE RIGHT':'WIDE LEFT'};
    }
    c.addEventListener('pointerdown',e=>{e.preventDefault();act()});
    const kd=e=>{if(e.key===' '||e.key==='Enter'){if(sec.hidden)return;e.preventDefault();act()}};window.addEventListener('keydown',kd);
    stopL=loopFn(dt=>{
      S.t+=dt;S.msgT+=dt;
      if(S.phase==='aim')S.aim=Math.sin(S.t*(2.1+S.i*.35))*1;
      if(S.phase==='power'){const p=(S.t*(1.25+S.i*.1))%2;S.pow=p<1?p:2-p}
      if(S.phase==='fly'){S.fl+=dt/1.15;if(S.fl>=1){S.phase='result';S.msgT=0;if(S.res.ok)S.score+=S.pts}}
      draw();
    });
    function draw(){
      const g=ctx.createLinearGradient(0,0,0,170);g.addColorStop(0,'#14284a');g.addColorStop(1,'#6fa3d6');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
      ctx.fillStyle='#2b3a55';ctx.fillRect(0,118,W,34);for(let x=0;x<W;x+=7){ctx.fillStyle=['#b33','#eee','#37c','#fc3','#4a4'][(x/7|0)%5];ctx.fillRect(x,122+((x/7|0)%3)*3,4,3)}
      ctx.fillStyle='#2f7d3a';ctx.beginPath();ctx.moveTo(0,152);ctx.lineTo(W,152);ctx.lineTo(W,H);ctx.lineTo(0,H);ctx.fill();
      for(let i=0;i<8;i++){ctx.fillStyle=i%2?'#348a40':'#2f7d3a';const y0=152+Math.pow(i/8,1.7)*288,y1=152+Math.pow((i+1)/8,1.7)*288;ctx.fillRect(0,y0,W,y1-y0)}
      ctx.strokeStyle='rgba(255,255,255,.55)';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(160,152);ctx.lineTo(60,H);ctx.moveTo(160,152);ctx.lineTo(260,H);ctx.stroke();
      // goalposts
      const s=goalS(),K=170*s,gx=160,gy=170-8*s;
      ctx.strokeStyle='#ffd23a';ctx.lineWidth=Math.max(2,4*s);ctx.beginPath();ctx.moveTo(gx,gy+30*s);ctx.lineTo(gx,gy);ctx.moveTo(gx-.22*K,gy);ctx.lineTo(gx+.22*K,gy);ctx.moveTo(gx-.22*K,gy);ctx.lineTo(gx-.22*K,gy-70*s);ctx.moveTo(gx+.22*K,gy);ctx.lineTo(gx+.22*K,gy-70*s);ctx.stroke();
      // ball
      let bx=160,by=392,sc=1;
      if(S.phase==='fly'||S.phase==='result'){const k=Math.min(1,S.fl),ex=160+S.lat*K,ey=S.short?gy+20+(1-S.powv)*40:gy-36*s;bx=160+(ex-160)*k;by=392+(ey-392)*k-Math.sin(k*Math.PI)*(S.short?70:130);sc=1-k*.72}
      ctx.save();ctx.translate(bx,by);ctx.rotate((S.fl||0)*14);ctx.scale(sc,sc);ctx.fillStyle='#7a4a1e';ctx.beginPath();ctx.ellipse(0,0,15,9,0,0,7);ctx.fill();ctx.fillStyle='#fff';ctx.fillRect(-4,-1,8,2);ctx.restore();
      // hud
      txt(ctx,`KICK ${Math.min(S.i+1,S.n)} / ${S.n}`,12,18,16,'#fff','left');txt(ctx,`SCORE ${S.score}`,W-12,18,16,'#ffd23a','right');
      txt(ctx,`${S.dist} YARDS`,W/2,40,22,'#fff');
      txt(ctx,S.wind===0?'Wind: calm':`Wind: ${Math.abs(S.wind)} mph ${S.wind>0?'→':'←'}`,W/2,64,14,'#cfe6ff',null,false);
      // meters
      ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(30,408,260,18);ctx.fillStyle='#2e9a4a';ctx.fillRect(160-.22*K*.5*(260/ (170*1))+0,408,0,0);
      ctx.fillStyle='#3a8a4a';const gw=.22*2*130*.5*1.0;ctx.fillRect(160-gw/2*1,408,gw,18);
      const ax=160+(S.phase==='aim'?S.aim:S.aimv)*130;ctx.fillStyle='#ffd23a';ctx.fillRect(ax-3,402,6,30);
      txt(ctx,'AIM',20,417,10,'#fff','right');
      ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(296,150,16,240);const pn=Math.min(.97,.42+S.dist/100);ctx.fillStyle='#3a8a4a';ctx.fillRect(296,390-(pn+.12)*240,16,.2*240);
      const py=390-(S.phase==='aim'?0:(S.phase==='power'?S.pow:S.powv))*240;ctx.fillStyle='#ffd23a';ctx.fillRect(292,py-3,24,6);txt(ctx,'POWER',304,140,10,'#fff');
      const msg=S.phase==='aim'?'Tap to lock your AIM':S.phase==='power'?'Tap again to lock POWER (hit the green)':S.phase==='result'||S.phase==='fly'?(S.phase==='result'?S.res.txt:''):'';
      if(msg)txt(ctx,msg,W/2,92,15,S.res&&S.res.ok?'#7dff9c':'#fff');
      if(S.phase==='result'&&S.msgT>.5)txt(ctx,'Tap for next kick',W/2,112,12,'#cfe6ff',null,false);
      if(S.phase==='end'){ctx.fillStyle='rgba(0,0,0,.72)';ctx.fillRect(0,0,W,H);txt(ctx,'FINAL SCORE',W/2,170,20);txt(ctx,String(S.score),W/2,222,56,'#ffd23a');txt(ctx,`Best ${S.best}`,W/2,268,16,'#cfe6ff');txt(ctx,'Tap to play again',W/2,320,15)}
    }
    return{stop(){stopL();window.removeEventListener('keydown',kd)}};
  }

  /* ---------------- 2. QB Target Throw ---------------- */
  function qbGame(stage,api){
    const W=320,H=440,[c,ctx]=cvs(stage,W,H);let stopL;
    const S={i:0,n:10,score:0,comp:0,ints:0,phase:'run',t:0,ball:null,msg:'',msgT:0,best:api.best(),mx:160,my:200,rs:[],ds:[]};
    function setup(){
      S.rs=[0,1,2].map(k=>({x0:60+k*100+(rnd()*30-15),A:14+rnd()*30,w:1.2+rnd()*1.6,ph:rnd()*6,v:55+rnd()*55,x:0,y:360,hist:[]}));
      S.ds=[0,1,2].map(k=>({ox:rnd()*30-15,oy:-(10+rnd()*20),lag:.3+rnd()*.35,x:0,y:0}));
      S.t=0;S.phase='run';S.ball=null;S.msg='';rpos(0);
    }
    function rpos(t){S.rs.forEach(r=>{r.x=clamp(r.x0+r.A*Math.sin(r.w*t+r.ph),22,W-22);r.y=Math.max(110,360-r.v*t);r.hist.push([t,r.x,r.y])});
      S.ds.forEach((d,k)=>{const r=S.rs[k],h=r.hist;let p=h[0];for(let j=h.length-1;j>=0;j--){if(h[j][0]<=t-d.lag){p=h[j];break}}d.x=p[1]+d.ox;d.y=p[2]+d.oy})}
    setup();
    function throwAt(x,y){
      if(S.phase!=='run')return;const d=Math.hypot(x-160,y-392);S.ball={x0:160,y0:392,tx:x,ty:y,T:d/330+.3,t:0};S.phase='fly'}
    function after(){S.msgT=0;S.phase='result'}
    c.addEventListener('pointermove',e=>{[S.mx,S.my]=ptr(c,e)});
    c.addEventListener('pointerdown',e=>{e.preventDefault();[S.mx,S.my]=ptr(c,e);
      if(S.phase==='run')throwAt(S.mx,S.my);
      else if(S.phase==='result'&&S.msgT>.45){S.i++;if(S.i>=S.n){S.phase='end';if(S.score>S.best){S.best=S.score;api.save(S.score)}}else setup()}
      else if(S.phase==='end'&&S.msgT>.4){S.i=0;S.score=0;S.comp=0;S.ints=0;setup()}});
    stopL=loopFn(dt=>{
      S.t+=dt;S.msgT+=dt;
      if(S.phase==='run'||S.phase==='fly'){rpos(S.t)}
      if(S.phase==='run'&&S.t>3.4){S.msg='SACKED! You held it too long.';after()}
      if(S.phase==='fly'){const b=S.ball;b.t+=dt;if(b.t>=b.T){
        let rec=null,rd=99,df=null,dd=99;S.rs.forEach(r=>{const d=Math.hypot(r.x-b.tx,r.y-b.ty);if(d<rd){rd=d;rec=r}});S.ds.forEach(d0=>{const d=Math.hypot(d0.x-b.tx,d0.y-b.ty);if(d<dd){dd=d;df=d0}});
        if(rd<26&&(dd>rd||dd>22)){const yds=Math.max(0,Math.round((392-rec.y)/9));S.comp++;const pts=50+yds*5+(rd<10?25:0);S.score+=pts;S.msg=`COMPLETE! ${yds} yards +${pts}`}
        else if(dd<24&&dd<rd+10){S.ints++;S.msg='INTERCEPTED!'}
        else S.msg='INCOMPLETE. Lead your receiver.';
        after()}}
      draw();
    });
    function draw(){
      ctx.fillStyle='#2f7d3a';ctx.fillRect(0,0,W,H);for(let i=0;i<11;i++){ctx.fillStyle=i%2?'#348a40':'#2f7d3a';ctx.fillRect(0,i*40,W,40)}
      ctx.fillStyle='rgba(255,255,255,.6)';for(let y=60;y<H;y+=80)ctx.fillRect(0,y,W,2);ctx.fillRect(0,0,3,H);ctx.fillRect(W-3,0,3,H);
      ctx.fillStyle='#3a7bff';ctx.fillRect(0,372,W,2);
      S.ds.forEach(d=>{ctx.fillStyle='#b8352b';ctx.fillRect(d.x-8,d.y-8,16,16);ctx.fillStyle='#e8e8ee';ctx.fillRect(d.x-5,d.y-12,10,6)});
      S.rs.forEach((r,k)=>{ctx.fillStyle='#ffd23a';ctx.fillRect(r.x-8,r.y-8,16,16);ctx.fillStyle='#e8e8ee';ctx.fillRect(r.x-5,r.y-12,10,6);ctx.strokeStyle='rgba(255,255,255,.35)';ctx.beginPath();ctx.moveTo(r.x0,372);ctx.lineTo(r.x,r.y);ctx.stroke()});
      ctx.fillStyle='#1d3a8a';ctx.fillRect(152,384,16,16);ctx.fillStyle='#e8e8ee';ctx.fillRect(155,380,10,6);
      if(S.ball){const b=S.ball,k=Math.min(1,b.t/b.T),x=b.x0+(b.tx-b.x0)*k,y=b.y0+(b.ty-b.y0)*k-Math.sin(k*Math.PI)*40;ctx.save();ctx.translate(x,y);ctx.rotate(k*10);ctx.fillStyle='#7a4a1e';ctx.beginPath();ctx.ellipse(0,0,9,5,0,0,7);ctx.fill();ctx.restore()}
      if(S.phase==='run'){ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(S.mx,S.my,14,0,7);ctx.moveTo(S.mx-20,S.my);ctx.lineTo(S.mx+20,S.my);ctx.moveTo(S.mx,S.my-20);ctx.lineTo(S.mx,S.my+20);ctx.stroke();
        ctx.fillStyle='rgba(0,0,0,.5)';ctx.fillRect(0,H-8,W,8);ctx.fillStyle='#ffd23a';ctx.fillRect(0,H-8,W*(1-S.t/3.4),8)}
      ctx.fillStyle='rgba(0,0,0,.5)';ctx.fillRect(0,0,W,30);
      txt(ctx,`THROW ${Math.min(S.i+1,S.n)}/${S.n}`,10,15,14,'#fff','left');txt(ctx,`${S.comp} comp  ${S.ints} INT`,W/2,15,13,'#cfe6ff');txt(ctx,`SCORE ${S.score}`,W-10,15,14,'#ffd23a','right');
      if(S.phase==='run'&&S.t<1.6)txt(ctx,'Tap where the ball should land',W/2,52,14,'#fff');
      if(S.phase==='result'){txt(ctx,S.msg,W/2,60,16,/COMPLETE/.test(S.msg)?'#7dff9c':'#ffb0a0');if(S.msgT>.45)txt(ctx,'Tap for next throw',W/2,84,12,'#cfe6ff',null,false)}
      if(S.phase==='end'){ctx.fillStyle='rgba(0,0,0,.72)';ctx.fillRect(0,0,W,H);txt(ctx,'FINAL SCORE',W/2,160,20);txt(ctx,String(S.score),W/2,214,56,'#ffd23a');txt(ctx,`${S.comp}/${S.n} completions, ${S.ints} interceptions`,W/2,262,14,'#cfe6ff');txt(ctx,`Best ${S.best}`,W/2,288,16,'#cfe6ff');txt(ctx,'Tap to play again',W/2,336,15)}
    }
    return{stop(){stopL()}};
  }

  /* ---------------- 3. Gridiron Dash ---------------- */
  function dash(stage,api){
    const W=240,H=420,[c,ctx]=cvs(stage,W,H);let stopL;const LW=80,PXY=14,RY=340;
    const S={lane:1,lx:1,y:0,line:25,from:25,down:1,tds:0,total:0,ds:[],spawn:0,v:4.6,tackled:0,jcd:0,flash:0,over:false,best:api.best(),dist:0,msgT:0,msg:''};
    function lanes(l){S.lane=clamp(l,0,2)}
    function move(dir){if(S.over)return;lanes(S.lane+dir)}
    function juke(){if(S.over||S.jcd>0||S.tackled>0)return;S.jcd=2.2;S.flash=.35;S.ds=S.ds.filter(d=>!(d.y>RY-120&&d.y<RY+10&&Math.abs(d.lane-S.lane)<=1))}
    function restart(){Object.assign(S,{lane:1,lx:1,line:25,from:25,down:1,tds:0,total:0,ds:[],spawn:0,v:4.6,tackled:0,jcd:0,flash:0,over:false,dist:0,msg:''})}
    let sx0=0,sy0=0;
    c.addEventListener('pointerdown',e=>{e.preventDefault();const[x,y]=ptr(c,e);sx0=x;sy0=y;if(S.over&&S.msgT>.5){restart();return}});
    c.addEventListener('pointerup',e=>{const[x,y]=ptr(c,e),dx=x-sx0,dy=y-sy0;if(Math.abs(dx)>28&&Math.abs(dx)>Math.abs(dy))move(dx>0?1:-1);else if(dy<-28)juke();else{if(x<W/3)move(-1);else if(x>W*2/3)move(1);else juke()}});
    const kd=e=>{if(sec.hidden)return;const k=e.key.toLowerCase();if(['arrowleft','a'].includes(k)){e.preventDefault();move(-1)}else if(['arrowright','d'].includes(k)){e.preventDefault();move(1)}else if([' ','arrowup','w'].includes(k)){e.preventDefault();if(S.over&&S.msgT>.5)restart();else juke()}};window.addEventListener('keydown',kd);
    stopL=loopFn(dt=>{
      S.msgT+=dt;
      if(!S.over){
        S.jcd=Math.max(0,S.jcd-dt);S.flash=Math.max(0,S.flash-dt);
        S.lx+=(S.lane-S.lx)*Math.min(1,dt*14);
        if(S.tackled>0){S.tackled-=dt;if(S.tackled<=0){S.v=4.6}}
        else{
          const spd=S.v+Math.min(4.4,(S.line-S.from)*.04+S.total*.0012);S.cur=spd;
          S.dist+=spd*dt;S.line+=spd*dt;S.total+=spd*dt;
          S.spawn-=spd*dt;if(S.spawn<=0){S.spawn=3.4+rnd()*3.2-Math.min(1.6,S.total/180);const n=1+(rnd()<.35?1:0),used=[];for(let k=0;k<n;k++){let l;do{l=Math.floor(rnd()*3)}while(used.includes(l)&&used.length<3);used.push(l);S.ds.push({lane:l,fl:l,y:-30,chase:rnd()<.3})}}
          S.ds.forEach(d=>{d.y+=(spd*PXY+30)*dt;if(d.chase&&d.y>90&&d.y<RY-80){const tl=S.lane;d.fl+=(tl-d.fl)*Math.min(1,dt*1.6)}else d.fl+=(d.lane-d.fl)*Math.min(1,dt*3)});
          S.ds=S.ds.filter(d=>d.y<H+40);
          const hit=S.ds.find(d=>Math.abs(d.y-RY)<22&&Math.abs(d.fl-S.lx)<.55);
          if(hit){S.ds=S.ds.filter(d=>d.y<RY-140||d.y>RY+60);S.tackled=.9;S.down++;S.msg='TACKLED!';S.msgT=0;
            if(S.down>4){S.over=true;S.msgT=0;const sc=Math.round(S.total)+S.tds*20;if(sc>S.best){S.best=sc;api.save(sc)}}}
          if(S.line-S.from>=10&&S.line<100){S.from=S.line;S.down=1;S.msg='FIRST DOWN!';S.msgT=0}
          if(S.line>=100){S.tds++;S.line=25;S.from=25;S.down=1;S.msg='TOUCHDOWN!';S.msgT=0;S.ds=[]}
        }
      }
      draw();
    });
    function draw(){
      ctx.fillStyle='#2e7a38';ctx.fillRect(0,0,W,H);
      const off=(S.line*PXY)%(10*PXY);
      for(let k=-1;k<=Math.ceil(H/(5*PXY))+1;k++){const yy=RY-(k*5*PXY)+((S.line*PXY)%(5*PXY));const idx=Math.round(S.line)+Math.round(RY-yy)/PXY;ctx.fillStyle=(Math.floor(idx/5)%2)?'#34853f':'#2e7a38';ctx.fillRect(0,yy-5*PXY,W,5*PXY)}
      ctx.fillStyle='rgba(255,255,255,.55)';for(let k=-2;k<Math.ceil(H/PXY/5)+2;k++){const yd=Math.floor(S.line/5)*5+k*5,yy=RY-(yd-S.line)*PXY;ctx.fillRect(0,yy,W,yd%10===0?3:1);if(yd%10===0&&yd>0&&yd<100){txt(ctx,String(yd<=50?yd:100-yd),22,yy-10,14,'rgba(255,255,255,.7)')}}
      ctx.fillStyle='rgba(255,255,255,.2)';ctx.fillRect(LW,0,2,H);ctx.fillRect(LW*2,0,2,H);ctx.fillStyle='#fff';ctx.fillRect(0,0,3,H);ctx.fillRect(W-3,0,3,H);
      const ly=RY-(S.from+10-S.line)*PXY;if(S.from+10<100){ctx.fillStyle='#ffd23a';ctx.fillRect(0,ly,W,3)}
      if(100-S.line<26){ctx.fillStyle='#1d3a8a';ctx.fillRect(0,RY-(100-S.line)*PXY-120,W,120);txt(ctx,'END ZONE',W/2,RY-(100-S.line)*PXY-60,22,'#ffd23a')}
      S.ds.forEach(d=>{const x=d.fl*LW+LW/2;ctx.fillStyle='rgba(0,0,0,.3)';ctx.fillRect(x-12,d.y+10,24,5);ctx.fillStyle='#b8352b';ctx.fillRect(x-12,d.y-12,24,22);ctx.fillStyle='#e8e8ee';ctx.fillRect(x-8,d.y-20,16,10);ctx.fillStyle='#fff';ctx.fillRect(x-12,d.y-12,24,3)});
      const x=S.lx*LW+LW/2,bob=Math.sin(S.dist*3)*2;
      ctx.fillStyle='rgba(0,0,0,.3)';ctx.fillRect(x-12,RY+10,24,5);
      if(S.tackled>0){ctx.fillStyle='#ffd23a';ctx.fillRect(x-18,RY-4,36,14);ctx.fillStyle='#e0a878';ctx.fillRect(x+14,RY-2,8,8)}
      else{ctx.fillStyle='#ffd23a';ctx.fillRect(x-12,RY-12+bob,24,22);ctx.fillStyle='#e0a878';ctx.fillRect(x-6,RY-18+bob,12,8);ctx.fillStyle='#1d3a8a';ctx.fillRect(x-9,RY-24+bob,18,8);ctx.fillStyle='#7a4a1e';ctx.fillRect(x+8,RY-6+bob,8,5);
        if(S.flash>0){ctx.strokeStyle='rgba(255,255,255,.8)';ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,RY-4,30+ (.35-S.flash)*60,0,7);ctx.stroke()}}
      ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(0,0,W,34);
      const dn=['1st','2nd','3rd','4th'][Math.min(3,S.down-1)];
      txt(ctx,`${dn} & ${Math.max(1,Math.ceil(S.from+10-S.line))}`,8,17,15,'#fff','left');txt(ctx,`${Math.round(S.total)} yds  ${S.tds} TD`,W-8,17,14,'#ffd23a','right');
      ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(W/2-34,H-24,68,14);ctx.fillStyle=S.jcd>0?'#777':'#7dff9c';ctx.fillRect(W/2-34,H-24,68*(1-S.jcd/2.2),14);txt(ctx,S.jcd>0?'JUKE':'JUKE READY',W/2,H-17,10,'#000');
      if(S.msgT<1.1&&S.msg&&!S.over)txt(ctx,S.msg,W/2,120,26,S.msg==='TACKLED!'?'#ffb0a0':'#7dff9c');
      if(S.down===1&&S.total<1)txt(ctx,'Swipe or tap sides to change lanes. Tap the middle to juke.',W/2,70,12,'#fff',null,false);
      if(S.over){ctx.fillStyle='rgba(0,0,0,.72)';ctx.fillRect(0,0,W,H);txt(ctx,'TURNOVER ON DOWNS',W/2,150,20);const sc=Math.round(S.total)+S.tds*20;txt(ctx,String(sc),W/2,206,56,'#ffd23a');txt(ctx,`${Math.round(S.total)} yards, ${S.tds} touchdowns`,W/2,250,14,'#cfe6ff');txt(ctx,`Best ${S.best}`,W/2,276,16,'#cfe6ff');if(S.msgT>.5)txt(ctx,'Tap to run it back',W/2,322,15)}
    }
    return{stop(){stopL();window.removeEventListener('keydown',kd)}};
  }

  /* ---------------- 4. Stat Showdown (higher / lower) ---------------- */
  function statGame(stage,api){
    const STATS=[['ppg','points per game','higher'],['ypg','total yards per game','higher'],['pypg','passing yards per game','higher'],['rypg','rushing yards per game','higher'],['sck','sacks','higher'],['int','interceptions caught','higher'],['t3p','third-down conversion rate','higher'],['rzp','red-zone touchdown rate','higher'],['fdpg','first downs per game','higher'],['papg','points allowed per game','higher'],['ypga','yards allowed per game','higher'],['peny','penalty yards','higher']];
    const S={streak:0,best:api.best(),q:null,locked:false,over:false};
    const logo=a=>(typeof LOGOS!=='undefined'&&LOGOS[a])?`<img src="${LOGOS[a]}" alt="" width="64" height="64">`:'';
    function newQ(){
      const yr=rnd()<.6?'2026':'2025',R=RK[yr]||RK['2025'];const teams=Object.keys(R).filter(t=>R[t].g>=3);
      let st,a,b,tries=0;do{st=STATS[Math.floor(rnd()*STATS.length)];a=teams[Math.floor(rnd()*teams.length)];b=teams[Math.floor(rnd()*teams.length)];tries++}while((a===b||R[a][st[0]]===R[b][st[0]]||R[a][st[0]]==null||R[b][st[0]]==null)&&tries<60);
      S.q={yr,st,a,b,va:R[a][st[0]],vb:R[b][st[0]]};S.locked=false;draw();
    }
    function fmt(k,v){return /p$/.test(k)&&k!=='ppg'&&k!=='papg'&&k!=='pypg'&&k!=='sck'?v.toFixed(1)+'%':Number.isInteger(v)?String(v):v.toFixed(1)}
    function draw(){
      const q=S.q;
      stage.innerHTML=`<div class="stg"><div class="stgtop"><span>Streak <b>${S.streak}</b></span><span>Best <b>${S.best}</b></span></div>
      ${S.over?`<div class="stgover"><h3>Streak over</h3><p>You got <b>${S.streak}</b> in a row. Best ever: <b>${S.best}</b>.</p><button class="btn solid" data-a="again">Play again</button></div>`:
      `<p class="stgq">${q.yr} season. Which team has the <b>higher</b> ${q.st[1]}?</p>
      <div class="stgrow">${['a','b'].map(k=>{const t=q[k],v=q['v'+k];return `<button class="stgcard" data-pick="${k}" ${S.locked?'disabled':''}>${logo(t)}<b>${NAMES[t]||t}</b><span class="stgv">${S.locked?fmt(q.st[0],v):'?'}</span></button>`}).join('')}</div>
      <p class="note" id="stgmsg" aria-live="polite"></p>`}</div>`;
      if(S.locked){const win=q.va>q.vb?'a':'b';stage.querySelectorAll('.stgcard').forEach(el=>{if(el.dataset.pick===win)el.classList.add('good');else if(el.dataset.pick===S.pick)el.classList.add('bad')})}
    }
    stage.addEventListener('click',onClick);
    function onClick(e){
      if(e.target.closest('[data-a="again"]')){S.streak=0;S.over=false;newQ();return}
      const b=e.target.closest('[data-pick]');if(!b||S.locked)return;
      const q=S.q,win=q.va>q.vb?'a':'b';S.locked=true;S.pick=b.dataset.pick;draw();
      const ok=S.pick===win;const m=stage.querySelector('#stgmsg');
      if(ok){S.streak++;if(S.streak>S.best){S.best=S.streak;api.save(S.best)}if(m)m.textContent='Correct!';setTimeout(()=>{if(!sec.hidden&&S.locked&&!S.over)newQ()},1300)}
      else{if(m)m.textContent='Not this time.';setTimeout(()=>{S.over=true;draw()},1500)}
    }
    newQ();
    return{stop(){stage.removeEventListener('click',onClick)}};
  }

  /* ---------------- hub ---------------- */
  const svg=(bg,body)=>`<svg viewBox="0 0 120 80" aria-hidden="true"><rect width="120" height="80" fill="${bg}"/>${body}</svg>`;
  const ART={
    showdown:svg('#1f5c2c','<g fill="#2e7a38"><rect y="0" width="120" height="16"/><rect y="32" width="120" height="16"/><rect y="64" width="120" height="16"/></g><g stroke="#fff" stroke-width="1.5" opacity=".7"><path d="M0 40h120M0 16h120M0 64h120"/></g><g><rect x="30" y="34" width="12" height="14" fill="#ffd23a"/><rect x="33" y="28" width="6" height="7" fill="#1d3a8a"/><rect x="74" y="26" width="12" height="14" fill="#b8352b"/><rect x="77" y="20" width="6" height="7" fill="#eee"/><ellipse cx="62" cy="40" rx="7" ry="4" fill="#7a4a1e" transform="rotate(-25 62 40)"/></g>'),
    kick:svg('#1a2f5a','<rect y="52" width="120" height="28" fill="#2f7d3a"/><path d="M60 46V22M46 22h28M46 22V6M74 22V6" stroke="#ffd23a" stroke-width="3" fill="none"/><ellipse cx="60" cy="68" rx="8" ry="5" fill="#7a4a1e"/><path d="M60 62Q64 40 60 26" stroke="#fff" stroke-dasharray="3 3" fill="none"/>'),
    qb:svg('#2e7a38','<g fill="#ffd23a"><rect x="20" y="30" width="10" height="10"/><rect x="52" y="20" width="10" height="10"/><rect x="88" y="34" width="10" height="10"/></g><g fill="#b8352b"><rect x="24" y="22" width="10" height="10"/><rect x="56" y="12" width="10" height="10"/></g><rect x="55" y="62" width="10" height="10" fill="#1d3a8a"/><path d="M60 60Q58 40 58 28" stroke="#fff" stroke-width="2" stroke-dasharray="4 3" fill="none"/><ellipse cx="58" cy="26" rx="5" ry="3" fill="#7a4a1e"/>'),
    stats:svg('#1b2a22','<g fill="#5cc28a"><rect x="14" y="40" width="14" height="30"/><rect x="36" y="26" width="14" height="44"/><rect x="58" y="48" width="14" height="22" opacity=".7"/><rect x="80" y="14" width="14" height="56"/></g><path d="M10 72h100" stroke="#fff" opacity=".5"/><text x="60" y="12" fill="#ffd23a" font-size="9" font-weight="700" text-anchor="middle" font-family="sans-serif">HIGHER or LOWER</text>')
  };
  const GAMES=[
    {id:'showdown',name:'Gridiron Showdown',tag:'New',blurb:'Retro head-to-head football. Call plays, run, throw and tackle in real time against the CPU or a friend.',how:'1 or 2 players',make:(s,a)=>window.__showdown(s,a)},
  ];
  const $=id=>document.getElementById(id);
  const stage=$('gmstage'),poster=$('gmposter'),grid=$('gmgrid'),rail=$('gmrailgrid');
  let cur=null,run=null;
  function tile(g,big){return `<button class="gmtile${cur&&cur.id===g.id?' on':''}" type="button" data-g="${g.id}"><span class="gmart">${ART[g.id]}${g.tag?`<i class="gmbadge ${g.tag.toLowerCase()}">${g.tag}</i>`:''}</span><b>${g.name}</b>${big?`<span class="gmhow">${g.how}</span>`:''}</button>`}
  function drawTiles(){grid.innerHTML=GAMES.map(g=>tile(g,true)).join('');rail.innerHTML=GAMES.filter(g=>!cur||g.id!==cur.id).map(g=>tile(g,false)).join('')}
  function stopRun(){if(run&&run.stop){try{run.stop()}catch(e){}}run=null;stage.innerHTML='';stage.hidden=true}
  function select(id,autoplay){
    stopRun();cur=GAMES.find(g=>g.id===id)||GAMES[0];
    $('gmtitle').textContent=cur.name;$('gmblurb').textContent=cur.blurb;
    const b=bestGet(cur.id);$('gmbest').textContent=cur.id==='showdown'?'':(b?`Your best: ${b}`:'');
    poster.hidden=false;poster.innerHTML=`<div class="gmpart">${ART[cur.id]}</div><div class="gmpbody"><h2>${cur.name}</h2><p>${cur.blurb}</p><button class="btn solid gmplay" type="button" id="gmplay">Play now</button><span class="gmhow">${cur.how}</span></div>`;
    drawTiles();
    try{history.replaceState(null,'','#games')}catch(e){}
    if(autoplay)play();
  }
  function play(){
    if(!cur)return;stopRun();poster.hidden=true;stage.hidden=false;
    const api={best:()=>bestGet(cur.id),save:v=>{bestSet(cur.id,v);$('gmbest').textContent=`Your best: ${v}`}};
    run=cur.make(stage,api);
  }
  // full screen with a visible exit button (works on phones that only allow a page-sized fake full screen)
  function isFull(){const p=$('gmplayer');return !!(document.fullscreenElement||document.webkitFullscreenElement)||p.classList.contains('gmfake')}
  function syncFull(){const p=$('gmplayer'),on=isFull();const b=$('gmexit');if(b)b.hidden=!on;const f=$('gmfull');if(f)f.textContent=on?'Exit full screen':'Full screen';document.body.classList.toggle('gmfs',on)}
  function enterFull(){
    const p=$('gmplayer');if(isFull()){exitFull();return}
    let ok=false;
    try{const fn=p.requestFullscreen||p.webkitRequestFullscreen;if(fn){const r=fn.call(p);ok=true;if(r&&r.catch)r.catch(()=>{p.classList.add('gmfake');syncFull()})}}catch(er){}
    if(!ok)p.classList.add('gmfake');
    setTimeout(syncFull,60);
  }
  function exitFull(){
    const p=$('gmplayer');p.classList.remove('gmfake');
    try{if(document.fullscreenElement&&document.exitFullscreen)document.exitFullscreen();else if(document.webkitFullscreenElement&&document.webkitExitFullscreen)document.webkitExitFullscreen()}catch(er){}
    setTimeout(syncFull,60);
  }
  document.addEventListener('fullscreenchange',syncFull);document.addEventListener('webkitfullscreenchange',syncFull);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('gmplayer')&&$('gmplayer').classList.contains('gmfake'))exitFull()});
  sec.addEventListener('click',e=>{
    const t=e.target.closest('[data-g]');if(t){select(t.dataset.g,true);const p=$('gmplayer');if(p&&p.scrollIntoView)p.scrollIntoView({behavior:'smooth',block:'start'});return}
    if(e.target.closest('#gmplay')){play();return}
    if(e.target.closest('#gmfull')){enterFull();return}
    if(e.target.closest('#gmexit')){exitFull();return}
    if(e.target.closest('#gmshare')){const url=WEB+'#games';const m=$('gmshmsg');
      const done=ok=>{m.textContent=ok?'Link copied':'Press and hold to copy: '+url;setTimeout(()=>{m.textContent=''},2600)};
      if(navigator.share){navigator.share({title:"Tyler's NFL APP Game Room",text:'Play football games with me:',url}).catch(()=>{})}
      else{navigator.clipboard&&navigator.clipboard.writeText(url).then(()=>done(true),()=>done(false))}return}
  });
  new MutationObserver(()=>{if(sec.hidden&&run){stopRun();if(cur){poster.hidden=false}}}).observe(sec,{attributes:true,attributeFilter:['hidden']});
  select('showdown',false);
  window.__gm={select,play,games:GAMES,run:()=>run};
})();
