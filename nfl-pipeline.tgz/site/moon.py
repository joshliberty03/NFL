import csv, json, math, random, datetime, collections, sys, zoneinfo
import ephem
ET=zoneinfo.ZoneInfo('America/New_York'); UTC=datetime.timezone.utc
def kick(g):
    t=g['gametime'] or '13:00'
    h,m=map(int,t.split(':')); y,mo,d=map(int,g['gameday'].split('-'))
    return datetime.datetime(y,mo,d,h,m,tzinfo=ET).astimezone(UTC)
def elong(dt):
    e=ephem.Date(dt.replace(tzinfo=None))
    s=ephem.Sun(e); m=ephem.Moon(e)
    return (math.degrees(ephem.Ecliptic(m).lon)-math.degrees(ephem.Ecliptic(s).lon))%360
NAMES8=['Waxing crescent','Waxing gibbous','Waning gibbous','Waning crescent']
def phase8(el): return int(el//90)
def broad(el): return 'Waxing crescent' if 0<=el<90 else 'Waxing gibbous' if el<180 else 'Waning gibbous' if el<270 else 'Waning crescent'
def illum(el): return round((1-math.cos(math.radians(el)))/2*100)
# full moon dates (ET calendar day) 1998..2028
fulls=[]
d=ephem.Date('1998/12/1')
while d<ephem.Date('2028/1/1'):
    d=ephem.next_full_moon(d); fulls.append(d.datetime().replace(tzinfo=UTC).astimezone(ET).date()); d=ephem.Date(d+1)
fullset=set(fulls)
news=[];d=ephem.Date('1998/12/1')
while d<ephem.Date('2028/1/1'):
    d=ephem.next_new_moon(d); news.append(d.datetime().replace(tzinfo=UTC).astimezone(ET).date()); d=ephem.Date(d+1)
newset=set(news)
def eve_full(gd):
    return (gd+datetime.timedelta(days=1)) in fullset
def binom_p(k,n,p=0.5):
    # two-sided exact via normal approx w/ continuity for large n, exact for small
    if n==0:return None
    if n<=60:
        pr=[math.comb(n,i)*p**i*(1-p)**(n-i) for i in range(n+1)];obs=pr[k]
        return min(1,sum(x for x in pr if x<=obs+1e-12))
    z=(abs(k-n*p)-0.5)/math.sqrt(n*p*(1-p));return math.erfc(z/math.sqrt(2))
rows=list(csv.DictReader(open('/home/runner/nfl/games/games.csv')))
G=[];UP=[]
for r in rows:
    gd=datetime.date.fromisoformat(r['gameday']);dt=kick(r);el=elong(dt)
    base={'id':r['game_id'],'date':r['gameday'],'s':int(r['season']),'gt':r['game_type'],'h':r['home_team'],'a':r['away_team'],'el':el,'p8':phase8(el),'br':broad(el),'eve':eve_full(gd),'full':gd in fullset,'nw':gd in newset,'wd':r['weekday']}
    sp=r['spread_line'];tl=r['total_line']
    base['sp']=float(sp) if sp not in('','NA') else None;base['tl']=float(tl) if tl not in('','NA') else None
    base['hml']=float(r['home_moneyline']) if r['home_moneyline'] not in('','NA') else None
    base['aml']=float(r['away_moneyline']) if r['away_moneyline'] not in('','NA') else None
    if r['home_score'] not in('','NA'):
        hs,as_=int(r['home_score']),int(r['away_score']);base.update(hs=hs,as_=as_)
        G.append(base)
    else: UP.append(base)
RELOC={'OAK':'LV','SD':'LAC','STL':'LA'}
for g in G+UP:
    g['h']=RELOC.get(g['h'],g['h']);g['a']=RELOC.get(g['a'],g['a'])
print('played',len(G),'upcoming',len(UP),'upcoming with spread',sum(1 for g in UP if g['sp'] is not None),'with ml',sum(1 for g in UP if g['hml'] is not None))
past=[g for g in G if g['s']<=2025]
# ---------- tests ----------
def cover(g):  # home cover: result - spread (spread = home favoured by sp)
    if g['sp'] is None:return None
    m=g['hs']-g['as_']-g['sp']
    return None if m==0 else m>0
def over(g):
    if g['tl'] is None:return None
    t=g['hs']+g['as_']-g['tl'];return None if t==0 else t>0
def rate(gs,f):
    v=[f(g) for g in gs];v=[x for x in v if x is not None];return sum(v),len(v)
out={}
# claim 1: eve of full moon, home cover
for lab,gs in [('1999-2025',past),('1999-2007 (overlaps the 1978-2007 study)',[g for g in past if g['s']<=2007]),('2008-2025 (never seen by the study)',[g for g in past if g['s']>=2008])]:
    e=[g for g in gs if g['eve']];o=[g for g in gs if not g['eve']]
    k,n=rate(e,cover);k2,n2=rate(o,cover)
    mm=[g['hs']-g['as_']-g['sp'] for g in e if g['sp'] is not None];mo=[g['hs']-g['as_']-g['sp'] for g in o if g['sp'] is not None]
    out.setdefault('eve_cover',[]).append({'label':lab,'eve_n':n,'eve_cov':k,'eve_pct':k/n,'p':binom_p(k,n),'rest_n':n2,'rest_pct':k2/n2,'eve_margin':sum(mm)/len(mm),'rest_margin':sum(mo)/len(mo)})
    print(lab,'eve home cover',k,n,round(k/n,3),'p',round(binom_p(k,n),3),'| rest',round(k2/n2,3),'| mean margin vs spread eve',round(sum(mm)/len(mm),2),'rest',round(sum(mo)/len(mo),2))
# claim 2: over rate by broad phase and by 8 phases, with permutation of phases for the max deviation
def table(keyf,labels,f):
    res=[]
    for lab in labels:
        gs=[g for g in past if keyf(g)==lab];k,n=rate(gs,f);res.append({'phase':lab,'n':n,'k':k,'pct':k/n,'p':binom_p(k,n)})
    return res
ov8=table(lambda g:NAMES8[g['p8']],NAMES8,over);cv8=table(lambda g:NAMES8[g['p8']],NAMES8,cover)
hw8=[]
for lab in NAMES8:
    gs=[g for g in past if NAMES8[g['p8']]==lab and g['hs']!=g['as_']];k=sum(1 for g in gs if g['hs']>g['as_']);hw8.append({'phase':lab,'n':len(gs),'k':k,'pct':k/len(gs),'p':binom_p(k,len(gs))})
out['over8']=ov8;out['cover8']=cv8;out['homewin8']=hw8
for nm,t in (('over',ov8),('home cover',cv8),('home win',hw8)): print(nm,[(x['phase'][:9],x['n'],round(x['pct'],3),round(x['p'],3)) for x in t])
# waxing gibbous broad (over, home cover) split out-of-sample
wg=[g for g in past if g['br']=='Waxing gibbous']
for lab,gs in [('all',wg),('1999-2007',[g for g in wg if g['s']<=2007]),('2008-2025',[g for g in wg if g['s']>=2008])]:
    k,n=rate(gs,over);k2,n2=rate(gs,cover);print('waxing gibbous',lab,'over',k,n,round(k/n,3),round(binom_p(k,n),3),'home cover',k2,n2,round(k2/n2,3),round(binom_p(k2,n2),3))
    out.setdefault('wg',[]).append({'label':lab,'over_n':n,'over_pct':k/n,'over_p':binom_p(k,n),'cov_n':n2,'cov_pct':k2/n2,'cov_p':binom_p(k2,n2)})
# claim 3: Lions Thanksgiving
lt=[g for g in G+UP if g['h']=='DET' and g['wd']=='Thursday' and g['date'][5:7]=='11' and 22<=int(g['date'][8:10])<=28]
L=[]
for g in sorted(lt,key=lambda g:g['date']):
    if 'hs' in g: L.append((g['date'],g['br'],'W' if g['hs']>g['as_'] else 'L',round(g['el']))) 
print('Lions Thanksgiving',len(L),L)
wgL=[x for x in L if x[1]=='Waxing gibbous'];print('Lions in waxing gibbous',len(wgL),[x[2] for x in wgL])
out['lions']=[{'d':x[0],'phase':x[1],'r':x[2]} for x in L]
# permutation: how many team x phase cells look "favourable" by chance
TEAMS=sorted({g['h'] for g in past}|{g['a'] for g in past})
def cells(phs):
    c=collections.defaultdict(lambda:[0,0])
    for g,ph in zip(past,phs):
        hw=g['hs']>g['as_'];tie=g['hs']==g['as_']
        if tie:continue
        for t,w in ((g['h'],hw),(g['a'],not hw)):
            c[(t,ph)][0]+=w;c[(t,ph)][1]+=1
    return c
base=cells([g['p8'] for g in past])
tot={};
for g in past:
    if g['hs']==g['as_']:continue
    hw=g['hs']>g['as_']
    for t,w in ((g['h'],hw),(g['a'],not hw)):
        tot.setdefault(t,[0,0]);tot[t][0]+=w;tot[t][1]+=1
def flagged(c):
    f=0;b=0
    for (t,ph),(w,n) in c.items():
        if n<40:continue
        d=w/n-tot[t][0]/tot[t][1]
        if d>=0.10:f+=1
        elif d<=-0.10:b+=1
    return f,b
fb=flagged(base);print('team-phase cells flagged +10/-10:',fb)
random.seed(8)
sims=[]
for _ in range(300):
    ph=[g['p8'] for g in past];random.shuffle(ph);sims.append(flagged(cells(ph)))
avg=(sum(s[0] for s in sims)/300,sum(s[1] for s in sims)/300);print('shuffled phases average flagged:',avg)
out['cells']={'real':fb,'shuffled':avg,'n_cells':len(base)}
# per-team per-phase table for site (1999-2025): wins,n, cover k,n, over k,n
TP={}
for t in TEAMS:
    TP[t]={}
    for p in range(4):
        w=n=ck=cn=ok=on=0
        for g in past:
            if g['p8']!=p:continue
            if t not in(g['h'],g['a']):continue
            ih=g['h']==t
            if g['hs']!=g['as_']:
                n+=1;w+=(g['hs']>g['as_'])==ih
            c=cover(g)
            if c is not None:cn+=1;ck+=(c==ih)
            o=over(g)
            if o is not None:on+=1;ok+=o
        TP[t][p]=[w,n,ck,cn,ok,on]
out['teamphase']=TP;out['tot']={t:tot[t] for t in tot}
# upcoming games
U={}
def imp(ml): return (100/(ml+100)) if ml>0 else (-ml/(-ml+100))
for g in UP+[x for x in G if x['s']==2026]:
    el=g['el'];e={'el':round(el,1),'p8':g['p8'],'ill':illum(el),'br':g['br'],'eve':g['eve'],'full':g['full'],'nw':g['nw'],'sp':g['sp'],'tl':g['tl'],'hml':g['hml'],'aml':g['aml']}
    if g['hml'] is not None and g['aml'] is not None:
        a,b=imp(g['aml']),imp(g['hml']);e['hp']=round(b/(a+b),3)
    U[g['id']]=e
out['games']=U
# next full moon info
out['fulls']=[str(x) for x in fulls if str(x)>='2026-10-01' and str(x)<'2027-02-01']
out['n_past']=len(past)
json.dump(out,open('moon.json','w'),separators=(',',':'),default=str)
print('upcoming sample',list(U.items())[:2]);print(out['fulls'])
