# Wraps the built page into a standalone web page (index.html) for GitHub Pages.
h=open('betting-by-numbers.html').read()
h=h.replace('<meta name="claude:viewport-fit-sides" content="cover">\n','',1)
desc="NFL scores, standings, team and player stats, draft results, all-time records, weekly pick-em and fantasy tools, plus a separate numerology and astrology reading for entertainment."
head='''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="description" content="%s">
<meta property="og:title" content="Tyler&#39;s NFL APP">
<meta property="og:description" content="%s">
<meta property="og:type" content="website">
<meta name="theme-color" content="#0f1512">
''' % (desc,desc)
html=head+h.replace('<meta charset="utf-8">\n','',1)
i=html.index('<style>');j=html.index('</style>')+len('</style>')
html=html[:j]+"\n</head>\n<body>"+html[j:]+"\n</body>\n</html>\n"
open('index.html','w').write(html);print('index.html',len(html))
