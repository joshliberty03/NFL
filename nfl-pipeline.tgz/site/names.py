"""Pythagorean name numbers: Expression/Destiny, Soul Urge, Personality; plus Birthday number."""
import unicodedata
MASTER={11,22,33}
VAL={**{c:i%9+1 for i,c in enumerate("ABCDEFGHI")},
     **{c:i%9+1 for i,c in enumerate("JKLMNOPQR")},
     **{c:i+1 for i,c in enumerate("STUVWXYZ")}}
# correct Pythagorean: S=1,T=2,U=3,V=4,W=5,X=6,Y=7,Z=8
for i,c in enumerate("STUVWXYZ"): VAL[c]=i+1
for i,c in enumerate("ABCDEFGHI"): VAL[c]=i+1
for i,c in enumerate("JKLMNOPQR"): VAL[c]=i+1
VOWELS=set("AEIOU")
SUFFIX={"JR","SR","II","III","IV","V","JR.","SR."}
def reduce_keep(n):
    while n>9 and n not in MASTER: n=sum(int(d) for d in str(n))
    return n
def clean(name):
    name=unicodedata.normalize("NFKD",name)
    name="".join(ch for ch in name if not unicodedata.combining(ch))
    parts=[]
    for w in name.replace("-"," ").replace("'","").split():
        u="".join(ch for ch in w.upper() if ch.isalpha() or ch=='.')
        if u.rstrip('.') in SUFFIX: continue
        u="".join(ch for ch in u if ch.isalpha())
        if u: parts.append(u)
    return parts
def numbers(name):
    parts=clean(name)
    letters=[ch for p in parts for ch in p if ch in VAL]
    if not letters: return None
    tot=sum(VAL[c] for c in letters)
    vow=sum(VAL[c] for c in letters if c in VOWELS)
    con=sum(VAL[c] for c in letters if c not in VOWELS)
    return {"expression":reduce_keep(tot),"soul":reduce_keep(vow),"personality":reduce_keep(con),
            "raw":tot,"name_used":" ".join(parts).title()}
def birthday(datestr):
    return reduce_keep(int(datestr.split("-")[2]))
if __name__=="__main__":
    print("letter values:", {c:VAL[c] for c in "ABCJKLSTUYZ"})
    for n in ["Joseph Flacco","Joe Flacco","Aaron Rodgers","Patrick Mahomes","Joshua Allen","Josh Allen"]:
        print(f"{n:18s}", numbers(n))
    print("birthday 1996-05-21 ->", birthday("1996-05-21"))
    # manual check: AARON = 1+1+9+6+5 = 22 ; RODGERS = 9+6+4+7+5+9+1 = 41 ; total 63 -> 9
    print("manual Aaron Rodgers check: 22+41=63 -> 6+3 =", reduce_keep(63))
