"""Game history 1999-2026 with date numbers and franchise founding numbers; out-of-sample test of team watch items."""
import csv, json, random, sys, collections, importlib.util, re

MASTER = {11, 22, 33}
ORDER = [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 22, 33]
def red(n):
    while n > 9 and n not in MASTER:
        n = sum(int(d) for d in str(n))
    return n
def lifep(b):
    y, m, d = b.split("-"); return red(red(int(m)) + red(int(d)) + red(sum(map(int, y))))
def pday(b, date):
    _, bm, bd = b.split("-"); y, m, d = date.split("-")
    py = red(red(int(bm)) + red(int(bd)) + red(sum(map(int, y))))
    return red(red(py + red(int(m))) + red(int(d)))

FOUNDED = {
 "ARI": None, "ATL": "1965-06-30", "BAL": "1996-02-09", "BUF": "1959-10-28", "CAR": "1993-10-26",
 "CHI": "1920-09-17", "CIN": "1967-05-23", "CLE": "1944-06-04", "DAL": "1960-01-28", "DEN": "1959-08-14",
 "DET": None, "GB": "1919-08-11", "HOU": "1999-10-06", "IND": "1953-01-23", "JAX": "1993-11-30",
 "KC": "1959-08-14", "LA": "1937-02-12", "LAC": "1959-08-14", "LV": "1960-01-30", "MIA": "1965-08-16",
 "MIN": "1960-01-28", "NE": "1959-11-16", "NO": "1966-11-01", "NYG": "1925-08-01", "NYJ": "1959-08-14",
 "PHI": "1933-07-08", "PIT": "1933-07-08", "SEA": "1974-06-04", "SF": "1944-06-04", "TB": "1974-04-24",
 "TEN": "1959-08-14", "WAS": "1932-07-09",
}
RELOC = {"OAK": "LV", "SD": "LAC", "STL": "LA"}

src, outdir = sys.argv[1], sys.argv[2]
rows = []
for r in csv.DictReader(open(src, newline="")):
    if not r["home_score"] or not r["away_score"]: continue
    h, a = RELOC.get(r["home_team"], r["home_team"]), RELOC.get(r["away_team"], r["away_team"])
    hs, as_ = int(r["home_score"]), int(r["away_score"])
    date = r["gameday"]
    rows.append({
        "s": int(r["season"]), "w": r["week"], "t": r["game_type"], "d": date,
        "h": h, "a": a, "hs": hs, "as": as_,
        "hc": r["home_coach"], "ac": r["away_coach"],
        "dn": lifep(date),
        "hpd": pday(FOUNDED[h], date) if FOUNDED[h] else None,
        "apd": pday(FOUNDED[a], date) if FOUNDED[a] else None,
    })
print("games with results:", len(rows), "seasons", rows[0]["s"], "-", rows[-1]["s"])

# out-of-sample: 1999-2025 only (the 2026 watch list was found in 2026 games)
past = [g for g in rows if g["s"] < 2026 and g["hs"] != g["as"]]
def value_rates(games, key_h, key_a, outcomes):
    w = collections.Counter(); n = collections.Counter()
    for g, hw in zip(games, outcomes):
        for k, won in ((g[key_h], hw), (g[key_a], not hw)):
            if k is None: continue
            n[k] += 1; w[k] += won
    return w, n
actual = [g["hs"] > g["as"] for g in past]
random.seed(1999)
SIMS = 2000
sims = [[random.random() < 0.5 for _ in past] for _ in range(SIMS)]

def table(kh, ka):
    vw, vn = value_rates(past, kh, ka, actual); ge = collections.Counter()
    for s in sims:
        sw, sn = value_rates(past, kh, ka, s)
        for k in vn:
            if abs(sw[k] / sn[k] - 0.5) >= abs(vw[k] / vn[k] - 0.5) - 1e-12: ge[k] += 1
    return [{"v": k, "wins": vw[k], "games": vn[k], "p": (ge[k] + 1) / (SIMS + 1)} for k in ORDER if vn[k]]

# add team founding life path per side for the history table
for g in past + rows:
    g["hlp"] = lifep(FOUNDED[g["h"]]) if FOUNDED[g["h"]] else None
    g["alp"] = lifep(FOUNDED[g["a"]]) if FOUNDED[g["a"]] else None
hist_team_pd = table("hpd", "apd")
hist_team_lp = table("hlp", "alp")
print("1999-2025 team personal day:", hist_team_pd)
print("1999-2025 team founding LP:", hist_team_lp)

# home field baseline, for context
print("home win rate 1999-2025:", round(sum(actual) / len(actual), 3))

compact = [[g["s"], g["w"], g["t"], g["d"], g["h"], g["a"], g["hs"], g["as"], g["hc"], g["ac"], g["dn"], g["hpd"], g["apd"]] for g in rows]
json.dump({"games": compact, "hist_team_pd": hist_team_pd, "hist_team_lp": hist_team_lp,
           "home_rate": sum(actual) / len(actual), "n_past": len(past)},
          open(f"{outdir}/history.json", "w"), separators=(",", ":"))
with open(f"{outdir}/nfl_1999_2026_games_numerology.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["season", "week", "game_type", "date", "home", "away", "home_score", "away_score", "home_coach", "away_coach", "date_number", "home_team_personal_day", "away_team_personal_day"])
    w.writerows(compact)
