"""Starting-QB numerology across every game 1999-2026, with the within-team control."""
import csv, json, collections, random, glob, re, statistics, sys, os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from names import numbers, birthday, reduce_keep
MASTER={11,22,33}; ORDER=[1,2,3,4,5,6,7,8,9,11,22,33]
def red(n): return reduce_keep(n)
def lifep(b):
    y,m,d=b.split("-"); return red(red(int(m))+red(int(d))+red(sum(map(int,y))))
def pday(b,date):
    _,bm,bd=b.split("-"); y,m,d=date.split("-")
    py=red(red(int(bm))+red(int(bd))+red(sum(map(int,y))))
    return red(red(py+red(int(m)))+red(int(d)))
# QB identity from every roster year
bd={}; legal={}; common={}
for f in sorted(glob.glob("/home/runner/nfl/hist/roster_*.csv"))+["/home/runner/nfl/roster_2026.csv"]:
    for r in csv.DictReader(open(f,encoding="utf-8")):
        g=r.get("gsis_id")
        if not g or not r.get("birth_date"): continue
        bd[g]=r["birth_date"]
        fn=(r.get("first_name") or "").strip(); ln=(r.get("last_name") or "").strip()
        if fn and ln: legal[g]=f"{fn} {ln}"
        if r.get("full_name"): common[g]=r["full_name"]
games=[]
for r in csv.DictReader(open("/home/runner/nfl/games/games.csv")):
    if not r["home_score"] or r["home_score"]==r["away_score"]: continue
    h,a=r["home_qb_id"],r["away_qb_id"]
    if not h or not a or h not in bd or a not in bd: continue
    games.append({"s":int(r["season"]),"d":r["gameday"],"t":r["game_type"],
      "home":r["home_team"],"away":r["away_team"],"hq":h,"aq":a,
      "hqn":r["home_qb_name"],"aqn":r["away_qb_name"],
      "hw":int(r["home_score"])>int(r["away_score"])})
print("games with both QBs identified:",len(games))
qbids=sorted({g["hq"] for g in games}|{g["aq"] for g in games})
print("distinct QBs:",len(qbids),"| missing birthdate:",len({g for r in csv.DictReader(open('/home/runner/nfl/games/games.csv')) if r['home_score'] for g in (r['home_qb_id'],r['away_qb_id']) if g and g not in bd}))
QB={}
for q in qbids:
    b=bd[q]; nm=legal.get(q) or common.get(q) or ""
    n=numbers(nm) or {}
    nc=numbers(common.get(q,"")) or {}
    QB[q]={"name":common.get(q,nm),"legal":nm,"birth":b,"lp":lifep(b),"bday":birthday(b),
           "expr":n.get("expression"),"soul":n.get("soul"),"pers":n.get("personality"),
           "expr_common":nc.get("expression")}
random.seed(42); N=20000
def flip_p(w,n):
    if not n: return None
    dev=abs(w/n-0.5); ge=sum(1 for _ in range(N) if abs(sum(random.random()<0.5 for _ in range(n))/n-0.5)>=dev-1e-12)
    return (ge+1)/(N+1)
print()
print("=== A) QB match tests: only one QB's number matches the date ===")
res={}
def match_test(fn,label):
    w=n=0
    for g in games:
        hm,am=fn(g,"h"),fn(g,"a")
        if hm==am: continue
        n+=1; w+=(g["hw"] if hm else not g["hw"])
    p=flip_p(w,n); res[label]={"w":w,"n":n,"rate":w/n if n else None,"p":p}
    print(f"  {label:42s} {w}-{n-w} = {100*w/n:.2f}%  n={n}  p={p:.3f}")
dn=lambda d: lifep(d)
match_test(lambda g,s: QB[g[s+"q"]]["lp"]==dn(g["d"]), "QB life path = date number")
match_test(lambda g,s: pday(QB[g[s+"q"]]["birth"],g["d"])==dn(g["d"]), "QB personal day = date number")
match_test(lambda g,s: QB[g[s+"q"]]["expr"]==dn(g["d"]), "QB expression = date number")
match_test(lambda g,s: QB[g[s+"q"]]["bday"]==dn(g["d"]), "QB birthday number = date number")
match_test(lambda g,s: QB[g[s+"q"]]["lp"] in MASTER, "QB has a master life path (11/22/33)")
match_test(lambda g,s: QB[g[s+"q"]]["expr"] in MASTER, "QB has a master expression number")
print()
print("=== B) win rate by each QB number value (raw, team strength NOT removed) ===")
tables={}
for field,lab in [("lp","life path"),("expr","expression"),("soul","soul urge"),("pers","personality"),("bday","birthday")]:
    rows=[]
    for v in ORDER:
        w=n=0
        for g in games:
            for s,won in (("h",g["hw"]),("a",not g["hw"])):
                if QB[g[s+"q"]][field]==v: n+=1; w+=won
        if n>=120: rows.append({"v":v,"w":w,"n":n,"rate":w/n,"p":flip_p(w,n)})
    tables[field]=rows
    best=sorted(rows,key=lambda r:r["p"])[:2]
    print(f"  {lab:12s} "+"  ".join(f"{r['v']}:{100*r['rate']:.1f}%(n={r['n']})" for r in rows))
    print(f"               most extreme: "+", ".join(f"{r['v']} at {100*r['rate']:.1f}% p={r['p']:.3f}" for r in best))
print()
print("=== C) within-QB control: does the SAME quarterback win more on his own matching dates? ===")
for field,lab in [("lp","life path"),("expr","expression"),("bday","birthday")]:
    w=n=0
    byq=collections.defaultdict(lambda:[0,0])
    for g in games:
        for s,won in (("h",g["hw"]),("a",not g["hw"])):
            q=g[s+"q"]; byq[q][0]+=won; byq[q][1]+=1
    for g in games:
        D=dn(g["d"])
        for s,won in (("h",g["hw"]),("a",not g["hw"])):
            q=g[s+"q"]
            if byq[q][1]<16: continue
            if QB[q][field]!=D: continue
            n+=1; w+=won
    # compare to each QB's own baseline over the same filter
    exp=0; cnt=0
    for g in games:
        D=dn(g["d"])
        for s in ("h","a"):
            q=g[s+"q"]
            if byq[q][1]<16 or QB[q][field]!=D: continue
            exp+=byq[q][0]/byq[q][1]; cnt+=1
    print(f"  {lab:12s} on his matching dates: {w}-{n-w} = {100*w/n:.2f}%  |  same QBs' overall rate: {100*exp/cnt:.2f}%  (n={n})")
json.dump({"qbs":QB,"match":res,"tables":tables,"n_games":len(games),
           "seasons":[min(g['s'] for g in games),max(g['s'] for g in games)]},
          open("qb.json","w"),separators=(",",":"))
