"""Builds pstats.json (players), rank.json (team rankings), teamsinfo.json (names/colors/logos),
season.json (all 2026 games + head-to-head). Run with python3 -I from the scratchpad. Inputs in /home/runner/nfl/stats."""
import csv, json, collections, math
D='/home/runner/nfl/stats/'
def rd(f): return list(csv.DictReader(open(D+f)))
def fl(x):
    try: return float(x)
    except: return 0.0
NORM={'LAR':'LA','OAK':'LV','SD':'LAC','STL':'LA','WSH':'WAS','JAC':'JAX'}
nz=lambda t:NORM.get(t,t)

# ---------------- team info ----------------
teams={}
for r in rd('teams.csv'):
    a=r['team_abbr']
    if a in('LAR','OAK','SD','STL','WSH','JAC') or a in('NFL','AFC','NFC') or not r['team_conf'] in('AFC','NFC'): continue
    teams[a]={'name':r['team_name'],'nick':r['team_nick'],'conf':r['team_conf'],'div':r['team_division'],
              'c1':r['team_color'],'c2':r['team_color2'],'logo':r['team_logo_espn']}
assert len(teams)==32,len(teams)
json.dump(teams,open('teamsinfo.json','w'),separators=(',',':'))

# ---------------- players ----------------
# stat columns kept: key -> csv column. Season totals are sums, except the "max" ones.
COLS=[('cmp','completions'),('att','attempts'),('pyd','passing_yards'),('ptd','passing_tds'),('int','passing_interceptions'),
('sck','sacks_suffered'),('pfd','passing_first_downs'),('pepa','passing_epa'),('p2','passing_2pt_conversions'),
('car','carries'),('ryd','rushing_yards'),('rtd','rushing_tds'),('rfd','rushing_first_downs'),('repa','rushing_epa'),('rfl','rushing_fumbles_lost'),
('tgt','targets'),('rec','receptions'),('yds','receiving_yards'),('td','receiving_tds'),('yac','receiving_yards_after_catch'),('ayd','receiving_air_yards'),
('rcfd','receiving_first_downs'),('rcepa','receiving_epa'),('rcfl','receiving_fumbles_lost'),('sfl','sack_fumbles_lost'),
('stt','special_teams_tds'),
('tks','def_tackles_solo'),('tka','def_tackle_assists'),('tfl','def_tackles_for_loss'),('qbh','def_qb_hits'),('dsk','def_sacks'),('dint','def_interceptions'),
('pd','def_pass_defended'),('ff','def_fumbles_forced'),('dtd','def_tds'),('dsf','def_safeties'),('fr','fumble_recovery_opp'),
('pen','penalties'),('peny','penalty_yards'),
('prt','punt_returns'),('pry','punt_return_yards'),('krt','kickoff_returns'),('kry','kickoff_return_yards'),
('fgm','fg_made'),('fga','fg_att'),('fg40','fg_made_40_49'),('fg50','fg_made_50_59'),('fg60','fg_made_60_'),('fgl','fg_long'),('xpm','pat_made'),('xpa','pat_att'),
('pnt','pt_att'),('pnty','pt_yards'),('pni','pt_inside_20'),('pnl','pt_long')]
MAXK={'fgl','pnl'}
KEYS=[k for k,_ in COLS]
KI={k:i for i,k in enumerate(KEYS)}
def load(season):
    rows=[r for r in rd(f'p{str(season)[2:]}.csv') if r['season_type']=='REG']
    ro={r['gsis_id']:r for r in rd(f'rosters{season}.csv' ) if r['gsis_id']}
    P={}
    for r in rows:
        pid=r['player_id']
        p=P.setdefault(pid,{'id':pid,'n':r['player_display_name'] or r['player_name'],'pos':r['position'] or r['position_group'],'tm':nz(r['team']),'w':{},'t':[0.0]*len(KEYS),'gp':0,'fp':0.0,'fpp':0.0})
        wk=int(r['week']); p['tm']=nz(r['team'])  # latest team (rows are in week order)
        row={}
        for k,c in COLS:
            v=fl(r[c])
            if v:
                row[KI[k]]=round(v,2) if v!=int(v) else int(v)
                if k in MAXK: p['t'][KI[k]]=max(p['t'][KI[k]],v)
                else: p['t'][KI[k]]+=v
        if row or fl(r['fantasy_points_ppr']) or fl(r['fantasy_points']):
            p['gp']+=1
        fp,fpp=round(fl(r['fantasy_points']),2),round(fl(r['fantasy_points_ppr']),2)
        p['fp']+=fp;p['fpp']+=fpp
        p['w'][wk]=[nz(r['opponent_team']),fp,fpp,row]
    # roster-only players (no recorded stats)
    for pid,r in ro.items():
        if pid in P: continue
        P[pid]={'id':pid,'n':r['full_name'],'pos':r['position'],'tm':nz(r['team']),'w':{},'t':[0.0]*len(KEYS),'gp':0,'fp':0.0,'fpp':0.0}
    for pid,r in ro.items():
        if pid in P:
            P[pid]['jn']=r['jersey_number'];P[pid]['st']=r['status']
            if not P[pid]['pos']: P[pid]['pos']=r['position']
            if season==2026 and r['team']: P[pid]['tm']=nz(r['team'])
    out=[]
    for p in P.values():
        if not p['n']: continue
        t=[(round(x,2) if x!=int(x) else int(x)) for x in p['t']]
        out.append([p['id'],p['n'],p['pos'] or '',p['tm'],p.get('jn',''),p['gp'],round(p['fp'],1),round(p['fpp'],1),t,
                    {str(w):[v[0],v[1],v[2],{str(i):x for i,x in v[3].items()}] for w,v in sorted(p['w'].items())}])
    out.sort(key=lambda x:-x[7])
    return out
PS={'keys':KEYS,'2026':load(2026),'2025':load(2025)}
for s in('2026','2025'): print(s,len(PS[s]),'players',sum(1 for p in PS[s] if p[5]),'with stats')
json.dump(PS,open('pstats.json','w'),separators=(',',':'))

# ---------------- team rankings ----------------
G=[g for g in rd('games_new.csv')]
def team_rank(season):
    gs=[g for g in G if g['season']==str(season) and g['game_type']=='REG' and g['home_score'] not in('','NA')]
    T={t:collections.defaultdict(float) for t in teams}
    pts={}
    for g in gs:
        h,a=nz(g['home_team']),nz(g['away_team']);hs,as_=int(g['home_score']),int(g['away_score'])
        pts[(g['game_id'],h)]=(hs,as_);pts[(g['game_id'],a)]=(as_,hs)
        for t,pf,pa in((h,hs,as_),(a,as_,hs)):
            T[t]['g']+=1;T[t]['pf']+=pf;T[t]['pa']+=pa
            T[t]['w']+= 1 if pf>pa else 0;T[t]['l']+=1 if pf<pa else 0;T[t]['t']+=1 if pf==pa else 0
    ts=[r for r in rd(f't{str(season)[2:]}.csv') if r['season_type']=='REG']
    by={}
    for r in ts: by[(r['game_id'],nz(r['team']))]=r
    ops=lambda gid,t:[v for (g2,t2),v in by.items() if g2==gid and t2!=t]
    # index opponents quickly
    byg=collections.defaultdict(list)
    for (gid,t),r in by.items(): byg[gid].append((t,r))
    F={'py':'passing_yards','ry':'rushing_yards','sck':'sacks_suffered','int':'passing_interceptions','fl':'fumbles_lost_total','pen':'penalties','peny':'penalty_yards',
       'fd':None,'ptd':'passing_tds','rtd':'rushing_tds','att':'attempts','car':'carries'}
    for gid,lst in byg.items():
        for t,r in lst:
            o=[x for tt,x in lst if tt!=t]
            if t not in T: continue
            d=T[t]
            d['py']+=fl(r['passing_yards']);d['ry']+=fl(r['rushing_yards']);d['sckT']+=fl(r['def_sacks']);d['intT']+=fl(r['def_interceptions'])
            d['gv']+=fl(r['passing_interceptions'])+fl(r['fumbles_lost_total']);d['pen']+=fl(r['penalties']);d['peny']+=fl(r['penalty_yards'])
            d['fd']+=fl(r['passing_first_downs'])+fl(r['rushing_first_downs']);d['sckA']+=fl(r['sacks_suffered'])
            d['frT']+=fl(r['fumble_recovery_opp'])
            if o:
                o=o[0];d['pya']+=fl(o['passing_yards']);d['rya']+=fl(o['rushing_yards']);d['fda']+=fl(o['passing_first_downs'])+fl(o['rushing_first_downs'])
                d['gvA']+=fl(o['passing_interceptions'])+fl(o['fumbles_lost_total'])
    # pbp: 3rd down, red zone, epa, plays
    px=[r for r in rd(f'pbp{str(season)[2:]}.csv') if r['season_type']=='REG' and r['posteam']]
    rz={}
    for r in px:
        o,dft=nz(r['posteam']),nz(r['defteam'])
        if o not in T or dft not in T: continue
        if r['play_type'] in('pass','run') and r['epa'] not in('','NA'):
            e=float(r['epa']);T[o]['epaO']+=e;T[o]['plO']+=1;T[dft]['epaD']+=e;T[dft]['plD']+=1
        if r['down']=='3.0' or r['down']=='3':
            if r['third_down_converted']=='1.0' or r['third_down_converted']=='1': T[o]['t3c']+=1;T[o]['t3a']+=1;T[dft]['t3cA']+=1;T[dft]['t3aA']+=1
            elif r['third_down_failed']=='1.0' or r['third_down_failed']=='1': T[o]['t3a']+=1;T[dft]['t3aA']+=1
        if r['play_type'] in('pass','run') and r['yardline_100'] not in('','NA') and float(r['yardline_100'])<=20:
            key=(r['game_id'],r['fixed_drive'],o);v=rz.setdefault(key,[dft,0])
            if (r['pass_touchdown'] in('1','1.0') or r['rush_touchdown'] in('1','1.0')): v[1]=1
    for (gid,dr,o),(dft,td) in rz.items():
        T[o]['rzt']+=1;T[o]['rztd']+=td;T[dft]['rztA']+=1;T[dft]['rztdA']+=td
    opp=collections.defaultdict(list)
    for g in gs:
        h,a2=nz(g['home_team']),nz(g['away_team']);opp[h].append(a2);opp[a2].append(h)
    wpf=lambda t:(T[t]['w']+T[t]['t']/2)/(T[t]['g'] or 1)
    out={}
    for t,d in T.items():
        g=d['g'] or 1
        out[t]={'g':int(d['g']),'w':int(d['w']),'l':int(d['l']),'t':int(d['t']),
          'pf':int(d['pf']),'pa':int(d['pa']),'ppg':round(d['pf']/g,1),'papg':round(d['pa']/g,1),'diff':int(d['pf']-d['pa']),
          'ypg':round((d['py']+d['ry'])/g,1),'pypg':round(d['py']/g,1),'rypg':round(d['ry']/g,1),
          'ypga':round((d['pya']+d['rya'])/g,1),'pypga':round(d['pya']/g,1),'rypga':round(d['rya']/g,1),
          'fdpg':round(d['fd']/g,1),'fdpga':round(d['fda']/g,1),
          'sck':int(d['sckT']),'sckA':int(d['sckA']),'int':int(d['intT']),'gv':int(d['gv']),'tk':int(d['intT']+d['frT']),'tov':int(d['intT']+d['frT']-d['gv']),
          'pen':int(d['pen']),'peny':int(d['peny']),
          't3p':round(100*d['t3c']/d['t3a'],1) if d['t3a'] else 0,'t3pA':round(100*d['t3cA']/d['t3aA'],1) if d['t3aA'] else 0,
          't3c':int(d['t3c']),'t3a':int(d['t3a']),
          'rzp':round(100*d['rztd']/d['rzt'],1) if d['rzt'] else 0,'rzpA':round(100*d['rztdA']/d['rztA'],1) if d['rztA'] else 0,
          'rzt':int(d['rzt']),'rztd':int(d['rztd']),
          'sos':round(sum(wpf(o) for o in opp[t])/len(opp[t]),3) if opp[t] else 0,
          'epaO':round(d['epaO']/d['plO'],3) if d['plO'] else 0,'epaD':round(d['epaD']/d['plD'],3) if d['plD'] else 0}
    return out
RK={'2026':team_rank(2026),'2025':team_rank(2025)}
json.dump(RK,open('rank.json','w'),separators=(',',':'))
print('rank sample',RK['2026']['KC'])
print('sum check 2026: total games',sum(v['g'] for v in RK['2026'].values())/2,'t3 total',sum(v['t3a'] for v in RK['2026'].values()))

# ---------------- all 2026 games + head-to-head (win/loss only, since 1999) ----------------
allg=[g for g in G if g['game_type'] in('REG','WC','DIV','CON','SB') or True]
h2h=collections.defaultdict(lambda:[0,0,0])  # key "A|B" sorted -> [wins A, wins B, ties]
for g in G:
    if g['home_score'] in('','NA'): continue
    if int(g['season'])>2026: continue
    h,a=nz(g['home_team']),nz(g['away_team'])
    if h not in teams or a not in teams: continue
    k=tuple(sorted((h,a)));hs,as_=int(g['home_score']),int(g['away_score'])
    if hs==as_: h2h[k][2]+=1
    elif (hs>as_)==(h==k[0]): h2h[k][0]+=1
    else: h2h[k][1]+=1
json.dump({'|'.join(k):v for k,v in h2h.items()},open('h2h.json','w'),separators=(',',':'))
print('h2h pairs',len(h2h),'sample BAL|BUF',h2h[('BAL','BUF')])

# ---------------- season.json: every 2026 game with line, for Pick Your Wins / Fantasy ----------------
gs=[g for g in G if g['season']=='2026' and g['game_type']=='REG']
def fv(x):
    try: return float(x)
    except: return None
SEA=[]
for g in gs:
    pl=g['home_score'] not in('','NA')
    SEA.append({'id':g['game_id'],'wk':int(g['week']),'d':g['gameday'],'t':g['gametime'] or '13:00','h':nz(g['home_team']),'a':nz(g['away_team']),
      'hs':int(g['home_score']) if pl else None,'as':int(g['away_score']) if pl else None,'sp':fv(g['spread_line'])})
json.dump(SEA,open('season.json','w'),separators=(',',':'))
print('season',len(SEA),sum(1 for x in SEA if x['hs'] is not None))
# ---------------- DEF weekly fantasy points (2026) ----------------
def defpts(season):
    ts=[r for r in rd(f't{str(season)[2:]}.csv') if r['season_type']=='REG']
    pa={}
    for g in G:
        if g['season']==str(season) and g['game_type']=='REG' and g['home_score'] not in('','NA'):
            pa[(g['game_id'],nz(g['home_team']))]=int(g['away_score']);pa[(g['game_id'],nz(g['away_team']))]=int(g['home_score'])
    out={}
    for r in ts:
        t=nz(r['team']);k=(r['game_id'],t)
        if k not in pa: continue
        p=pa[k]
        tier=10 if p==0 else 7 if p<=6 else 4 if p<=13 else 1 if p<=20 else 0 if p<=27 else -1 if p<=34 else -4
        pts=fl(r['def_sacks'])+2*fl(r['def_interceptions'])+2*fl(r['fumble_recovery_opp'])+6*(fl(r['def_tds'])+fl(r['special_teams_tds']))+2*fl(r['def_safeties'])+tier+fl(r['def_fg_blocks'])*2
        out.setdefault(t,{})[int(r['week'])]=round(pts,1)
    return out
json.dump({'2026':defpts(2026),'2025':defpts(2025)},open('defpts.json','w'),separators=(',',':'))
print('def sample',list(defpts(2026)['KC'].items())[:5])

# ---------------- 2025 results for rank trends ----------------
S25=[{'wk':int(g['week']),'h':nz(g['home_team']),'a':nz(g['away_team']),'hs':int(g['home_score']),'as':int(g['away_score'])} for g in G if g['season']=='2025' and g['game_type']=='REG' and g['home_score'] not in('','NA')]
json.dump(S25,open('season25.json','w'),separators=(',',':'));print('2025 games',len(S25))
