/* ===================== FANTASY FOOTBALL ===================== */
(function(){
  const KEY='bbn.fantasy.v2';
  const SLOTS=[['QB',['QB']],['RB1',['RB']],['RB2',['RB']],['WR1',['WR']],['WR2',['WR']],['TE',['TE']],['FLEX',['RB','WR','TE']],['K',['K']],['DEF',['DEF']]];
  const SF_SLOT=['SFLEX',['QB','RB','WR','TE']];
  const rounds=()=>L?(L.r||(L.sf?13:12)):15,slots=()=>L&&L.sf?[...SLOTS.slice(0,7),SF_SLOT,...SLOTS.slice(7)]:SLOTS,cap=p=>(L&&L.sf&&p==='QB')?4:CAP[p];
  const CAP={QB:3,RB:8,WR:8,TE:3,K:2,DEF:2},POSORD=['QB','RB','WR','TE','K','DEF'];
  const P26=new Map(PS['2026'].map(r=>[r[0],r])),P25=new Map(PS['2025'].map(r=>[r[0],r]));
  const lastWeek=Math.max(...SEA.map(g=>g.wk)),LASTREG=Math.min(17,lastWeek-1);
  const playsIn=new Map();SEA.forEach(g=>{[g.h,g.a].forEach(t=>{const k=g.wk;if(!playsIn.has(k))playsIn.set(k,new Set());playsIn.get(k).add(t)})});
  const nextOpenWeek=()=>{for(let w=1;w<=lastWeek;w++){if(wkState(w)!=='final')return w}return lastWeek};
  const defaultStart=nextOpenWeek();
  /* ---- points ---- */
  function ptsRow(r,wk,sc){const x=r[9][wk];if(!x)return 0;
    if(r[2]==='K'){return kickPts(PKEYS.map((k,i)=>x[3][i]||0))}
    return sc==='ppr'?x[2]:sc==='half'?Math.round((x[1]+x[2])*50)/100:x[1]}
  const POOL=(()=>{const out=[];
    PS['2026'].forEach(r=>{const pos=r[2];if(!['QB','RB','WR','TE','K'].includes(pos)||!TI[r[3]])return;const o=P25.get(r[0]);
      const sum=(rr)=>rr?Object.keys(rr[9]).reduce((a,w)=>a+ptsRow(rr,w,'ppr'),0):0;
      const g26=r[5],pp26=sum(r),pp25=sum(o),g25=o?o[5]:0;
      const v=g26>=3?pp26/g26*0.7+(g25>=5?pp25/g25*0.3:pp26/g26*0.3):(g25>=5?pp25/g25*0.8:0);
      if(v<=0&&g26===0)return;out.push({id:r[0],n:r[1],pos,tm:r[3],v:Math.round(v*100)/100,g:g26})});
    Object.keys(TI).forEach(t=>{const d=DEFP['2026'][t]||{},ws=Object.values(d);const v=ws.length?ws.reduce((a,b)=>a+b,0)/ws.length:0;out.push({id:'DEF-'+t,n:tname(t)+' D/ST',pos:'DEF',tm:t,v:Math.round(v*100)/100,g:ws.length})});
    out.sort((a,b)=>b.v-a.v);return out})();
  const PIDX=new Map(POOL.map(p=>[p.id,p]));
  const wkPts=(pid,wk,sc)=>{if(pid.startsWith('DEF-')){const d=DEFP['2026'][pid.slice(4)];return d&&d[wk]!=null?d[wk]:0}const r=P26.get(pid);return r?ptsRow(r,wk,sc):0};
  const projMemo=new Map();
  function proj(pid,sc,wk){ // average of earlier 2026 weeks, else 2025 average; zero on a bye
    const p=PIDX.get(pid);if(!p)return 0;const pl=playsIn.get(wk);if(pl&&!pl.has(p.tm))return 0;
    const k=pid+'|'+sc+'|'+wk;if(projMemo.has(k))return projMemo.get(k);
    let vals=[];
    if(pid.startsWith('DEF-')){const d=DEFP['2026'][pid.slice(4)]||{};Object.keys(d).forEach(w=>{if(+w<wk)vals.push(d[w])});
      if(!vals.length){const d5=DEFP['2025'][pid.slice(4)]||{};vals=Object.values(d5).map(x=>x*0.85)}}
    else{const r=P26.get(pid);if(r)Object.keys(r[9]).forEach(w=>{if(+w<wk)vals.push(ptsRow(r,w,sc))});
      if(!vals.length){const o=P25.get(pid);if(o)vals=Object.keys(o[9]).map(w=>ptsRow(o,w,sc)*0.85)}}
    const v=vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:0;const out=Math.round(v*10)/10;projMemo.set(k,out);return out}
  /* ---- league state ---- */
  let L=lsGet(KEY,null);const save=()=>lsSet(KEY,L);
  const rosterAt=(L,mi,wk)=>{let r=L.picks.filter(x=>x.m===mi).map(x=>x.id);
    (L.tx||[]).filter(t=>t.wk<=wk).forEach(t=>{
      if(t.type==='add'&&t.m===mi){r=r.filter(x=>x!==t.drop);r.push(t.add)}
      if(t.type==='trade'){if(t.a===mi){r=r.filter(x=>!t.give.includes(x)).concat(t.get)}else if(t.b===mi){r=r.filter(x=>!t.get.includes(x)).concat(t.give)}}});
    return r};
  function lineup(roster,wk,sc,byActual,ov){
    const items=roster.map(id=>({id,p:PIDX.get(id),pr:proj(id,sc,wk),pts:wkPts(id,wk,sc)})).filter(x=>x.p).sort((a,b)=>b.pr-a.pr||b.p.v-a.p.v);const used=new Set(),lu=[];
    const slS=[...slots()].sort((a,b)=>a[1].length-b[1].length);if(ov)slS.forEach(([slot,allowed])=>{const it=ov[slot]&&items.find(x=>x.id===ov[slot]&&!used.has(x.id)&&allowed.includes(x.p.pos));if(it){used.add(it.id);lu.push({slot,...it,manual:1})}});
    slS.forEach(([slot,allowed])=>{if(lu.some(z=>z.slot===slot))return;const it=items.find(x=>!used.has(x.id)&&allowed.includes(x.p.pos));if(it){used.add(it.id);lu.push({slot,...it})}else lu.push({slot,id:null,p:null,pr:0,pts:0})});
    const order=slots().map(s=>s[0]);lu.sort((a,b)=>order.indexOf(a.slot)-order.indexOf(b.slot));
    const r2=x=>Math.round(x*100)/100;
    return {lu,total:r2(lu.reduce((a,b)=>a+b.pts,0)),proj:r2(lu.reduce((a,b)=>a+b.pr,0)),bench:items.filter(x=>!used.has(x.id))};
  }
  const LU=(L,mi,w)=>lineup(rosterAt(L,mi,w),w,L.sc,undefined,L.ov&&L.ov[mi+':'+w]);
  let editLU=null;
  const snake=(n,i)=>{const r=Math.floor(i/n),k=i%n;return r%2===0?k:n-1-k};
  function rr(n){const ids=[...Array(n).keys()];if(n%2)ids.push(-1);const m=ids.length,rounds=m-1,wks=[];
    for(let r=0;r<rounds;r++){const pairs=[];for(let i=0;i<m/2;i++)pairs.push([ids[i],ids[m-1-i]]);wks.push(pairs);ids.splice(1,0,ids.pop())}return wks}
  const plan=(L)=>{const n=L.mgr.length,po=n>=4&&L.start<=LASTREG-2,regEnd=po?LASTREG-2:LASTREG,sch={},R=rr(n);let w=L.start,i=0;
    while(w<=regEnd){sch[w]=R[i%R.length];w++;i++}return {sch,regEnd,po,semi:regEnd+1,fin:regEnd+2}};
  const wkFinal=w=>wkState(w)==='final';
  const hasCPU=L=>L.cpu&&L.cpu.some(Boolean);
  function standings(L){const n=L.mgr.length,rows=L.mgr.map((m,i)=>({i,name:m,cpu:!!(L.cpu&&L.cpu[i]),w:0,l:0,t:0,pf:0,pa:0})),P=plan(L);
    Object.keys(P.sch).map(Number).forEach(w=>{if(wkState(w)==='·')return;P.sch[w].forEach(([a,b])=>{if(a<0||b<0)return;const x=LU(L,a,w).total,y=LU(L,b,w).total;
      rows[a].pf+=x;rows[a].pa+=y;rows[b].pf+=y;rows[b].pa+=x;if(!wkFinal(w))return;if(x>y){rows[a].w++;rows[b].l++}else if(y>x){rows[b].w++;rows[a].l++}else{rows[a].t++;rows[b].t++}})});
    rows.forEach(r=>{r.pf=Math.round(r.pf*100)/100;r.pa=Math.round(r.pa*100)/100});
    return rows.sort((a,b)=>(b.w+b.t/2)-(a.w+a.t/2)||b.pf-a.pf)}
  function autoPick(L,mi){
    const taken=new Set(L.picks.map(x=>x.id)),have=L.picks.filter(x=>x.m===mi).map(x=>PIDX.get(x.id));
    const cnt=pos=>have.filter(h=>h.pos===pos).length,left=rounds()-have.length;
    const needs=[];if(cnt('QB')<(L.sf?2:1))needs.push('QB');if(cnt('RB')<2)needs.push('RB');if(cnt('WR')<2)needs.push('WR');if(!cnt('TE'))needs.push('TE');if(!cnt('K'))needs.push('K');if(!cnt('DEF'))needs.push('DEF');
    const pickable=POOL.filter(p=>!taken.has(p.id)&&cnt(p.pos)<cap(p.pos));
    let c=pickable.filter(p=>(p.pos!=='K'&&p.pos!=='DEF')||left<=3);
    if(left<=needs.length)c=pickable.filter(p=>needs.includes(p.pos));
    return c[0]||pickable[0]}
  const needOK=(L,mi,p)=>L.picks.filter(x=>x.m===mi&&PIDX.get(x.id).pos===p.pos).length<cap(p.pos);
  function runCPU(){if(!L||L.phase!=='draft')return;const n=L.mgr.length;while(L.picks.length<n*rounds()&&L.cpu&&L.cpu[snake(n,L.picks.length)]){const m=snake(n,L.picks.length),p=autoPick(L,m);if(!p)break;L.picks.push({m,id:p.id})}}
  /* ---- rules text ---- */
  const RULES=`<div class="rules">
    <h3>How it works</h3>
    <ol>
      <li><b>Set up a league.</b> Play with friends on this screen (2 to 6 managers) or play solo against computer teams (1 to 5).</li>
      <li><b>Draft.</b> Managers take turns choosing real players in a snake draft, 15 rounds (16 with Superflex). Computer managers pick for themselves.</li>
      <li><b>Each week</b> your best lineup is set for you, using each player's average so far. Your lineup scores that week's real stats.</li>
      <li><b>Win the week</b> by scoring more than your opponent. The league plays a round-robin schedule. In a league of 4 or more with enough weeks left, the top four meet in the playoffs.</li>
      <li><b>Manage your team.</b> Add free agents and drop players, or trade with another human manager. Moves take effect from the week you choose and cannot change a week that is already final.</li>
    </ol>
    <h3>Your lineup</h3>
    <p class="note">9 starters: 1 QB, 2 RB, 2 WR, 1 TE, 1 FLEX (a RB, WR or TE), 1 K and 1 D/ST. You carry 15 players, so 6 sit on the bench, the same as most hosted leagues. Position limits for your roster: QB 3, RB 8, WR 8, TE 3, K 2, D/ST 2. If the league is set to Superflex when it is created, there is a second flex spot (SFLEX) that can also be a QB, so 10 start and 16 are carried (QB limit 4).</p>
    <h3>Scoring</h3>
    <ul>
      <li><b>Passing:</b> 1 point per 25 yards, 4 per touchdown, −2 per interception.</li>
      <li><b>Rushing and receiving:</b> 1 point per 10 yards, 6 per touchdown. A catch adds 1 point in PPR leagues and half a point in half-PPR leagues.</li>
      <li><b>Other:</b> 2 per two-point conversion, −2 per fumble lost.</li>
      <li><b>Kickers:</b> 3 per field goal under 40 yards, 4 for 40 to 49, 5 for 50 or more, 1 per extra point, −1 per missed field goal.</li>
      <li><b>Team defense / special teams:</b> 1 per sack, 2 per interception, 2 per fumble recovery, 2 per safety, 2 per blocked field goal, 6 per touchdown. Points allowed: 0 is +10, 1–6 is +7, 7–13 is +4, 14–20 is +1, 21–27 is 0, 28–34 is −1, 35 or more is −4.</li>
    </ul>
    <h3>Standings, tiebreakers and playoffs</h3>
    <p class="note">Teams are ranked by wins (a tie counts half), then by total points scored. Only final weeks count as wins and losses; a week that is still in progress adds to points only. Playoffs, when there are enough weeks, are two rounds: seeds 1 v 4 and 2 v 3, then the final. In a solo league you play the same schedule against the computer teams.</p>
    <h3>Terms</h3>
    <dl>
      <dt>Snake draft</dt><dd>The pick order reverses every round, so the manager picking last in one round picks first in the next.</dd>
      <dt>Standard, Half PPR, PPR</dt><dd>PPR means "points per reception". Standard gives nothing for a catch, half PPR gives 0.5 and PPR gives 1.</dd>
      <dt>SFLEX (Superflex)</dt><dd>An optional extra starting spot, chosen when the league is created, that any QB, RB, WR or TE can fill. It lets you start two quarterbacks.</dd>
      <dt>FLEX</dt><dd>A starting spot that any running back, wide receiver or tight end can fill.</dd>
      <dt>Bench</dt><dd>Rostered players who are not in the starting lineup that week. They score nothing for you.</dd>
      <dt>D/ST</dt><dd>A team's defense and special teams, drafted as one unit and scored on its sacks, takeaways, touchdowns and points allowed.</dd>
      <dt>Projection</dt><dd>A player's average points per game so far this season (or last season's, discounted, before he has played). A player whose team has a bye is projected at zero.</dd>
      <dt>Auto lineup</dt><dd>Each week the highest-projected eligible player is started at each spot, so the lineup is set before the games and does not use hindsight.</dd>
      <dt>Free agent</dt><dd>Any player not on a roster. You can add one if you drop someone, which keeps your roster full (15 players, or 16 with Superflex).</dd>
      <dt>Bye week</dt><dd>A week in which a player's real team does not play.</dd>
      <dt>Points for / against</dt><dd>The total your lineups have scored, and the total your opponents' lineups scored against you.</dd>
      <dt>Seed</dt><dd>A team's rank going into the playoffs. Seed 1 is the best record.</dd>
      <dt>Live week</dt><dd>A week where some games are final and others are still to be played.</dd>
      <dt>Computer team</dt><dd>A team drafted and set by the site in a solo league. It does not trade or pick up free agents.</dd>
    </dl>
  </div>`;
  const rulesCard=(open)=>`<details class="card rulescard"${open?' open':''}><summary><h2 style="display:inline">Rules and terms</h2></summary>${RULES}</details>`;
  /* ---- screens ---- */
  let q='',fpos='',tab='lineups',tradeSel={a:0,b:1,give:[],get:[]},pend=null,txWeek=null,faPos='',faQ='';
  const namesInputs=(n,mode)=>mode==='solo'?`<label>Your name<input class="ffmn" value="You" maxlength="18"></label>`:Array.from({length:n},(_,i)=>`<label>Manager ${i+1}<input class="ffmn" value="${['Alex','Blake','Casey','Drew','Emery','Finley'][i]}" maxlength="18"></label>`).join('');
  function render(){
    $('ffeyebrow').textContent=L?`${L.name} · ${L.mgr.length} teams${hasCPU(L)?' (solo with computer teams)':''} · ${L.sc==='ppr'?'PPR':L.sc==='half'?'Half PPR':'Standard'} scoring`:`Set up a league · weeks ${defaultStart}–${LASTREG} available`;
    const el=$('ffbody');
    if(!L){el.innerHTML=setupHtml()+rulesCard(true);return}
    if(L.phase==='draft'){el.innerHTML=draftHtml()+rulesCard(false);return}
    el.innerHTML=seasonHtml()+rulesCard(false)}
  function setupHtml(){return `<div class="card"><h2>New league</h2>
    <div class="setup">
      <label>League name<input id="ffname" value="Sunday League" maxlength="30"></label>
      <label>Mode<select id="ffmode"><option value="friends">With friends on this screen</option><option value="solo">Solo, against computer teams</option></select></label>
      <label id="ffnwrap">Managers<select id="ffn">${[2,3,4,5,6].map(n=>`<option value="${n}"${n===4?' selected':''}>${n} managers</option>`).join('')}</select></label>
      <label id="ffcwrap" hidden>Computer teams<select id="ffcpu">${[1,2,3,4,5].map(n=>`<option value="${n}"${n===3?' selected':''}>${n} computer team${n>1?'s':''}</option>`).join('')}</select></label>
      <label>Quarterbacks<select id="ffsf"><option value="0">Standard: one QB starts</option><option value="1">Superflex: a second flex spot that can also be a QB</option></select></label>
      <label>Scoring<select id="ffsc"><option value="ppr">PPR (1 per catch)</option><option value="half">Half PPR</option><option value="std">Standard</option></select></label>
      <label>Season starts in week<select id="ffstart">${Array.from({length:LASTREG},(_,i)=>i+1).map(w=>`<option value="${w}"${w===defaultStart?' selected':''}>Week ${w}${wkState(w)==='final'?' (already played)':wkState(w)==='live'?' (in progress)':''}</option>`).join('')}</select></label>
    </div>
    <div class="setup" id="ffnames">${namesInputs(4,'friends')}</div>
    <p class="note">Choosing a week that has already been played replays it with the real results. Open the rules and terms below for how scoring, lineups and playoffs work.</p>
    <div class="btnrow"><button class="btn solid" type="button" id="ffgo">Start the draft</button></div></div>`}
  function draftHtml(){
    const n=L.mgr.length,total=n*rounds(),cur=L.picks.length,done=cur>=total,turn=done?-1:snake(n,cur),taken=new Set(L.picks.map(x=>x.id));
    const gt=`style="grid-template-columns:64px repeat(${n},minmax(78px,1fr))"`,curR=Math.floor(cur/n);
    const head=`<div class="brow" ${gt}><div class="bhd"></div>${L.mgr.map((m,i)=>`<div class="bhd${i===turn?' clock':''}">${esc(m)}${L.cpu&&L.cpu[i]?' <span class="st">CPU</span>':''}</div>`).join('')}</div>`;
    let rows='';for(let r=0;r<rounds();r++){const cells=Array(n).fill('');for(let k=0;k<n;k++){const idx=r*n+(r%2===0?k:n-1-k),pk=L.picks[idx],m=k;
      cells[m]=pk?(()=>{const p=PIDX.get(pk.id);return `<div class="bcell ${p.pos}"><small class="pn">#${idx+1}</small><b>${esc(p.n.split(' ').slice(-1)[0])}</b><small>${esc(p.n.split(' ')[0].slice(0,1))}. · ${p.pos} · ${p.tm}</small></div>`})():`<div class="bcell empty${idx===cur?' now':''}"><small class="pn">#${idx+1}</small>${idx===cur?'<b>On the clock</b>':''}</div>`}
      rows+=`<div class="brow${r===curR&&!done?' curround':''}" ${gt}><div class="brl"><b>Round ${r+1}</b><small>${r%2===0?'left to right →':'← right to left'}</small></div>${cells.join('')}</div>`}
    const mine=turn>=0?L.picks.filter((x,i)=>snake(n,i)===turn).map(x=>PIDX.get(x.id)):[];
    const REQ={QB:1,RB:2,WR:2,TE:1,K:1,DEF:1},have=ps=>mine.filter(p=>p.pos===ps).length;
    const extras=Math.max(0,have('RB')-2)+Math.max(0,have('WR')-2)+Math.max(0,have('TE')-1)+(L.sf?Math.max(0,have('QB')-1):0),flexN=L.sf?2:1,flexOpenN=Math.max(0,flexN-extras),flexOpen=flexOpenN>0;
    const left=rounds()-mine.length;
    const sel=POSORD.map(ps=>{const h=have(ps),need=Math.max(0,REQ[ps]-h),room=Math.max(0,(cap(ps)||0)-h);
      return `<button type="button" class="selchip ${ps}${need?' need':room?'':' full'}" data-fpos="${ps}" title="Show only ${ps}s"><b>${ps}</b><span>${need?`need ${need} starter${need>1?'s':''}`:room?'starter set':'maxed out'}</span><small>${h} drafted · room for ${room}</small></button>`}).join('')+`<span class="selchip FLEX${flexOpen?' need':''}"><b>${L.sf?'FLEX + SFLEX':'FLEX'}</b><span>${flexOpen?flexOpenN+' still open':'filled'}</span><small>${L.sf?'RB, WR, TE; SFLEX may be a QB':'1 RB, WR or TE'}</small></span>`;
    const clockCard=turn>=0?`<div class="clockcard"><div><span class="st">On the clock</span><b>${esc(L.mgr[turn])}</b><span class="st">Pick ${cur+1} of ${total} · Round ${curR+1} · ${left} pick${left===1?'':'s'} left for ${esc(L.mgr[turn])}</span></div><div class="selwrap"><span class="st">${esc(L.mgr[turn])}'s roster: what is left to pick (tap a position to filter the list)</span><div class="selrow">${sel}</div></div><div><span class="st">Drafted so far</span><div>${mine.length?mine.map(p=>`<span class="rchip ${p.pos}">${esc(p.n)}</span>`).join(''):'<span class="st">None yet</span>'}</div></div></div>`:'';
    const avail=POOL.filter(p=>!taken.has(p.id)&&(!fpos||p.pos===fpos)&&(!q||p.n.toLowerCase().includes(q))).slice(0,60);
    return `<div class="card"><div class="teamhead"><h2>Draft room</h2><span class="count">${done?'Draft complete':`Pick ${cur+1} of ${total} · round ${Math.floor(cur/n)+1}`}</span></div>
      ${done?`<div class="btnrow"><button class="btn solid" type="button" id="ffseason">Open the season</button></div>`:`${clockCard}<div class="btnrow"><button class="btn" type="button" id="ffauto">Auto-pick for ${esc(L.mgr[turn])}</button><button class="btn" type="button" id="ffautoall">Auto-draft the rest</button><button class="btn" type="button" id="ffundo" ${cur?'':'disabled'}>Undo last pick</button></div>`}
    </div><div class="warroom"><div class="card" style="overflow:auto"><h2>Draft board</h2><p class="note">Each row is a round (Round 1 is everyone's first pick). The order snakes: it reverses every other round, so whoever picks last in one round picks first in the next. The number on each square is the overall pick.</p><div class="legend">${POSORD.map(ps=>`<span class="rchip ${ps}">${ps}</span>`).join('')}</div><div class="board">${head}${rows}</div></div>
    <div class="card"><h2>Players available</h2><div class="filters"><label>Position<select id="ffpos"><option value="">All</option>${POSORD.map(p=>`<option value="${p}"${fpos===p?' selected':''}>${p}</option>`).join('')}</select></label><label>Search<input id="ffq" type="search" value="${esc(q)}" placeholder="Name"></label></div>
      <div class="pool-list">${avail.map(p=>`<div class="poolrow"><span class="pos rchip ${p.pos}">${p.pos}</span><span class="nm">${esc(p.n)}<small>${tlogo(p.tm,14)} ${p.tm}</small></span><span class="pv" title="Average points per game">${p.v.toFixed(1)}</span><button class="btn" type="button" data-pick="${p.id}" ${done||!needOK(L,turn,p)?'disabled':''}>Draft</button></div>`).join('')||'<p class="note">Nobody matches.</p>'}</div></div></div>
    <div class="card"><div class="btnrow"><button class="btn danger" type="button" id="ffreset">Scrap this league</button></div></div>`}
  function seasonHtml(){
    const n=L.mgr.length,P=plan(L),wks=Object.keys(P.sch).map(Number),allW=[...wks,...(P.po?[P.semi,P.fin]:[])];
    const wk=Math.min(Math.max(L.wk||wks[0],allW[0]),allW[allW.length-1]),st=standings(L);
    const editing=(i,w)=>editLU===i+':'+w;
    const availTag=(p,w)=>{if(!p)return '';const x=INJS(p.id),by=BYE[p.tm]===w;return (by?' <span class="inj O">BYE</span>':'')+(x&&w>=INJ.wk?injchip(p.id):'')};
    const luSel=(i,w,s)=>{const allowed=slots().find(z=>z[0]===s.slot)[1];const opts=rosterAt(L,i,w).map(id=>PIDX.get(id)).filter(p=>p&&allowed.includes(p.pos));
      return `<select data-luslot="${s.slot}" data-lum="${i}" data-luw="${w}" aria-label="Player for ${s.slot}">${opts.map(p=>`<option value="${p.id}"${s.p&&s.p.id===p.id?' selected':''}>${esc(p.n)} (${p.pos} ${p.tm})${INJS(p.id)&&w>=INJ.wk?' - '+INJS(p.id).s:''}${BYE[p.tm]===w?' - BYE':''}</option>`).join('')}</select>`};
    const luCtl=(i,w,state)=>{if(state==='final'||(L.cpu&&L.cpu[i]))return '';const has=L.ov&&L.ov[i+':'+w];return `<div class="btnrow" style="margin-top:8px"><button class="btn" type="button" data-luedit="${i}:${w}">${editing(i,w)?'Done':'Set lineup'}</button>${has?`<button class="btn" type="button" data-luclr="${i}:${w}">Back to auto</button>`:''}</div>`};
    const side=(i,w,opp)=>{if(i<0)return `<div class="mu-side"><h3>Bye week</h3></div>`;const bl=LU(L,i,w),ob=opp>=0?LU(L,opp,w).total:-1;const state=wkState(w);
      return `<div class="mu-side${state==='final'&&bl.total>ob?' won':''}"><h3><span>${esc(L.mgr[i])}${L.cpu&&L.cpu[i]?' <span class="st">CPU</span>':''}</span><span>${bl.total.toFixed(1)}${state!=='final'?` <small class="st">proj ${bl.proj.toFixed(1)}</small>`:''}</span></h3>${bl.lu.map(s=>`<div class="mu-row"><span class="pos">${s.slot.replace(/\d/,'')}</span><span>${editing(i,w)?luSel(i,w,s):(s.p?esc(s.p.n)+` <span class="st">${s.p.tm}</span>`+(s.manual?' <span class="st">set by you</span>':'')+availTag(s.p,w):'<span class="st">empty</span>')}</span><b class="mono">${s.pts.toFixed(1)}${state!=='final'&&s.pr?` <small class="st">/${s.pr.toFixed(1)}</small>`:''}</b></div>`).join('')}${luCtl(i,w,state)}</div>`};
    let pairs=P.sch[wk]||[];let title=`Week ${wk}`;
    if(P.po&&(wk===P.semi||wk===P.fin)){const seeds=st.map(r=>r.i);const regDone=Object.keys(P.sch).every(w=>wkFinal(+w));
      if(wk===P.semi)pairs=regDone?[[seeds[0],seeds[3]],[seeds[1],seeds[2]]]:[];
      else{const sw=poWinners(L,st,P);pairs=sw?[[sw[0],sw[1]]]:[]}
      title=`Playoffs · ${wk===P.semi?'semifinals':'final'}`}
    const match=pairs.length?pairs.map(([a,b])=>`<div class="matchup">${side(a,wk,b)}<div class="mu-vs">vs</div>${side(b,wk,a)}</div>`).join(''):`<p class="note">${wk>P.regEnd?'The playoff matchups are set once the regular season is final.':'No games this week.'}</p>`;
    const st2=wkState(wk);
    const rosters=L.mgr.map((m,i)=>`<details class="card"><summary><b>${esc(m)}</b> <span class="st">${rosterAt(L,i,wk).length} players</span></summary><div class="tablebox"><table><tbody>${rosterAt(L,i,wk).map(id=>PIDX.get(id)).filter(Boolean).sort((a,b)=>POSORD.indexOf(a.pos)-POSORD.indexOf(b.pos)).map(p=>`<tr><td class="mono">${p.pos}</td><td>${esc(p.n)}</td><td class="mono">${p.tm}</td><td class="mono">${proj(p.id,L.sc,wk).toFixed(1)} proj</td></tr>`).join('')}</tbody></table></div></details>`).join('');
    const champ=P.po&&wkFinal(P.fin)?(()=>{const w=poWinners(L,st,P,true);return w!=null?`<p class="note" style="font-size:15px;color:var(--fg)"><b>Champion: ${esc(L.mgr[w])}</b></p>`:''})():'';
    const tabs=`<div class="wkstrip" style="margin-bottom:6px">${[['lineups','Matchups'],['fa','Free agents'],...(hasCPU(L)?[]:[['trade','Trades']]),['log','Moves']].map(([k,l])=>`<button class="wkb" type="button" data-ftab="${k}" aria-pressed="${tab===k}" style="min-width:90px">${l}</button>`).join('')}</div>`;
    return `<div class="card"><div class="teamhead"><h2>Standings</h2><span class="count">${wks.length} regular weeks${P.po?' + playoffs':''} · stats through week ${LASTWK}${wkState(LASTWK)==='live'?' (in progress)':''}</span></div>
      <div class="tablebox"><table class="stand"><thead><tr><th>#</th><th>Team</th><th>W</th><th>L</th><th>T</th><th>Points for</th><th>Points against</th></tr></thead><tbody>${st.map((r,i)=>`<tr${P.po&&i<4?' class="seed"':''}><td>${i+1}</td><td><b>${esc(r.name)}</b>${r.cpu?' <span class="st">CPU</span>':''}</td><td class="w">${r.w}</td><td>${r.l}</td><td>${r.t}</td><td class="mono">${r.pf.toFixed(1)}</td><td class="mono">${r.pa.toFixed(1)}</td></tr>`).join('')}</tbody></table></div>${P.po?'<p class="note">The top four teams reach the playoffs.</p>':''}${champ}</div>
      <div class="card">${tabs}${tab==='lineups'?`<div class="teamhead"><h2>${title}</h2><span class="count">${st2==='live'?'In progress':st2==='·'?'Not played yet · projections':'Final'}</span></div>
      <div class="wkstrip">${allW.map(w=>`<button class="wkb" type="button" data-fw="${w}" aria-pressed="${w===wk}">${w}<s>${P.po&&w>P.regEnd?'PO':wkState(w)}</s></button>`).join('')}</div>${match}`:tab==='fa'?faHtml(wk):tab==='trade'?tradeHtml(wk):logHtml()}</div>
      <div class="card"><h2>Rosters</h2>${rosters}</div>
      <div class="card"><h2>Back up or move this league</h2><textarea class="code" id="ffcode" aria-label="League code"></textarea><div class="btnrow"><button class="btn" type="button" id="ffexp">Make code</button><button class="btn" type="button" id="ffimp">Load code</button><button class="btn danger" type="button" id="ffreset">Scrap this league</button></div><p class="note" id="ffmsg"></p></div>`}
  function poWinners(L,st,P,champ){const seeds=st.map(r=>r.i);const sc=(a,b)=>{const x=LU(L,a,P.semi).total,y=LU(L,b,P.semi).total;return x>=y?a:b};
    if(!wkFinal(P.semi))return null;const w1=sc(seeds[0],seeds[3]),w2=sc(seeds[1],seeds[2]);
    if(!champ)return [w1,w2];const x=LU(L,w1,P.fin).total,y=LU(L,w2,P.fin).total;return x>=y?w1:w2}
  const humanIdx=()=>L.mgr.map((m,i)=>i).filter(i=>!(L.cpu&&L.cpu[i]));
  const effWeeks=()=>{const out=[];for(let w=nextOpenWeek();w<=LASTREG;w++)out.push(w);return out.length?out:[LASTREG]};
  function faHtml(wk){
    const on=new Set();L.mgr.forEach((m,i)=>rosterAt(L,i,wk).forEach(x=>on.add(x)));
    const free=POOL.filter(p=>!on.has(p.id)&&(!faPos||p.pos===faPos)&&(!faQ||p.n.toLowerCase().includes(faQ))).slice(0,40);
    const hs=humanIdx(),ew=effWeeks();if(txWeek==null||!ew.includes(txWeek))txWeek=ew[0];
    const pe=pend?PIDX.get(pend.add):null;
    return `<h2>Free agents</h2><p class="note">Players on nobody's roster, best average first. A move starts in the week you choose and never changes a final week.</p>
    <div class="filters"><label>Position<select id="fapos"><option value="">All</option>${POSORD.map(p=>`<option value="${p}"${faPos===p?' selected':''}>${p}</option>`).join('')}</select></label><label>Search<input id="faq" type="search" value="${esc(faQ)}" placeholder="Name"></label><label>Starts in week<select id="fawk">${ew.map(w=>`<option value="${w}"${w===txWeek?' selected':''}>Week ${w}</option>`).join('')}</select></label>${hs.length>1?`<label>For<select id="famgr">${hs.map(i=>`<option value="${i}"${pend&&pend.m===i?' selected':''}>${esc(L.mgr[i])}</option>`).join('')}</select></label>`:''}</div>
    ${pe?`<div class="card" style="border-color:var(--accent)"><b>Add ${esc(pe.n)} (${pe.pos}, ${pe.tm}) for ${esc(L.mgr[pend.m])}.</b> Drop:<select id="fadrop">${rosterAt(L,pend.m,txWeek).map(id=>PIDX.get(id)).filter(Boolean).sort((a,b)=>POSORD.indexOf(a.pos)-POSORD.indexOf(b.pos)).map(p=>`<option value="${p.id}">${esc(p.n)} (${p.pos})</option>`).join('')}</select><div class="btnrow"><button class="btn solid" type="button" id="faok">Confirm move</button><button class="btn" type="button" id="facancel">Cancel</button></div></div>`:''}
    <div class="pool-list">${free.map(p=>`<div class="poolrow"><span class="pos">${p.pos}</span><span class="nm">${esc(p.n)}<small>${p.tm}</small></span><span class="pv">${p.v.toFixed(1)}</span><button class="btn" type="button" data-fa="${p.id}">Add</button></div>`).join('')||'<p class="note">Nobody matches.</p>'}</div>`}
  function tradeHtml(wk){
    const hs=humanIdx(),ew=effWeeks();if(txWeek==null||!ew.includes(txWeek))txWeek=ew[0];if(!hs.includes(tradeSel.a))tradeSel.a=hs[0];if(!hs.includes(tradeSel.b)||tradeSel.b===tradeSel.a)tradeSel.b=hs.find(i=>i!==tradeSel.a)??hs[0];
    const ros=i=>rosterAt(L,i,txWeek).map(id=>PIDX.get(id)).filter(Boolean).sort((a,b)=>POSORD.indexOf(a.pos)-POSORD.indexOf(b.pos));
    const box=(i,k)=>ros(i).map(p=>`<label style="display:flex;gap:6px;align-items:center;font-size:13px"><input type="checkbox" data-tr="${k}" value="${p.id}"${tradeSel[k].includes(p.id)?' checked':''}> <span class="mono">${p.pos}</span> ${esc(p.n)} <span class="st">${p.tm}</span></label>`).join('');
    return `<h2>Trades</h2><p class="note">Both managers agree on the screen, then confirm. Each side gives and receives the same number of players.</p>
    <div class="filters"><label>Manager A<select id="tra">${hs.map(i=>`<option value="${i}"${i===tradeSel.a?' selected':''}>${esc(L.mgr[i])}</option>`).join('')}</select></label><label>Manager B<select id="trb">${hs.map(i=>`<option value="${i}"${i===tradeSel.b?' selected':''}>${esc(L.mgr[i])}</option>`).join('')}</select></label><label>Starts in week<select id="trwk">${ew.map(w=>`<option value="${w}"${w===txWeek?' selected':''}>Week ${w}</option>`).join('')}</select></label></div>
    <div class="matchup"><div class="mu-side"><h3>${esc(L.mgr[tradeSel.a])} gives</h3>${box(tradeSel.a,'give')}</div><div class="mu-vs">⇄</div><div class="mu-side"><h3>${esc(L.mgr[tradeSel.b])} gives</h3>${box(tradeSel.b,'get')}</div></div>
    <div class="btnrow"><button class="btn solid" type="button" id="trok" ${tradeSel.give.length&&tradeSel.give.length===tradeSel.get.length&&tradeSel.a!==tradeSel.b?'':'disabled'}>Both agree: make the trade</button></div><p class="note" id="trmsg"></p>`}
  function logHtml(){const tx=L.tx||[];return `<h2>Moves</h2>${tx.length?`<div class="tablebox"><table><thead><tr><th>From week</th><th>Move</th></tr></thead><tbody>${tx.map(t=>t.type==='add'?`<tr><td>${t.wk}</td><td>${esc(L.mgr[t.m])} added ${esc(PIDX.get(t.add).n)}, dropped ${esc(PIDX.get(t.drop).n)}</td></tr>`:`<tr><td>${t.wk}</td><td>Trade: ${esc(L.mgr[t.a])} gave ${t.give.map(x=>esc(PIDX.get(x).n)).join(', ')} for ${t.get.map(x=>esc(PIDX.get(x).n)).join(', ')} from ${esc(L.mgr[t.b])}</td></tr>`).join('')}</tbody></table></div>`:'<p class="note">No moves yet.</p>'}`}
  const root=$('ffbody');let armed=false;
  root.addEventListener('input',e=>{const id=e.target.id;
    if(e.target.dataset&&e.target.dataset.luslot){const k=e.target.dataset.lum+':'+e.target.dataset.luw;L.ov=L.ov||{};L.ov[k]=L.ov[k]||{};L.ov[k][e.target.dataset.luslot]=e.target.value;save();render();return}
    if(id==='ffmode'){const solo=e.target.value==='solo';$('ffnwrap').hidden=solo;$('ffcwrap').hidden=!solo;$('ffnames').innerHTML=namesInputs(solo?1:+$('ffn').value,solo?'solo':'friends')}
    if(id==='ffn')$('ffnames').innerHTML=namesInputs(+e.target.value,'friends');
    if(id==='ffpos'){fpos=e.target.value;render()}
    if(id==='ffq'){q=e.target.value.trim().toLowerCase();const pos=e.target.selectionStart;render();const x=$('ffq');if(x){x.focus();try{x.setSelectionRange(pos,pos)}catch(er){}}}
    if(id==='fapos'){faPos=e.target.value;render()}
    if(id==='faq'){faQ=e.target.value.trim().toLowerCase();const pos=e.target.selectionStart;render();const x=$('faq');if(x){x.focus();try{x.setSelectionRange(pos,pos)}catch(er){}}}
    if(id==='fawk'||id==='trwk'){txWeek=+e.target.value;render()}
    if(id==='famgr'&&pend){pend.m=+e.target.value;render()}
    if(id==='tra'){tradeSel.a=+e.target.value;tradeSel.give=[];tradeSel.get=[];render()}
    if(id==='trb'){tradeSel.b=+e.target.value;tradeSel.give=[];tradeSel.get=[];render()}
    if(e.target.dataset&&e.target.dataset.tr){const k=e.target.dataset.tr,v=e.target.value;tradeSel[k]=e.target.checked?[...tradeSel[k],v]:tradeSel[k].filter(x=>x!==v);render()}
  });
  root.addEventListener('click',e=>{const t=e.target.closest('button');if(!t)return;
    if(t.dataset.fpos!==undefined){fpos=fpos===t.dataset.fpos?'':t.dataset.fpos;render();return}
    if(t.id==='ffgo'){const solo=$('ffmode').value==='solo';let mg=[...document.querySelectorAll('.ffmn')].map(i=>i.value.trim()||'Manager'),cpu=mg.map(()=>false);
      if(solo){const k=+$('ffcpu').value;for(let i=1;i<=k;i++){mg.push('Computer '+i);cpu.push(true)}}
      L={name:$('ffname').value.trim()||'Our League',sc:$('ffsc').value,sf:$('ffsf').value==='1',r:$('ffsf').value==='1'?16:15,start:+$('ffstart').value,mgr:mg,cpu,phase:'draft',picks:[],tx:[],wk:+$('ffstart').value,ver:2};runCPU();save();render();return}
    if(t.dataset.pick){const n=L.mgr.length;if(L.picks.length>=n*rounds())return;const m=snake(n,L.picks.length),p=PIDX.get(t.dataset.pick);if(!needOK(L,m,p))return;L.picks.push({m,id:p.id});runCPU();save();render();return}
    if(t.id==='ffauto'){const n=L.mgr.length,m=snake(n,L.picks.length),p=autoPick(L,m);if(p){L.picks.push({m,id:p.id});runCPU();save();render()}return}
    if(t.id==='ffautoall'){const n=L.mgr.length;while(L.picks.length<n*rounds()){const m=snake(n,L.picks.length),p=autoPick(L,m);if(!p)break;L.picks.push({m,id:p.id})}save();render();return}
    if(t.id==='ffundo'){let p;do{p=L.picks.pop()}while(p&&L.cpu&&L.cpu[p.m]&&L.picks.length);runCPU();save();render();return}
    if(t.id==='ffseason'){L.phase='season';L.wk=L.start;save();render();return}
    if(t.dataset.luedit){editLU=editLU===t.dataset.luedit?null:t.dataset.luedit;render();return}
    if(t.dataset.luclr){if(L.ov)delete L.ov[t.dataset.luclr];save();render();return}
    if(t.dataset.fw){L.wk=+t.dataset.fw;save();render();return}
    if(t.dataset.ftab){tab=t.dataset.ftab;render();return}
    if(t.dataset.fa){const hs=humanIdx();pend={add:t.dataset.fa,m:pend&&pend.m!=null&&hs.includes(pend.m)?pend.m:hs[0]};render();return}
    if(t.id==='facancel'){pend=null;render();return}
    if(t.id==='faok'&&pend){const drop=$('fadrop').value;L.tx=L.tx||[];L.tx.push({type:'add',wk:txWeek,m:pend.m,add:pend.add,drop});pend=null;save();render();return}
    if(t.id==='trok'){const a=tradeSel.a,b=tradeSel.b;L.tx=L.tx||[];L.tx.push({type:'trade',wk:txWeek,a,b,give:tradeSel.give.slice(),get:tradeSel.get.slice()});tradeSel.give=[];tradeSel.get=[];save();render();return}
    if(t.id==='ffreset'){if(!armed){armed=true;t.textContent='Press again to scrap it';setTimeout(()=>{armed=false;if(t.isConnected)t.textContent='Scrap this league'},4000);return}L=null;armed=false;try{localStorage.removeItem(KEY)}catch(er){}render();return}
    if(t.id==='ffexp'){try{$('ffcode').value=btoa(unescape(encodeURIComponent(JSON.stringify(L))));$('ffmsg').textContent='Copy this code to keep or move the league.'}catch(er){}return}
    if(t.id==='ffimp'){try{const o=JSON.parse(decodeURIComponent(escape(atob($('ffcode').value.trim()))));if(!o||!Array.isArray(o.mgr)||!Array.isArray(o.picks))throw 0;o.tx=o.tx||[];o.cpu=o.cpu||o.mgr.map(()=>false);L=o;save();render()}catch(er){$('ffmsg').textContent='That code could not be read.'}return}
  });
  window.__ffRender=render;render();
})();

/* ===================== BACKUP ===================== */
(function(){
  const KEYS=['bbn.picks.v1','bbn.fantasy.v2','bbn.friends','bbn.myname','bbn.pknum'],TS='bbn.lastbackup';
  const g=k=>{try{return localStorage.getItem(k)}catch(e){return null}};
  const has=()=>KEYS.some(k=>g(k));
  function note(){
    const ts=+g(TS)||0,days=ts?Math.floor((Date.now()-ts)/864e5):null;
    $('bknote').textContent=!has()?'Nothing to back up yet. Your picks and leagues live only in this browser, so clearing site data or switching devices would lose them.':ts?`Your picks and leagues live only in this browser. Last backup: ${days===0?'today':days+' day'+(days===1?'':'s')+' ago'}.${days>=7?' It is time for a fresh one.':''}`:'Your picks and leagues live only in this browser, and you have not made a backup yet. Copy one and keep it in a note or message to yourself.';
  }
  $('bkcopy').addEventListener('click',()=>{
    const o={v:1,at:new Date().toISOString(),d:{}};KEYS.forEach(k=>{const v=g(k);if(v!=null)o.d[k]=v});
    const s=JSON.stringify(o);$('bkbox').value=s;
    const done=()=>{try{localStorage.setItem(TS,String(Date.now()))}catch(e){};$('bkmsg').textContent='Backup copied. Paste it somewhere safe.';note()};
    try{navigator.clipboard.writeText(s).then(done,()=>{$('bkbox').select();$('bkmsg').textContent='Select the text above and copy it by hand.';})}catch(e){$('bkbox').select();$('bkmsg').textContent='Select the text above and copy it by hand.'}
  });
  $('bkrestore').addEventListener('click',()=>{
    let o;try{o=JSON.parse($('bkbox').value)}catch(e){}
    if(!o||!o.d||typeof o.d!=='object'){$('bkmsg').textContent='That does not look like a backup.';return}
    let n=0;KEYS.forEach(k=>{if(typeof o.d[k]==='string'){try{localStorage.setItem(k,o.d[k]);n++}catch(e){}}});
    $('bkmsg').textContent=n?`Restored ${n} item${n===1?'':'s'}. Reload the page to see them.`:'The backup had nothing to restore.';
  });
  note();
  try{const s=document.createElement('p');s.className='note';s.id='stamp';const d=new Date(BUILT);
    s.textContent=`Data last refreshed ${d.toLocaleString('en-US',{timeZone:'America/New_York',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})} ET, through week ${LASTWK} (${SEAPLAYED.length} games final). Injury reports are from week ${INJ.wk}.`;
    $('bkcard').after(s)}catch(e){}
})();
