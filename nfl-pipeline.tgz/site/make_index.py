# Wraps the built page into a standalone web page (index.html) for GitHub Pages.
h=open('betting-by-numbers.html').read()
h=h.replace('<meta name="claude:viewport-fit-sides" content="cover">\n','',1)
desc="NFL scores, standings, team and player stats, draft results, all-time records, weekly pick-em and fantasy tools, plus a separate numerology and astrology reading for entertainment."
head='''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="description" content="%s">
<meta property="og:title" content="Tyler&#39;s NFL APP">
<meta property="og:description" content="%s">
<meta property="og:type" content="website">
<meta name="theme-color" content="#0f1512">
<meta property="og:url" content="https://joshliberty03.github.io/NFL/">
<meta property="og:site_name" content="Tyler&#39;s NFL APP">
<meta property="og:image" content="https://joshliberty03.github.io/NFL/og.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Tyler&#39;s NFL APP">
<meta name="twitter:image" content="https://joshliberty03.github.io/NFL/og.png">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="favicon-32.png">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<link rel="manifest" href="manifest.webmanifest">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="NFL APP">
<link rel="canonical" href="https://joshliberty03.github.io/NFL/">
''' % (desc,desc)
html=head+h.replace('<meta charset="utf-8">\n','',1)
i=html.index('<style>');j=html.index('</style>')+len('</style>')
html=html[:j]+"\n</head>\n<body>"+html[j:]+"\n<script>if('serviceWorker' in navigator&&location.protocol==='https:'){addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(){})})}</script>\n</body>\n</html>\n"
open('index.html','w').write(html);print('index.html',len(html))
