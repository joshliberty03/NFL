# Provisional final scores entered by the owner; applied only while the feed still has the game unscored.
import csv
P='/home/runner/nfl/games/games.csv'
OV={'2026_08_CHI_SEA':(34,17)}  # (away, home): Bears 34, Seahawks 17
rows=list(csv.DictReader(open(P)));f=rows and list(rows[0].keys())
for r in rows:
    if r['game_id'] in OV and r['home_score'] in ('','NA'):
        a,h=OV[r['game_id']];r['away_score']=str(a);r['home_score']=str(h);r['result']=str(h-a);r['total']=str(a+h);r['overtime']='0'
w=csv.DictWriter(open(P,'w',newline=''),fieldnames=f);w.writeheader();w.writerows(rows)
