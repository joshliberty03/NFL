"""Add Expression, Soul Urge, Personality and Birthday numbers to every 2026 player, coach and team."""
import csv, json, sys, os, collections
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from names import numbers, birthday
players=json.load(open("data.json"))   # [name, team, pos, status, birth, lp]
S=json.load(open("step2.json"))
# legal first/last from the 2026 roster, keyed by common name + team
legal={}
for r in csv.DictReader(open("/home/runner/nfl/roster_2026.csv",encoding="utf-8")):
    fn=(r.get("first_name") or "").strip(); ln=(r.get("last_name") or "").strip()
    if fn and ln: legal[(r["full_name"],r["team"])]=f"{fn} {ln}"
out=[]; diff=0
for p in players:
    lg=legal.get((p[0],p[1]),p[0])
    n=numbers(lg) or {}; c=numbers(p[0]) or {}
    if n.get("expression")!=c.get("expression"): diff+=1
    out.append([n.get("expression"),n.get("soul"),n.get("personality"),birthday(p[4]),
                lg if lg!=p[0] else "", c.get("expression")])
print("players:",len(out))
print("legal name differs from common name:",diff)
print("sample:",players[0][0],legal.get((players[0][0],players[0][1])),out[0])
co={}
for c in S["coaches"]:
    n=numbers(c["coach"]) or {}
    co[c["team"]]={"expr":n.get("expression"),"soul":n.get("soul"),"pers":n.get("personality"),"bday":birthday(c["birth_date"])}
# team: name numbers from the franchise name, birthday from the founding day
NAMES=json.load(open("teamnames.json")) if os.path.exists("teamnames.json") else None
F=json.load(open("founded.json"))
tm={}
for t,b in F.items():
    tm[t]={"bday":birthday(b) if b else None}
json.dump({"players":out,"coaches":co,"teams":tm,
           "dist":{k:sorted(collections.Counter(r[i] for r in out if r[i]).items()) for i,k in [(0,"expression"),(1,"soul"),(2,"personality"),(3,"birthday")]}},
          open("mainnums.json","w"),separators=(",",":"))
for k,v in json.load(open("mainnums.json"))["dist"].items(): print(k,v)
