import csv,json,glob,os
P=json.load(open('pstats.json'))
ids=set()
for s in ('2026','2025'):
    for r in P[s]: ids.add(r[0])
if not ids:
    print(list(P.keys())[:6]); raise SystemExit
G={}
for r in csv.DictReader(open('/home/runner/nfl/games/games.csv')):
    if r['home_score'] in ('','NA') : continue
    G[r['game_id']]=(r['home_team'],r['away_team'],int(float(r['home_score'])),int(float(r['away_score'])))
MAP={'OAK':'LV','SD':'LAC','STL':'LA','LAR':'LA','SDG':'LAC'}
m=lambda t:MAP.get(t,t)
files=sorted(glob.glob('pw/pw*.csv'))+['/home/runner/nfl/stats/p25.csv','/home/runner/nfl/stats/p26.csv']
out={};seen=set()
for f in files:
    for r in csv.DictReader(open(f)):
        pid=r['player_id']
        if pid not in ids or r['season_type'] not in ('REG','POST'):continue
        g=G.get(r['game_id'])
        if not g:continue
        k=(pid,r['game_id'])
        if k in seen:continue
        seen.add(k)
        h,a,hs,as_=g;t=r['team']
        if t==h:me,op=hs,as_
        elif t==a:me,op=as_,hs
        else:continue
        opp=m(r['opponent_team'])
        x=out.setdefault(pid,{}).setdefault(opp,[0,0,0])
        x[0 if me>op else 1 if me<op else 2]+=1
json.dump(out,open('pvt.json','w'),separators=(',',':'))
print(len(out),sum(len(v) for v in out.values()),os.path.getsize('pvt.json'))
