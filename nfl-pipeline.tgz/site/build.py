import json
m={'__PLAYERS__':'data.json','__STEP2__':'step2.json','__STEP3__':'step3.json','__HIST__':'history.json','__APPEAR__':'appear.json','__SB__':'superbowl.json','__FORECAST__':'forecast.json','__ASTRO__':'astro_small.json','__AGRIDS__':'astro_grids.json','__VERDICTS__':'verdicts.json','__QBPAGE__':'qbpage.json','__MAINNUMS__':'mainnums.json','__BETTING__':'betting.json','__JERSEY__':'jersey.json','__LNY__':'lny.json','__MOON__':'moon.json'}
t=open('template2.html').read()
for k,f in m.items():
    assert k in t,k
    t=t.replace(k,open(f).read().strip())
open('nfl-life-path-ledger.html','w').write(t); print(len(t))
