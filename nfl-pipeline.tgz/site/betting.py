"""Betting by Numbers: starters for every team with their numbers, upcoming games by day number."""
import csv, json, collections, sys, os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from names import numbers, birthday, reduce_keep
MASTER={11,22,33}
def red(n): return reduce_keep(n)
def lifep(b):
    y,m,d=b.split("-"); return red(red(int(m))+red(int(d))+red(sum(map(int,y))))
def pday(b,date):
    _,bm,bd=b.split("-"); y,m,d=date.split("-")
    py=red(red(int(bm))+red(int(bd))+red(sum(map(int,y))))
    return red(red(py+red(int(m)))+red(int(d)))

# ---- latest depth-chart snapshot per team ----
rows=list(csv.DictReader(open("/home/runner/nfl/depth_2026.csv",encoding="utf-8")))
latest={}
for r in rows:
    t=r["team"]
    if t not in latest or r["dt"]>latest[t]: latest[t]=r["dt"]
SIDE={"3WR 1TE":"Offense","Base 3-4 D":"Defense","Base 4-3 D":"Defense","Special Teams":"Special teams"}
ORD={"Offense":0,"Defense":1,"Special teams":2}
starters=collections.defaultdict(dict)   # team -> (side,pos) -> name
for r in rows:
    if r["dt"]!=latest[r["team"]] or r["pos_rank"]!="1": continue
    side=SIDE.get(r["pos_grp"]); 
    if not side: continue
    starters[r["team"]][(side,r["pos_abb"])]=r["player_name"]
print("teams with starters:",len(starters),"| sample sizes:",{t:len(v) for t,v in list(starters.items())[:4]})

# ---- birth dates + legal names from the newest roster ----
ros=list(csv.DictReader(open("/home/runner/nfl/roster_2026_new.csv",encoding="utf-8")))
import re
def norm(n):
    n=re.sub(r"[^a-z ]","",n.lower().replace("-"," "))
    return " ".join(w for w in n.split() if w not in {"jr","sr","ii","iii","iv","v"})
bd={}; lg={}; pos={}; bysur=collections.defaultdict(list)
for r in ros:
    if not r.get("birth_date"): continue
    k=(norm(r["full_name"]),r["team"]); bd[k]=r["birth_date"]
    bd.setdefault(norm(r["full_name"]),r["birth_date"])
    fn=(r.get("first_name") or "").strip(); ln=(r.get("last_name") or "").strip()
    if fn and ln:
        lg[k]=f"{fn} {ln}"; lg.setdefault(norm(r["full_name"]),f"{fn} {ln}")
    pos[k]=r["position"]
    bysur[(norm(r["last_name"]),r["team"])].append(r)
def fallback(name,team):
    """depth charts use nicknames (Dax) where rosters use legal names (Daxton)."""
    parts=norm(name).split()
    if not parts: return None
    first,sur=parts[0],parts[-1]
    cands=bysur.get((sur,team),[])
    hits=[r for r in cands if (lambda f: f.startswith(first) or first.startswith(f))(norm(r["first_name"] or ""))]
    if len(hits)!=1:
        hits=[r for r in cands if norm(r["full_name"]).split()[0].startswith(first[:3])]
    return hits[0] if len(hits)==1 else (cands[0] if len(cands)==1 else None)
def pack(name,team,side,posab):
    k=(norm(name),team)
    b=bd.get(k) or bd.get(norm(name)); legal=lg.get(k) or lg.get(norm(name))
    if not b:
        r=fallback(name,team)
        if not r: return None
        b=r["birth_date"]; legal=f'{(r["first_name"] or "").strip()} {(r["last_name"] or "").strip()}'.strip()
    legal=legal or name
    nm=numbers(legal) or {}
    nc=numbers(name) or {}
    return {"n":name,"legal":legal if legal!=name else "","b":b,"side":side,"pos":posab,
            "lp":lifep(b),"bd":birthday(b),
            "ex":nm.get("expression"),"su":nm.get("soul"),"pe":nm.get("personality"),
            "exC":nc.get("expression") if nc.get("expression")!=nm.get("expression") else None}
TEAM={}; missing=[]
for t,d in starters.items():
    lst=[]
    for (side,posab),name in d.items():
        p=pack(name,t,side,posab)
        if p: lst.append(p)
        else: missing.append((t,name))
    lst.sort(key=lambda x:(ORD[x["side"]],x["pos"]))
    TEAM[t]=lst
print("starters packed:",sum(len(v) for v in TEAM.values()),"| no birth date:",len(missing),missing[:5])

# ---- coaches ----
S=json.load(open("step2.json"))
COACH={c["team"]:{"name":c["coach"],"b":c["birth_date"],"lp":c["life_path"],
                  "bd":birthday(c["birth_date"]),
                  "ex":(numbers(c["coach"]) or {}).get("expression")} for c in S["coaches"]}
# ---- team records ----
rec=collections.defaultdict(lambda:[0,0,0])
games=[r for r in csv.DictReader(open("/home/runner/nfl/games/games.csv")) if r["season"]=="2026"]
for r in games:
    if not r["home_score"]: continue
    h,a=int(r["home_score"]),int(r["away_score"])
    if h==a: rec[r["home_team"]][2]+=1; rec[r["away_team"]][2]+=1
    else:
        w,l=(r["home_team"],r["away_team"]) if h>a else (r["away_team"],r["home_team"])
        rec[w][0]+=1; rec[l][1]+=1
# ---- upcoming games grouped by date ----
up=[]
for r in games:
    date=r["gameday"]
    pl=r["home_score"] not in ("","NA")
    up.append({"id":r["game_id"],"wk":int(r["week"]),"date":date,"wd":r["weekday"],"pl":pl,
      "hs":int(r["home_score"]) if pl else None,"as":int(r["away_score"]) if pl else None,
      "time":r["gametime"],"home":r["home_team"],"away":r["away_team"],
      "dn":lifep(date),
      "hcpd":pday(COACH[r["home_team"]]["b"],date),"acpd":pday(COACH[r["away_team"]]["b"],date)})
up.sort(key=lambda g:(g["date"],g["time"]))
print("upcoming:",len(up),"| dates:",len({g['date'] for g in up}),"| first:",up[0]["date"],"last:",up[-1]["date"])
# ---- actual starting QB for games already played ----
byid={r["gsis_id"]:r for r in ros if r.get("gsis_id")}
QBS={}
for r in games:
    if r["home_score"] in ("","NA"): continue
    for sd,tm in (("h",r["home_team"]),("a",r["away_team"])):
        qid=r[("home" if sd=="h" else "away")+"_qb_id"]; qn=r[("home" if sd=="h" else "away")+"_qb_name"]
        dq=[m for m in TEAM.get(tm,[]) if m["pos"]=="QB"]
        if dq and norm(dq[0]["n"])==norm(qn): continue
        ro=byid.get(qid)
        if not ro or not ro.get("birth_date"): continue
        legal=f'{(ro["first_name"] or "").strip()} {(ro["last_name"] or "").strip()}'.strip() or qn
        nm=numbers(legal) or {}; nc=numbers(qn) or {}
        QBS.setdefault(r["game_id"],{})[sd]={"n":qn,"legal":legal if legal!=qn else "","b":ro["birth_date"],"side":"Offense","pos":"QB",
          "lp":lifep(ro["birth_date"]),"bd":birthday(ro["birth_date"]),"ex":nm.get("expression"),"su":nm.get("soul"),"pe":nm.get("personality"),
          "exC":nc.get("expression") if nc.get("expression")!=nm.get("expression") else None,"jy":(ro.get("jersey_number") or None)}
print("games with a different starting QB than the depth chart:",len(QBS))
json.dump({"qbs":QBS,"teams":TEAM,"coaches":COACH,"rec":{k:v for k,v in rec.items()},"upcoming":up,
           "depth_as_of":max(latest.values()),"played":sum(1 for r in games if r['home_score'])},
          open("betting.json","w"),separators=(",",":"))
print("size",os.path.getsize("betting.json"))
print("sample KC starters:",[(x["pos"],x["n"],x["lp"],x["ex"]) for x in TEAM["KC"][:5]])
# keep the reference list (stored separately in refs.json)
_b=json.load(open("betting.json")); _b["refs"]=json.load(open("refs.json")); json.dump(_b,open("betting.json","w"),separators=(",",":"))
