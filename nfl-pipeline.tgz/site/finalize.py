# Pours freshly built data (betting-by-numbers.html) into the full app shell (app_shell.html),
# which carries the features built in Claude: Team News, My Team rosters + injury report,
# Madden-style Gridiron Showdown. Keeps the shell's hand-corrected rosters, news and logos,
# applies head-coach corrections, and refreshes the injury report from nflverse.
# Usage: python3 finalize.py SHELL BUILT INJ_CSV GAMES_CSV OUT
import re,json,base64,gzip,csv,sys,datetime
SHELL,BUILT,INJ,GAMES,OUT=sys.argv[1:6]
def load(f):
    s=open(f).read(); i=s.find('const __ZD=')
    m=re.search(r'const __ZD=(\{.*?\});',s[i:i+5000000],re.S)
    return s,i+m.start(1),i+m.end(1),json.loads(m.group(1))
dz=lambda v: json.loads(gzip.decompress(base64.b64decode(v)))
ez=lambda o: base64.b64encode(gzip.compress(json.dumps(o,separators=(',',':')).encode(),9,mtime=0)).decode()
def tiline(f): return [l for l in open(f).read().split('\n') if l.startswith('const TI=')][0]
def red(n,master=True):
    while n>9 and not (master and n in (11,22,33)): n=sum(int(c) for c in str(n))
    return n
V={c:(i%9)+1 for i,c in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ')}
FIX={'BUF':('Joe Brady','1989-09-23'),'ARI':('Mike LaFleur','1987-03-03'),'ATL':('Kevin Stefanski','1982-05-08')}
lp=lambda b_:(lambda y,m,d: red(red(int(m))+red(int(d))+red(sum(map(int,y)))))(*b_.split('-'))
ex=lambda n: red(sum(V[c] for c in n.upper() if c in V))
def pday(bdate,date):
    y,m,d=map(int,date.split('-')); _,bm,bdy=map(int,bdate.split('-'))
    py=red(red(bm)+red(bdy)+red(sum(map(int,str(y)))))
    return red(red(py+red(m))+red(d))
s,a,b,A=load(SHELL); _,_,_,G=load(BUILT)
out={k:(G[k] if k in G and k!='__LOGOS__' else v) for k,v in A.items()}
print('fresh:',[k for k in A if k in G and k!='__LOGOS__'],'kept from shell:',[k for k in A if k not in G or k=='__LOGOS__'])
GM={r['game_id']:r for r in csv.DictReader(open(GAMES)) if r['season']=='2026' and r['home_score'] not in ('','NA')}
S=dz(out['__SEASON__'])
for g in S:
    r=GM.get(g['id'])
    if r and g.get('hs') is None: g['hs']=int(r['home_score']); g['as']=int(r['away_score'])
out['__SEASON__']=ez(S)
B=dz(out['__BETTING__'])
for u in B['upcoming']:
    r=GM.get(u['id'])
    if r and not u.get('pl'): u['pl']=True; u['hs']=int(r['home_score']); u['as']=int(r['away_score'])
B['played']=sum(1 for u in B['upcoming'] if u.get('pl'))
for t,(n,bd_) in FIX.items():
    B['coaches'][t]={'name':n,'b':bd_,'lp':lp(bd_),'bd':red(int(bd_[-2:])),'ex':ex(n)}
for u in B['upcoming']:
    u['hcpd']=pday(B['coaches'][u['home']]['b'],u['date']); u['acpd']=pday(B['coaches'][u['away']]['b'],u['date'])
out['__BETTING__']=ez(B)
R=dz(out['__ROSTER__']); ids={p[0] for t in R['teams'].values() for p in t}
try:
    rows=list(csv.DictReader(open(INJ))); lw={}
    for r in rows: lw[r['team']]=max(lw.get(r['team'],0),int(r['week']))
    inj={r['gsis_id']:[int(r['week']),r['report_status'],r['report_primary_injury'] or r['practice_primary_injury'],r['report_secondary_injury'] or r['practice_secondary_injury'],r['practice_status']]
         for r in rows if int(r['week'])==lw[r['team']] and r['gsis_id'] in ids}
    if inj:
        R['inj']=inj; R['lastwk']=lw
        R['asof']=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-5))).strftime('%Y-%m-%d')
    print('injury rows',len(inj))
except Exception as e: print('injury refresh skipped:',e)
out['__ROSTER__']=ez(R)
s2=s[:a]+json.dumps(out,separators=(',',':'))+s[b:]
L=s2.split('\n'); idx=[i for i,l in enumerate(L) if l.startswith('const TI=')]; assert len(idx)==1
L[idx[0]]=tiline(BUILT)
open(OUT,'w').write('\n'.join(L)); print('wrote',OUT,len(s2))
