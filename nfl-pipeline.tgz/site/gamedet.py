import json,re,pandas as pd,numpy as np
S='/home/runner/nfl/stats/'
TMAP={'OAK':'LV','STL':'LA','LAR':'LA','SD':'LAC','JAC':'JAX','WSH':'WAS'}
T=lambda t:TMAP.get(t,t)
sea=[g for g in json.load(open('season.json')) if g['hs'] is not None]
ids={g['id']:g for g in sea}
p=pd.read_csv(S+'pbp26.csv',low_memory=False)
p=p[p.game_id.isin(ids)].sort_values(['game_id','play_id'])
pl=pd.read_csv(S+'p26.csv',low_memory=False)
pl=pl[pl.game_id.isin(ids)]
def clean(d):
    d=str(d);d=re.sub(r'^\(\d+:\d+\)\s*','',d)
    d=re.sub(r'\b\d{1,2}-(?=[A-Z])','',d)
    d=re.sub(r'[A-Z]\.[A-Za-z\' -]+ reported in as eligible\.\s*','',d)
    d=re.sub(r',?\s*Center-.*$','',d);d=re.sub(r'\((Shotgun|No Huddle[^)]*|Shotgun, No Huddle)\)\s*','',d);d=re.sub(r'\s+',' ',d).strip()
    return d[:170]
def num(v):
    try:
        return int(v) if v==v else 0
    except: return 0
out={}
for gid,g in ids.items():
    x=p[p.game_id==gid]
    if x.empty: continue
    H,A=T(g['h']),T(g['a'])
    ev=[];ph=pa=0
    for r in x.itertuples():
        th,ta=num(r.total_home_score),num(r.total_away_score)
        if th==ph and ta==pa: continue
        dh,da=th-ph,ta-pa;ph,pa=th,ta
        pt=str(r.play_type);ex=pt=='extra_point' or (isinstance(r.two_point_conv_result,str) and pt in('pass','run'))
        if ex and ev and ev[-1][3]=='TD':
            ev[-1][4]+=(' · '+('Kick good' if pt=='extra_point' else '2-pt good'));ev[-1][5],ev[-1][6]=th,ta;ev[-1].append(dh+da);continue
        team=H if dh>0 else A;pts=dh if dh>0 else da
        kind={6:'TD',3:'FG',2:'Safety'}.get(pts,'Score')
        ev.append([int(r.qtr),str(r.time),team,kind,clean(r.desc),th,ta,pts])
    # quarter points
    qs={}
    prev=[0,0]
    for e in ev:
        q=e[0];tot=e[7] if len(e)>7 else 0
    # recompute quarter points from running scores
    qh={};qa={};lh=la=0
    for e in ev:
        q=e[0];qh[q]=qh.get(q,0)+(e[5]-lh);qa[q]=qa.get(q,0)+(e[6]-la);lh,la=e[5],e[6]
    nq=max([4]+[e[0] for e in ev])
    q={'h':[qh.get(i,0) for i in range(1,nq+1)],'a':[qa.get(i,0) for i in range(1,nq+1)]}
    ev=[e[:7] for e in ev]
    # team stats
    ts={}
    for side,tm in (('h',g['h']),('a',g['a'])):
        o=x[(x.posteam==tm)|(x.posteam==T(tm))]
        off=o[o.play_type.isin(['pass','run'])]
        ps=off[off.play_type=='pass'];rs=off[off.play_type=='run']
        th=off[(off.down==3)];fo=off[(off.down==4)]
        pen=x[(x.penalty==1)&(x.penalty_team.isin([tm,T(tm)]))]
        ts[side]={'ply':len(off),'yds':num(off.yards_gained.sum()),'py':num(ps.yards_gained.sum()),'ry':num(rs.yards_gained.sum()),
          'fd':num((o.first_down==1).sum()),'t3':[num(th.third_down_converted.sum()),len(th)],'t4':[num(fo.fourth_down_converted.sum()),len(fo)],
          'to':num((o.interception==1).sum())+num((o.fumble_lost==1).sum()),'sk':num((ps.sack==1).sum()),'pen':[len(pen),num(pen.penalty_yards.sum())]}
    # performers
    pf={}
    for side,tm in (('h',g['h']),('a',g['a'])):
        d=pl[(pl.game_id==gid)&pl.team.isin([tm,T(tm)])];L=[]
        for r in d[d.attempts>=3].sort_values('attempts',ascending=False).itertuples():
            L.append(['Passing',r.player_display_name,f"{num(r.completions)}/{num(r.attempts)}, {num(r.passing_yards)} yds, {num(r.passing_tds)} TD"+(f", {num(r.passing_interceptions)} INT" if num(r.passing_interceptions) else '')])
        for r in d[d.carries>=2].sort_values('rushing_yards',ascending=False).head(2).itertuples():
            L.append(['Rushing',r.player_display_name,f"{num(r.carries)} car, {num(r.rushing_yards)} yds"+(f", {num(r.rushing_tds)} TD" if num(r.rushing_tds) else '')])
        for r in d[d.receptions>=1].sort_values('receiving_yards',ascending=False).head(3).itertuples():
            L.append(['Receiving',r.player_display_name,f"{num(r.receptions)} rec, {num(r.receiving_yards)} yds"+(f", {num(r.receiving_tds)} TD" if num(r.receiving_tds) else '')])
        dd=d.copy();dd['tk']=dd.def_tackles_solo.fillna(0)+dd.def_tackle_assists.fillna(0)
        for r in dd[(dd.def_sacks>0)|(dd.def_interceptions>0)|(dd.def_fumbles_forced>0)|(dd.def_tds>0)].sort_values('tk',ascending=False).head(4).itertuples():
            b=[]
            if r.def_sacks>0:b.append(f"{r.def_sacks:g} sack"+('s' if r.def_sacks>1 else ''))
            if r.def_interceptions>0:b.append(f"{num(r.def_interceptions)} INT")
            if r.def_fumbles_forced>0:b.append(f"{num(r.def_fumbles_forced)} FF")
            if r.def_tds>0:b.append(f"{num(r.def_tds)} def TD")
            L.append(['Defense',r.player_display_name,', '.join(b)])
        for r in dd.sort_values('tk',ascending=False).head(1).itertuples():
            if r.tk>0:L.append(['Tackles',r.player_display_name,f"{num(r.tk)} total"])
        for r in d[(d.fg_att>0)|(d.pat_att>0)].itertuples():
            L.append(['Kicking',r.player_display_name,f"FG {num(r.fg_made)}/{num(r.fg_att)}"+(f" (long {num(r.fg_long)})" if num(r.fg_made) and r.fg_long==r.fg_long else '')+f", XP {num(r.pat_made)}/{num(r.pat_att)}"])
        pf[side]=L
    w=x[x.home_wp.notna()]
    wp=[int(round(v*100)) for v in w.home_wp.values]
    if len(wp)>60:
        idx=np.linspace(0,len(wp)-1,60).astype(int);wp=[wp[i] for i in idx]
    f=x.iloc[0]
    wx=[str(f.stadium)] if isinstance(f.stadium,str) else []
    if f.roof==f.roof and isinstance(f.roof,str) and f.roof!='outdoors':wx.append(f.roof.capitalize())
    elif f.temp==f.temp:
        wx.append(f"{int(f.temp)}°F");
        if f.wind==f.wind:wx.append(f"wind {int(f.wind)} mph")
    out[gid]={'wx':' · '.join(wx),'co':[f.away_coach if isinstance(f.away_coach,str) else '',f.home_coach if isinstance(f.home_coach,str) else ''],'q':q,'sp':ev,'ts':ts,'pf':pf,'wp':wp}
json.dump(out,open('gamedet.json','w'),separators=(',',':'))
print(len(out),len(ids),len(json.dumps(out)))
k=next(iter(out));print(json.dumps(out[k])[:1500])

# ---- time of possession per team (average per game), from drive data ----
ps=pd.read_csv(S+'pbp26.csv',usecols=['game_id','posteam','fixed_drive','drive_time_of_possession','season_type'],low_memory=False)
ps=ps[ps.game_id.isin(ids)&ps.drive_time_of_possession.notna()&ps.posteam.notna()].drop_duplicates(['game_id','posteam','fixed_drive'])
def secs(s):
    try:
        m,sec=str(s).split(':');return int(m)*60+int(sec)
    except Exception:return 0
ps['s']=ps.drive_time_of_possession.map(secs)
per=ps.groupby(['game_id','posteam']).s.sum().reset_index()
chk=per.groupby('game_id').s.sum()
top={}
for tm,d in per.groupby('posteam'):
    top[T(tm)]={'g':int(len(d)),'s':int(round(d.s.sum()/len(d)))}
json.dump(top,open('top.json','w'),separators=(',',':'))
print('top',len(top),'game total min/max',chk.min(),chk.max(),top.get('BUF'))
