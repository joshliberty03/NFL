/* ===================== SUPER BOWL ECHO ===================== */
(function(){
const S=__SBX__;
const $q=id=>document.getElementById(id);
if(!$q('sxbody'))return;
const PR=S.pairs,E=S.echo,SIM=S.sim.teams,SBL=S.sblxi;
const nm=t=>(typeof NAMES!=='undefined'&&NAMES[t])||t;
const tl=(t,s)=>typeof tlogo==='function'?tlogo(t,s||26):esc(t);
const f0=(v,d)=>v==null||isNaN(v)?'–':Number(v).toFixed(d==null?0:d);
const pc=(x,d)=>(x*100).toFixed(d==null?1:d)+'%';
const red=n=>{while(n>9&&![11,22,33].includes(n))n=String(n).split('').reduce((a,b)=>a+ +b,0);return n};
const rec=ts=>`${ts.w}–${ts.l}${ts.t?'–'+ts.t:''}`;
const dt=d=>new Date(d+'T12:00:00').toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
const wd=d=>new Date(d+'T12:00:00').toLocaleDateString('en-US',{weekday:'long'});
const ord=n=>{const q=['th','st','nd','rd'],v=n%100;return n+(q[(v-20)%10]||q[v]||q[0])};
const SBY={};S.sb.forEach(x=>SBY[x.y]=x);const SBN={};S.sb.forEach(x=>SBN[x.n]=x);
const W=(h)=>`<div class="sxw">${h}</div>`;
const tile=(b,s,e)=>`<div class="mtile"><b>${b}</b><span>${s}</span>${e?`<em>${e}</em>`:''}</div>`;
const note=h=>`<p class="note sxn">${h}</p>`;
const h3=(t,s)=>`<h3 class="mth sxh">${t}${s?`<span class="note">${s}</span>`:''}</h3>`;
const mark=ok=>ok?'<span class="sxy">✔</span>':'<span class="sxm">✗</span>';
/* ---------- quarterback helpers ---------- */
const arche=q=>{const g=Math.max(1,q.reg.g),r=q.reg.ry/g;return r>=25?'Dual-threat runner':r>=12?'Mobile passer':'Pocket passer'};
const draft=q=>q.dr?`Round ${q.dr}, pick ${q.dp} (${q.dy||''})`.replace(' ()',''):'Undrafted';
const htw=q=>q.ht?`${Math.floor(q.ht/12)}′${q.ht%12}″ · ${q.wt} lb`:'–';
const cmpPct=q=>q.reg.att?pc(q.reg.cmp/q.reg.att,1):'–';
/* ---------- the three pairs ---------- */
function cell(c,now,i){
  const open=c.res==null,cls=open?'n':c.res==='W'?'w':'l';
  const yr=c.date.slice(0,4);
  return `<div class="sxcell ${cls}"><div class="sxyr">${yr}</div><div class="sxtm">${tl(c.team,34)}<span class="sxbadge ${cls}">${open?'NEXT?':c.res==='W'?'WON':'LOST'}</span></div>
  <div class="sxln"><b>Super Bowl ${c.n}</b></div>
  ${open?`<div class="sxln">${dt(c.date)} · ${esc(SBL.venue)}</div><div class="sxln">${S.cur.CHI.w}–${S.cur.CHI.l} after ${S.cur.CHI.w+S.cur.CHI.l} games</div><div class="sxln sxdim">QB ${esc(c.qb)} · Coach ${esc(c.coach)}</div>`
  :`<div class="sxln">${c.res==='W'?'Beat':'Lost to'} ${tl(c.opp,20)} <b>${c.sc[0]}–${c.sc[1]}</b></div><div class="sxln sxdim">QB ${esc(c.qb)} · Coach ${esc(c.coach||'')}</div>`}
  </div>`}
function vPattern(){
  const L=E.lags,top=[...L].sort((a,b)=>b.LW-a.LW),pm=E.perm;
  const rows=PR.map((p,i)=>`<div class="sxrow">${cell(p.then)}<div class="sxarr"><b>20</b><span>years<br>later</span><i>→</i></div>${cell(p.now,true)}</div>`).join('');
  const max=Math.max(...L.map(x=>x.LW),1);
  const bars=L.map(x=>`<div class="sxcol${x.lag===20?' hot':''}" title="${x.lag} years apart: ${x.LW} of ${x.n}"><i style="height:${Math.round(x.LW/max*100)}%"></i><b>${x.LW||''}</b><span>${x.lag%5===0||x.lag===1?x.lag:''}</span></div>`).join('');
  const b=SIM.CHI;
  return `<p class="note sxn">The graphic going around says: Philadelphia lost the Super Bowl in 2005 and won it 20 years later in 2025. Seattle lost in 2006 and won in 2026. Chicago lost in 2007, so "Chicago next?" in 2027. We rebuilt it from the game data below. Every score, quarterback and coach on this page comes from public game records (nflverse, plus Wikipedia's list of starting quarterbacks).</p>
  <div class="sxrows">${rows}</div>
  ${note('Super Bowl years are the calendar year the game was played (Super Bowl XXXIX was February 2005, for the 2004 season). Row three is not finished: Chicago has to reach Super Bowl LXI on February 14, 2027 and win it.')}
  ${h3('How unusual is a "20 years later" echo?')}
  <div class="mtgrid2">
  ${tile(`${pm.obs20} of 40`,'20-year pairs (1967–2006) where the Super Bowl loser won the title exactly 20 years later',`chance alone expects about ${pm.mean20.toFixed(1)}`)}
  ${tile('#1 of 40',`no other gap from 1 to 40 years has as many loser-then-champion echoes`,`next best: ${top[1].lag} years apart, ${top[1].LW}`)}
  ${tile('Never',`three echoes in a row, at any gap, in 60 Super Bowls`,`longest run so far: ${Math.max(...L.map(x=>x.run))}`)}
  ${tile(pc(b.win),`model chance the Bears win Super Bowl LXI`,`${pc(b.sb)} to reach it · ${pc(b.po)} to make the playoffs`)}
  </div>
  ${h3('Loser-then-champion echoes, by gap in years',`bars show how many of the possible pairs matched`)}
  <div class="sxbars" role="img" aria-label="Echo counts for every gap from 1 to 40 years; 20 years is the tallest">${bars}</div>
  ${note(`The 20-year bar stands well above its neighbors. That is the real finding. The catch, covered under Reality check: 40 gaps were tried, and one of them was always going to look best.`)}
  <div class="sxcall"><b>The honest summary</b><p>The pattern is real as a count: seven franchises lost a Super Bowl and won one exactly 20 years later (Cowboys, Broncos, Rams twice, Patriots, Eagles, Seahawks), far more than the ${pm.mean20.toFixed(1)} you would expect by chance. If the 20-year gap had been chosen before looking, the odds of seven or more are about ${(pm.p20*100).toFixed(1)}%. After allowing for the 40 gaps that could have been picked, the odds are about ${(pm.pAnyLag*100).toFixed(0)}%, which is not unusual enough to call it a rule. The third row is a prediction, not a result.</p></div>`;
}
/* ---------- quarterbacks ---------- */
function qcard(c,q,label){
  if(!q)return '<div class="sxqc"><p class="note">No data.</p></div>';
  const r=q.reg,g=Math.max(1,r.g);
  const open=c.res==null;
  return `<div class="sxqc ${open?'n':c.res==='W'?'w':'l'}"><div class="sxqh"><span class="sxyr s">${c.date.slice(0,4)}</span><b>${esc(q.name)}</b><span class="sxbadge ${open?'n':c.res==='W'?'w':'l'}">${open?'SO FAR':c.res==='W'?'WON':'LOST'}</span></div>
  <div class="sxqt">${tl(c.team,22)} #${q.jn||'–'} · ${arche(q)}</div>
  <dl class="sxkv"><dt>Season${open?' so far':''}</dt><dd>${r.g} games · ${f0(r.yds/g,0)} pass yds/game · ${r.td} TD, ${r.int} INT · ${cmpPct(q)}</dd>
  <dt>Running</dt><dd>${r.car} carries · ${r.ry} yds (${f0(r.ry/g,1)}/game) · ${r.rtd} TD</dd>
  <dt>Sacked</dt><dd>${r.sk} times</dd>
  ${q.sb&&!open?`<dt>Super Bowl</dt><dd>${q.sb.cmp}/${q.sb.att}, ${q.sb.yds} yds, ${q.sb.td} TD, ${q.sb.int} INT${q.sb.ry?` · ${q.sb.ry} rushing`:''}</dd>`:''}
  <dt>Draft</dt><dd>${draft(q)}${q.col?` · ${esc(q.col.split(';')[0])}`:''}</dd>
  <dt>Size</dt><dd>${htw(q)}</dd>
  <dt>Age on game day</dt><dd>${q.age||'–'}</dd>
  <dt>Born</dt><dd>${dt(q.bd)} (${q.wd||wd(q.bd)}) · ${q.sun} · ${q.cz}</dd>
  <dt>Numbers</dt><dd>Life path <b>${q.lp}</b> · name <b>${q.nx||'–'}</b>${q.pd!=null?` · personal day <b>${q.pd}</b>`:''} · jersey <b>${q.jn||'–'}</b></dd></dl></div>`}
const ATTR=[['Style',q=>arche(q)],['Draft round',q=>q.dr?'Round '+q.dr:'Undrafted'],['Drafted in the top 3',q=>q.dp&&q.dp<=3?'Yes':'No'],['Life path',q=>q.lp],['Name number',q=>q.nx],['Jersey number',q=>q.jn],['Birth weekday',q=>q.wd],['Sun sign',q=>q.sun],['Chinese animal',q=>q.cz],['Chinese element',q=>q.cze]];
function vQbs(){
  const pairs=PR.map(p=>[p.then,p.now]);
  let h=`<p class="note sxn">The quarterback is the easiest "type of player" to compare, because every Super Bowl has exactly one starter per side. These are the six starters in the pattern. Season numbers are regular season only; Chicago's cover the 4 games Caleb Williams has stats for so far in 2026 (the week 8 game is not in the stats feed yet).</p>`;
  const scoreboard=ATTR.map(([lab,f])=>{const m=pairs.filter(([a,b])=>{const x=f(a.qbrow),y=f(b.qbrow);return x!=null&&x===y}).length;return [lab,m]});
  pairs.forEach(([a,b],i)=>{h+=`${h3(`${a.qb} → ${b.qb}`,`${a.date.slice(0,4)} ${a.team} · ${b.date.slice(0,4)} ${b.team}`)}<div class="sxcmp">${qcard(a,a.qbrow)}${qcard(b,b.qbrow)}</div>`;
    h+=W(`<table class="sxt"><thead><tr><th>Trait</th><th>${esc(a.qb)}</th><th>${esc(b.qb)}</th><th>Same?</th></tr></thead><tbody>${ATTR.map(([lab,f])=>{const x=f(a.qbrow),y=f(b.qbrow);return `<tr><td>${lab}</td><td>${esc(x==null?'–':x)}</td><td>${esc(y==null?'–':y)}</td><td>${mark(x!=null&&x===y)}</td></tr>`}).join('')}</tbody></table>`)});
  h+=h3('Scoreboard: which traits matched in all three pairs?');
  h+=W(`<table class="sxt"><thead><tr><th>Trait</th><th>Pairs that match (of 3)</th></tr></thead><tbody>${scoreboard.map(([l,m])=>`<tr><td>${l}</td><td>${m}</td></tr>`).join('')}</tbody></table>`);
  const qa=PR.map(p=>p.then.qbrow),qb=PR.map(p=>p.now.qbrow);
  const avg=(a,f)=>a.reduce((s,q)=>s+f(q),0)/a.length;
  h+=note(`Honest reading: the players do not repeat. No trait matches in all three pairs. What the later group does share is style. The three losing quarterbacks of 2005–2007 averaged ${f0(avg(qa,q=>q.reg.ry/Math.max(1,q.reg.g)),1)} rushing yards a game and the three of 2025–2027 average ${f0(avg(qb,q=>q.reg.ry/Math.max(1,q.reg.g)),1)}: the league moved toward quarterbacks who run, and the Eagles and Bears are on that side of it. One coincidence worth noting: Darnold and Hurts, the two quarterbacks who completed their echoes, both have the master name number 11. Two of the three younger starters were top-three picks (Darnold #3, Williams #1) against one of the older group (McNabb #2).`);
  /* every quarterback in the data */
  const all=S.qbs.slice().sort((a,b)=>b.season-a.season||(a.res==='W'?-1:1));
  h+=h3('Every Super Bowl starting quarterback since 1999','54 starts');
  h+=W(`<table class="sxt sxsm"><thead><tr><th>Year</th><th>QB</th><th>Team</th><th></th><th>Style</th><th>Draft</th><th>Age</th><th>Life path</th><th>Sun</th></tr></thead><tbody>${all.map(q=>`<tr class="${q.res==='W'?'sxwr':'sxlr'}"><td>${q.season+1}</td><td>${esc(q.name)}</td><td>${q.team}</td><td>${q.res}</td><td>${arche(q)}</td><td>${q.dr?'R'+q.dr+' #'+q.dp:'Undr.'}</td><td>${q.age}</td><td>${q.lp}</td><td>${q.sun}</td></tr>`).join('')}</tbody></table>`);
  const lw=S.lpdist.W,ll=S.lpdist.L,tot=n=>n.reduce((s,x)=>s+x[1],0),orderLP=[1,2,3,4,5,6,7,8,9,11,22,33];
  const get=(a,k)=>(a.find(x=>x[0]===k)||[k,0])[1];
  h+=h3('Life paths of Super Bowl quarterbacks','winners and losers, 1999–2026');
  h+=W(`<table class="sxt sxsm"><thead><tr><th>Life path</th>${orderLP.map(k=>`<th>${k}</th>`).join('')}</tr></thead><tbody><tr><td>Winners (${tot(lw)})</td>${orderLP.map(k=>`<td>${get(lw,k)||''}</td>`).join('')}</tr><tr><td>Losers (${tot(ll)})</td>${orderLP.map(k=>`<td>${get(ll,k)||''}</td>`).join('')}</tr></tbody></table>`);
  h+=note('Life path is the birth date reduced the same way the Betting page does it (master numbers 11, 22 and 33 are kept). Winners and losers spread across the numbers with no number owning the winners. With 54 starts, a gap of a couple of quarterbacks in one column is what chance produces.');
  return h}
/* ---------- teams and records ---------- */
const bye=ts=>!ts.po.length||ts.po[0].rd!=='Wild card';
function vTeams(){
  let h=`<p class="note sxn">Win–loss records only, as on the rest of the site. Each pair is the same franchise 20 years apart; the box shows the regular season, the playoff road and the roster that took the field.</p>`;
  PR.forEach(p=>{const a=p.then,b=p.now;
    const R=(f)=>`<tr><td>${f[0]}</td><td>${f[1]}</td><td>${f[2]}</td></tr>`;
    const path=c=>c.ts.po.length?c.ts.po.map(x=>`${x.rd==='Super Bowl'?'<b>SB</b>':x.rd.slice(0,3)} ${x.f>x.a?'W':'L'} ${x.f}–${x.a} ${x.h?'vs':'at'} ${x.opp}`).join('<br>'):'Not yet';
    const ro=(c,k)=>c.rost?c.rost[k]:'–';
    const st=(c)=>c.stars?`${c.stars.rush[0]?esc(c.stars.rush[0][0])+' '+c.stars.rush[0][3]+' rush yds':''}<br>${c.stars.rec.slice(0,2).map(r=>esc(r[0])+' '+r[3]+' rec yds').join('<br>')}<br>${c.stars.sack[0]?esc(c.stars.sack[0][0])+' '+c.stars.sack[0][2]+' sacks':''}`:'–';
    const fin=c=>c.res==null?`${S.cur.CHI.w}–${S.cur.CHI.l} so far`:`${c.res==='W'?'Won':'Lost'} ${c.sc[0]}–${c.sc[1]}`;
    const h2=S.h2h[[a.team,a.opp].sort().join('|')];
    const hh=(x)=>{if(!x.opp)return '–';const k=[x.team,x.opp].sort().join('|'),v=S.h2h[k];if(!v)return '–';const first=k.split('|')[0]===x.team;return `${x.team} ${first?v[0]:v[1]}–${first?v[1]:v[0]} ${x.opp}`};
    h+=`${h3(`${tl(a.team,26)} ${nm(a.team)}`,`${a.date.slice(0,4)} and ${b.date.slice(0,4)}`)}`+W(`<table class="sxt sxtwo"><thead><tr><th></th><th>${a.date.slice(0,4)} · SB ${a.n}</th><th>${b.date.slice(0,4)} · SB ${b.n}</th></tr></thead><tbody>
    ${R(['Regular season',rec(a.ts),rec(b.ts)+(b.res==null?' (so far)':'')])}
    ${R(['Points for–against',`${a.ts.pf}–${a.ts.pa}`,`${b.ts.pf}–${b.ts.pa}`])}
    ${R(['Point differential',`${a.rank[2]>0?'+':''}${a.rank[2]} (${ord(a.rank[0])} of ${a.rank[1]})`,`${b.rank[2]>0?'+':''}${b.rank[2]} (${ord(b.rank[0])} of ${b.rank[1]})`])}
    ${R(['First-round bye',bye(a.ts)?'Yes':'No',b.res==null?'–':bye(b.ts)?'Yes':'No'])}
    ${R(['Playoff road',path(a),path(b)])}
    ${R(['Super Bowl',fin(a),fin(b)])}
    ${R(['Opponent',`${tl(a.opp,20)} ${a.oppts?rec(a.oppts):''}`,b.opp?`${tl(b.opp,20)} ${b.oppts?rec(b.oppts):''}`:'To be decided'])}
    ${R(['Head coach',esc(a.coach||'–'),esc(b.coach||'–')])}
    ${R(['Head coach of opponent',esc(a.ocoach||'–'),esc(b.ocoach||'–')])}
    ${R(['Roster age / experience',`${ro(a,'age')} yrs / ${ro(a,'exp')} yrs`,`${ro(b,'age')} yrs / ${ro(b,'exp')} yrs`])}
    ${R(['Rookies · 8+ year veterans',`${ro(a,'rook')} · ${ro(a,'vet8')}`,`${ro(b,'rook')} · ${ro(b,'vet8')}`])}
    ${R(['Top-32 draft picks · undrafted',`${ro(a,'top32')} · ${ro(a,'undr')}`,`${ro(b,'top32')} · ${ro(b,'undr')}`])}
    ${R(['Stars (regular season)',st(a),st(b)])}
    ${R(['Series since 1999 vs that opponent',hh(a),hh(b)])}
    </tbody></table>`)});
  /* matches */
  const tm=PR.map(p=>p.then),nw=PR.slice(0,2).map(p=>p.now);
  h+=h3('What lines up across the six team-seasons');
  const lines=[
   [`All three losing teams went 13–3 in the regular season (Eagles 2004, Seahawks 2005, Bears 2006).`,tm.every(c=>c.ts.w===13&&c.ts.l===3)],
   [`All three lost with a first-round bye, then won a conference title, then lost the Super Bowl to an AFC team (Patriots, Steelers, Colts).`,tm.every(c=>bye(c.ts))],
   [`Both resolved winners went 14–3 (the league now plays 17 games).`,nw.every(c=>c.ts.w===14&&c.ts.l===3)],
   [`All three franchises are NFC teams.`,true],
   [`The Eagles' 2025 win came against the Chiefs, coached by Andy Reid, who coached the 2005 Eagles.`,true],
   [`Seattle's 2026 win came against the Patriots, the team that beat Philadelphia in 2005 and beat Seattle in the 2015 Super Bowl.`,true]];
  h+=`<ul class="sxul">${lines.map(l=>`<li>${mark(l[1])} ${l[0]}</li>`).join('')}</ul>`;
  const rs=S.sbrecsum;
  h+=h3('What happens to Super Bowl teams the next season','2000–2025 Super Bowls, regular season wins');
  h+=`<div class="mtgrid2">${tile(rs.W,'average wins of champions in their title season')}${tile(rs.L,'average wins of the losing team in their Super Bowl season')}${tile(rs.nW,'champions the next season',`${(rs.W-rs.nW).toFixed(1)} fewer wins`)}${tile(rs.nL,'losing teams the next season',`${(rs.L-rs.nL).toFixed(1)} fewer wins`)}</div>`;
  const cur=S.cur;
  h+=note(`The defending champion Seahawks are ${rec(cur.SEA)} and the Eagles (champions a year earlier) are ${rec(cur.PHI)} so far in 2026, while the Bears are ${rec(cur.CHI)}. Super Bowl teams usually slip the following season, and the losing teams have fallen further than the champions. The Eagles' drop fits that hangover.`);
  const by=S.sbrec.slice().sort((a,b)=>b.y-a.y||(a.r==='W'?-1:1));
  h+=`<details class="sxdet"><summary>Every Super Bowl team-season since 2000 (regular season record and the next year)</summary>`+W(`<table class="sxt sxsm"><thead><tr><th>Game</th><th>Team</th><th></th><th>Record</th><th>PF–PA</th><th>Next season</th></tr></thead><tbody>${by.map(r=>`<tr class="${r.r==='W'?'sxwr':'sxlr'}"><td>${r.n} (${r.y})</td><td>${r.t}</td><td>${r.r}</td><td>${r.w}–${r.l}${r.t_?'–'+r.t_:''}</td><td>${r.pf}–${r.pa}</td><td>${r.nw==null?'–':r.nw+'–'+r.nl}</td></tr>`).join('')}</tbody></table>`)+`</details>`;
  return h}
/* ---------- numbers ---------- */
function vNumbers(){
  const rows=PR.map(p=>{const a=p.then,b=p.now;const ya=+a.date.slice(0,4),yb=+b.date.slice(0,4);
    return [ya,yb,red(String(ya).split('').reduce((s,c)=>s+ +c,0)),red(String(yb).split('').reduce((s,c)=>s+ +c,0)),a.n,b.n]});
  const rv=n=>{const v={I:1,V:5,X:10,L:50};let s=0;for(let i=0;i<n.length;i++){s+=(i+1<n.length&&v[n[i]]<v[n[i+1]])?-v[n[i]]:v[n[i]]}return s};
  let h=`<p class="note sxn">Numerology here follows the same rules as the Betting page: add the digits until one is left, keeping the master numbers 11, 22 and 33. Nothing is fitted to the outcome; the numbers are laid out so you can look for yourself.</p>`;
  h+=h3('Years and Super Bowl numbers');
  h+=W(`<table class="sxt"><thead><tr><th>Then</th><th>Year number</th><th>Super Bowl</th><th>Now</th><th>Year number</th><th>Super Bowl</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${r[0]}</td><td>${r[2]}</td><td>${r[4]} = ${rv(r[4])} → ${red(rv(r[4]))}</td><td>${r[1]}</td><td>${r[3]}</td><td>${r[5]} = ${rv(r[5])} → ${red(rv(r[5]))}</td></tr>`).join('')}</tbody></table>`);
  h+=note(`The 2027 year number is 11, a master number, the first one in the chain. Each row steps up the same way (7→9, 8→1, 9→11) and the Super Bowl numbers climb 39→59, 40→60 and 41→61. That is arithmetic, not a discovery: any two years 20 apart add 2 to the digit sum, and the Super Bowl is played once a year. One genuine curiosity: XL and LX are the same letters in a different order, and so are XLI and LXI.`);
  /* the dates */
  const dn=(n)=>n==='LXI'?SBL.dn:SBN[n].dn;
  h+=h3('Game dates and franchise numbers');
  const tn=(c)=>{if(c.res==null)return {lp:SBL.clp,pd:SBL.cpd,dn:SBL.dn};const x=SBN[c.n];return c.res==='W'?{lp:x.wlp,pd:x.wpd,dn:x.dn}:{lp:x.llp,pd:x.lpd,dn:x.dn}};
  h+=W(`<table class="sxt"><thead><tr><th>Game</th><th>Date</th><th>Team</th><th></th><th>Date number</th><th>Team founding life path</th><th>Team personal day</th></tr></thead><tbody>${PR.flatMap(p=>[p.then,p.now]).map(c=>{const t=tn(c);return `<tr><td>${c.n}</td><td>${dt(c.date)}</td><td>${c.team}</td><td>${c.res==null?'?':c.res}</td><td>${t.dn}</td><td>${t.lp}</td><td>${t.pd}</td></tr>`}).join('')}</tbody></table>`);
  h+=note(`Date number is the game date reduced like a birth date. Each team's life path comes from its founding date and its personal day from that life path and the game date, the same method as the Betting page. Look for repeats: the Eagles' founding number is ${SBN.XXXIX.llp} and the Seahawks' is ${SBN.XL.llp}; Chicago's is ${SBL.clp}.`);
  h+=h3('Score numbers');
  const sc=PR.slice(0,2).flatMap(p=>[p.then,p.now]).map(c=>[c.n,c.team,c.sc[0],c.sc[1]]);
  h+=W(`<table class="sxt"><thead><tr><th>Game</th><th>Team</th><th>Its score</th><th>Other score</th><th>Total</th><th>Total reduced</th><th>Margin</th></tr></thead><tbody>${sc.map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td><td>${r[2]+r[3]}</td><td>${red(r[2]+r[3])}</td><td>${r[2]-r[3]>0?'+':''}${r[2]-r[3]}</td></tr>`).join('')}</tbody></table>`);
  h+=h3('Quarterback numbers');
  h+=W(`<table class="sxt"><thead><tr><th>Game</th><th>QB</th><th>Jersey</th><th>Life path</th><th>Name</th><th>Personal day on game date</th><th>Born</th></tr></thead><tbody>${PR.flatMap(p=>[p.then,p.now]).map(c=>`<tr><td>${c.n}</td><td>${esc(c.qb)}</td><td>${c.qbrow.jn||'–'}</td><td>${c.qbrow.lp}</td><td>${c.qbrow.nx||'–'}</td><td>${c.qbrow.pd==null?'–':c.qbrow.pd}</td><td>${dt(c.qbrow.bd)}</td></tr>`).join('')}</tbody></table>`);
  h+=note(`Jersey numbers by pair: 5→1, 8→14, 8→18. Hasselbeck and Grossman both wore 8, and the 8 sits inside Williams' 18, the closest rhyme in the set. The life paths do not rhyme, and neither do the name numbers.`);
  /* lag-20 echo tally */
  const L20=S.lag20,same=(f)=>L20.filter(r=>f(r)).length;const allp=(()=>{let n=0,k=0;S.sb.forEach(x=>{const z=SBY[x.y+20];if(z){n++;if(z.dn===x.dn)k++}});return{n,k}})();
  h+=h3('The seven loser-then-champion echoes, numbers side by side');
  h+=W(`<table class="sxt sxsm"><thead><tr><th>Franchise</th><th>Lost</th><th>Date no.</th><th>QB</th><th>Won</th><th>Date no.</th><th>QB</th><th>Same date no.?</th></tr></thead><tbody>${L20.map(r=>`<tr><td>${r.t}</td><td>${r.a.n} (${r.a.y})</td><td>${r.a.dn}</td><td>${esc(r.a.qb)}</td><td>${r.b.n} (${r.b.y})</td><td>${r.b.dn}</td><td>${esc(r.b.qb)}</td><td>${mark(r.a.dn===r.b.dn)}</td></tr>`).join('')}</tbody></table>`);
  h+=note(`${same(r=>r.a.dn===r.b.dn)} of the 7 echoes share a date number. Across all ${allp.n} pairs of Super Bowls 20 years apart, ${allp.k} (${pc(allp.k/allp.n,0)}) do, so the echoes are no more alike than any other pair and no number-based rule shows up.`);
  return h}
/* ---------- the sky ---------- */
function vSky(){
  const sk=S.sky,L20=S.lag20;
  const pairs=PR.map(p=>[p.then.n,p.now.n]);
  const row=(n)=>{const s=sk[n],x=n==='LXI'?{d:'2027-02-14'}:SBN[n];return `<tr><td>${n}</td><td>${dt(x.d)}</td><td>${s.sun} ${Math.floor(s.sunlon%30)}°</td><td>${s.phase} (${s.ill}%)</td><td>${s.moon}</td><td>${s.jup}</td><td>${s.sat}</td><td>${s.js.toFixed(0)}°</td></tr>`};
  let h=`<p class="note sxn">Positions are calculated for each kickoff (about 6:30 p.m. Eastern) with a standard astronomy library, tropical zodiac. Astrology is a tradition people use to read games; nothing here has been shown to predict one.</p>`;
  h+=h3('The sky on each Super Bowl date');
  h+=W(`<table class="sxt sxsm"><thead><tr><th>Game</th><th>Date</th><th>Sun</th><th>Moon phase</th><th>Moon in</th><th>Jupiter in</th><th>Saturn in</th><th>Saturn minus Jupiter</th></tr></thead><tbody>${pairs.flatMap(p=>p).map(row).join('')}</tbody></table>`);
  const d=(a,b)=>Math.abs((sk[b].js-sk[a].js+180)%360-180);
  h+=h3('The one real astronomical rhyme','Jupiter and Saturn');
  h+=`<div class="mtgrid2">${pairs.map(([a,b])=>tile(d(a,b).toFixed(1)+'°',`${a} to ${b}: change in the Jupiter–Saturn angle`,`${sk[a].js.toFixed(0)}° then, ${sk[b].js.toFixed(0)}° now`)).join('')}</div>`;
  h+=note(`Jupiter and Saturn line up with each other about every 19.86 years, which is almost exactly 20. So two dates 20 years apart find the two giants in nearly the same arrangement: across all ${S.js20.n} Super Bowl pairs 20 years apart the angle changed by ${S.js20.mean}° on average (at most ${S.js20.max}°). The Eagles' pair (a few degrees) is tighter than most, but this is true of any date, football or not. It explains why "20 years later" feels like a natural cycle in astrology; it does not point at football.`);
  h+=h3('Moon phase','20 years later');
  h+=W(`<table class="sxt sxsm"><thead><tr><th>Franchise</th><th>Lost on</th><th>Moon</th><th>Won on</th><th>Moon</th></tr></thead><tbody>${L20.map(r=>`<tr><td>${r.t}</td><td>${dt(r.a.d)}</td><td>${r.sky[2]}</td><td>${dt(r.b.d)}</td><td>${r.sky[3]}</td></tr>`).join('')}</tbody></table>`);
  h+=note(`The Moon repeats its phase on the same calendar date after 19 years, not 20, so a 20-year gap moves the phase by about 11 days (across all Super Bowl pairs 20 years apart it averages ${S.mp20.mean}° of the 360° cycle). ${(()=>{const d=L20.map(r=>Math.abs((S.sky[r.b.n].el-S.sky[r.a.n].el+180)%360-180));return `For the seven echoes the phase differed by between ${Math.min(...d).toFixed(0)}° and ${Math.max(...d).toFixed(0)}° of the 360° cycle.`})()}`);
  h+=h3('Chinese zodiac');
  const czr=PR.flatMap(p=>[p.then,p.now]).map(c=>c.qbrow);
  h+=W(`<table class="sxt"><thead><tr><th>Game</th><th>Quarterback</th><th>Birth animal</th><th>Element</th></tr></thead><tbody>${PR.flatMap(p=>[p.then,p.now]).map(c=>`<tr><td>${c.n}</td><td>${esc(c.qb)}</td><td>${c.qbrow.cz}</td><td>${c.qbrow.cze}</td></tr>`).join('')}</tbody></table>`);
  h+=note(`Twenty years is eight steps around the 12-animal wheel, so a gap of exactly 20 years never returns to the same animal. Each of the six quarterbacks has a different animal from his partner, which is built into the calendar. The game dates themselves fall in February, in the Aquarius season of the Western zodiac (the Sun is in Aquarius for all of them).`);
  return h}
/* ---------- echo hunt ---------- */
let lag=20,kind='LW';
function vHunt(){
  const byY={};S.sb.forEach(x=>byY[x.y]=x);
  const ys=S.sb.map(x=>x.y);
  const cnt={};S.sb.forEach(x=>{cnt[x.w]=cnt[x.w]||{w:0,l:0};cnt[x.l]=cnt[x.l]||{w:0,l:0};cnt[x.w].w++;cnt[x.l].l++});
  const N=S.sb.length,den=N*(N-1);
  const exp=(lg,k)=>{const n=ys.filter(y=>byY[y+lg]).length;let s=0;Object.values(cnt).forEach(c=>{s+=k==='LW'||k==='WL'?c.l*c.w:k==='WW'?c.w*(c.w-1):c.l*(c.l-1)});return n*s/den};
  const hit=(y,lg,k)=>{const a=byY[y],b=byY[y+lg];if(!b)return null;return k==='LW'?a.l===b.w:k==='WW'?a.w===b.w:k==='LL'?a.l===b.l:a.w===b.l};
  const matches=[];ys.forEach(y=>{if(hit(y,lag,kind)){const a=byY[y],b=byY[y+lag];matches.push({y,a,b})}});
  const npairs=ys.filter(y=>byY[y+lag]).length;
  const lab={LW:'lost, then won',WW:'won, then won again',LL:'lost, then lost again',WL:'won, then lost'};
  const rowsAll=E.lags.map(x=>({lag:x.lag,v:x[kind],e:exp(x.lag,kind)}));
  const max=Math.max(...rowsAll.map(r=>r.v),1);
  const bars=rowsAll.map(r=>`<div class="sxcol${r.lag===lag?' hot':''}" data-lag="${r.lag}" title="${r.lag} years: ${r.v} (about ${r.e.toFixed(1)} expected)"><i style="height:${Math.round(r.v/max*100)}%"></i><em style="bottom:${Math.round(r.e/max*100)}%"></em><b>${r.v||''}</b><span>${r.lag%5===0||r.lag===1?r.lag:''}</span></div>`).join('');
  const runs=E.runs.map(r=>`<li><b>${r.lag} years apart</b>: ${r.from}→${r.from+r.lag} and ${r.to}→${r.to+r.lag} back to back (${r.team.join(', ')})${r.lag===20?' ← the Eagles and Seahawks':''}</li>`).join('');
  return `<p class="note sxn">Pick any gap and any kind of echo and see which franchises match. The small tick on each bar is how many matches chance alone would produce for that gap, given how often each team has won and lost. Tap a bar to choose its gap.</p>
  <div class="filters sxf"><label for="sxlag">Gap in years<select id="sxlag">${E.lags.map(x=>`<option value="${x.lag}"${x.lag===lag?' selected':''}>${x.lag}</option>`).join('')}</select></label>
  <label for="sxkind">Echo<select id="sxkind">${Object.keys(lab).map(k=>`<option value="${k}"${k===kind?' selected':''}>Team ${lab[k]}</option>`).join('')}</select></label></div>
  <div class="mtgrid2">${tile(matches.length,`matches at a ${lag}-year gap`,`out of ${npairs} possible pairs`)}${tile(exp(lag,kind).toFixed(1),'expected by chance','shuffled-order average')}${tile(Math.max(...E.lags.map(x=>x[kind])),'most matches at any gap',`gap(s): ${E.lags.filter(x=>x[kind]===Math.max(...E.lags.map(y=>y[kind]))).map(x=>x.lag).join(', ')}`)}</div>
  <div class="sxbars" id="sxhb">${bars}</div>
  ${h3(`Franchises that ${lab[kind]} ${lag} years apart`)}
  ${matches.length?W(`<table class="sxt"><thead><tr><th>Franchise</th><th>First game</th><th>Second game</th><th>QBs</th></tr></thead><tbody>${matches.map(m=>{const t=(kind==='LW'||kind==='LL')?m.a.l:m.a.w;return `<tr><td>${tl(t,22)}</td><td>${m.a.n} (${m.a.y}): ${m.a.w} ${m.a.ws}, ${m.a.l} ${m.a.ls}</td><td>${m.b.n} (${m.b.y}): ${m.b.w} ${m.b.ws}, ${m.b.l} ${m.b.ls}</td><td>${esc(kind==='LW'?m.a.lq:kind==='WW'?m.a.wq:kind==='LL'?m.a.lq:m.a.wq)} → ${esc(kind==='LW'?m.b.wq:kind==='WW'?m.b.wq:kind==='LL'?m.b.lq:m.b.lq)}</td></tr>`}).join('')}</tbody></table>`):'<p class="note">No franchise did this at that gap.</p>'}
  ${lag===20&&kind==='LW'?note('The 2007 → 2027 pair is not in this list because it has not been played. If the Bears win Super Bowl LXI it becomes the eighth echo and the first three-in-a-row at any gap.'):''}
  ${h3('Back-to-back echoes at the same gap')}<ul class="sxul">${runs}</ul>
  ${note('Only four times in 60 Super Bowls has the same gap produced two loser-then-champion echoes in consecutive years, and never three. The 2005–2006 run at 20 years is one of them.')}`}
/* ---------- other patterns ---------- */
function vOther(){
  let h=`<p class="note sxn">Everything below was found by searching all 60 Super Bowls for other shapes like the "20 years later" one.</p>`;
  const rd=S.fr.filter(r=>r.redeem).sort((a,b)=>a.gap-b.gap);
  h+=h3('Franchises that lost, then won','every Super Bowl franchise');
  h+=W(`<table class="sxt sxsm"><thead><tr><th>Franchise</th><th>Super Bowls</th><th>Order (W/L)</th><th>Years</th><th>First loss → later win</th></tr></thead><tbody>${S.fr.map(r=>`<tr><td>${tl(r.t,22)}</td><td>${r.w}–${r.l}</td><td class="sxseq">${r.seq.split('').map(c=>`<i class="${c==='W'?'w':'l'}">${c}</i>`).join('')}</td><td>${r.yrs.join(', ')}</td><td>${r.redeem?`${r.redeem[0]} → ${r.redeem[1]} (${r.redeem[1]-r.redeem[0]} yrs)`:'–'}</td></tr>`).join('')}</tbody></table>`);
  h+=note(`${rd.length} of ${S.fr.length} franchises have lost one and later won one. Shortest wait from a loss to a later title: ${rd[0].t} (${rd[0].gap} year${rd[0].gap>1?'s':''}). Never won in a Super Bowl: ${S.never.join(', ')}.`);
  h+=h3('Rematches and revenge','two teams meeting in more than one Super Bowl');
  h+=W(`<table class="sxt sxsm"><thead><tr><th>Teams</th><th>Games (winner, score)</th><th>Loser later won it back?</th></tr></thead><tbody>${S.rematch.map(r=>`<tr><td>${r.pair.join(' vs ')}</td><td>${r.g.map(g=>`${g.n} ${g.y}: ${g.w} ${g.sc[0]}–${g.sc[1]}`).join('<br>')}</td><td>${mark(r.revenge)}</td></tr>`).join('')}</tbody></table>`);
  h+=note(`Super Bowl LX is a revenge game in this list: Seattle beat New England 29–13 after losing to them 28–24 in 2015, and Philadelphia's 40–22 win over Kansas City reversed the 38–35 loss two years before.New England is the common thread: it beat Philadelphia in 2005 and Seattle in 2015, and both later beat it (Eagles in 2018, Seahawks in 2026).`);
  h+=h3('Quarterbacks who lost a Super Bowl, then won one');
  const q=S.qled.filter(r=>r.lw);
  h+=W(`<table class="sxt sxsm"><thead><tr><th>Quarterback</th><th>Order</th><th>Teams</th><th>Loss → win</th></tr></thead><tbody>${q.map(r=>`<tr><td>${esc(r.q)}</td><td class="sxseq">${r.seq.split('').map(c=>`<i class="${c==='W'?'w':'l'}">${c}</i>`).join('')}</td><td>${r.teams.join(', ')}</td><td>${r.lw[0]} → ${r.lw[1]}${r.diff_team?' (new team)':''}</td></tr>`).join('')}</tbody></table>`);
  h+=note(`Jalen Hurts is on this list (lost 2023, won 2025). Tom Brady lost with the Patriots and later won with the Buccaneers; Peyton Manning lost with the Colts and later won with the Broncos. The earlier echoes had their own quarterback stories: Drew Bledsoe lost for New England in 1997 and Tom Brady won for them in 2017; Kurt Warner won for the Rams in 2000, lost in 2002 and the Rams won again 20 years later under Matthew Stafford.`);
  h+=h3('Coaches against their old teams');
  h+=`<ul class="sxul">${S.coachfacts.map(c=>`<li><b>${esc(c.who)}.</b> ${esc(c.txt)}</li>`).join('')}</ul>`;
  h+=h3('Same final score, different year');
  h+=W(`<table class="sxt sxsm"><thead><tr><th>Score</th><th>Games</th></tr></thead><tbody>${S.scoredup.map(r=>`<tr><td>${r.s[0]}–${r.s[1]}</td><td>${r.g.join(' and ')}</td></tr>`).join('')}</tbody></table>`);
  const l20=S.lag20.find(r=>r.t==='PHI');
  h+=h3('Calendar curiosities');
  h+=`<ul class="sxul"><li>The 2005 Eagles loss (February 6) and the 2025 win (February 9) are exactly ${l20.days.toLocaleString()} days apart, which is 1,044 weeks, so both were Sundays. That happens whenever two dates are 20 years apart and the leap years line up; it is the calendar, not the game.</li><li>XL and LX, and XLI and LXI, are anagrams as Roman numerals.</li><li>The Rams' two echoes (1980 → 2000 and 2002 → 2022) are the only franchise with more than one loser-then-champion echo at 20 years.</li><li>Every echo came with a different quarterback, as you would expect across a full generation.</li></ul>`;
  h+=h3('Droughts','how long since each champion last won');
  const dr=S.fr.filter(r=>r.last).sort((a,b)=>a.last-b.last).slice(0,10);
  h+=W(`<table class="sxt sxsm"><thead><tr><th>Franchise</th><th>Last Super Bowl win</th><th>Years to the 2027 game</th></tr></thead><tbody>${dr.map(r=>`<tr><td>${tl(r.t,22)}</td><td>${r.last}</td><td>${2027-r.last}</td></tr>`).join('')}</tbody></table>`);
  h+=note(`The Bears' only Super Bowl win was January 1986 (XX, 46–10 over New England). If they reach February 2027 it will be 41 years since.`);
  return h}
/* ---------- Bears 2027 ---------- */
function vBears(){
  const c=S.cur.CHI,b=SIM.CHI,pm=E.perm;
  const lead=Object.entries(SIM).sort((x,y)=>y[1].win-x[1].win).slice(0,10);
  const log=S.sched.filter(g=>g.f!=null).map(g=>`<tr><td>${g.wk}</td><td>${dt(g.d)}</td><td>${g.h?'vs':'at'} ${tl(g.opp,20)}</td><td>${g.f>g.a?'W':'L'} ${g.f}–${g.a}</td></tr>`).join('');
  const rem=S.bearsrem.map(g=>`<tr><td>${g.wk}</td><td>${dt(g.d)}</td><td>${g.h?'vs':'at'} ${tl(g.opp,20)}</td><td>${pc(g.p,0)}</td></tr>`).join('');
  let h=`<p class="note sxn">Row three of the graphic is "Chicago next?" That needs the Bears to win Super Bowl LXI. Here is where they stand today, and a simulation of the rest of the season.</p>
  <div class="mtgrid2">${tile(rec(c),'Bears record, 2026',`${ord(S.pairs[2].now.rank[0])} in point differential (${S.pairs[2].now.rank[2]>0?'+':''}${S.pairs[2].now.rank[2]})`)}${tile(pc(b.po,0),'chance to make the playoffs')}${tile(pc(b.bye,0),'chance of the top seed and a bye')}${tile(pc(b.sb),'chance to reach Super Bowl LXI',`about 1 in ${Math.round(1/b.sb)}`)}${tile(pc(b.win),'chance to win it',`about 1 in ${Math.round(1/b.win)}`)}</div>
  ${note(`Method: a team-strength rating (Elo, rebuilt from every game since 1999, with a home-field edge and a margin-of-victory adjustment) plays the rest of the regular season ${S.sim.ns.toLocaleString()} times, then the seven-team playoff bracket for each conference. It knows nothing about injuries, trades or weather. It is a model, and it is not betting advice. The Bears' rating is ${b.elo}, ${S.sig.findIndex(x=>x[0]==='CHI')>=0?'among the five highest':'outside the top five'}.`)}
  ${h3('Who is most likely to win Super Bowl LXI','this model, top ten')}
  ${W(`<table class="sxt"><thead><tr><th>Team</th><th>Rating</th><th>Record</th><th>Playoffs</th><th>Reach SB</th><th>Win SB</th></tr></thead><tbody>${lead.map(([t,v])=>`<tr class="${t==='CHI'?'sxme':''}"><td>${tl(t,22)}</td><td>${v.elo}</td><td>${v.w}</td><td>${pc(v.po,0)}</td><td>${pc(v.sb)}</td><td>${pc(v.win)}</td></tr>`).join('')}${SIM.CHI&&!lead.find(x=>x[0]==='CHI')?`<tr class="sxme"><td>${tl('CHI',22)}</td><td>${b.elo}</td><td>${b.w}</td><td>${pc(b.po,0)}</td><td>${pc(b.sb)}</td><td>${pc(b.win)}</td></tr>`:''}</tbody></table>`)}
  ${h3('Where the two finished rows stand this season')}
  <div class="mtgrid2">${tile(rec(S.cur.PHI),'Eagles, 2026 (champions of 2025 season)',`${pc(SIM.PHI.po,0)} to make the playoffs`)}${tile(rec(S.cur.SEA),'Seahawks, 2026 (defending champions)',`${pc(SIM.SEA.po,0)} to make the playoffs`)}${tile(rec(S.cur.CHI),'Bears, 2026',`${pc(b.po,0)} to make the playoffs`)}</div>
  ${h3('Bears results so far')}${W(`<table class="sxt sxsm"><thead><tr><th>Wk</th><th>Date</th><th>Game</th><th>Result</th></tr></thead><tbody>${log}</tbody></table>`)}
  ${h3('Bears remaining schedule','single-game win chance from the same ratings')}${W(`<table class="sxt sxsm"><thead><tr><th>Wk</th><th>Date</th><th>Game</th><th>Win chance</th></tr></thead><tbody>${rem}</tbody></table>`)}
  ${h3('How to weigh the pattern against the model')}
  <div class="sxcall"><p>If the pattern is only a coincidence, the Bears are a 1-in-${Math.round(1/b.win)} shot (${pc(b.win)}), a good team but one of several contenders. If the pattern were a real force, the third row would be a lock. Nothing in the test says it is a force: the strongest honest reading is "an unusual count with no known cause". A fair way to hold both is to treat the Bears at about the model's number, maybe a little better, and enjoy the symmetry if it lands.</p></div>
  ${note(`For scale: the average team has a 3.1% chance (1 in 32) before the season starts. The Bears' only title came in Super Bowl XX (January 1986).`)}`;
  return h}
/* ---------- reality check ---------- */
function vCheck(){
  const pm=E.perm,L=E.lags;
  let h=`<p class="note sxn">A pattern that someone spotted after the fact needs three tests before it is worth anything: is it rarer than chance, does it survive being one of many things you could have looked at, and does it predict anything new. Here is how this one does.</p>
  ${h3('Test 1: is a 20-year gap rarer than chance?')}
  <p class="sxp">We shuffled the order of all 60 Super Bowls ${pm.N.toLocaleString()} times (keeping every team's wins and losses the same, only moving them between years) and counted loser-then-champion echoes at a 20-year gap. A typical shuffle gives ${pm.mean20.toFixed(1)}. Only ${(pm.p20*100).toFixed(2)}% of shuffles reached seven. Verdict: <b>yes, rarer than chance</b>, if 20 years was the only gap you were going to check.</p>
  ${h3('Test 2: was it one of many gaps?')}
  <p class="sxp">It was not the only one. The graphic could have said 10 years or 15 or 25, and 40 gaps are possible. Taking the best gap in each shuffle, a count of seven or more appears about ${(pm.pAnyLag*100).toFixed(0)}% of the time just by picking the most striking gap. Verdict: <b>not strong evidence</b>. This is the same trap as picking the one lucky stock out of a basket after the fact.</p>
  ${h3('Test 3: does a streak this long mean more?')}
  <p class="sxp">Two echoes in a row at the 20-year gap (Eagles then Seahawks) happens in about ${(pm.pRun2At20*100).toFixed(0)}% of shuffles. It is also one of four back-to-back pairs found across all gaps in real history. A third in a row would be new, but the best gap in each shuffle produces a three-in-a-row about ${(pm.pRun3AnyLag*100).toFixed(0)}% of the time, so even that would not be wildly improbable.</p>
  ${h3('Test 4: what it can and cannot predict')}
  <ul class="sxul"><li>${mark(true)} It describes real history accurately: the seven echoes exist.</li><li>${mark(false)} It names no cause. One plausible reason it is not pure luck: strong franchises stay strong for stretches, and the shuffle test treats every year as independent. That would make repeats less surprising, not more.</li><li>${mark(false)} It cannot be tested on the future until February 2027, one game.</li><li>${mark(false)} Nothing in the players, records, numbers or sky repeats in all three rows: no quarterback trait, no life path, no date number.</li></ul>
  ${h3('Bottom line')}
  <div class="sxcall"><p><b>The tab's verdict:</b> a genuine oddity, not a rule. The 20-year echo is the strongest of 40 gaps, and once you allow for choosing it from those 40, luck alone produces something this striking about one time in nine; it has no known mechanism; and the Bears' chance of completing it is best estimated by how good the Bears are (${pc(SIM.CHI.win)}), not by the pattern. Enjoy it as a story. Do not read it as a forecast.</p></div>
  ${note('Data: game results, rosters and player stats from nflverse; Super Bowl starting quarterbacks from Wikipedia; Super Bowl LXI date from the NFL and Wikipedia. Planet and Moon positions calculated with the PyEphem astronomy library. The shuffle tests and season simulation were run on this site\'s own pipeline and refresh with every data update.')}`;
  return h}
/* ---------- wiring ---------- */
const VIEWS={pattern:vPattern,qbs:vQbs,teams:vTeams,numbers:vNumbers,sky:vSky,hunt:vHunt,other:vOther,bears:vBears,check:vCheck};
let view='pattern';
function draw(keepScroll){
  const bd=$q('sxbody');
  try{bd.innerHTML=VIEWS[view]()}catch(e){bd.innerHTML='<p class="note">This section could not be drawn.</p>';try{console.error(e)}catch(_){}}
  $q('sxviews').querySelectorAll('[data-sv]').forEach(b=>b.classList.toggle('solid',b.dataset.sv===view));
}
$q('sxeyebrow').textContent=`60 Super Bowls · through Super Bowl LX · Bears ${rec(S.cur.CHI)} in 2026`;
$q('sxviews').addEventListener('click',e=>{const b=e.target.closest('[data-sv]');if(b){view=b.dataset.sv;draw();try{$q('sxviews').scrollIntoView({block:'start'})}catch(_){}}});
$q('sxbody').addEventListener('change',e=>{if(e.target.id==='sxlag'){lag=+e.target.value;draw()}else if(e.target.id==='sxkind'){kind=e.target.value;draw()}});
$q('sxbody').addEventListener('click',e=>{const c=e.target.closest('.sxcol[data-lag]');if(c){lag=+c.dataset.lag;draw()}});
draw();
})();
