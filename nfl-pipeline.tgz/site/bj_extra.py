# executed inside assemble.py (has bj, once, re, bet in scope)
# ---- actual starting QB for played games ----
bj=once(bj,"  const UP=BT.upcoming, TEAMS2=Object.keys(BT.teams).sort();","""  const UP=BT.upcoming, TEAMS2=Object.keys(BT.teams).sort();
  const menFor=(team,g)=>{const base=BT.teams[team]||[];const o=g&&BT.qbs&&BT.qbs[g.id]&&BT.qbs[g.id][team===g.home?'h':'a'];if(!o)return base;return base.some(m=>m.pos==='QB')?base.map(m=>m.pos==='QB'?o:m):[...base,o]};""")
bj=bj.replace("men=BT.teams[team]||[],qb=men.find(m=>m.pos==='QB')","men=menFor(team,g),qb=men.find(m=>m.pos==='QB')")
assert bj.count("menFor(team,g)")>=3,bj.count("menFor(team,g)")
bj=once(bj,"  function lineup(team,hl,dn){\n    const men=BT.teams[team]||[];","  function lineup(team,hl,dn,g){\n    const men=menFor(team,g);")
bj=once(bj,"${lineup(A,$('btnum').value,dn)}${lineup(B,$('btnum').value,dn)}","${lineup(A,$('btnum').value,dn,g)}${lineup(B,$('btnum').value,dn,g)}")
bj=once(bj,"const ma=BT.teams[A]||[],mb=BT.teams[B]||[];","const ma=menFor(A,g),mb=menFor(B,g);")
bj=once(bj,"const jnum=(team,m)=>{const j=JY[team]&&JY[team][m.n+'|'+m.pos];return j==null?'–':j};","const jnum=(team,m)=>{const j=m.jy!=null?m.jy:(JY[team]&&JY[team][m.n+'|'+m.pos]);return j==null?'–':j};")
bj=once(bj,"const jy=m=>JY[team]&&JY[team][m.n+'|'+m.pos];","const jy=m=>m.jy!=null?m.jy:(JY[team]&&JY[team][m.n+'|'+m.pos]);")
bj=once(bj,"""<h2 style="margin-top:18px">Both starting units</h2>""","""<h2 style="margin-top:18px">Both starting units</h2>${g.pl?'<p class="note">For a game already played, the quarterback shown is the one who actually started it. Every other starter is the current depth chart.</p>':''}""")
# ---- lean cache ----
bj=once(bj,"    let la=0,lb=0,le=0;sumRows.forEach","    window.__LEAN=window.__LEAN||{};window.__LEAN[g.id]=sumRows.map(r=>[r[0],r[2],r[3]]);\n    let la=0,lb=0,le=0;sumRows.forEach")
# ---- scoreboard card html ----
bet=once(bet,'''  <div id="btdetail"></div>
''','''  <div id="btdetail"></div>

  <div class="card" id="btscore">
    <div class="teamhead"><h2>Did the numbers work?</h2><span class="count" id="btscorecount"></span></div>
    <p class="note">For every game already played, each tradition leans to the side with more indications, and the table counts how often that side won. Ties count as no call. The quarterback is the one who actually started.</p>
    <div class="tablebox"><table><thead><tr><th>Tradition</th><th>Called</th><th>Right</th><th>Wrong</th><th>Hit rate</th><th>Odds of doing this well or badly by luck</th><th>Link with the final margin (r)</th></tr></thead><tbody id="btscoretb"><tr><td colspan="6" class="st">Counting…</td></tr></tbody></table></div>
    <p class="note" id="btscorenote"></p>
  </div>
''')
# ---- coach filter ----
bet=once(bet,'''      <label for="btteam">Team<select id="btteam">''','''      <label for="btcoach">Coaches' personal day<select id="btcoach"><option value="">Any</option><option value="either">Matches the day of the month, either coach</option><option value="both">Matches the day of the month, both coaches</option></select></label>
      <label for="btteam">Team<select id="btteam">''')
bj=once(bj,"&&(!sh||(sh==='played'?g.pl:!g.pl)));","&&(!sh||(sh==='played'?g.pl:!g.pl))&&(!$('btcoach').value||($('btcoach').value==='both'?(cpm(g,'a')&&cpm(g,'h')):(cpm(g,'a')||cpm(g,'h')))));")
bj=once(bj,"['btdn','btwk','btteam','btnum','btshow'].forEach","['btdn','btwk','btteam','btnum','btshow','btcoach'].forEach")
bj=once(bj,'''      <span class="ph2h">Series''','''      <span class="ph2h${cpm(g,'a')||cpm(g,'h')?' cpd':''}">Coach day ${g.acpd} / ${g.hcpd}${cpm(g,'a')||cpm(g,'h')?' ★':''}</span>
      <span class="ph2h">Series''')
# helper
bj=once(bj,"  const menFor=","  const cpm=(g,s)=>{const pd=s==='a'?g.acpd:g.hcpd;return red9(pd)===red9(+g.date.slice(8))};\n  const menFor=")
# ---- scoreboard + lean API (appended at the end of the betting IIFE) ----
score_js = r'''
  /* ---- scoreboard: did each tradition's lean match the result? ---- */
  window.__LEAN=window.__LEAN||{};
  const leanOf=g=>{if(!window.__LEAN[g.id])traditions(g);return window.__LEAN[g.id]};
  window.__numbersLean=id=>{const g=UP.find(x=>x.id===id);if(!g)return null;let a=0,b=0;leanOf(g).forEach(r=>{if(r[1]>r[2])a++;else if(r[2]>r[1])b++});return {away:g.away,home:g.home,a,b,pick:a>b?g.away:b>a?g.home:null}};
  function binP(k,n){if(!n)return 1;const lf=[0];for(let i=1;i<=n;i++)lf[i]=lf[i-1]+Math.log(i);const pm=i=>Math.exp(lf[n]-lf[i]-lf[n-i]-n*Math.LN2);const o=pm(k);let s=0;for(let i=0;i<=n;i++){const p=pm(i);if(p<=o+1e-12)s+=p}return Math.min(1,s)}
  const rootOf=n=>{n=Math.abs(n);while(n>9)n=String(n).split('').reduce((x,y)=>x+ +y,0);return n};
  function pearson(xs,ys){const n=xs.length;if(n<8)return null;const mx=xs.reduce((a,b)=>a+b,0)/n,my=ys.reduce((a,b)=>a+b,0)/n;let sxy=0,sxx=0,syy=0;for(let i=0;i<n;i++){sxy+=(xs[i]-mx)*(ys[i]-my);sxx+=(xs[i]-mx)**2;syy+=(ys[i]-my)**2}if(!sxx||!syy)return null;const r=sxy/Math.sqrt(sxx*syy),t=r*Math.sqrt((n-2)/Math.max(1e-9,1-r*r));const z=Math.abs(t),p=Math.min(1,2*(1-0.5*(1+erf(z/Math.SQRT2))));return {r,p}}
  function erf(x){const s=x<0?-1:1;x=Math.abs(x);const t=1/(1+0.3275911*x),y=1-(((((1.061405429*t-1.453152027)*t)+1.421413741)*t-0.284496736)*t+0.254829592)*t*Math.exp(-x*x);return s*y}
  window.__lookBack=g=>{
    if(!g.pl||g.hs===g.as)return '';
    const win=g.hs>g.as?'h':'a',wn=NAMES[win==='h'?g.home:g.away]||'',ln=NAMES[win==='h'?g.away:g.home]||'';
    const rows=leanOf(g).map(r=>({n:r[0],a:r[1],b:r[2]}));
    const dc=(cpm(g,'a')?1:0)-(cpm(g,'h')?1:0);rows.push({n:'Coach personal day matches the day of the month',a:cpm(g,'a')?1:0,b:cpm(g,'h')?1:0});
    let hit=0,miss=0,none=0;
    const tr=rows.map(r=>{const side=r.a>r.b?'a':r.b>r.a?'h':null;let res='no lean';if(side){if(side===win){hit++;res='<b class="w">pointed to the winner</b>'}else{miss++;res='pointed to the loser'}}else none++;
      return `<tr><td>${r.n}</td><td class="mono">${r.a}</td><td class="mono">${r.b}</td><td>${side?esc(NAMES[side==='a'?g.away:g.home]||''):'–'}</td><td>${res}</td></tr>`}).join('');
    const w=win==='h'?g.hs:g.as,l=win==='h'?g.as:g.hs,tot=g.hs+g.as,dn=g.dn;
    const sc=[[`${NAMES[g.away]||g.away} ${g.as}`,rootOf(g.as)],[`${NAMES[g.home]||g.home} ${g.hs}`,rootOf(g.hs)],['Total points '+tot,rootOf(tot)],['Margin '+(w-l),rootOf(w-l)]];
    const scr=sc.map(([lab,r0])=>`<span class="nchip ${r0===dn?'fav':'neutral'}">${esc(lab)} <b>${r0}${r0===dn?' ★':''}</b></span>`).join('');
    return `<div class="scsec">Looking back: what lined up with the result</div>
      <p class="note" style="margin-top:6px"><b>${esc(wn)}</b> beat ${esc(ln)} ${w}–${l}. Of the ${hit+miss} factors that leaned either way, <b>${hit}</b> pointed to ${esc(wn)} and ${miss} to ${esc(ln)}; ${none} had no lean. This is a look back, made after the score was known.</p>
      <div class="tablebox"><table><thead><tr><th>Factor</th><th>${esc(g.away)}</th><th>${esc(g.home)}</th><th>Leaned to</th><th>Result</th></tr></thead><tbody>${tr}</tbody></table></div>
      <h4 style="margin:12px 0 4px">Numbers in the final score</h4><div class="nchips l">${scr}</div>
      <p class="note">★ marks a score number that reduces to this game's day number (${dn}). Scores only exist after the game, so this can describe a result but cannot predict one.</p>`};
  function drawScore(){
    const played=UP.filter(g=>g.pl&&g.hs!==g.as),T={},order=[],cons=[0,0,0],X={};let homeW=0,srH=0,srN=0;
    played.forEach(g=>{const win=g.hs>g.as?'h':'a';if(win==='h')homeW++;let va=0,vb=0;const mg=g.as-g.hs;
      const wsc=win==='h'?g.hs:g.as;srN++;if(rootOf(wsc)===g.dn)srH++;
      const rows=leanOf(g).map(r=>[r[0],r[1],r[2]]);rows.push(['Coach personal day matches the day of the month',cpm(g,'a')?1:0,cpm(g,'h')?1:0]);
      rows.forEach(r=>{const n=r[0];if(!T[n]){T[n]=[0,0,0];order.push(n);X[n]=[[],[]]}X[n][0].push(r[1]-r[2]);X[n][1].push(mg);
        if(r[1]===r[2]){T[n][2]++;return}const side=r[1]>r[2]?'a':'h';if(side===win)T[n][0]++;else T[n][1]++;if(n!=='Coach personal day matches the day of the month'){if(side==='a')va++;else vb++}});
      if(va===vb)cons[2]++;else if((va>vb?'a':'h')===win)cons[0]++;else cons[1]++});
    const row=(n,c,pr)=>{const call=c[0]+c[1];return `<tr><td><b>${n}</b></td><td class="mono">${call}</td><td class="mono w">${c[0]}</td><td class="mono">${call?c[1]:'–'}</td><td class="mono">${call?Math.round(c[0]/call*100)+'%':'–'}</td><td class="mono">${call?(binP(c[0],call)*100).toFixed(0)+'%':'–'}</td><td class="mono">${pr?(pr.r>=0?'+':'−')+Math.abs(pr.r).toFixed(2)+' (luck '+Math.round(pr.p*100)+'%)':'–'}</td></tr>`};
    $('btscoretb').innerHTML=order.map(n=>row(n,T[n],pearson(X[n][0],X[n][1]))).join('')+`<tr class="tot"><td><b>Majority of the traditions</b></td>${row('',cons).replace(/^<tr><td><b><\/b><\/td>/,'').replace(/<\/tr>$/,'')}</tr>`;
    $('btscorecount').textContent=`${played.length} finished games`;
    $('btscorenote').textContent=`For comparison, the home team won ${homeW} of ${played.length} (${Math.round(homeW/played.length*100)}%). A tradition that calls games at random lands near 50% and a link (r) near 0. The last two columns each say how often chance alone would do this well or badly; with ten rows tested at once, one or two will look good or bad by luck. r is the straight-line link between how many more indications the away side had and how much better the away team did on the scoreboard (+1 would be a perfect match, 0 none). The winning team's score reduced to the game's day number in ${srH} of ${srN} games (${Math.round(srH/srN*100)}%); chance alone gives roughly 11%.`;
  }
  (function chunk(i,list){const step=8;for(let k=0;k<step&&i<list.length;k++,i++)leanOf(list[i]);if(i<list.length)setTimeout(()=>chunk(i,list),0);else drawScore()})(0,UP.filter(g=>g.pl));
'''
bj=bj.rstrip()
assert bj.endswith("})();")
bj=bj[:-len("})();")]+score_js+"})();\n"

# ================= names instead of generic words + zodiac tally by links =================

# scorecard sections
bj=once(bj,"h+=sec('Team')+srow('team name number',A.items.tname,B.items.tname)+srow('team life path (founding date)',A.items.tlp,B.items.tlp)+srow('team personal day',A.items.tpd,B.items.tpd);",
 "h+=sec(esc(A.team)+' vs '+esc(B.team))+srow('name number',A.items.tname,B.items.tname)+srow('life path (founding date)',A.items.tlp,B.items.tlp)+srow('personal day',A.items.tpd,B.items.tpd);")
bj=once(bj,"h+=sec('Starting quarterback')+textrow('starting QB',A.qb?esc(A.qb.name):'–',B.qb?esc(B.qb.name):'–')","h+=sec(esc(A.qb?A.qb.name:'–')+' vs '+esc(B.qb?B.qb.name:'–'))")
bj=once(bj,"h+=sec('Head coach')+textrow('head coach',esc(A.coach),esc(B.coach))+srow('life path'","h+=sec(esc(A.coach)+' vs '+esc(B.coach))+srow('life path'")
# Chaldean
bj=once(bj,"sec('Names, read in the Chaldean table')+srow('team name',A.it.cteam,B.it.cteam)+textrow('starting QB',A.qb?esc(A.qb.legal||A.qb.n):'–',B.qb?esc(B.qb.legal||B.qb.n):'–')+srow('QB name',A.it.cqb,B.it.cqb)+textrow('head coach',esc(A.co.name),esc(B.co.name))+srow('coach name',A.it.cco,B.it.cco)",
 "sec(esc(A.team)+' vs '+esc(B.team))+srow('name in the Chaldean table',A.it.cteam,B.it.cteam)+sec(esc(A.qb?(A.qb.legal||A.qb.n):'–')+' vs '+esc(B.qb?(B.qb.legal||B.qb.n):'–'))+srow('name in the Chaldean table',A.it.cqb,B.it.cqb)+sec(esc(A.co.name)+' vs '+esc(B.co.name))+srow('name in the Chaldean table',A.it.cco,B.it.cco)")
# Indian
bj=once(bj,"sec('Quarterback')+textrow('starting QB',A.qb?esc(A.qb.n):'–',B.qb?esc(B.qb.n):'–')+srow('Moolank (psychic)',A.it.iqm","sec(esc(A.qb?A.qb.n:'–')+' vs '+esc(B.qb?B.qb.n:'–'))+srow('Moolank (psychic)',A.it.iqm")
bj=once(bj,"sec('Head coach')+textrow('head coach',esc(A.co.name),esc(B.co.name))+srow('Moolank (psychic)',A.it.icm","sec(esc(A.co.name)+' vs '+esc(B.co.name))+srow('Moolank (psychic)',A.it.icm")
bj=once(bj,"sec('Franchise founding date')+","sec(esc(A.team)+' vs '+esc(B.team)+', founding dates')+")
# Gematria
bj=once(bj,"sec('Team names')+","sec(esc(A.team)+' vs '+esc(B.team))+")
bj=once(bj,"sec('Starting quarterbacks')+textrow('starting QB',A.qb?esc(A.qb.n):'–',B.qb?esc(B.qb.n):'–')+","sec(esc(A.qb?A.qb.n:'–')+' vs '+esc(B.qb?B.qb.n:'–'))+")
bj=once(bj,"sec('Head coaches')+textrow('head coach',esc(A.co.name),esc(B.co.name))+","sec(esc(A.co.name)+' vs '+esc(B.co.name))+")
bj=once(bj,'<div class="lab">starting QB jersey</div>','<div class="lab">${esc(A.qb?A.qb.n:\'–\')} / ${esc(B.qb?B.qb.n:\'–\')} jerseys</div>')
# zodiac: names on tags, rows grouped under names, tally by links
bj=once(bj,"addO(S.items.tY&&S.items.tY.a,tm+' team');addO(S.items.qY&&S.items.qY.a,tm+' QB');addO(S.items.cY&&S.items.cY.a,tm+' coach')","addO(S.items.tY&&S.items.tY.a,NAMES[tm]||tm);addO(S.items.qY&&S.items.qY.a,S.qbn||'QB');addO(S.items.cY&&S.items.cY.a,S.con||'coach')")
bj=once(bj,"return {team:tn,items,fav,bad};","return {team:tn,items,fav,bad,qbn:qb?qb.n:'',con:co.name};")
bj=once(bj,"let fav=0,bad=0;Object.values(items).forEach(i=>{if(i.r){if(i.r.k==='fav')fav++;if(i.r.k==='own')fav+=2;if(i.r.k==='enemy')bad++}});",
 "let fav=0,bad=0;Object.values(items).forEach(i=>{if(!i.r)return;if(i.r.good){fav+=i.r.good.length;bad+=i.r.bad.length;if(i.r.k==='own')fav+=2}else{if(i.r.k==='fav')fav++;if(i.r.k==='enemy')bad++}});")
bj=once(bj,"h+=zrow('team · game year',SA.items.tY,SB.items.tY)+zrow('team · game day',SA.items.tD,SB.items.tD)\n      +zrow('QB · game year',SA.items.qY,SB.items.qY)+zrow('QB · game day',SA.items.qD,SB.items.qD)+zrow('QB · element',SA.items.qE,SB.items.qE)\n      +zrow('coach · game year',SA.items.cY,SB.items.cY)+zrow('coach · game day',SA.items.cD,SB.items.cD)+zrow('coach · element',SA.items.cE,SB.items.cE);",
 "h+=sec(esc(SA.team)+' vs '+esc(SB.team))+zrow('game year',SA.items.tY,SB.items.tY)+zrow('game day',SA.items.tD,SB.items.tD)\n      +sec(esc(SA.qbn||'–')+' vs '+esc(SB.qbn||'–'))+zrow('game year',SA.items.qY,SB.items.qY)+zrow('game day',SA.items.qD,SB.items.qD)+zrow('element',SA.items.qE,SB.items.qE)\n      +sec(esc(SA.con)+' vs '+esc(SB.con))+zrow('game year',SA.items.cY,SB.items.cY)+zrow('game day',SA.items.cD,SB.items.cD)+zrow('element',SA.items.cE,SB.items.cE);")
bj=once(bj,"✓ friendly · ${SA.bad} ✗ enemy","✓ friendly links · ${SA.bad} ✗ enemy links")
bj=once(bj,"✓ friendly · ${SB.bad} ✗ enemy","✓ friendly links · ${SB.bad} ✗ enemy links")
bj=once(bj,"  window.__zodCheck=","  window.__zrel=zrel;window.__ZT={ZAN,ZTRINE,ZHARMONY,ZCLASH,ZHARM,ZBREAK,ZPUN};\n  window.__zodCheck=")

bj=once(bj,"const add=(label,v,note)=>{if(v==null)return;const r=red9(v);out.push({label,v,r,note:note||''})};",
 "const lastN=x=>String(x||'').trim().replace(/\\s+(Jr\\.?|Sr\\.?|II|III|IV|V)$/i,'').split(/\\s+/).slice(-1)[0],qbo=menFor(team,g).find(m=>m.pos==='QB'),pn={team:(TI[team]&&TI[team].nick)||team,QB:qbo?lastN(qbo.n):'QB',coach:lastN((BT.coaches[team]||{}).name)||'coach'};\n    const add=(label,v,note)=>{if(v==null)return;label=label.replace(/^(team|QB|coach) /,(m0,w)=>pn[w]+' ');const r=red9(v);out.push({label,v,r,note:note||''})};")

bj=once(bj,"      ${scorecard(g)}","      ${scorecard(g)}\n      ${g.pl&&window.__lookBack?'<div class=\"scorecard\" style=\"margin-top:14px\">'+window.__lookBack(g)+'</div>':''}")
bj=once(bj,"<h2>Side by side: team, quarterback and coach</h2>","<h2>Side by side: ${esc(A.team)} at ${esc(B.team)}</h2>")
