import csv, json, sys

MASTER = {11, 22, 33}
def red(n, keep=True):
    while n > 9 and not (keep and n in MASTER):
        n = sum(int(d) for d in str(n))
    return n
def digsum(s): return sum(int(c) for c in s)
def date_number(y, m, d):  # same method as life path
    return red(red(m) + red(d) + red(digsum(str(y))))
def personal_year(bm, bd, y): return red(red(bm) + red(bd) + red(digsum(str(y))))
def personal_month(py, m): return red(py + red(m))
def personal_day(pm, d): return red(pm + red(d))

COACHES = {  # team: (name, birth date, source)
 "ARI": ("Jonathan Gannon", "1983-01-04"), "ATL": ("Raheem Morris", "1976-09-03"),
 "BAL": ("Jesse Minter", "1983-05-09"), "BUF": ("Sean McDermott", "1974-03-21"),
 "CAR": ("Dave Canales", "1981-05-07"), "CHI": ("Ben Johnson", "1986-05-11"),
 "CIN": ("Zac Taylor", "1983-05-10"), "CLE": ("Todd Monken", "1966-02-05"),
 "DAL": ("Brian Schottenheimer", "1973-10-16"), "DEN": ("Sean Payton", "1963-12-29"),
 "DET": ("Dan Campbell", "1976-04-13"), "GB": ("Matt LaFleur", "1979-11-03"),
 "HOU": ("DeMeco Ryans", "1984-07-28"), "IND": ("Shane Steichen", "1985-05-11"),
 "JAX": ("Liam Coen", "1985-11-08"), "KC": ("Andy Reid", "1958-03-19"),
 "LA": ("Sean McVay", "1986-01-24"), "LAC": ("Jim Harbaugh", "1963-12-23"),
 "LV": ("Klint Kubiak", "1987-02-17"), "MIA": ("Jeff Hafley", "1979-04-04"),
 "MIN": ("Kevin O'Connell", "1985-05-25"), "NE": ("Mike Vrabel", "1975-08-14"),
 "NO": ("Kellen Moore", "1988-07-05"), "NYG": ("John Harbaugh", "1962-09-23"),
 "NYJ": ("Aaron Glenn", "1972-07-16"), "PHI": ("Nick Sirianni", "1981-06-15"),
 "PIT": ("Mike McCarthy", "1963-11-10"), "SEA": ("Mike Macdonald", "1987-06-26"),
 "SF": ("Kyle Shanahan", "1979-12-14"), "TB": ("Todd Bowles", "1963-11-18"),
 "TEN": ("Robert Saleh", "1979-01-31"), "WAS": ("Dan Quinn", "1970-09-11"),
}
def life_path(b):
    y, m, d = b.split("-"); return date_number(y, int(m), int(d))

src, outdir = sys.argv[1], sys.argv[2]
games = [r for r in csv.DictReader(open(src, newline="")) if r["season"] == "2026"]
coach_rows = []
for t, (n, b) in sorted(COACHES.items()):
    coach_rows.append({"team": t, "coach": n, "birth_date": b, "life_path": life_path(b)})

out = []
for g in games:
    y, m, d = g["gameday"].split("-"); Y, M, D = int(y), int(m), int(d)
    uy = red(digsum(y)); um = red(uy + red(M)); ud = date_number(y, M, D)
    played = g["home_score"] != "" and g["away_score"] != ""
    row = {"game_id": g["game_id"], "week": g["week"], "date": g["gameday"], "weekday": g["weekday"],
           "kickoff_et": g["gametime"], "away": g["away_team"], "home": g["home_team"],
           "away_score": g["away_score"], "home_score": g["home_score"], "played": played,
           "universal_year": uy, "universal_month": um, "universal_day": ud, "day_of_month_number": red(D)}
    if played:
        a, h = int(g["away_score"]), int(g["home_score"])
        row["winner"] = "TIE" if a == h else (g["home_team"] if h > a else g["away_team"])
    else:
        row["winner"] = ""
    for side in ("away", "home"):
        t = g[f"{side}_team"]; n, b = COACHES[t]
        _, bm, bd = b.split("-")
        py = personal_year(int(bm), int(bd), Y); pm = personal_month(py, M); pd = personal_day(pm, D)
        row[f"{side}_coach"] = n
        row[f"{side}_coach_life_path"] = life_path(b)
        row[f"{side}_coach_personal_day"] = pd
    out.append(row)

with open(f"{outdir}/nfl_2026_games_numerology.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(out[0].keys())); w.writeheader(); w.writerows(out)
with open(f"{outdir}/nfl_2026_coaches.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(coach_rows[0].keys())); w.writeheader(); w.writerows(coach_rows)
json.dump({"games": out, "coaches": coach_rows}, open(f"{outdir}/step2.json", "w"))

done = [r for r in out if r["played"]]
print("games", len(out), "played", len(done))
print("today:", [(r["away"], r["away_score"], r["home"], r["home_score"]) for r in out if r["date"] == "2026-10-18"])
print("universal days seen:", sorted({r["universal_day"] for r in done}))
print("sample:", done[0])
print("coach LPs:", [(c["coach"], c["life_path"]) for c in coach_rows])
