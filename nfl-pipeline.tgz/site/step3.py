"""Step 3: correlate numerology with wins, testing every pattern against shuffled outcomes."""
import csv, json, random, sys, collections

MASTER = {11, 22, 33}
ORDER = [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 22, 33]
def red(n):
    while n > 9 and n not in MASTER:
        n = sum(int(d) for d in str(n))
    return n
def lifep(b):
    y, m, d = b.split("-"); return red(red(int(m)) + red(int(d)) + red(sum(map(int, y))))
def pday(b, date):
    _, bm, bd = b.split("-"); y, m, d = date.split("-")
    py = red(red(int(bm)) + red(int(bd)) + red(sum(map(int, y))))
    return red(red(py + red(int(m))) + red(int(d)))

roster_csv, snaps_csv, step2_json, outdir = sys.argv[1:5]
# Founding dates as listed in each franchise's Wikipedia infobox. ARI and DET list a year only.
FOUNDED = {
 "ARI": None, "ATL": "1965-06-30", "BAL": "1996-02-09", "BUF": "1959-10-28", "CAR": "1993-10-26",
 "CHI": "1920-09-17", "CIN": "1967-05-23", "CLE": "1944-06-04", "DAL": "1960-01-28", "DEN": "1959-08-14",
 "DET": None, "GB": "1919-08-11", "HOU": "1999-10-06", "IND": "1953-01-23", "JAX": "1993-11-30",
 "KC": "1959-08-14", "LA": "1937-02-12", "LAC": "1959-08-14", "LV": "1960-01-30", "MIA": "1965-08-16",
 "MIN": "1960-01-28", "NE": "1959-11-16", "NO": "1966-11-01", "NYG": "1925-08-01", "NYJ": "1959-08-14",
 "PHI": "1933-07-08", "PIT": "1933-07-08", "SEA": "1974-06-04", "SF": "1944-06-04", "TB": "1974-04-24",
 "TEN": "1959-08-14", "WAS": "1932-07-09",
}
FOUND_YEAR_ONLY = {"ARI": "1898", "DET": "1928"}
# birthdates by pfr id, from every roster row (includes players cut since they played)
import re
def norm(n):
    n = re.sub(r"[^a-z ]", "", n.lower().replace("-", " "))
    return " ".join(w for w in n.split() if w not in {"jr", "sr", "ii", "iii", "iv", "v"})
bd, by_name_team, by_name = {}, {}, collections.defaultdict(set)
for r in csv.DictReader(open(roster_csv, newline="", encoding="utf-8")):
    if not r["birth_date"]: continue
    if r["pfr_id"]: bd[r["pfr_id"]] = r["birth_date"]
    by_name_team[(norm(r["full_name"]), r["team"])] = r["birth_date"]
    by_name[norm(r["full_name"])].add(r["birth_date"])
def lookup(r):
    if r["pfr_player_id"] in bd: return bd[r["pfr_player_id"]]
    k = norm(r["player"])
    if (k, r["team"]) in by_name_team: return by_name_team[(k, r["team"])]
    if len(by_name.get(k, ())) == 1: return next(iter(by_name[k]))
    return None
S = json.load(open(step2_json))
games = {g["game_id"]: g for g in S["games"] if g["played"] and g["winner"] != "TIE"}
coach_bd = {c["team"]: c["birth_date"] for c in S["coaches"]}

# who played: any offensive, defensive or special teams snap
played = collections.defaultdict(list)   # (game, team) -> [(lp, pd)]
snap_rows = matched = 0
for r in csv.DictReader(open(snaps_csv, newline="", encoding="utf-8")):
    if r["game_id"] not in games: continue
    snaps = sum(float(r[k] or 0) for k in ("offense_snaps", "defense_snaps", "st_snaps"))
    if snaps <= 0: continue
    snap_rows += 1
    b = lookup(r)
    if not b: continue
    matched += 1
    date = games[r["game_id"]]["date"]
    played[(r["game_id"], r["team"])].append((lifep(b), pday(b, date)))

gids = sorted(g for g in games if (g, games[g]["home"]) in played and (g, games[g]["away"]) in played)
print(f"games analysed: {len(gids)}  player-appearances: {snap_rows}  with birthdate: {matched}")

# per team-game features
TG = []  # one entry per game: (dn, home_feats, away_feats, home_won)
for g in gids:
    G = games[g]; dn = G["universal_day"]; feats = {}
    for side in ("home", "away"):
        t = G[side]; ps = played[(g, t)]
        cb = coach_bd[t]
        feats[side] = {
            "team": t,
            "coach_pd": pday(cb, G["date"]), "coach_lp": lifep(cb),
            "team_lp": lifep(FOUNDED[t]) if FOUNDED[t] else None,
            "team_pd": pday(FOUNDED[t], G["date"]) if FOUNDED[t] else None,
            "lp_share": sum(1 for lp, _ in ps if lp == dn) / len(ps),
            "pd_share": sum(1 for _, pd in ps if pd == dn) / len(ps),
            "lps": [lp for lp, _ in ps],
        }
    TG.append((g, dn, feats["home"], feats["away"], G["winner"] == G["home"]))

# ---- statistics, each a function of the outcome vector (home_won per game) ----
def stat_coach(key, outcomes):
    """Games where exactly one coach's number matches the date number: how often that coach won."""
    w = n = 0
    for (g, dn, h, a, _), hw in zip(TG, outcomes):
        if h[key] is None or a[key] is None: continue
        hm, am = h[key] == dn, a[key] == dn
        if hm == am: continue
        n += 1; w += (hw if hm else not hw)
    return w, n
def stat_share(key, outcomes):
    """Games where one roster had more players matching the date number: how often that side won."""
    w = n = 0
    for (g, dn, h, a, _), hw in zip(TG, outcomes):
        if h[key] == a[key]: continue
        n += 1; w += (hw if h[key] > a[key] else not hw)
    return w, n
def grid(outcomes):
    """player appearances on the winning side, per (life path, date number)."""
    win = collections.Counter(); tot = collections.Counter()
    for (g, dn, h, a, _), hw in zip(TG, outcomes):
        for side, won in ((h, hw), (a, not hw)):
            for lp in side["lps"]:
                tot[(lp, dn)] += 1; win[(lp, dn)] += won
    return win, tot
def value_rates(outcomes, key="coach_pd"):
    w = collections.Counter(); n = collections.Counter()
    for (g, dn, h, a, _), hw in zip(TG, outcomes):
        for side, won in ((h, hw), (a, not hw)):
            if side[key] is None: continue
            n[side[key]] += 1; w[side[key]] += won
    return w, n
def coach_pd_value(outcomes): return value_rates(outcomes, "coach_pd")
def stat_team_coach(_, outcomes):
    """Games where exactly one team's founding life path equals its own head coach's life path."""
    w = n = 0
    for (g, dn, h, a, _), hw in zip(TG, outcomes):
        if h["team_lp"] is None or a["team_lp"] is None: continue
        hm, am = h["team_lp"] == h["coach_lp"], a["team_lp"] == a["coach_lp"]
        if hm == am: continue
        n += 1; w += (hw if hm else not hw)
    return w, n
def value_table(key):
    vw, vn = value_rates(actual, key); ge = collections.Counter()
    for s in sims[:SUB]:
        sw, sn = value_rates(s, key)
        for k in vn:
            if abs(sw[k] / sn[k] - 0.5) >= abs(vw[k] / vn[k] - 0.5) - 1e-12: ge[k] += 1
    return [{"v": k, "wins": vw[k], "games": vn[k], "p": (ge[k] + 1) / (SUB + 1)} for k in ORDER if vn[k]]

actual = [x[4] for x in TG]
random.seed(2026)
N = 10000
sims = [[random.random() < 0.5 for _ in TG] for _ in range(N)]

def perm_p(fn, key):
    w, n = fn(key, actual)
    rate = w / n if n else 0
    dev = abs(rate - 0.5)
    ge = 0
    for s in sims:
        sw, sn = fn(key, s)
        if sn and abs(sw / sn - 0.5) >= dev - 1e-12: ge += 1
    return {"wins": w, "games": n, "rate": rate, "p": (ge + 1) / (N + 1)}

tests = {
    "coach_lp_match": perm_p(stat_coach, "coach_lp"),
    "roster_lp_match": perm_p(stat_share, "lp_share"),
    "roster_pd_match": perm_p(stat_share, "pd_share"),
    "team_lp_match": perm_p(stat_coach, "team_lp"),
    "team_coach_match": perm_p(stat_team_coach, None),
}
for k, v in tests.items(): print(k, v)

# grid with per-cell permutation p-values (whole game flips together, so teammates move as a block)
gw, gt = grid(actual)
cells = [c for c in gt if gt[c] >= 40]
dev = {c: abs(gw[c] / gt[c] - 0.5) for c in cells}
ge = collections.Counter()
SUB = 4000
for s in sims[:SUB]:
    sw, st = grid(s)
    for c in cells:
        if abs(sw[c] / st[c] - 0.5) >= dev[c] - 1e-12: ge[c] += 1
grid_out = []
for c in sorted(gt):
    row = {"lp": c[0], "dn": c[1], "wins": gw[c], "apps": gt[c], "rate": gw[c] / gt[c]}
    if c in cells:
        row["p"] = (ge[c] + 1) / (SUB + 1)
    grid_out.append(row)
tested = [r for r in grid_out if "p" in r]
sig = [r for r in tested if r["p"] < 0.05]
print(f"grid cells tested: {len(tested)}  p<0.05: {len(sig)}  expected by chance: {0.05*len(tested):.1f}")
for r in sorted(sig, key=lambda r: r["p"]): print("  ", r)

pw, pn = coach_pd_value(actual)
pge = collections.Counter()
for s in sims[:SUB]:
    sw, sn = coach_pd_value(s)
    for k in pn:
        if abs(sw[k] / sn[k] - 0.5) >= abs(pw[k] / pn[k] - 0.5) - 1e-12: pge[k] += 1
coach_pd_rates = [{"pd": k, "wins": pw[k], "games": pn[k], "p": (pge[k] + 1) / (SUB + 1)} for k in ORDER if pn[k]]
print("coach personal day:", coach_pd_rates)
team_lp_rates = value_table("team_lp"); team_pd_rates = value_table("team_pd")
print("team founding LP:", team_lp_rates); print("team personal day:", team_pd_rates)
teams_info = [{"team": t, "founded": FOUNDED[t] or FOUND_YEAR_ONLY[t], "lp": lifep(FOUNDED[t]) if FOUNDED[t] else None}
              for t in sorted(FOUNDED)]

# per date number summary: games and home/away is irrelevant; list winners' coaches for display
dn_games = collections.Counter(x[1] for x in TG)

# team-level: each team's record by date number
team_dn = collections.defaultdict(lambda: [0, 0])
for g, dn, h, a, hw in TG:
    team_dn[(h["team"], dn)][0 if hw else 1] += 1
    team_dn[(a["team"], dn)][1 if hw else 0] += 1

result = {
    "meta": {"games": len(TG), "appearances": snap_rows, "matched": matched, "perms": N, "grid_perms": SUB,
             "first": games[gids[0]]["date"], "last": games[gids[-1]]["date"],
             "dn_games": dict(sorted(dn_games.items()))},
    "tests": tests, "grid": grid_out, "coach_pd_rates": coach_pd_rates,
    "team_lp_rates": team_lp_rates, "team_pd_rates": team_pd_rates, "teams": teams_info,
    "grid_summary": {"tested": len(tested), "sig": len(sig), "expected": 0.05 * len(tested)},
    "team_dn": [{"team": t, "dn": d, "w": v[0], "l": v[1]} for (t, d), v in sorted(team_dn.items())],
    "games": [{"game_id": g, "dn": dn,
               "home": h["team"], "away": a["team"], "home_won": hw,
               "home_coach_pd": h["coach_pd"], "away_coach_pd": a["coach_pd"],
               "home_lp_share": round(h["lp_share"], 3), "away_lp_share": round(a["lp_share"], 3)}
              for g, dn, h, a, hw in TG],
}
json.dump(result, open(f"{outdir}/step3.json", "w"))
with open(f"{outdir}/nfl_2026_lifepath_x_datenumber.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["life_path", "date_number", "appearances_on_winning_side", "total_appearances", "win_rate", "permutation_p"])
    for r in grid_out: w.writerow([r["lp"], r["dn"], r["wins"], r["apps"], round(r["rate"], 3), round(r["p"], 4) if "p" in r else ""])
