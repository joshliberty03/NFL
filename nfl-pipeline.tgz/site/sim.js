/* ===================== GAME SIMULATOR (inside Pick Your Wins) ===================== */
(function(){
  const host=document.getElementById('sandbox');if(!host)return;
  const R26=RK['2026'],R25=RK['2025']||{},TMS=Object.keys(R26);
  const mean=a=>a.reduce((x,y)=>x+y,0)/(a.length||1);
  const LG={ppg:mean(TMS.map(t=>R26[t].ppg)),py:mean(TMS.map(t=>R26[t].pypg)),ry:mean(TMS.map(t=>R26[t].rypg)),pya:mean(TMS.map(t=>R26[t].pypga)),rya:mean(TMS.map(t=>R26[t].rypga))};
  const SIMS=4000;
  const cl=(x,a,b)=>Math.max(a,Math.min(b,x));
  const rn=()=>{let u=0,v=0;while(!u)u=Math.random();while(!v)v=Math.random();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)};
  const pois=l=>{let L=Math.exp(-l),k=0,p=1;do{k++;p*=Math.random()}while(p>L&&k<30);return k-1};
  // blend this season with last season so early-season teams are not wild
  function eff(t,k){const a=R26[t],b=R25[t];if(!b||!a.g)return a[k];const w=a.g/(a.g+5);return a[k]*w+b[k]*(1-w)}
  const KEYI={cmp:0,att:1,pyd:2,ptd:3,int:4,car:9,ryd:10,rtd:11,tgt:15,rec:16,yds:17,td:18};
  const wkOf=g=>g.wk;
  // ---------- roster tables ----------
  const RO={};
  function roster(t){
    if(RO[t])return RO[t];
    const rows=PS['2026'].filter(r=>r[3]===t&&['QB','RB','WR','TE','K'].includes(r[2])&&r[5]>0);
    const out=rows.map(r=>{
      const s=r[8],g=r[5],pos=r[2];
      const wk=r[9]||{},ws=Object.keys(wk).map(Number).sort((a,b)=>a-b);
      const ppr=ws.map(w=>wk[w][2]||0),sea=ppr.length?mean(ppr):0,l3=ppr.slice(-3),form=l3.length?mean(l3):0;
      const recent=ws.slice(-3).length&&ws[ws.length-1]>=LASTWK-1;
      const trend=g>=4&&sea>0?form/sea:1;
      const p={id:r[0],n:r[1],pos,g,sea,form,trend,hot:g>=4&&recent&&trend>=1.35&&form>=8,cold:g>=4&&recent&&trend<=.65&&sea>=8,
        ydsPG:s[KEYI.yds]/g,recPG:s[KEYI.rec]/g,tgtPG:s[KEYI.tgt]/g,tdPG:s[KEYI.td]/g,
        rydPG:s[KEYI.ryd]/g,carPG:s[KEYI.car]/g,rtdPG:s[KEYI.rtd]/g,
        ypr:s[KEYI.rec]?s[KEYI.yds]/s[KEYI.rec]:10,ypc:s[KEYI.car]?s[KEYI.ryd]/s[KEYI.car]:4.2,
        att:s[KEYI.att],pyd:s[KEYI.pyd],ptd:s[KEYI.ptd],ints:s[KEYI.int],fgm:s[41]||0,fga:s[42]||0,
        szn:{py:s[KEYI.pyd]/g,ry:s[KEYI.ryd]/g,ry2:s[KEYI.yds]/g}};
      return p});
    RO[t]=out;return out;
  }
  const status=id=>{const x=INJ.p[id];return x?x[0]:null};
  const availP={Out:0,Doubtful:.25,Questionable:.85};
  const pprPG=p=>p.sea;
  function qbOf(t,O){const q=roster(t).filter(p=>p.pos==='QB').sort((a,b)=>b.att-a.att);return q.find(p=>(O[p.id]!=='out')&&status(p.id)!=='Out')||q[0]}
  // ---------- late-game profiles: comebacks, blown leads, fourth-quarter scoring ----------
  const PROF={},QBCB={};
  (function(){
    const fin=SEA.filter(g=>g.hs!=null&&GD[g.id]);
    const gm={};TMS.forEach(t=>gm[t]=[]);
    let q4s=0,q4n=0;
    fin.forEach(g=>{
      const d=GD[g.id],sum=a=>a.reduce((x,y)=>x+y,0);
      // running margin from the scoring plays: [..., home, away]
      let mh=0,ma=0;const ph=[0],pa=[0];
      (d.sp||[]).forEach(x=>{ph.push(x[x.length-2]);pa.push(x[x.length-1])});
      const maxH=Math.max(...ph.map((v,i)=>v-pa[i])),maxA=Math.max(...pa.map((v,i)=>v-ph[i]));
      const qb=side=>{const r=(d.pf&&d.pf[side]||[]).find(x=>x[0]==='Passing');return r?r[1]:null};
      [['h',g.h,g.hs,g.as,maxH,maxA],['a',g.a,g.as,g.hs,maxA,maxH]].forEach(([k,t,f,aq,lead,def])=>{
        if(!gm[t])return;
        const qq=(d.q&&d.q[k])||[],oq=(d.q&&d.q[k==='h'?'a':'h'])||[];
        gm[t].push({f,a:aq,win:f>aq,lead,def,q4f:qq[3]||0,q4a:oq[3]||0,qb:qb(k)});
        q4s+=qq[3]||0;q4n++;
        const n=qb(k);if(n){const e=QBCB[n]||(QBCB[n]={st:0,cb:0});e.st++;if(f>aq&&def>=7)e.cb++}
      });
    });
    LG.q4=q4n?q4s/q4n:5.4;
    const pts=[];TMS.forEach(t=>gm[t].forEach(x=>pts.push(x.f)));const mp=mean(pts),cvL=Math.sqrt(mean(pts.map(v=>(v-mp)*(v-mp))))/mp;
    LG.gv=mean(TMS.map(t=>R26[t].gv/Math.max(1,R26[t].g)));LG.tk=mean(TMS.map(t=>R26[t].tk/Math.max(1,R26[t].g)));
    TMS.forEach(t=>{
      const G=gm[t],n=G.length;
      const led10=G.filter(x=>x.lead>=10).length,blown=G.filter(x=>x.lead>=10&&!x.win).length;
      const tr10=G.filter(x=>x.def>=10).length,cb10=G.filter(x=>x.def>=10&&x.win).length;
      const q4f=n?mean(G.map(x=>x.q4f)):LG.q4,q4a=n?mean(G.map(x=>x.q4a)):LG.q4;
      const m=n?mean(G.map(x=>x.f)):mp,cv=n>1?Math.sqrt(mean(G.map(x=>(x.f-m)*(x.f-m))))/(m||1):cvL;
      const w=n/(n+6),cvS=cv*w+cvL*(1-w);
      PROF[t]={n,led10,blown,tr10,cb10,q4f,q4a,q4net:(q4f-q4a)*(n/(n+4)),
        rateCB:(cb10+.8)/(tr10+4),rateBL:(blown+.7)/(led10+4),
        q4aEx:((q4a*n+LG.q4*4)/(n+4)-LG.q4)/LG.q4,
        vol:cl(.1+(cvS-cvL)*.6,.07,.2),gv:R26[t].gv/Math.max(1,R26[t].g),tk:R26[t].tk/Math.max(1,R26[t].g)};
    });
  })();
  function profFor(t,O){
    const P=PROF[t]||{},qb=qbOf(t,O),e=qb&&QBCB[qb.n],qr=e?(e.cb+.5)/(e.st+4):.14;
    const cb=cl(.18+((P.rateCB||.2)-.2)*.5+(qr-.14)*.8+(P.q4net||0)*.015,.06,.5);
    const cl2=cl(.14+((P.rateBL||.17)-.17)*.7+(P.q4aEx||0)*.2,.05,.45);
    return {cb,cl:cl2,vol:P.vol||.12,gv:P.gv||LG.gv,tk:P.tk||LG.tk,qb,qbCb:e?e.cb:0,qbSt:e?e.st:0,P};
  }
  // ---------- team points ----------
  function teamPts(t,opp,home,O){
    const oF=eff(t,'ppg')/LG.ppg,dF=eff(opp,'papg')/LG.ppg;
    let m=LG.ppg*Math.pow(oF,.9)*Math.pow(dF,.9)*(home?1.03:.97);
    const sk=roster(t).filter(p=>p.pos!=='K'),tot=sk.reduce((a,p)=>a+pprPG(p),0)||1;
    let fr=0;
    sk.forEach(p=>{const st=O[p.id]==='out'?'Out':O[p.id]==='hot'?null:status(p.id);const f=st==='Out'?1:st==='Doubtful'?.75:st==='Questionable'?.15:0;
      fr+=f*(pprPG(p)/tot)*(p.pos==='QB'?.55:.4);if(O[p.id]==='hot')fr-=.04*(pprPG(p)/tot)*3});
    return m*(1-cl(fr,-.08,.4));
  }
  // ---------- one simulated game ----------
  function build(g,O){
    const A=g.a,H=g.h,mA=teamPts(A,H,false,O),mH=teamPts(H,A,true,O);
    return {g,A,H,m:{[A]:mA,[H]:mH},O,prof:{[A]:profFor(A,O),[H]:profFor(H,O)}};
  }
  function active(t,O){
    return roster(t).filter(p=>p.pos!=='K').map(p=>{
      const st=O[p.id]==='out'?'Out':O[p.id]==='hot'?null:status(p.id);
      let av=st?availP[st]??1:1;if(O[p.id]==='out')av=0;
      return {p,av}
    });
  }
  function simSide(ctx,t,opp,pre){
    const O=ctx.O,R=R26[t],Ro=R26[opp];
    let {pts,td,fg,sc,dr}=pre;
    // player lines
    const act=active(t,O);const pid={};
    const pyExp=eff(t,'pypg')*Math.pow(eff(opp,'pypga')/LG.pya,.8)*Math.sqrt(cl(ctx.m[t]*sc/eff(t,'ppg'),.4,2.2));
    const ryExp=eff(t,'rypg')*Math.pow(eff(opp,'rypga')/LG.rya,.8)*Math.pow(cl(ctx.m[t]*sc/eff(t,'ppg'),.4,2.2),.3);
    const py=Math.max(70,pyExp*Math.exp(rn()*.15)),ry=Math.max(25,ryExp*Math.exp(rn()*.2));
    const qb=qbOf(t,O);
    const bo={};
    act.forEach(({p,av})=>{
      const pb=.06+(p.hot?.16:0)+(O[p.id]==='hot'?.4:0);
      let f=Math.exp(rn()*.5-.06);
      if(Math.random()<pb)f*=1.5+Math.random()*.9;
      bo[p.id]=f*(Math.random()<av?1:0);
    });
    // receiving
    const rw=act.map(({p})=>({p,w:Math.max(0,p.ydsPG)*bo[p.id]})),rs=rw.reduce((a,x)=>a+x.w,0)||1;
    const L={};const line=p=>L[p.id]||(L[p.id]={p,py:0,pa:0,pc:0,ptd:0,int:0,rec:0,tgt:0,ry:0,car:0,rtd:0,rcy:0,rctd:0});
    rw.forEach(x=>{if(x.w<=0)return;const l=line(x.p);l.rcy=Math.round(py*x.w/rs);l.rec=Math.max(0,Math.round(l.rcy/Math.max(7,x.p.ypr)*(.9+Math.random()*.2)));l.tgt=Math.round(l.rec*1.5)+(l.rec?0:Math.random()<.4?1:0)});
    // rushing
    const cw=act.map(({p})=>({p,w:Math.max(0,p.rydPG)*bo[p.id]})),cs=cw.reduce((a,x)=>a+x.w,0)||1;
    cw.forEach(x=>{if(x.w<=0)return;const l=line(x.p);l.ry=Math.round(ry*x.w/cs);l.car=Math.max(l.ry>0?1:0,Math.round(l.ry/Math.max(3,x.p.ypc)*(.9+Math.random()*.2)))});
    // touchdowns
    const tdr=[];
    const ptdT=roster(t).reduce((a,p)=>a+p.ptd,0),rtdT=0;
    const rtdRaw=roster(t).reduce((a,p)=>a+(p.rtdPG*p.g),0);
    const pp=cl((ptdT+3)/(ptdT+rtdRaw+5),.35,.8);
    for(let i=0;i<td;i++){
      if(Math.random()<pp){
        const ws=act.map(({p})=>({p,w:(p.tdPG+.12*p.tgtPG/10+.01)*bo[p.id]})),s=ws.reduce((a,x)=>a+x.w,0);let r=Math.random()*s,pick=ws[0];for(const x of ws){r-=x.w;if(r<=0){pick=x;break}}
        if(pick&&pick.w>0){line(pick.p).rctd++;if(qb)line(qb).ptd++;tdr.push({k:'pass',p:pick.p})}else{if(qb)line(qb).ptd++;tdr.push({k:'pass',p:qb})}
      }else{
        const ws=act.map(({p})=>({p,w:(p.rtdPG+.04*p.carPG/10+.005)*bo[p.id]})),s=ws.reduce((a,x)=>a+x.w,0);let r=Math.random()*s,pick=ws[0];for(const x of ws){r-=x.w;if(r<=0){pick=x;break}}
        if(pick){line(pick.p).rtd++;tdr.push({k:'rush',p:pick.p})}
      }
    }
    if(qb){const l=line(qb);l.py=Math.round(py);l.pa=Math.max(8,Math.round(py/7.0));l.pc=Math.round(l.pa*cl(.64+(py-eff(t,'pypg'))/900,.5,.8));l.int=pois(l.pa*(qb.att?qb.ints/qb.att:.025)*(.9+.2*Math.random()))}
    const k=roster(t).find(p=>p.pos==='K');
    return {t,pts,td,fg,py:Math.round(py),ry:Math.round(ry),L,tdr,dr,qb,k,sc};
  }
  // ---------- the game itself, drive by drive, with lead/deficit effects ----------
  function driveSim(ctx){
    const A=ctx.A,H=ctx.H,P=ctx.prof,first=Math.random()<.5?A:H;
    const nd=Math.max(20,22+Math.round(rn()*1.4));
    const S={};[A,H].forEach(t=>S[t]={pts:0,td:0,fg:0,dr:[],q4:0,maxLead:0,maxDef:0,sc:Math.exp(rn()*P[t].vol)});
    const seq=[];let surge=null,lastTO=null;
    for(let i=0;i<nd;i++){
      const t=(i%2===0)?first:(first===A?H:A),o=t===A?H:A,q=Math.min(4,1+Math.floor(i/(nd/4)));
      const lead=S[t].pts-S[o].pts;
      let mu=ctx.m[t]*.975*S[t].sc/(nd/2);
      if(q>=3&&lead>0)mu*=1-(q===4?.045:.02)*Math.min(lead,21)/7;           // leaders run the clock
      if(q>=3&&lead<0){const d=Math.min(-lead,21);mu*=1+P[t].cb*(d/10)*(q===4?.85:.45)+P[o].cl*(d/10)*(q===4?.6:.3)} // trailing team pushes, leader may wobble
      if(lastTO===o)mu*=1.3;                                               // short field after a turnover
      if(q===4&&!surge&&lead<=-10&&Math.random()<.02+.12*P[t].cb+.1*P[o].cl){surge={t,d:-lead};seq.push({t,r:'SURGE',q,d:-lead})}
      if(surge)mu*=surge.t===t?2.0:.62;
      const pFG=Math.min(.13,mu/6),pTD=cl((mu-3*pFG)/6.95,.01,.55);
      const pTO=cl(.085*Math.pow(P[t].gv/LG.gv,.5)*Math.pow(P[o].tk/LG.tk,.5),.04,.2);
      const u=Math.random();let r;
      if(u<pTD){r='TD';S[t].td++;S[t].pts+=Math.random()<.94?7:6}
      else if(u<pTD+pFG){r='FG';S[t].fg++;S[t].pts+=3}
      else r=Math.random()<pTO/Math.max(.2,1-pTD-pFG)?'TO':'X';
      if(Math.random()<.008){S[t].pts+=2}
      const gain=S[t].pts-S[o].pts;S[t].maxLead=Math.max(S[t].maxLead,gain);S[o].maxDef=Math.max(S[o].maxDef,gain);
      S[t].maxDef=Math.max(S[t].maxDef,-gain);S[o].maxLead=Math.max(S[o].maxLead,-gain);
      if(q===4){S[t].q4+=S[t].pts-(S[t].last||0)}S[t].last=S[t].pts;
      S[t].dr.push(r);seq.push({t,r,q});lastTO=r==='TO'?t:null;
    }
    return {S,seq,surge};
  }
  function simGame(ctx,detail){
    const D=driveSim(ctx),a=simSide(ctx,ctx.A,ctx.H,D.S[ctx.A]),h=simSide(ctx,ctx.H,ctx.A,D.S[ctx.H]);
    if(a.pts===h.pts){ // overtime: one more score for whoever gets it first
      const aw=ctx.m[ctx.A]/(ctx.m[ctx.A]+ctx.m[ctx.H]);const win=Math.random()<aw?a:h;const f=Math.random()<.35?7:3;win.pts+=f;win.ot=f;if(Math.random()<.04){a.pts=h.pts=a.pts-(win===a?f:0)}
    }
    // late-game outcomes
    const wn=a.pts>h.pts?a:h.pts>a.pts?h:null,ls=wn?(wn===a?h:a):null,SA=D.S[ctx.A],SH=D.S[ctx.H];
    const W=wn&&(wn===a?SA:SH),Ls=ls&&(ls===a?SA:SH);
    const fl={cb10:!!(W&&W.maxDef>=10),cb14:!!(W&&W.maxDef>=14),blown10:!!(Ls&&Ls.maxLead>=10),surge:D.surge?D.surge.t:null,
      surgeWon:!!(D.surge&&wn&&wn.t===D.surge.t),win:wn?wn.t:null,q4:{[ctx.A]:SA.q4,[ctx.H]:SH.q4},maxDef:{[ctx.A]:SA.maxDef,[ctx.H]:SH.maxDef},maxLead:{[ctx.A]:SA.maxLead,[ctx.H]:SH.maxLead}};
    return {a,h,seq:D.seq,fl};
  }
  // ---------- many games ----------
  function runMany(ctx,n){
    const w={[ctx.A]:0,[ctx.H]:0,T:0},sumP={[ctx.A]:0,[ctx.H]:0},tot=[],mar=[];const sc={};
    const acc={};const LT={cb10:{[ctx.A]:0,[ctx.H]:0},blown:{[ctx.A]:0,[ctx.H]:0},surge:{[ctx.A]:0,[ctx.H]:0},surgeWon:{[ctx.A]:0,[ctx.H]:0},q4big:{[ctx.A]:0,[ctx.H]:0},cbGames:0,trail10:{[ctx.A]:0,[ctx.H]:0}};
    const bump=(side,l)=>{
      const k=l.p.id,e=acc[k]||(acc[k]={p:l.p,t:side.t,n:0,ry:0,rc:0,py:0,td:0,big:0,hun:0,tds:0,fy:0,q2:0});
      e.n++;e.ry+=l.ry;e.rc+=l.rcy;e.py+=l.py;e.td+=(l.ptd+l.rtd+l.rctd);e.fy+=l.rcy+l.ry;
      const anyTd=(l.rtd+l.rctd)>0;if(anyTd)e.tds++;
      if(l.p.pos==='QB'){if(l.py>=325||l.ptd>=4)e.big++;if(l.py>=300)e.hun++;if(l.ptd>=2)e.q2++}
      else{const base=l.p.szn.ry+l.p.szn.ry2;const y=l.ry+l.rcy;if(y>=Math.max(60,base*1.6))e.big++;if(l.ry>=100||l.rcy>=100)e.hun++}
    };
    const qbs={};
    for(let i=0;i<n;i++){
      const {a,h,fl}=simGame(ctx);
      if(fl.win){LT.cb10[fl.win]+=fl.cb10?1:0;const lz=fl.win===ctx.A?ctx.H:ctx.A;LT.blown[lz]+=fl.blown10?1:0;if(fl.cb10)LT.cbGames++}
      if(fl.surge){LT.surge[fl.surge]++;if(fl.surgeWon)LT.surgeWon[fl.surge]++}
      [ctx.A,ctx.H].forEach(t=>{const o=t===ctx.A?ctx.H:ctx.A;if(fl.q4[t]-fl.q4[o]>=14)LT.q4big[t]++;if(fl.maxDef[t]>=10)LT.trail10[t]++});
      if(a.pts>h.pts)w[ctx.A]++;else if(h.pts>a.pts)w[ctx.H]++;else w.T++;
      sumP[ctx.A]+=a.pts;sumP[ctx.H]+=h.pts;tot.push(a.pts+h.pts);mar.push(h.pts-a.pts);
      const key=a.pts+'-'+h.pts;sc[key]=(sc[key]||0)+1;
      [a,h].forEach(s=>{Object.values(s.L).forEach(l=>{if(l.p.pos!=='K')bump(s,l)})});
    }
    const tops=Object.entries(sc).sort((x,y)=>y[1]-x[1]).slice(0,3).map(([k,v])=>({k,p:v/n}));
    tot.sort((x,y)=>x-y);mar.sort((x,y)=>x-y);
    const hist={};for(let m=-28;m<=28;m+=4)hist[m]=0;mar.forEach(m=>{const b=cl(Math.round(m/4)*4,-28,28);hist[b]++});
    return {n,LT,w,avg:{[ctx.A]:sumP[ctx.A]/n,[ctx.H]:sumP[ctx.H]/n},tot:{med:tot[Math.floor(n/2)],avg:mean(tot)},mar:{med:mar[Math.floor(n/2)],avg:mean(mar)},tops,hist,acc};
  }
  // ---------- UI ----------
  const rem=SEA.filter(g=>g.hs==null);
  const card=document.createElement('div');card.className='card';card.id='simcard';
  host.parentNode.insertBefore(card,host);
  if(!rem.length){card.innerHTML='<div class="teamhead"><h2>Game simulator</h2></div><p class="note">The season is complete: no games left to simulate.</p>';return}
  const wks=[...new Set(rem.map(g=>g.wk))].sort((a,b)=>a-b);
  card.innerHTML=`<div class="teamhead"><h2>Game simulator</h2><span class="count" id="smeye"></span></div>
    <p class="note">Pick an upcoming game and the simulator plays it thousands of times using each team's scoring, defense, yards, injuries and recent player form. It also gives every player a chance at a breakout game. It is a stats-based estimate, not a promise.</p>
    <div class="filters"><label for="smwk">Week<select id="smwk">${wks.map(w=>`<option value="${w}">Week ${w}</option>`).join('')}</select></label>
      <label for="smgame">Game<select id="smgame"></select></label>
      <button class="btn solid" type="button" id="smrun">Simulate again</button><button class="btn" type="button" id="smplay">Play one game out</button></div>
    <div id="smout"></div><div id="smadj"></div><div id="smlog"></div>`;
  const q=id=>card.querySelector('#'+id);
  q('smeye').textContent=`${rem.length} upcoming games · ${SIMS.toLocaleString()} runs each`;
  const firstW=wks[0];q('smwk').value=String(firstW);
  const OVR={};let cur=null,timer=0;
  function fillGames(){
    const w=+q('smwk').value,gs=rem.filter(g=>g.wk===w).sort((a,b)=>etKick(a.d,a.t)-etKick(b.d,b.t));
    q('smgame').innerHTML=gs.map(g=>`<option value="${g.id}">${tname(g.a)} at ${tname(g.h)} · ${fmtDay(g.d)}</option>`).join('');
  }
  const gameById=id=>SEA.find(g=>g.id===id);
  const pc=x=>Math.round(x*100)+'%';
  function chip(p,t,O){
    const st=O[p.id]||'';const inj=INJS(p.id);
    return `<button type="button" class="smchip${st?' '+st:''}" data-p="${p.id}" aria-label="${esc(p.n)}: ${st||'normal'}"><b>${esc(p.n)}</b><span>${p.pos}${inj&&!st?' · '+(inj.s==='Questionable'?'Q':inj.s==='Doubtful'?'D':'OUT'):''}${st==='out'?' · OUT':st==='hot'?' · BOOSTED':''}${p.hot&&!st?' · hot':''}</span></button>`;
  }
  function run(){
    clearInterval(timer);q('smlog').innerHTML='';
    const g=gameById(q('smgame').value);if(!g)return;
    const O=OVR[g.id]||(OVR[g.id]={});
    const ctx=build(g,O);cur={g,ctx};
    const r=runMany(ctx,SIMS);cur.r=r;
    const A=g.a,H=g.h,pA=r.w[A]/r.n,pH=r.w[H]/r.n,tie=r.w.T/r.n;
    const cA=(TEAMCOL[A]||['#888'])[0],cH=(TEAMCOL[H]||['#888'])[0];
    const fav=pH>=pA?H:A,fp=Math.max(pA,pH);
    const mk=g.sp!=null&&g.sp!==0?`${g.sp>0?g.h:g.a} by ${Math.abs(g.sp)}`:g.sp===0?'pick-em':'no line';
    const simSpread=r.mar.avg;
    const hmax=Math.max(...Object.values(r.hist),1);
    const bars=Object.keys(r.hist).map(Number).sort((a,b)=>a-b).map(m=>`<i class="${m>0?'h':m<0?'a':'t'}" style="height:${Math.max(2,Math.round(r.hist[m]/hmax*100))}%" title="${m>0?tname(H)+' by ~'+m:m<0?tname(A)+' by ~'+(-m):'close'}: ${(r.hist[m]/r.n*100).toFixed(1)}%"></i>`).join('');
    const tn2=t=>TI[t].nick||tname(t);
    q('smout').innerHTML=`
      <div class="smhead"><div class="smt" style="--tc:${cA}">${tlogo(A,40)}<b>${esc(tn2(A))}</b><span>${trec(A)} · away</span></div><div class="smat">at</div><div class="smt" style="--tc:${cH}">${tlogo(H,40)}<b>${esc(tn2(H))}</b><span>${trec(H)} · home</span></div></div>
      <div class="smwin" role="img" aria-label="${tname(A)} ${pc(pA)}, ${tname(H)} ${pc(pH)}"><i style="width:${pA*100}%;background:${cA}"><b>${pc(pA)}</b></i><i style="width:${tie*100}%;background:#999"></i><i style="width:${pH*100}%;background:${cH}"><b>${pc(pH)}</b></i></div>
      <div class="pkstats">
        <div class="pkstat"><b>${esc(tname(fav))}</b><span>Wins ${pc(fp)} of runs</span></div>
        <div class="pkstat"><b>${r.avg[A].toFixed(1)} – ${r.avg[H].toFixed(1)}</b><span>Average score (${A} – ${H})</span></div>
        <div class="pkstat"><b>${r.tops[0]?r.tops[0].k:'–'}</b><span>Most common final (${r.tops[0]?pc(r.tops[0].p):''})</span></div>
        <div class="pkstat"><b>${r.tot.avg.toFixed(1)}</b><span>Average total points</span></div>
        <div class="pkstat"><b>${simSpread>=0?esc(H)+' by '+simSpread.toFixed(1):esc(A)+' by '+(-simSpread).toFixed(1)}</b><span>Sim margin (listed line: ${esc(mk)})</span></div>
      </div>
      <div class="smhist" aria-hidden="true">${bars}</div><div class="smhl"><span>${esc(tn2(A))} win bigger</span><span>close</span><span>${esc(tn2(H))} win bigger</span></div>
      ${late(g,ctx,r)}
      <div class="stgrid">${side(A,r)}${side(H,r)}</div>
      <p class="note">How it works: each team's expected points come from its scoring and its opponent's defense this season (blended with last season early on), a small home edge, and injury reports. Each simulated drive ends in a touchdown, field goal or nothing, then yards and scores are shared among players by their usage. Every player has a breakout chance, bigger if they have been hot over the last three games. "Big game" means 100+ yards (300+ for a QB), or yards at least 1.6 times their usual pace.</p>`;
    // adjust chips
    q('smadj').innerHTML=`<div class="teamhead"><h3 class="scwk">Change the lineup</h3><span class="note">Tap a player: once to boost, twice to sit them out, three times to reset.</span></div><div class="smadj">${[A,H].map(t=>`<div><h4 class="rkg">${esc(tn2(t))}</h4><div class="smchips">${roster(t).filter(p=>p.pos!=='K').sort((a,b)=>b.sea-a.sea).slice(0,9).map(p=>chip(p,t,O)).join('')}</div></div>`).join('')}</div>`;
  }
  function lvl(x,hi,mid){return x>=hi?'High':x>=mid?'Medium':'Low'}
  function late(g,ctx,r){
    const A=g.a,H=g.h,n=r.n,L=r.LT,tn2=t=>TI[t].nick||tname(t);
    const up=Math.min(r.w[A],r.w[H])/n,under=r.w[A]<r.w[H]?A:H;
    const prof=t=>{const p=ctx.prof[t],P=p.P||{},qb=p.qb;
      return `<div class="smprof"><h4 class="rkg">${tlogo(t,18)} ${esc(tn2(t))} · late-game profile</h4>
        <div class="smpills"><span class="smpill ${p.cb>=.3?'g':p.cb>=.2?'':'r'}">Comeback power: <b>${lvl(p.cb,.3,.2)}</b></span><span class="smpill ${p.cl>=.24?'r':p.cl>=.16?'':'g'}">Blown-lead risk: <b>${lvl(p.cl,.24,.16)}</b></span><span class="smpill">Swing: <b>${lvl(p.vol,.15,.11)}</b></span></div>
        <ul class="smfacts">
          <li>4th quarter: <b>${(P.q4f||0).toFixed(1)}</b> points for, <b>${(P.q4a||0).toFixed(1)}</b> against per game</li>
          <li>Led by 10+ and lost: <b>${P.blown||0}</b> of ${P.led10||0} games</li>
          <li>Trailed by 10+ and won: <b>${P.cb10||0}</b> of ${P.tr10||0} games</li>
          ${qb?`<li>${esc(qb.n)}: <b>${p.qbCb}</b> comeback win${p.qbCb===1?'':'s'} in ${p.qbSt} start${p.qbSt===1?'':'s'} this season</li>`:''}
        </ul></div>`};
    const row=t=>`<div class="pkstat"><b>${pc(L.cb10[t]/n)}</b><span>${esc(tn2(t))} win after trailing by 10+</span></div>`;
    const row2=t=>`<div class="pkstat"><b>${pc(L.blown[t]/n)}</b><span>${esc(tn2(t))} blow a 10+ lead</span></div>`;
    const row3=t=>`<div class="pkstat"><b>${(L.q4big[t]/n*100).toFixed(1)}%</b><span>${esc(tn2(t))} win Q4 by 14+</span></div>`;
    const sg=t=>L.surge[t]?`${(L.surge[t]/n*100).toFixed(1)}%`:'0%';
    return `<div class="teamhead"><h3 class="scwk">Upsets, comebacks and collapses</h3><span class="note">late-game swings across ${n.toLocaleString()} runs</span></div>
      <div class="pkstats"><div class="pkstat"><b>${pc(up)}</b><span>Upset chance: ${esc(tn2(under))} win</span></div>
        <div class="pkstat"><b>${pc(L.cbGames/n)}</b><span>Games won from 10+ down</span></div>
        ${row(A)}${row(H)}${row2(A)}${row2(H)}${row3(A)}${row3(H)}
        <div class="pkstat"><b>${sg(A)} · ${sg(H)}</b><span>4th-quarter surge games (${A} · ${H})</span></div></div>
      <div class="stgrid">${prof(A)}${prof(H)}</div>
      <p class="note">Why upsets happen here: every team has a swing level from how much its scoring bounces game to game, turnovers can give the other side a short field, leaders slow down late while trailing teams push harder, and teams with a quarterback who wins from behind (or a defense that has coughed up leads) shift those late odds. A "surge" is a fourth-quarter explosion by a team trailing by 10 or more: it scores far more while the leader stalls. Most surges still fall short, and the rare ones that win are the historic comebacks.</p>`;
  }
  function side(t,r){
    const arr=Object.values(r.acc).filter(e=>e.t===t&&e.n>=r.n*.2).map(e=>{
      const p=e.p,n=e.n,isQ=p.pos==='QB';
      const prj=isQ?`${Math.round(e.py/n)} pass${e.ry/n>=8?' · '+Math.round(e.ry/n)+' rush':''}`:`${p.pos==='RB'||e.ry/n>e.rc/n?Math.round(e.ry/n)+' rush · ':''}${Math.round(e.rc/n)} rec`;
      return {p,prj,td:isQ?e.q2/r.n:e.tds/r.n,tdq:0,big:e.big/r.n,hun:e.hun/r.n,fy:e.fy/n,isQ,key:isQ?e.py/n:e.fy/n}}).filter(x=>x.key>12);
    arr.sort((a,b)=>(b.big*1.0+b.td*.5+b.key/400)-(a.big+a.td*.5+a.key/400));
    const top=arr.slice(0,6);
    const rows=top.map(x=>{const p=x.p,inj=INJS(p.id);const tag=p.hot?'<span class="smtag hot">hot</span>':p.cold?'<span class="smtag cold">cold</span>':'';
      return `<tr><td><b>${esc(p.n)}</b> <span class="st">${p.pos}</span>${tag}${inj?` <span class="inj ${inj.s[0]}">${inj.s==='Questionable'?'Q':inj.s==='Doubtful'?'D':'OUT'}</span>`:''}</td><td>${x.prj}</td><td>${pc(x.td)}${x.isQ?' <span class="st">2+ pass TD</span>':''}</td><td><b>${pc(x.big)}</b></td></tr>`}).join('');
    return `<div><h4 class="rkg">${tlogo(t,18)} ${esc(TI[t].nick||tname(t))} · breakout watch</h4><div class="stwrap"><table class="sttbl"><thead><tr><th>Player</th><th>Average line</th><th>Scores a TD</th><th>Big game</th></tr></thead><tbody>${rows||'<tr><td colspan="4">No player data yet.</td></tr>'}</tbody></table></div></div>`;
  }
  // ---------- play one game ----------
  function playOut(){
    if(!cur)run();clearInterval(timer);
    const {g,ctx}=cur,A=g.a,H=g.h;
    const {a,h,seq}=simGame(ctx,true);
    const seqs=seq.map(e=>({s:e.t===A?a:h,r:e.r,q:e.q,d:e.d,t:e.t}));
    const tdq={[A]:a.tdr.slice(),[H]:h.tdr.slice()};const sc={[A]:0,[H]:0};
    const cN=t=>TI[t].nick||tname(t);
    const ylong=()=>Math.round(2+Math.pow(Math.random(),1.6)*48);
    const evs=seqs.map(({s,r,q,d},k)=>{
      const t=s.t;
      let txt='',pts=0;
      if(r==='SURGE')return {q,t,txt:'4TH QUARTER SURGE! '+tname(t)+' trail by '+d+' and the offense catches fire',pts:0,surge:true};
      if(r==='TD'){const x=tdq[t].shift();const y=x&&x.k==='rush'?Math.round(1+Math.pow(Math.random(),1.8)*30):ylong();
        const nm=x&&x.p?x.p.n:'the offense';
        txt=x&&x.k==='rush'?`${nm} runs it in from ${y} yards. TOUCHDOWN`:`${s.qb?s.qb.n:'QB'} hits ${nm} for ${y} yards. TOUCHDOWN`;pts=7;
      }else if(r==='FG'){const y=Math.round(22+Math.random()*30);txt=`${s.k?s.k.n:'Kicker'} kicks a ${y}-yard field goal`;pts=3}
      else if(r==='TO'){txt=Math.random()<.5?`${s.qb?s.qb.n:'QB'} is intercepted. Turnover`:'Fumble! Defense takes over'}
      else txt=['Drive stalls. Punt','Fourth down stopped','Sacked on third down. Punt','Three and out','Drive ends on downs'][Math.floor(Math.random()*5)];
      sc[t]+=pts;return {q,t,txt,pts,a:sc[A],h:sc[H]};
    });
    // make the displayed scoring match the simulated final exactly
    [a,h].forEach(s=>{const want=s.pts-(s.ot||0)-3*s.fg;let have=0;const mine=evs.filter(e=>e.t===s.t&&e.pts===7);
      let d=want-7*s.td;for(let j=0;d<0&&j<mine.length;j++,d++){mine[j].pts=6}
      if(d>0)evs.push({q:4,t:s.t,txt:d===2?'Safety! Two points':'Two-point conversion is good',pts:d});
      if(s.ot)evs.push({q:5,t:s.t,txt:'Overtime: wins it with '+(s.ot===7?'a touchdown':'a field goal'),pts:s.ot})});
    let ra=0,rh=0;evs.forEach(e=>{if(e.t===A)ra+=e.pts;else rh+=e.pts;e.a=ra;e.h=rh});
    const fa=ra,fh=rh;
    q('smlog').innerHTML=`<div class="teamhead"><h3 class="scwk">One simulated game</h3><span class="count" id="smstat">Kickoff</span></div><div class="smscore"><div><b id="smsa">0</b><span>${esc(cN(A))}</span></div><div><b id="smsh">0</b><span>${esc(cN(H))}</span></div></div><ol class="smdrv" id="smdrv"></ol><div id="smbox"></div>`;
    const ol=q('smdrv');let i=0;
    const fin=()=>{
      clearInterval(timer);q('smsa').textContent=fa;q('smsh').textContent=fh;
      const w=fa>fh?A:fh>fa?H:null;q('smstat').textContent=w?`FINAL · ${tname(w)} win${a.ot||h.ot?' (OT)':''}`:'FINAL · tie';
      const perf=side=>Object.values(side.L).filter(l=>l.p.pos!=='K'&&(l.py||l.ry||l.rcy)).sort((x,y)=>(y.py*.04+y.ry*.1+y.rcy*.1+(y.ptd+y.rtd+y.rctd)*6)-(x.py*.04+x.ry*.1+x.rcy*.1+(x.ptd+x.rtd+x.rctd)*6)).slice(0,5).map(l=>{
        const p=l.p,bits=[];if(l.py)bits.push(`${l.pc}/${l.pa}, ${l.py} yds${l.ptd?', '+l.ptd+' TD':''}${l.int?', '+l.int+' INT':''}`);if(l.ry>=5)bits.push(`${l.car} car, ${l.ry} yds${l.rtd?', '+l.rtd+' TD':''}`);if(l.rcy)bits.push(`${l.rec} rec, ${l.rcy} yds${l.rctd?', '+l.rctd+' TD':''}`);
        const hotp=p.hot&&p.pos!=='QB'&&(l.ry+l.rcy)>=100?' <span class="smtag hot">breakout</span>':'';
        return `<li><b>${esc(p.n)}</b> <span class="st">${p.pos}</span>${hotp}<br><span class="note">${bits.join(' · ')}</span></li>`}).join('');
      q('smbox').innerHTML=`<div class="stgrid"><div><h4 class="rkg">${tlogo(A,18)} ${esc(cN(A))}</h4><ul class="smperf">${perf(a)}</ul><p class="note">${a.py} pass + ${a.ry} rush yards</p></div><div><h4 class="rkg">${tlogo(H,18)} ${esc(cN(H))}</h4><ul class="smperf">${perf(h)}</ul><p class="note">${h.py} pass + ${h.ry} rush yards</p></div></div>`;
    };
    // normalise drive log so the last visible score equals the final
    timer=setInterval(()=>{
      if(i>=evs.length){fin();return}
      const e=evs[i++];const li=document.createElement('li');li.className=e.pts?'sc':e.surge?'surge':'';
      li.innerHTML=`<span class="smq">${e.q>4?'OT':'Q'+e.q}</span><span class="smtm" style="--tc:${(TEAMCOL[e.t]||['#888'])[0]}">${e.t}</span><span>${esc(e.txt)}</span>${e.pts?`<b>${e.a}–${e.h}</b>`:''}`;
      ol.appendChild(li);q('smsa').textContent=e.a;q('smsh').textContent=e.h;q('smstat').textContent=`${e.q>4?'OT':'Q'+e.q} · drive ${i} of ${evs.length}`;
      if(li.scrollIntoView&&0)li.scrollIntoView({block:'nearest'});
    },230);
  }
  q('smwk').addEventListener('input',()=>{fillGames();run()});
  q('smgame').addEventListener('input',run);
  q('smrun').addEventListener('click',run);
  q('smplay').addEventListener('click',playOut);
  q('smadj').addEventListener('click',e=>{const b=e.target.closest('[data-p]');if(!b||!cur)return;const O=OVR[cur.g.id],id=b.dataset.p;
    const nx={'':'hot',hot:'out',out:''}[O[id]||''];if(nx)O[id]=nx;else delete O[id];run()});
  fillGames();
  // simulate lazily the first time the tab is opened, then on demand
  let started=false;const go=()=>{if(started)return;started=true;try{run()}catch(e){q('smout').innerHTML='<p class="note">The simulator could not start: '+esc(String(e.message||e))+'</p>'}};
  window.__simGo=go;window.__simT={build,runMany,simGame,PROF,QBCB,profFor,get:()=>cur,SIMS};
  const sec=document.getElementById('picks');
  if(sec&&!sec.hidden)go();
  else{const mo=new MutationObserver(()=>{if(!sec.hidden){go();mo.disconnect()}});if(sec)mo.observe(sec,{attributes:true,attributeFilter:['hidden']})}
})();
