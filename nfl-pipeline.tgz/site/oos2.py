"""Add the numerology flagged cells to the same out-of-sample framework."""
import json, csv, math, datetime, collections, random, re
import ephem
from lunardate import LunarDate
MASTER={11,22,33}
def red(n):
    while n>9 and n not in MASTER: n=sum(int(d) for d in str(n))
    return n
def lifep(b):
    y,m,d=b.split("-"); return red(red(int(m))+red(int(d))+red(sum(map(int,y))))
def pdayv(b,date):
    _,bm,bd=b.split("-"); y,m,d=date.split("-")
    py=red(red(int(bm))+red(int(bd))+red(sum(map(int,y))))
    return red(red(py+red(int(m)))+red(int(d)))
def norm(n):
    n=re.sub(r"[^a-z ]","",n.lower().replace("-"," "))
    return " ".join(w for w in n.split() if w not in {"jr","sr","ii","iii","iv","v"})
GM={}
for r in csv.DictReader(open("/home/runner/nfl/games/games.csv")):
    if r["home_score"] and r["away_score"] and r["home_score"]!=r["away_score"]:
        GM[r["game_id"]]={"d":r["gameday"],"win":r["home_team"] if int(r["home_score"])>int(r["away_score"]) else r["away_team"]}
units=collections.defaultdict(dict)
for y in range(2013,2026):
    bd={}; nm={}
    for r in csv.DictReader(open(f"/home/runner/nfl/hist/roster_{y}.csv",encoding="utf-8")):
        if not r.get("birth_date"): continue
        if r.get("pfr_id"): bd[r["pfr_id"]]=r["birth_date"]
        nm[(norm(r["full_name"]),r["team"])]=r["birth_date"]; nm.setdefault(norm(r["full_name"]),r["birth_date"])
    for r in csv.DictReader(open(f"/home/runner/nfl/hist/snaps_{y}.csv",encoding="utf-8")):
        gid=r["game_id"]
        if gid not in GM: continue
        if sum(float(r[k] or 0) for k in ("offense_snaps","defense_snaps","st_snaps"))<=0: continue
        b=bd.get(r["pfr_player_id"]) or nm.get((norm(r["player"]),r["team"])) or nm.get(norm(r["player"]))
        if b: units[gid].setdefault(r["team"],[]).append(b)
good=[g for g,v in units.items() if len(v)==2 and all(len(x)>=20 for x in v.values())]
LPC={}
def lpc(b):
    if b not in LPC: LPC[b]=lifep(b)
    return LPC[b]
DNC={}
def dnc(d):
    if d not in DNC: DNC[d]=lifep(d)
    return DNC[d]
FLAG=[(5,5,"Life path 5 on date number 5",(100,162)),(2,6,"Life path 2 on date number 6",(34,52)),(5,4,"Life path 5 on date number 4",(81,139))]
random.seed(11); N=20000
print(f"{'pattern':34s} {'2026 (searched)':>18} {'2013-2025 out-of-sample':>26} {'p':>7}")
out=[]
for plp,dn,label,(iw,ina) in FLAG:
    w=n=0
    for gid in good:
        if dnc(GM[gid]["d"])!=dn: continue
        sh={t:sum(1 for b in bl if lpc(b)==plp)/len(bl) for t,bl in units[gid].items()}
        ts=list(sh)
        if sh[ts[0]]==sh[ts[1]]: continue
        more=ts[0] if sh[ts[0]]>sh[ts[1]] else ts[1]
        n+=1; w+=(GM[gid]["win"]==more)
    dev=abs(w/n-0.5); ge=sum(1 for _ in range(N) if abs(sum(random.random()<0.5 for _ in range(n))/n-0.5)>=dev-1e-12)
    p=(ge+1)/(N+1)
    # in-sample here was appearance-weighted; recompute the game-level 2026 figure for a fair comparison
    print(f"{label:34s} {format(iw/ina*100,'.0f')+'% of apps':>18} {str(w)+'-'+str(n-w)+' ('+format(w/n*100,'.1f')+'%)':>26} {round(p,3):>7}")
    out.append({"pattern":label,"oos_w":w,"oos_n":n,"oos_rate":w/n,"p":p})
json.dump(out,open("oos_numer.json","w"),separators=(",",":"))
print("games used:",len(good))
