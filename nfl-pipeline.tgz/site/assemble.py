import re, json
T=open('template2.html').read().split('\n')
L=lambda a,b:'\n'.join(T[a-1:b])           # 1-based inclusive
def once(s,a,b,cnt=1):
    assert s.count(a)==cnt,(s.count(a),a[:80]); return s.replace(a,b)

# ---------------- CSS ----------------
css=L(1,422)   # up to the line before </style>
css=re.sub(r'@media \(prefers-color-scheme: dark\)\{:root:not\(\[data-theme="light"\]\)\{\s*--bg.*?color-scheme:dark\}\}','',css,flags=re.S)
css=re.sub(r':root\[data-theme="dark"\]\{\s*--bg.*?color-scheme:dark\}','',css,flags=re.S)
css=css.replace('@media (prefers-color-scheme: dark){:root:not([data-theme="light"]) #betting{--accent:#e0ae5c;--accent-soft:#3a2e18}}\n','')
css=css.replace(':root[data-theme="dark"] #betting{--accent:#e0ae5c;--accent-soft:#3a2e18}\n','')
css=css.replace('@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--zl:72%}}\n','')
css=css.replace(':root[data-theme="dark"],:root[data-theme="football"]{--zl:72%}',':root[data-theme="football"]{--zl:72%}')
css=re.sub(r':root\[data-theme="football"\] #door-ledger::after,:root\[data-theme="football"\] #door-betting::after\{[^}]*\}\n','',css)
css=css.replace('<title>NFL Numbers Project</title>','<title>Tyler&#39;s NFL APP</title>')
css=css.replace('/* Layout: tabbed tool — Players (grouped by team, team chips to jump), Games (by week, date numbers + coach personal days), Coaches */','')
css=css.replace(':root[data-theme="football"]',':root')  # always the football look, whatever theme the host page sets
assert 'prefers-color-scheme' not in css and 'data-theme="dark"' not in css, [m.start() for m in re.finditer('prefers-color-scheme|data-theme="dark"',css)]
css+='\n'+open('new.css').read()
css=css.replace(':root[data-theme="football"]',':root')
head='<meta charset="utf-8">\n'+'\n'.join(T[1:4])  # title/meta/link lines 2-4
head=head.replace('<title>NFL Numbers Project</title>','<title>Tyler&#39;s NFL APP</title>')
head+='\n<style>\n'+css[css.index(':root{'):]+'\n</style>\n'

# ---------------- body ----------------
nav='''<div class="wrap">

<nav class="sitenav" aria-label="Site">
  <button class="brand" type="button" data-nav="home"><span class="mark">#</span><span class="btext">Betting by Numbers</span><span class="season">2026 Season</span></button>
  <button class="sharebtn" id="sharebtn" type="button" aria-haspopup="dialog" aria-expanded="false"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 16V4"/><path d="M7 9l5-5 5 5"/><path d="M5 14v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5"/></svg><span>Share</span></button>
  <button class="reportbtn" id="reportbtn" type="button" aria-haspopup="dialog"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 21V4"/><path d="M5 4h11l-2 4 2 4H5"/></svg><span>Report</span></button>
  <div class="navright">
  <div class="navbtns">
    <button class="navbtn" type="button" data-nav="home">Home</button>
    <button class="navbtn" type="button" data-nav="betting"><span class="lbl-l">Betting by Numbers</span><span class="lbl-s">Bets</span></button>
    <button class="navbtn" type="button" data-nav="picks"><span class="lbl-l">Pick Your Wins</span><span class="lbl-s">Picks</span></button>
    <button class="navbtn" type="button" data-nav="fantasy"><span class="lbl-l">Fantasy Football</span><span class="lbl-s">Fantasy</span></button>
    <button class="navbtn" type="button" data-nav="stats"><span class="lbl-l">Player Stats</span><span class="lbl-s">Stats</span></button>
    <button class="navbtn" type="button" data-nav="myteam"><span class="lbl-l">My Team</span><span class="lbl-s">My Team</span></button>
    <button class="navbtn" type="button" data-nav="standings"><span class="lbl-l">Standings</span><span class="lbl-s">Standings</span></button>
    <button class="navbtn" type="button" data-nav="ranks"><span class="lbl-l">Team Rankings</span><span class="lbl-s">Teams</span></button>
    <button class="navbtn" type="button" data-nav="scores"><span class="lbl-l">Schedule &amp; Scores</span><span class="lbl-s">Scores</span></button>
    <button class="navbtn" type="button" data-nav="draft"><span class="lbl-l">Draft</span><span class="lbl-s">Draft</span></button>
    <button class="navbtn" type="button" data-nav="history"><span class="lbl-l">All-Time Records</span><span class="lbl-s">Records</span></button>
    <button class="navbtn" type="button" data-nav="sbx"><span class="lbl-l">Super Bowl Echo</span><span class="lbl-s">Super Bowl</span></button>
    <button class="navbtn" type="button" data-nav="games"><span class="lbl-l">Game Room</span><span class="lbl-s">Games</span></button>
  </div>
  </div>
</nav>

<section class="screen hero" id="home">
  <i class="fbart fb-goal"></i><i class="fbart fb-ball"></i><i class="fbart fb-helmet"></i>
  <div>
    <div class="kicker">2026 NFL season</div>
    <h1>Betting by Numbers</h1>
    <p class="lede">Every game of the 2026 season read through numerology, plus a weekly pick sheet, an offline fantasy league, every player's stats and the team rankings. Each is its own page.</p>
    <p class="note" style="margin:0">Pick a page below, or use the bar at the top at any time.</p>
  </div>
  <div class="doors doors5">
    <button class="door b" type="button" data-nav="betting"><span class="num">Page one</span><h2>Betting by Numbers</h2><p>All 272 games by day number, with both sides' numbers, signs and moon laid out side by side.</p><span class="go">Open →</span></button>
    <button class="door" type="button" data-nav="picks"><span class="num">Page two</span><h2>Pick Your Wins</h2><p>Choose the winner of every game each week. Picks lock at kickoff and your history is saved.</p><span class="go">Open →</span></button>
    <button class="door" type="button" data-nav="fantasy"><span class="num">Page three</span><h2>Fantasy Football</h2><p>Draft and play a private league of up to six managers on one screen, scored with real stats.</p><span class="go">Open →</span></button>
    <button class="door" type="button" data-nav="stats"><span class="num">Page four</span><h2>Player Stats</h2><p>Every player on a roster, starter or not, with a full breakdown and game log.</p><span class="go">Open →</span></button>
    <button class="door" type="button" data-nav="myteam"><span class="num">Your page</span><h2>My Team</h2><p>Choose your team and get its record, schedule, stats, players, injuries and history in one place.</p><span class="go">Open →</span></button>
    <button class="door" type="button" data-nav="standings"><span class="num">Page five</span><h2>Standings</h2><p>Division, conference and league standings, the playoff picture and a what-if bracket.</p><span class="go">Open →</span></button>
    <button class="door" type="button" data-nav="ranks"><span class="num">Page five</span><h2>Team Rankings</h2><p>All 32 teams in every category for 2026 and 2025, including third downs and the red zone.</p><span class="go">Open →</span></button>
    <button class="door" type="button" data-nav="scores"><span class="num">Page six</span><h2>Schedule &amp; Scores</h2><p>Every game, week by week, with final scores and Eastern kickoff times.</p><span class="go">Open →</span></button>
    <button class="door" type="button" data-nav="draft"><span class="num">Page seven</span><h2>Draft Results</h2><p>Every pick from 2000 to 2026, filtered by team, position and round.</p><span class="go">Open →</span></button>
    <button class="door" type="button" data-nav="history"><span class="num">Page eight</span><h2>All-Time Records</h2><p>Player and team records, every Super Bowl, and the rivalries behind the league.</p><span class="go">Open →</span></button>
    <button class="door" type="button" data-nav="sbx"><span class="num">Page nine</span><h2>Super Bowl Echo</h2><p>The "20 years later" Super Bowl pattern: Eagles, Seahawks, Bears. The players, records, numbers and sky, other echoes, and an honest test.</p><span class="go">Open →</span></button>
    <button class="door" type="button" data-nav="games"><span class="num">Play</span><h2>Game Room</h2><p>Five football games: a retro head-to-head showdown, a field goal kicker, a QB throwing test and more.</p><span class="go">Open →</span></button>
  </div>
  <div class="card" id="bkcard"><div class="teamhead"><h2>Back up your picks and leagues</h2></div>
    <p class="note" id="bknote"></p>
    <div class="filters"><button class="btn" type="button" id="bkcopy">Copy backup</button><button class="btn" type="button" id="bkrestore">Restore from pasted backup</button></div>
    <textarea id="bkbox" rows="3" style="width:100%;margin-top:8px" placeholder="Paste a backup here to restore it" aria-label="Backup text"></textarea>
    <p class="note" id="bkmsg" aria-live="polite"></p></div>
  <p class="foot" id="homefoot"></p>
</section>
'''
bet=L(906,1150)
bet=once(bet,'<p class="sub">Only games still to be played, grouped by the day number of the date they fall on. Each game opens to both starting units with their life path and name numbers, and both head coaches\' life paths.</p>','<p class="sub">Every game of the season, grouped by the day number of the date it falls on. Each game opens to both sides\' numbers side by side. Games already played are shaded in the winner\'s color.</p>')
bet=once(bet,'''  <div class="callout">
    <b>Read this first</b>
    <p id="btwarn"></p>
  </div>''','''  <button class="readme" type="button" id="btreadme" aria-expanded="false" aria-controls="btreadpop">Read this first</button>
  <p class="readpop" id="btreadpop" hidden></p>
  <button class="readme" type="button" id="btguide" aria-expanded="false" aria-controls="btguidepop" style="margin-left:8px">How to read this</button>
  <div class="readpop" id="btguidepop" hidden><b>Worked examples</b>
  <p><b>Day number.</b> Add every digit of the date until one digit is left (a master number 11 or 22 stays as is). September 13, 2026 is 9+1+3+2+0+2+6 = 23, then 2+3 = <b>5</b>. Games are grouped by that number.</p>
  <p><b>Life path.</b> The same method on a birth date. Born June 4, 1990: 6+4+1+9+9+0 = 29, then 2+9 = 11, a master number, so the life path is <b>11</b>.</p>
  <p><b>Name number.</b> Each letter is worth a number (A=1, B=2 … I=9, J=1 … and so on around the alphabet); add them all and reduce. JOSH: 1+6+1+8 = 16, then 1+6 = <b>7</b>.</p>
  <p><b>Zodiac friends and enemies.</b> In the Chinese zodiac each animal has traditional friends (the three signs of its trine) and traditional enemies (signs that clash with it). The count shown is how many of the tradition's links connect the two units. More friend links read as favorable, more enemy links as unfavorable.</p>
  <p><b>How strong is a match?</b> Matching numbers or friendly signs only mean the tradition says "favorable". They have not been shown to predict who wins; the scoreboard card on each game shows how often each reading was right so far.</p></div>''')
bet=once(bet,'<option value="">All remaining weeks</option>','<option value="">All 18 weeks</option>')
bet=once(bet,'''      <label for="btteam">Team<select id="btteam">''','''      <label for="btshow">Games<select id="btshow"><option value="">All games</option><option value="played">Played</option><option value="open">Still to play</option></select></label>
      <label for="btteam">Team<select id="btteam">''')
bet=once(bet,'Tap any game to open the full number comparison between the two sides.','Tap any game to open the full number comparison between the two sides. Shaded games are final.')
bet=once(bet,'<p class="note">The 32 starting units as the depth charts stand, <span id="btasof"></span>.','<p class="note">The 32 starting units as the depth charts stand, <span id="btasof"></span>. These are the current units, used for every game on this page.')
# prose that referred to the old Part One
bet=re.sub(r"Part one of this site tested these ideas on 3,550 games and found nothing that beat a co","These ideas were tested on 3,550 games and found nothing that beat a co",bet)
bet=re.sub(r'\bPart one\b','Testing',bet)
mid=''  # ledger removed
tabs=open('tabs.html').read()+open('more.html').read()+open('sbx.html').read()+open('games.html').read()

# ---------------- script ----------------
glob=[]
for ln in T[1153:1180]:
    if re.match(r'const (NAMES|ORDER|TEAMS|\$|esc|lp|fill|red)[ =]',ln): glob.append(ln)
assert len(glob)>=8,len(glob)
glob=[('const BT=__BETTING__;')]+glob+[l for l in T[1300:1330] if l.startswith('const dsum=')]
tj=open('tabs.js').read();tj=tj[:tj.index('/* ===================== FANTASY FOOTBALL')]+open('fantasy.js').read()+open('more.js').read()+open('sim.js').read()+open('showdown.js').read()+open('games.js').read()+open('sbx.js').read()+open('report.js').read()
bj='\n'.join(T[1801:2417])   # betting IIFE (lines 1802..2417)
# betting edits
bj=once(bj,"""  $('bteyebrow').textContent=`2026 NFL season · ${UP.length} games still to play · weeks ${Math.min(...UP.map(g=>g.wk))}–${Math.max(...UP.map(g=>g.wk))} · depth charts as of ${new Date(BT.depth_as_of).toLocaleDateString('en-US',{month:'long',day:'numeric'})}`;""",
"""  $('bteyebrow').textContent=`2026 NFL season · ${UP.length} games · ${UP.filter(g=>g.pl).length} played, ${UP.filter(g=>!g.pl).length} to play · weeks 1–18 · depth charts as of ${new Date(BT.depth_as_of).toLocaleDateString('en-US',{month:'long',day:'numeric'})}`;""")
m=re.search(r"  \$\('btwarn'\)\.textContent='.*?';\n",bj,flags=re.S); assert m
bj=bj.replace(m.group(0),"""  $('btreadpop').textContent='These systems were tested on 3,550 games that the pattern search never saw, and none of them picked winners better than a coin flip. The one pattern that survived turned out to be a few strong rosters being credited to their birth dates. Nothing on this page is a forecast or a betting tip, and none of these numbers has been shown to predict a result. It is a reading sheet: the numbers for every game, laid out so you can see them for yourself.';
  $('btguide').addEventListener('click',()=>{const p=$('btguidepop'),o=p.hidden;p.hidden=!o;$('btguide').setAttribute('aria-expanded',String(o))});
  $('btreadme').addEventListener('click',()=>{const p=$('btreadpop'),o=p.hidden;p.hidden=!o;$('btreadme').setAttribute('aria-expanded',String(o))});
""")
bj=once(bj,"""    return UP.filter(g=>(!fdn||g.dn==fdn)&&(!fwk||g.wk==fwk)&&(!ft||g.home===ft||g.away===ft));""","""    const sh=$('btshow').value;
    return UP.filter(g=>(!fdn||g.dn==fdn)&&(!fwk||g.wk==fwk)&&(!ft||g.home===ft||g.away===ft)&&(!sh||(sh==='played'?g.pl:!g.pl)));""")
# pick buttons: winner wash, score, head-to-head
old_pick=bj[bj.index("    $('btpick').innerHTML=rows.map(g=>`<button class=\"pick\""):bj.index("    const g=rows.find(x=>x.id===chosen);")]
new_pick="""    $('btpick').innerHTML=rows.map(g=>{
      const win=g.pl?(g.hs>g.as?g.home:g.as>g.hs?g.away:null):null,hh=h2h(g.away,g.home);
      const wc=g.pl?(win?(TI[win]||{}).c1:'#8a8f94'):'';
      return `<button class="pick${g.pl?' done':''}" type="button" data-g="${g.id}" aria-pressed="${chosen===g.id}"${g.pl?` style="--wc:${wc}"`:''}>
      <span class="prow">${tlogo(g.away,22)}<span class="pteams">${g.away} <span class="st">at</span> ${g.home}</span>${tlogo(g.home,22)}</span>
      ${g.pl?`<span class="pscore"><b>${g.as}</b> – <b>${g.hs}</b> <span class="st">final</span></span>`:''}
      <span class="pwhen">${new Date(g.date+'T12:00:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'})} · wk ${g.wk}</span>
      <span class="pdn">Day number <b>${g.dn}</b></span>
      <span class="ph2h">Series ${g.away} ${hh.a}–${hh.b}${hh.t?'–'+hh.t:''} ${g.home}</span></button>`}).join('')||'<p class="note">No games match these filters.</p>';
"""
bj=bj.replace(old_pick,new_pick)
bj=once(bj,"['btdn','btwk','btteam','btnum'].forEach","['btdn','btwk','btteam','btnum','btshow'].forEach")
bj=once(bj,"UP.forEach(g=>{[g.home,g.away].forEach(t=>{if(!nextOf[t]||g.date<nextOf[t].date)nextOf[t]=g})});","UP.filter(g=>!g.pl).forEach(g=>{[g.home,g.away].forEach(t=>{if(!nextOf[t]||g.date<nextOf[t].date)nextOf[t]=g})});")
# detail header: final score + series bar
bj=once(bj,"""      <div class="vs" style="margin:10px 0 4px">""","""      ${(()=>{const hh=h2h(A,B),tot=hh.a+hh.b+hh.t||1;const ca=(TI[A]||{}).c1||'#888',cb=(TI[B]||{}).c1||'#444';
        const fin=g.pl?`<div class="finalline" style="text-align:center">${tlogo(A,30)} ${g.as} – ${g.hs} ${tlogo(B,30)} <span class="st">final</span></div>`:'';
        return fin+`<div class="h2hbar"><span>All-time series record, wins and losses only</span><b>${A} ${hh.a} – ${hh.b}${hh.t?' – '+hh.t:''} ${B}</b><span class="hb"><i style="width:${hh.a/tot*100}%;background:${ca}"></i><i style="width:${hh.t/tot*100}%;background:#999"></i><i style="width:${hh.b/tot*100}%;background:${cb}"></i></span></div>`})()}
      <div class="vs" style="margin:10px 0 4px">""")
bj=once(bj,"""<span class="gmeta">${ra[0]}–${ra[1]}${ra[2]?'–'+ra[2]:''} · away</span>""","""<span class="gmeta">${tlogo(A,34)}<br>${ra[0]}–${ra[1]}${ra[2]?'–'+ra[2]:''} · away</span>""")
bj=once(bj,"""<span class="gmeta">${rb[0]}–${rb[1]}${rb[2]?'–'+rb[2]:''} · home</span>""","""<span class="gmeta">${tlogo(B,34)}<br>${rb[0]}–${rb[1]}${rb[2]?'–'+rb[2]:''} · home</span>""")
# clickable trine bubbles
bj=once(bj,"""    const chip=n=>`<span class="nchip ${n.rel.k}" title="${esc(n.label+': '+(n.note?n.note+'; ':'')+'reads as '+n.r+' ('+n.rel.why.join(', ')+')')}">${esc(n.label)} <b>${n.v>9?n.v+'→':''}${n.r}</b></span>`;""","""    window.__NC=[];
    const chip=n=>{const i=window.__NC.push({n,g,R})-1;return `<button type="button" class="nchip ${n.rel.k}" data-nc="${i}" aria-expanded="false" title="Click for the source">${esc(n.label)} <b>${n.v>9?n.v+'→':''}${n.r}</b></button>`};""")
bj=once(bj,"""      ${chart}
      <div class="cmprow sc schead">""","""      ${chart}
      <div class="ncsrc" id="ncsrc" hidden></div>
      <div class="cmprow sc schead">""")
src_js="""
  const NCORIG=l=>/jersey/.test(l)?'the nflverse roster file (jersey number)':/QB/.test(l)?'the starting quarterback on the nflverse depth chart; birth date and legal name from the nflverse roster file':/coach/.test(l)?'the head coach list compiled for this site from public coaching records (birth dates)':/team (life path|personal day|Moolank|Bhagyank)/.test(l)?'the franchise founding date (public team histories), worked through the same method as a birth date':/team name/.test(l)?'the team name spelled out, using the letter table shown above':'the data shown above';
  $('btdetail').addEventListener('click',e=>{const b=e.target.closest('.nchip');if(!b)return;const o=window.__NC[+b.dataset.nc];if(!o)return;const box=$('ncsrc');const open=b.getAttribute('aria-expanded')==='true';
    document.querySelectorAll('#btdetail .nchip').forEach(x=>x.setAttribute('aria-expanded','false'));
    if(open){box.hidden=true;return}
    b.setAttribute('aria-expanded','true');const n=o.n,side=b.closest('.v.l')?o.g.away:o.g.home;
    box.innerHTML=`<b>${esc(n.label)} · ${esc(NAMES[side]||side)}</b><span>Value <b>${n.v}</b>${n.v>9?` (master/long number, reduced to <b>${n.r}</b> by adding its digits)`:''}. ${esc(n.note||'')}</span><span>Compared with the date number <b>${o.R}</b> (${NPLN[o.R]}): <b>${n.rel.k==='fav'?'friendly':n.rel.k==='enemy'?'enemy':n.rel.k==='mixed'?'mixed':n.rel.k==='same'?'same number':'neutral'}</b> — ${esc(n.rel.why.join(', ')||'no trine or planetary link')}.</span><span class="st">Data origin: ${NCORIG(n.label)}. The full working for each number is in the comparison rows above (use their source links).</span>`;
    box.hidden=false;try{box.scrollIntoView({block:'nearest',behavior:'smooth'})}catch(er){}});
"""
bj=once(bj,"  let trTab='west';",src_js+"\n  let trTab='west';")
# part-one wording
bj=once(bj,"  $('btmethodnote').textContent='Every number on this page is computed from public birth dates, names and dates by these rules alone. Nothing is weighted, fitted or adjusted against results, which is what keeps this half of the site separate from the testing in part one.';","  $('btmethodnote').textContent='Every number on this page is computed from public birth dates, names and dates by these rules alone. Nothing is weighted, fitted or adjusted against results.';")
bj=bj.replace(" Part one tested the zodiac against past results as well and found no edge."," The zodiac was tested against past results as well and showed no edge.")
bj=bj.replace('Part one','Testing')
exec(open('bj_extra.py').read())
body=nav+'\n'+bet+'\n\n'+tabs+'\n</div>\n'
# home footer + shell + theme
shell='''
/* ===================== site shell ===================== */
(function(){
  const NAMES_S=['home','betting','picks','fantasy','stats','standings','ranks','scores','draft','history','myteam','sbx','games'];
  const screens={};NAMES_S.forEach(n=>screens[n]=$(n));
  function go(name,push){
    Object.entries(screens).forEach(([k,el])=>{el.hidden=(k!==name)});
    document.querySelectorAll('.navbtn[data-nav]').forEach(b=>b.setAttribute('aria-current',String(b.dataset.nav===name)));
    try{window.scrollTo(0,0)}catch(e){}
    try{if(push&&location.hash!=='#'+name)history.replaceState(null,'','#'+name)}catch(e){}
    try{localStorage.setItem('bbn.screen',name)}catch(e){}
    if(name==='picks'&&window.__pkDraw)window.__pkDraw();
  }
  document.querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.nav,true)));
  let start='home';let h=(location.hash||'').replace('#','');if(h==='sandbox')h='picks';
  if(NAMES_S.includes(h))start=h;else{try{const s=localStorage.getItem('bbn.screen');if(NAMES_S.includes(s))start=s}catch(e){}}
  go(start,false);
  $('homefoot').textContent=`Schedule, scores and player data from nflverse, through ${SEAPLAYED.length} completed games of the 2026 season. Numerology and astrology are traditions people use to read games, not tested predictors, and nothing here is betting advice.`;
})();

/* Football theme only */
document.documentElement.setAttribute('data-theme','football');
'''
three='<script type="text/javascript">\n'+open('three.min.js').read().replace('__THREE__','__THREEJS__')+'\n</script>\n'
script=three+'<script>\n'+'\n'.join(glob)+'\n'+tj+'\n/* ===================== Betting by Numbers ===================== */\n'+bj+'\n'+shell+'</script>\n'
html=head+body+script
open('template3.html','w').write(html)
for k in ['Part one','Part two','part one','part two','Ledger','ledger']:
    if k in html: print('LEFTOVER',k,[m.start() for m in re.finditer(k,html)][:5])
print(len(html))
